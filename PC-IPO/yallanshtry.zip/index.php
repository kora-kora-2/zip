<!doctype html>
<!--PASTI NAIK-->

<html class="no-js">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="apple-itunes-app" content="app-id=1576832504">
    <link rel="icon" type="image/x-icon" href="https://1v5pkxe0s3.ucarecd.net/3ad00fb4-6357-4eb3-84d4-bc08f561ab76/icon.jpg">
    <title>IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar</title>
    <meta name="description" content="IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!">
    <meta name="keywords" content="IPOTOTO, togel online, situs togel, bandar togel, bandar togel online" />
    <link rel="canonical" href="https://www.yallanshtry.com/blog/">
    <link rel="amphtml" href="https://stres.b-cdn.net/bandar-togel.html"/>
    <meta property="og:type" content="BANDAR TOGEL">
    <meta property="og:title" content="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar">
    <meta property="og:image" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta property="og:image:secure_url" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta property="og:image" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta property="og:image:secure_url" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta property="og:image" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta property="og:image:secure_url" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta property="og:description" content="IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!">
    <meta property="og:price:amount" content="10,000-,">
    <meta property="og:price:currency" content="IDR">
    <meta property="og:url" content="https://www.yallanshtry.com/blog/">
    <meta property="og:site_name" content="IPOTOTO">
    <meta name="twitter:site" content="@IPOTOTO">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar">
    <meta name="twitter:description" content="IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!">
    <meta name="twitter:image" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">
    <meta name="twitter:image:width" content="600">
    <meta name="twitter:image:height" content="600">
    <link rel="shortcut icon" href="https://1v5pkxe0s3.ucarecd.net/3ad00fb4-6357-4eb3-84d4-bc08f561ab76/icon.jpg" type="image/png">
    <meta name="theme-color" content="#ffffff">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&family=Poppins&display=swap" rel="stylesheet">
    <link href="//outerbloom.com/cdn/shop/t/138/assets/custom-styles.css?v=94643080714485117621752652418" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="//outerbloom.com/cdn/shop/t/138/assets/wishlist-styles.css?v=166819525406734116961754385201"><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js" defer></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"
      integrity="sha512-57oZ/vW8ANMjR/KQ6Be9v/+/h6bq9/l3f0Oc7vn6qMqyhvPd1cvKBRWWpzu0QoneImqr2SkmO4MSqU+RpHom3Q=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
      defer
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" async="async"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js" defer></script><!-- Facebook Pixel Code -->
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '165971065669324');
      fbq('track', 'PageView');
    </script>
    <noscript
      ><img
        height="1"
        width="1"
        style="display:none"
        src="https://www.facebook.com/tr?id=165971065669324&ev=PageView&noscript=1"
    ></noscript>
    <!-- End Facebook Pixel Code -->

    <!-- Google G4 Script - Disabled by developer (William) to prioritize Mobile App tracking -->
    <!--
     Global site tag (gtag.js) - Google Analytics -->
          <script async src="https://www.googletagmanager.com/gtag/js?id=G-X26HYP4083"></script>
          <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
  
            gtag('config', 'G-X26HYP4083');
          </script>
      <!-- Global site tag (gtag.js) - Google Analytics -->
    
    <div class="button-login-daftar">
                    <a class="login" href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noreferrer" style="color: white;">
                        LOGIN
                    </a>
                    <a class="register" href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noreferrer" style="color: white;">
                        DAFTAR
                    </a>
                </div>
  
    <script src="//cdnjs.cloudflare.com/ajax/libs/vissense/0.9.0/vissense.js" defer></script>
  
    <!-- Bing UET -->
    <script>
      (function(w,d,t,r,u)
      {
          var f,n,i;
          w[u]=w[u]||[],f=function()
          {
              var o={ti:"343051754", tm:"shpfy_ui", enableAutoSpaTracking: true};
              o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")
          },
          n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function()
          {
              var s=this.readyState;
              s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)
          },
          i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)
      })
      (window,document,"script","//bat.bing.com/bat.js","uetq");
    </script>
    <script>
      window.uetq = window.uetq || [];
      window.uetq.push('event', '', {"revenue_value":0,"currency":"IDR"});
    </script>
    <!-- End Bing UET -->
  
    <!-- Microsoft Clarity -->
    <script type="text/javascript">
      (function(c,l,a,r,i,t,y){
          c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
          t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
          y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
      })(window, document, "clarity", "script", "h7rbxqry9k");
    </script>
    <!-- End Microsoft Clarity -->


<link href="//outerbloom.com/cdn/shop/t/138/assets/combine.min.css?v=111340648424012527321754385205" rel="stylesheet" type="text/css" media="all" />

<link href="//outerbloom.com/cdn/shop/t/138/assets/font-awesome.css?v=132324219581463622051752652421" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.min.css">

<script src="//code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
<script src="//outerbloom.com/cdn/shop/t/138/assets/combine.js?v=140218079523075729301752652421" type="text/javascript"></script>
<script src="//code.jquery.com/ui/1.13.0/jquery-ui.min.js"></script>
    <script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script>
<meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/15896833/digital_wallets/dialog">
<link rel="alternate" type="application/json+oembed" href="https://www.yallanshtry.com/blog/.oembed">
<script async="async" src="/checkouts/internal/preloads.js?locale=en-ID"></script>
<script id="shopify-features" type="application/json">{"accessToken":"d2e176e59f6658d5056234d6249b3ab4","betas":["rich-media-storefront-analytics"],"domain":"outerbloom.com","predictiveSearch":true,"shopId":15896833,"locale":"en"}</script>
<script>var Shopify = Shopify || {};
Shopify.shop = "outerbloom1.myshopify.com";
Shopify.locale = "en";
Shopify.currency = {"active":"IDR","rate":"1.0"};
Shopify.country = "ID";
Shopify.theme = {"name":"web-outerbloom-shopify\/main","id":153139282135,"schema_name":null,"schema_version":null,"theme_store_id":null,"role":"main"};
Shopify.theme.handle = "null";
Shopify.theme.style = {"id":null,"handle":null};
Shopify.cdnHost = "outerbloom.com/cdn";
Shopify.routes = Shopify.routes || {};
Shopify.routes.root = "/";</script>
<script type="module">!function(o){(o.Shopify=o.Shopify||{}).modules=!0}(window);</script>
<script>!function(o){function n(){var o=[];function n(){o.push(Array.prototype.slice.apply(arguments))}return n.q=o,n}var t=o.Shopify=o.Shopify||{};t.loadFeatures=n(),t.autoloadFeatures=n()}(window);</script>
<script id="shop-js-analytics" type="application/json">{"pageType":"product"}</script>
<script defer="defer" async="async" src="//outerbloom.com/cdn/shopifycloud/shop-js/client.js" onload="window.Shopify.SignInWithShop?.initShopCartSync?.({&quot;fedCMEnabled&quot;:true,&quot;windoidEnabled&quot;:true});
"></script>
<script>(function() {
  var isLoaded = false;
  function asyncLoad() {
    if (isLoaded) return;
    isLoaded = true;
    var urls = ["https:\/\/e9e1-180-254-64-204.ngrok.io\/public\/scripts\/shopifyPageScript.js?shop=outerbloom1.myshopify.com","https:\/\/ajax.googleapis.com\/ajax\/libs\/jquery\/3.5.1\/jquery.min.js?shop=outerbloom1.myshopify.com","https:\/\/14e1-180-254-64-204.ngrok.io\/public\/scripts\/shopifyPageScript.js?shop=outerbloom1.myshopify.com","https:\/\/6403-180-254-64-204.ngrok.io\/public\/scripts\/shopify-page-script.js?shop=outerbloom1.myshopify.com","https:\/\/googlesignintest.loca.lt\/public\/scripts\/shopify-page-script.js?shop=outerbloom1.myshopify.com","https:\/\/api-na1.hubapi.com\/scriptloader\/v1\/6800477.js?shop=outerbloom1.myshopify.com"];
    for (var i = 0; i < urls.length; i++) {
      var s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.src = urls[i];
      var x = document.getElementsByTagName('script')[0];
      x.parentNode.insertBefore(s, x);
    }
  };
  if(window.attachEvent) {
    window.attachEvent('onload', asyncLoad);
  } else {
    window.addEventListener('load', asyncLoad, false);
  }
})();</script>
<script id="__st">var __st={"a":15896833,"offset":25200,"reqid":"78149bf2-9ab6-43c0-b2ce-821afbfe5bd0-1759566675","pageurl":"outerbloom.com\/products\/blossom-shine","u":"381e6a1da038","p":"product","rtyp":"product","rid":8144957800663};</script>
<script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
<script id="captcha-bootstrap">!function(){'use strict';const t='contact',e='account',n='new_comment',o=[[t,t],['blogs',n],['comments',n],[t,'customer']],c=[[e,'customer_login'],[e,'guest_login'],[e,'recover_customer_password'],[e,'create_customer']],r=t=>t.map((([t,e])=>`form[action*='/${t}']:not([data-nocaptcha='true']) input[name='form_type'][value='${e}']`)).join(','),a=t=>()=>t?[...document.querySelectorAll(t)].map((t=>t.form)):[];function s(){const t=[...o],e=r(t);return a(e)}const i='password',u='form_key',d=['recaptcha-v3-token','g-recaptcha-response','h-captcha-response',i],f=()=>{try{return window.sessionStorage}catch{return}},m='__shopify_v',_=t=>t.elements[u];function p(t,e,n=!1){try{const o=window.sessionStorage,c=JSON.parse(o.getItem(e)),{data:r}=function(t){const{data:e,action:n}=t;return t[m]||n?{data:e,action:n}:{data:t,action:n}}(c);for(const[e,n]of Object.entries(r))t.elements[e]&&(t.elements[e].value=n);n&&o.removeItem(e)}catch(o){console.error('form repopulation failed',{error:o})}}const l='form_type',E='cptcha';function T(t){t.dataset[E]=!0}const w=window,h=w.document,L='Shopify',v='ce_forms',y='captcha';let A=!1;((t,e)=>{const n=(g='f06e6c50-85a8-45c8-87d0-21a2b65856fe',I='https://cdn.shopify.com/shopifycloud/storefront-forms-hcaptcha/ce_storefront_forms_captcha_hcaptcha.v1.5.2.iife.js',D={infoText:'Protected by hCaptcha',privacyText:'Privacy',termsText:'Terms'},(t,e,n)=>{const o=w[L][v],c=o.bindForm;if(c)return c(t,g,e,D).then(n);var r;o.q.push([[t,g,e,D],n]),r=I,A||(h.body.append(Object.assign(h.createElement('script'),{id:'captcha-provider',async:!0,src:r})),A=!0)});var g,I,D;w[L]=w[L]||{},w[L][v]=w[L][v]||{},w[L][v].q=[],w[L][y]=w[L][y]||{},w[L][y].protect=function(t,e){n(t,void 0,e),T(t)},Object.freeze(w[L][y]),function(t,e,n,w,h,L){const[v,y,A,g]=function(t,e,n){const i=e?o:[],u=t?c:[],d=[...i,...u],f=r(d),m=r(i),_=r(d.filter((([t,e])=>n.includes(e))));return[a(f),a(m),a(_),s()]}(w,h,L),I=t=>{const e=t.target;return e instanceof HTMLFormElement?e:e&&e.form},D=t=>v().includes(t);t.addEventListener('submit',(t=>{const e=I(t);if(!e)return;const n=D(e)&&!e.dataset.hcaptchaBound&&!e.dataset.recaptchaBound,o=_(e),c=g().includes(e)&&(!o||!o.value);(n||c)&&t.preventDefault(),c&&!n&&(function(t){try{if(!f())return;!function(t){const e=f();if(!e)return;const n=_(t);if(!n)return;const o=n.value;o&&e.removeItem(o)}(t);const e=Array.from(Array(32),(()=>Math.random().toString(36)[2])).join('');!function(t,e){_(t)||t.append(Object.assign(document.createElement('input'),{type:'hidden',name:u})),t.elements[u].value=e}(t,e),function(t,e){const n=f();if(!n)return;const o=[...t.querySelectorAll(`input[type='${i}']`)].map((({name:t})=>t)),c=[...d,...o],r={};for(const[a,s]of new FormData(t).entries())c.includes(a)||(r[a]=s);n.setItem(e,JSON.stringify({[m]:1,action:t.action,data:r}))}(t,e)}catch(e){console.error('failed to persist form',e)}}(e),e.submit())}));const S=(t,e)=>{t&&!t.dataset[E]&&(n(t,e.some((e=>e===t))),T(t))};for(const o of['focusin','change'])t.addEventListener(o,(t=>{const e=I(t);D(e)&&S(e,y())}));const B=e.get('form_key'),M=e.get(l),P=B&&M;t.addEventListener('DOMContentLoaded',(()=>{const t=y();if(P)for(const e of t)e.elements[l].value===M&&p(e,B);[...new Set([...A(),...v().filter((t=>'true'===t.dataset.shopifyCaptcha))])].forEach((e=>S(e,t)))}))}(h,new URLSearchParams(w.location.search),n,t,e,['guest_login'])})(!1,!0)}();</script>
<script integrity="sha256-52AcMU7V7pcBOXWImdc/TAGTFKeNjmkeM1Pvks/DTgc=" data-source-attribution="shopify.loadfeatures" defer="defer" src="//outerbloom.com/cdn/shopifycloud/storefront/assets/storefront/load_feature-81c60534.js" crossorigin="anonymous"></script>
<script data-source-attribution="shopify.dynamic_checkout.dynamic.init">var Shopify=Shopify||{};Shopify.PaymentButton=Shopify.PaymentButton||{isStorefrontPortableWallets:!0,init:function(){window.Shopify.PaymentButton.init=function(){};var t=document.createElement("script");t.src="https://outerbloom.com/cdn/shopifycloud/portable-wallets/latest/portable-wallets.en.js",t.type="module",document.head.appendChild(t)}};
</script>
<script data-source-attribution="shopify.dynamic_checkout.buyer_consent">
  function portableWalletsHideBuyerConsent(e){var t=document.getElementById("shopify-buyer-consent"),n=document.getElementById("shopify-subscription-policy-button");t&&n&&(t.classList.add("hidden"),t.setAttribute("aria-hidden","true"),n.removeEventListener("click",e))}function portableWalletsShowBuyerConsent(e){var t=document.getElementById("shopify-buyer-consent"),n=document.getElementById("shopify-subscription-policy-button");t&&n&&(t.classList.remove("hidden"),t.removeAttribute("aria-hidden"),n.addEventListener("click",e))}window.Shopify?.PaymentButton&&(window.Shopify.PaymentButton.hideBuyerConsent=portableWalletsHideBuyerConsent,window.Shopify.PaymentButton.showBuyerConsent=portableWalletsShowBuyerConsent);
</script>
<script data-source-attribution="shopify.dynamic_checkout.cart.bootstrap">document.addEventListener("DOMContentLoaded",(function(){function t(){return document.querySelector("shopify-accelerated-checkout-cart, shopify-accelerated-checkout")}if(t())Shopify.PaymentButton.init();else{new MutationObserver((function(e,n){t()&&(Shopify.PaymentButton.init(),n.disconnect())})).observe(document.body,{childList:!0,subtree:!0})}}));
</script>

<script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>
    <!-- /snippets/oldIE-js.liquid -->


<!--[if lt IE 9]>
<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.min.js" type="text/javascript"></script>
<script src="//outerbloom.com/cdn/shop/t/138/assets/respond.min.js?v=52248677837542619231752652418" type="text/javascript"></script>
<link href="//outerbloom.com/cdn/shop/t/138/assets/respond-proxy.html" id="respond-proxy" rel="respond-proxy" />
<link href="//outerbloom.com/search?q=142e9156869335090161dced0ac98b64" id="respond-redirect" rel="respond-redirect" />
<script src="//outerbloom.com/search?q=142e9156869335090161dced0ac98b64" type="text/javascript"></script>
<![endif]-->




<link href="https://cdn.shopify.com/extensions/5c1bf460-65bd-4bca-82d0-995a5814b48d/bitlogin-social-login-135/assets/app.css" rel="stylesheet" type="text/css" media="all">
<link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
<script>(function(){if ("sendBeacon" in navigator && "performance" in window) {try {var session_token_from_headers = performance.getEntriesByType('navigation')[0].serverTiming.find(x => x.name == '_s').description;} catch {var session_token_from_headers = undefined;}var session_cookie_matches = document.cookie.match(/_shopify_s=([^;]*)/);var session_token_from_cookie = session_cookie_matches && session_cookie_matches.length === 2 ? session_cookie_matches[1] : "";var session_token = session_token_from_headers || session_token_from_cookie || "";function handle_abandonment_event(e) {var entries = performance.getEntries().filter(function(entry) {return /monorail-edge.shopifysvc.com/.test(entry.name);});if (!window.abandonment_tracked && entries.length === 0) {window.abandonment_tracked = true;var currentMs = Date.now();var navigation_start = performance.timing.navigationStart;var payload = {shop_id: 15896833,url: window.location.href,navigation_start,duration: currentMs - navigation_start,session_token,page_type: "product"};window.navigator.sendBeacon("https://monorail-edge.shopifysvc.com/v1/produce", JSON.stringify({schema_id: "online_store_buyer_site_abandonment/1.1",payload: payload,metadata: {event_created_at_ms: currentMs,event_sent_at_ms: currentMs}}));}}window.addEventListener('pagehide', handle_abandonment_event);}}());</script>
<script id="web-pixels-manager-setup">(function e(e,d,r,n,o){if(void 0===o&&(o={}),!Boolean(null===(a=null===(i=window.Shopify)||void 0===i?void 0:i.analytics)||void 0===a?void 0:a.replayQueue)){var i,a;window.Shopify=window.Shopify||{};var t=window.Shopify;t.analytics=t.analytics||{};var s=t.analytics;s.replayQueue=[],s.publish=function(e,d,r){return s.replayQueue.push([e,d,r]),!0};try{self.performance.mark("wpm:start")}catch(e){}var l=function(){var e={modern:/Edge?\/(1{2}[4-9]|1[2-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Firefox\/(1{2}[4-9]|1[2-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Chrom(ium|e)\/(9{2}|\d{3,})\.\d+(\.\d+|)|(Maci|X1{2}).+ Version\/(15\.\d+|(1[6-9]|[2-9]\d|\d{3,})\.\d+)([,.]\d+|)( \(\w+\)|)( Mobile\/\w+|) Safari\/|Chrome.+OPR\/(9{2}|\d{3,})\.\d+\.\d+|(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS|CPU iPad OS)[ +]+(15[._]\d+|(1[6-9]|[2-9]\d|\d{3,})[._]\d+)([._]\d+|)|Android:?[ /-](13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})(\.\d+|)(\.\d+|)|Android.+Firefox\/(13[5-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+Chrom(ium|e)\/(13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|SamsungBrowser\/([2-9]\d|\d{3,})\.\d+/,legacy:/Edge?\/(1[6-9]|[2-9]\d|\d{3,})\.\d+(\.\d+|)|Firefox\/(5[4-9]|[6-9]\d|\d{3,})\.\d+(\.\d+|)|Chrom(ium|e)\/(5[1-9]|[6-9]\d|\d{3,})\.\d+(\.\d+|)([\d.]+$|.*Safari\/(?![\d.]+ Edge\/[\d.]+$))|(Maci|X1{2}).+ Version\/(10\.\d+|(1[1-9]|[2-9]\d|\d{3,})\.\d+)([,.]\d+|)( \(\w+\)|)( Mobile\/\w+|) Safari\/|Chrome.+OPR\/(3[89]|[4-9]\d|\d{3,})\.\d+\.\d+|(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS|CPU iPad OS)[ +]+(10[._]\d+|(1[1-9]|[2-9]\d|\d{3,})[._]\d+)([._]\d+|)|Android:?[ /-](13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})(\.\d+|)(\.\d+|)|Mobile Safari.+OPR\/([89]\d|\d{3,})\.\d+\.\d+|Android.+Firefox\/(13[5-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+Chrom(ium|e)\/(13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+(UC? ?Browser|UCWEB|U3)[ /]?(15\.([5-9]|\d{2,})|(1[6-9]|[2-9]\d|\d{3,})\.\d+)\.\d+|SamsungBrowser\/(5\.\d+|([6-9]|\d{2,})\.\d+)|Android.+MQ{2}Browser\/(14(\.(9|\d{2,})|)|(1[5-9]|[2-9]\d|\d{3,})(\.\d+|))(\.\d+|)|K[Aa][Ii]OS\/(3\.\d+|([4-9]|\d{2,})\.\d+)(\.\d+|)/},d=e.modern,r=e.legacy,n=navigator.userAgent;return n.match(d)?"modern":n.match(r)?"legacy":"unknown"}(),u="modern"===l?"modern":"legacy",c=(null!=n?n:{modern:"",legacy:""})[u],f=function(e){return[e.baseUrl,"/wpm","/b",e.hashVersion,"modern"===e.buildTarget?"m":"l",".js"].join("")}({baseUrl:d,hashVersion:r,buildTarget:u}),m=function(e){var d=e.version,r=e.bundleTarget,n=e.surface,o=e.pageUrl,i=e.monorailEndpoint;return{emit:function(e){var a=e.status,t=e.errorMsg,s=(new Date).getTime(),l=JSON.stringify({metadata:{event_sent_at_ms:s},events:[{schema_id:"web_pixels_manager_load/3.1",payload:{version:d,bundle_target:r,page_url:o,status:a,surface:n,error_msg:t},metadata:{event_created_at_ms:s}}]});if(!i)return console&&console.warn&&console.warn("[Web Pixels Manager] No Monorail endpoint provided, skipping logging."),!1;try{return self.navigator.sendBeacon.bind(self.navigator)(i,l)}catch(e){}var u=new XMLHttpRequest;try{return u.open("POST",i,!0),u.setRequestHeader("Content-Type","text/plain"),u.send(l),!0}catch(e){return console&&console.warn&&console.warn("[Web Pixels Manager] Got an unhandled error while logging to Monorail."),!1}}}}({version:r,bundleTarget:l,surface:e.surface,pageUrl:self.location.href,monorailEndpoint:e.monorailEndpoint});try{o.browserTarget=l,function(e){var d=e.src,r=e.async,n=void 0===r||r,o=e.onload,i=e.onerror,a=e.sri,t=e.scriptDataAttributes,s=void 0===t?{}:t,l=document.createElement("script"),u=document.querySelector("head"),c=document.querySelector("body");if(l.async=n,l.src=d,a&&(l.integrity=a,l.crossOrigin="anonymous"),s)for(var f in s)if(Object.prototype.hasOwnProperty.call(s,f))try{l.dataset[f]=s[f]}catch(e){}if(o&&l.addEventListener("load",o),i&&l.addEventListener("error",i),u)u.appendChild(l);else{if(!c)throw new Error("Did not find a head or body element to append the script");c.appendChild(l)}}({src:f,async:!0,onload:function(){if(!function(){var e,d;return Boolean(null===(d=null===(e=window.Shopify)||void 0===e?void 0:e.analytics)||void 0===d?void 0:d.initialized)}()){var d=window.webPixelsManager.init(e)||void 0;if(d){var r=window.Shopify.analytics;r.replayQueue.forEach((function(e){var r=e[0],n=e[1],o=e[2];d.publishCustomEvent(r,n,o)})),r.replayQueue=[],r.publish=d.publishCustomEvent,r.visitor=d.visitor,r.initialized=!0}}},onerror:function(){return m.emit({status:"failed",errorMsg:"".concat(f," has failed to load")})},sri:function(e){var d=/^sha384-[A-Za-z0-9+/=]+$/;return"string"==typeof e&&d.test(e)}(c)?c:"",scriptDataAttributes:o}),m.emit({status:"loading"})}catch(e){m.emit({status:"failed",errorMsg:(null==e?void 0:e.message)||"Unknown error"})}}})({shopId: 15896833,storefrontBaseUrl: "https://outerbloom.com",extensionsBaseUrl: "https://extensions.shopifycdn.com/cdn/shopifycloud/web-pixels-manager",monorailEndpoint: "https://monorail-edge.shopifysvc.com/unstable/produce_batch",surface: "storefront-renderer",enabledBetaFlags: [],webPixelsConfigList: [{"id":"870383831","configuration":"{\"accountID\":\"outerbloom1\"}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"162380e6ffd3e5a2854f1aabf54537bb","type":"APP","apiClientId":32196493313,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"]},{"id":"824574167","configuration":"{\"shop\":\"outerbloom1.myshopify.com\", \"backend\": \"api.bitbybit.studio\"}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"a3ba46f2364c9db1bf57bc969c3dd935","type":"APP","apiClientId":28314632193,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"]},{"id":"521994455","configuration":"{\"config\":\"{\\\"pixel_id\\\":\\\"G-X26HYP4083\\\",\\\"target_country\\\":\\\"ID\\\",\\\"gtag_events\\\":[{\\\"type\\\":\\\"search\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/YjjSCKiog9gZEMHe74Yp\\\"]},{\\\"type\\\":\\\"begin_checkout\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/RHfSCK6og9gZEMHe74Yp\\\"]},{\\\"type\\\":\\\"view_item\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/dMv0CKWog9gZEMHe74Yp\\\",\\\"MC-HY9J2ZJTNZ\\\"]},{\\\"type\\\":\\\"purchase\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/Y2DbCJ-og9gZEMHe74Yp\\\",\\\"MC-HY9J2ZJTNZ\\\"]},{\\\"type\\\":\\\"page_view\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/xwQ2CKKog9gZEMHe74Yp\\\",\\\"MC-HY9J2ZJTNZ\\\"]},{\\\"type\\\":\\\"add_payment_info\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/i9yRCLGog9gZEMHe74Yp\\\"]},{\\\"type\\\":\\\"add_to_cart\\\",\\\"action_label\\\":[\\\"G-X26HYP4083\\\",\\\"AW-11020267329\\\/T9poCKuog9gZEMHe74Yp\\\"]}],\\\"enable_monitoring_mode\\\":false}\"}","eventPayloadVersion":"v1","runtimeContext":"OPEN","scriptVersion":"b2a88bafab3e21179ed38636efcd8a93","type":"APP","apiClientId":1780363,"privacyPurposes":[]},{"id":"236060887","configuration":"{\"pixel_id\":\"165971065669324\",\"pixel_type\":\"facebook_pixel\",\"metaapp_system_user_token\":\"-\"}","eventPayloadVersion":"v1","runtimeContext":"OPEN","scriptVersion":"6d8c3ef0426b37b2a9b717daeb719f58","type":"APP","apiClientId":2329312,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"]},{"id":"62947543","eventPayloadVersion":"v1","runtimeContext":"LAX","scriptVersion":"1","type":"CUSTOM","privacyPurposes":["MARKETING"],"name":"Meta pixel (migrated)"},{"id":"shopify-app-pixel","configuration":"{}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"0450","apiClientId":"shopify-pixel","type":"APP","privacyPurposes":["ANALYTICS","MARKETING"]},{"id":"shopify-custom-pixel","eventPayloadVersion":"v1","runtimeContext":"LAX","scriptVersion":"0450","apiClientId":"shopify-pixel","type":"CUSTOM","privacyPurposes":["ANALYTICS","MARKETING"]}],isMerchantRequest: false,initData: {"shop":{"name":"Outerbloom","paymentSettings":{"currencyCode":"IDR"},"myshopifyDomain":"outerbloom1.myshopify.com","countryCode":"ID","storefrontUrl":"https:\/\/outerbloom.com"},"customer":null,"cart":null,"checkout":null,"productVariants":[{"price":{"amount":835000.0,"currencyCode":"IDR"},"product":{"title":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","vendor":"Outerbloom Florist","id":"8144957800663","untranslatedTitle":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","url":"\/products\/blossom-shine","type":"IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!"},"id":"44083045826775","image":{"src":"\/\/outerbloom.com\/cdn\/shop\/files\/Blossom-Shine-WM.jpg?v=1695788426"},"sku":"OBVSTF1086","title":"Default Title","untranslatedTitle":"Default Title"}],"purchasingCompany":null},},"https://outerbloom.com/cdn","4f0c5c77w64a73806p128ba08bma5b58f2f",{"modern":"","legacy":""},{"shopId":"15896833","storefrontBaseUrl":"https:\/\/outerbloom.com","extensionBaseUrl":"https:\/\/extensions.shopifycdn.com\/cdn\/shopifycloud\/web-pixels-manager","surface":"storefront-renderer","enabledBetaFlags":"[]","isMerchantRequest":"false","hashVersion":"4f0c5c77w64a73806p128ba08bma5b58f2f","publish":"custom","events":"[[\"page_viewed\",{}],[\"product_viewed\",{\"productVariant\":{\"price\":{\"amount\":835000.0,\"currencyCode\":\"IDR\"},\"product\":{\"title\":\"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar\",\"vendor\":\"Outerbloom Florist\",\"id\":\"8144957800663\",\"untranslatedTitle\":\"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar\",\"url\":\"\/products\/blossom-shine\",\"type\":\"IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!\"},\"id\":\"44083045826775\",\"image\":{\"src\":\"\/\/outerbloom.com\/cdn\/shop\/files\/Blossom-Shine-WM.jpg?v=1695788426\"},\"sku\":\"OBVSTF1086\",\"title\":\"Default Title\",\"untranslatedTitle\":\"Default Title\"}}]]"});</script><script>
  window.ShopifyAnalytics = window.ShopifyAnalytics || {};
  window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
  window.ShopifyAnalytics.meta.currency = 'IDR';
  var meta = {"product":{"id":8144957800663,"gid":"gid:\/\/shopify\/Product\/8144957800663","vendor":"Outerbloom Florist","type":"IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!","variants":[{"id":44083045826775,"price":1000000
  ,"name":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","public_title":null,"sku":"OBVSTF1086"}],"remote":false},"page":{"pageType":"product","resourceType":"product","resourceId":8144957800663}};
  for (var attr in meta) {
    window.ShopifyAnalytics.meta[attr] = meta[attr];
  }
</script>
<script class="analytics">
  (function () {
    var customDocumentWrite = function(content) {
      var jquery = null;

      if (window.jQuery) {
        jquery = window.jQuery;
      } else if (window.Checkout && window.Checkout.$) {
        jquery = window.Checkout.$;
      }

      if (jquery) {
        jquery('body').append(content);
      }
    };

    var hasLoggedConversion = function(token) {
      if (token) {
        return document.cookie.indexOf('loggedConversion=' + token) !== -1;
      }
      return false;
    }

    var setCookieIfConversion = function(token) {
      if (token) {
        var twoMonthsFromNow = new Date(Date.now());
        twoMonthsFromNow.setMonth(twoMonthsFromNow.getMonth() + 2);

        document.cookie = 'loggedConversion=' + token + '; expires=' + twoMonthsFromNow;
      }
    }

    var trekkie = window.ShopifyAnalytics.lib = window.trekkie = window.trekkie || [];
    if (trekkie.integrations) {
      return;
    }
    trekkie.methods = [
      'identify',
      'page',
      'ready',
      'track',
      'trackForm',
      'trackLink'
    ];
    trekkie.factory = function(method) {
      return function() {
        var args = Array.prototype.slice.call(arguments);
        args.unshift(method);
        trekkie.push(args);
        return trekkie;
      };
    };
    for (var i = 0; i < trekkie.methods.length; i++) {
      var key = trekkie.methods[i];
      trekkie[key] = trekkie.factory(key);
    }
    trekkie.load = function(config) {
      trekkie.config = config || {};
      trekkie.config.initialDocumentCookie = document.cookie;
      var first = document.getElementsByTagName('script')[0];
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.onerror = function(e) {
        var scriptFallback = document.createElement('script');
        scriptFallback.type = 'text/javascript';
        scriptFallback.onerror = function(error) {
                var Monorail = {
      produce: function produce(monorailDomain, schemaId, payload) {
        var currentMs = new Date().getTime();
        var event = {
          schema_id: schemaId,
          payload: payload,
          metadata: {
            event_created_at_ms: currentMs,
            event_sent_at_ms: currentMs
          }
        };
        return Monorail.sendRequest("https://" + monorailDomain + "/v1/produce", JSON.stringify(event));
      },
      sendRequest: function sendRequest(endpointUrl, payload) {
        // Try the sendBeacon API
        if (window && window.navigator && typeof window.navigator.sendBeacon === 'function' && typeof window.Blob === 'function' && !Monorail.isIos12()) {
          var blobData = new window.Blob([payload], {
            type: 'text/plain'
          });

          if (window.navigator.sendBeacon(endpointUrl, blobData)) {
            return true;
          } // sendBeacon was not successful

        } // XHR beacon

        var xhr = new XMLHttpRequest();

        try {
          xhr.open('POST', endpointUrl);
          xhr.setRequestHeader('Content-Type', 'text/plain');
          xhr.send(payload);
        } catch (e) {
          console.log(e);
        }

        return false;
      },
      isIos12: function isIos12() {
        return window.navigator.userAgent.lastIndexOf('iPhone; CPU iPhone OS 12_') !== -1 || window.navigator.userAgent.lastIndexOf('iPad; CPU OS 12_') !== -1;
      }
    };
    Monorail.produce('monorail-edge.shopifysvc.com',
      'trekkie_storefront_load_errors/1.1',
      {shop_id: 15896833,
      theme_id: 153139282135,
      app_name: "storefront",
      context_url: window.location.href,
      source_url: "//outerbloom.com/cdn/s/trekkie.storefront.10b9e06bd1980b2ce8435c2fe6c8f07eb6305ae4.min.js"});

        };
        scriptFallback.async = true;
        scriptFallback.src = '//outerbloom.com/cdn/s/trekkie.storefront.10b9e06bd1980b2ce8435c2fe6c8f07eb6305ae4.min.js';
        first.parentNode.insertBefore(scriptFallback, first);
      };
      script.async = true;
      script.src = '//outerbloom.com/cdn/s/trekkie.storefront.10b9e06bd1980b2ce8435c2fe6c8f07eb6305ae4.min.js';
      first.parentNode.insertBefore(script, first);
    };
    trekkie.load(
      {"Trekkie":{"appName":"storefront","development":false,"defaultAttributes":{"shopId":15896833,"isMerchantRequest":null,"themeId":153139282135,"themeCityHash":"1741993959449676309","contentLanguage":"en","currency":"IDR"},"isServerSideCookieWritingEnabled":true,"monorailRegion":"shop_domain"},"Session Attribution":{},"S2S":{"facebookCapiEnabled":true,"source":"trekkie-storefront-renderer","apiClientId":580111}}
    );

    var loaded = false;
    trekkie.ready(function() {
      if (loaded) return;
      loaded = true;

      window.ShopifyAnalytics.lib = window.trekkie;

      var originalDocumentWrite = document.write;
      document.write = customDocumentWrite;
      try { window.ShopifyAnalytics.merchantGoogleAnalytics.call(this); } catch(error) {};
      document.write = originalDocumentWrite;

      window.ShopifyAnalytics.lib.page(null,{"pageType":"product","resourceType":"product","resourceId":8144957800663,"shopifyEmitted":true});

      var match = window.location.pathname.match(/checkouts\/(.+)\/(thank_you|post_purchase)/)
      var token = match? match[1]: undefined;
      if (!hasLoggedConversion(token)) {
        setCookieIfConversion(token);
        window.ShopifyAnalytics.lib.track("Viewed Product",{"currency":"IDR","variantId":44083045826775,"productId":8144957800663,"productGid":"gid:\/\/shopify\/Product\/8144957800663","name":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","price":"835000.00","sku":"OBVSTF1086","brand":"Outerbloom Florist","variant":null,"category":"IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!","nonInteraction":true,"remote":false},undefined,undefined,{"shopifyEmitted":true});
      window.ShopifyAnalytics.lib.track("monorail:\/\/trekkie_storefront_viewed_product\/1.1",{"currency":"IDR","variantId":44083045826775,"productId":8144957800663,"productGid":"gid:\/\/shopify\/Product\/8144957800663","name":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","price":"835000.00","sku":"OBVSTF1086","brand":"Outerbloom Florist","variant":null,"category":"IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!","nonInteraction":true,"remote":false,"referer":"https:\/\/outerbloom.com\/products\/blossom-shine"});
      }
    });


        var eventsListenerScript = document.createElement('script');
        eventsListenerScript.async = true;
        eventsListenerScript.src = "//outerbloom.com/cdn/shopifycloud/storefront/assets/shop_events_listener-abeef7a0.js";
        document.getElementsByTagName('head')[0].appendChild(eventsListenerScript);

})();</script>
  <script>
  if (!window.ga || (window.ga && typeof window.ga !== 'function')) {
    window.ga = function ga() {
      (window.ga.q = window.ga.q || []).push(arguments);
      if (window.Shopify && window.Shopify.analytics && typeof window.Shopify.analytics.publish === 'function') {
        window.Shopify.analytics.publish("ga_stub_called", {}, {sendTo: "google_osp_migration"});
      }
      console.error("Shopify's Google Analytics stub called with:", Array.from(arguments), "\nSee https://help.shopify.com/manual/promoting-marketing/pixels/pixel-migration#google for more information.");
    };
    if (window.Shopify && window.Shopify.analytics && typeof window.Shopify.analytics.publish === 'function') {
      window.Shopify.analytics.publish("ga_stub_initialized", {}, {sendTo: "google_osp_migration"});
    }
  }
</script>
<script
  defer
  src="https://outerbloom.com/cdn/shopifycloud/perf-kit/shopify-perf-kit-2.0.13.min.js"
  data-application="storefront-renderer"
  data-shop-id="15896833"
  data-render-region="gcp-asia-southeast1"
  data-page-type="product"
  data-theme-instance-id="153139282135"
  data-theme-name=""
  data-theme-version=""
  data-monorail-region="shop_domain"
  data-resource-timing-sampling-rate="10"
  data-shs="true"
  data-shs-beacon="true"
  data-shs-export-with-fetch="true"
  data-shs-logs-sample-rate="1"
></script>
</head><body
    data-template="product"
    id="blossom-shine"
    class="template-product template-product" >

    <div class="header-wrapper">
      
      <div id="shopify-section-NotifBar" class="shopify-section m-0">

<style>
  #notification {z-index: 99;width: 100%;transition: top 0.2s ease-in-out;}
  #notification.promo-up {top: -48px!important;}
  .promo-bg {width: 100%;padding: 6px 0;background-color: #242424;}
  .notification__message p {margin: 0;color: #47af63c4;font-size: 14px!important;}
  .notification__message p a {text-decoration: underline;color: #ffffff;}
  @media (max-width: 991px){
    .notification__message p {font-size: 14px!important;}
  }
</style>
<input id="clearCookie" class="hide" type="button" value="Delete Cookie" />
<div id="notification" class="promo-down promo-bg pl-2 pr-2" data-text="up-to-40-off-embrace-traditions-with-our-special-mooncake-hampers-pre-order-now">
  <div class="page-width notification__inner ">
    
    
    <div class="notification__message text-center">
      <p><a href="https://www.yallanshtry.com/blog/" title="IPOTOTO">IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar</a></p>
    </div>
  </div>
</div>




</div>
      <div id="shopify-section-new-header" class="shopify-section mb-0 mt-0"><link href="//outerbloom.com/cdn/shop/t/138/assets/section-new-header.css?v=159841885358852784021757475904" rel="stylesheet" type="text/css" media="all"/>


<header style="background-image: url(#); background-attachment: fixed;">
  <div class="container">
    <div class="header-container row justify-content-between pl-lg-0 pr-lg-0">
        <a href="https://www.yallanshtry.com/blog/">
        <img src="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" alt="logo-IPOTOTO" style="width: 190px;"></a>
      <link href="https://1v5pkxe0s3.ucarecd.net/3ad00fb4-6357-4eb3-84d4-bc08f561ab76/icon.jpg" rel="shortcut icon" type="image/x-icon" />
        <div id="menu-hamburger" class="d-lg-none">
          <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="16" height="10" viewBox="0 0 16 10" fill="none">
  <path d="M15.5995 0.949976H0.400342C0.320777 0.949976 0.244471 0.918369 0.18821 0.862108C0.131949 0.805847 0.100342 0.729541 0.100342 0.649976C0.100342 0.570411 0.131949 0.494104 0.18821 0.437843C0.244471 0.381582 0.320777 0.349976 0.400342 0.349976H15.5995C15.6791 0.349976 15.7554 0.381582 15.8117 0.437843C15.8679 0.494104 15.8995 0.570411 15.8995 0.649976C15.8995 0.729541 15.8679 0.805847 15.8117 0.862108C15.7554 0.918369 15.6791 0.949976 15.5995 0.949976ZM15.5995 5.29998H0.400342C0.320777 5.29998 0.244471 5.26837 0.18821 5.21211C0.131949 5.15585 0.100342 5.07954 0.100342 4.99998C0.100342 4.92041 0.131949 4.8441 0.18821 4.78784C0.244471 4.73158 0.320777 4.69998 0.400342 4.69998H15.5995C15.6791 4.69998 15.7554 4.73158 15.8117 4.78784C15.8679 4.8441 15.8995 4.92041 15.8995 4.99998C15.8995 5.07954 15.8679 5.15585 15.8117 5.21211C15.7554 5.26837 15.6791 5.29998 15.5995 5.29998ZM15.5995 9.64998H0.400342C0.320777 9.64998 0.244471 9.61837 0.18821 9.56211C0.131949 9.50585 0.100342 9.42954 0.100342 9.34998C0.100342 9.27041 0.131949 9.1941 0.18821 9.13784C0.244471 9.08158 0.320777 9.04998 0.400342 9.04998H15.5995C15.6791 9.04998 15.7554 9.08158 15.8117 9.13784C15.8679 9.1941 15.8995 9.27041 15.8995 9.34998C15.8995 9.42954 15.8679 9.50585 15.8117 9.56211C15.7554 9.61837 15.6791 9.64998 15.5995 9.64998Z" fill="#ffffff"/>
</svg>

        <a href="/"><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" viewBox="0 0 854 78.29">
  <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path d="M36.85.11a36.6,36.6,0,0,1,14.91,3,34.84,34.84,0,0,1,11.71,8.35,38.29,38.29,0,0,1,7.6,12.48,43.13,43.13,0,0,1,2.69,15.36,41.58,41.58,0,0,1-4.65,19.78,35.49,35.49,0,0,1-13,13.86A36.21,36.21,0,0,1,36.85,78,36.65,36.65,0,0,1,17.37,73,34.34,34.34,0,0,1,4.54,59.15,42.43,42.43,0,0,1,0,39.29,42.2,42.2,0,0,1,2.71,24.1a38.64,38.64,0,0,1,7.67-12.51A35.23,35.23,0,0,1,36.85.11Zm0,8.47a27.77,27.77,0,0,0-15,4,27.18,27.18,0,0,0-10,11A34.19,34.19,0,0,0,8.3,39.29a30.63,30.63,0,0,0,2.19,11.53,31.32,31.32,0,0,0,6.08,9.69,29,29,0,0,0,9.08,6.66,25.84,25.84,0,0,0,11.2,2.44,25.2,25.2,0,0,0,11.2-2.55,30.26,30.26,0,0,0,9.19-6.86,32.46,32.46,0,0,0,6.17-9.74,29.2,29.2,0,0,0,2.21-11.17,32.83,32.83,0,0,0-3.79-16A27.77,27.77,0,0,0,51.54,12.45,28.15,28.15,0,0,0,36.85,8.58Z"></path><path d="M97.26,4.76a4.13,4.13,0,0,1,1.19-2.88A3.59,3.59,0,0,1,101.14.61q4.36,0,4.42,4.15L106,42.33a44.26,44.26,0,0,0,2.27,14.5,19.83,19.83,0,0,0,7,9.73q4.78,3.5,12.53,3.49,8.58,0,13.72-3.49A19.72,19.72,0,0,0,148.94,57a38.56,38.56,0,0,0,2.33-13.83L151.16,4.7v0a4,4,0,0,1,1.19-2.93A3.87,3.87,0,0,1,155.25.5a4.06,4.06,0,0,1,3,1.22,3.93,3.93,0,0,1,1.24,2.93v0l.12,38.4q0,16.5-7.83,25.84T128,78.29q-10.18,0-16.88-4.56a27.51,27.51,0,0,1-10-12.67,50.37,50.37,0,0,1-3.43-18.68L97.26,4.81Z"></path><path d="M180.3,4.48a4.2,4.2,0,0,1,1.25-3,4,4,0,0,1,3-1.27H239.9a4.13,4.13,0,0,1,2.93,1.13,3.75,3.75,0,0,1,1.22,2.85,4.31,4.31,0,0,1-1.22,3,4,4,0,0,1-3,1.3H216.27V73.59A3.9,3.9,0,0,1,215,76.52a4.16,4.16,0,0,1-3,1.22,3.81,3.81,0,0,1-2.88-1.22A4.11,4.11,0,0,1,208,73.59V8.47H184.45a4.13,4.13,0,0,1-2.93-1.14A3.72,3.72,0,0,1,180.3,4.48Z"></path><path d="M264.73,4.48A4,4,0,0,1,266,1.55,4,4,0,0,1,268.88.33l51.84.06h.06a4,4,0,0,1,2.93,1.21,4,4,0,0,1,1.22,2.94,4,4,0,0,1-1.22,2.93,4,4,0,0,1-2.93,1.22h-.06L273,8.63l.05,26a1.48,1.48,0,0,0,.31,0l.25,0,42.55.28a4,4,0,0,1,3,1.19,4.38,4.38,0,0,1,1.19,3.24A3.58,3.58,0,0,1,319.06,42a4.14,4.14,0,0,1-2.87,1.16h-.06l-42.55-.28h-.44l.05,25.73,47.53,0h.06a4.15,4.15,0,0,1,0,8.3h-.06l-51.68,0a4.17,4.17,0,0,1-4.15-4.15Z"></path><path d="M405.09,74.2A3.73,3.73,0,0,1,403.9,77a3.48,3.48,0,0,1-2.4,1.16,4.15,4.15,0,0,1-2.05-.53c-.63-.35-1.09-.62-1.38-.8a40.76,40.76,0,0,1-8.5-8.13,51.74,51.74,0,0,1-6.11-10,33.41,33.41,0,0,0-4.9-8,14.69,14.69,0,0,0-6.17-4.26A28,28,0,0,0,363.26,45l-6.42,0,.06,28.38v.12a4.13,4.13,0,0,1-7.08,2.9,4.1,4.1,0,0,1-1.22-3l-.17-69.16a3.9,3.9,0,0,1,1.22-2.94A4.22,4.22,0,0,1,352.53.06L367.25,0h1.27A51.16,51.16,0,0,1,385,2.43a23.75,23.75,0,0,1,11.18,7.5q4,5.07,4,13a19.65,19.65,0,0,1-2.33,9.71,22.07,22.07,0,0,1-6.09,7,27,27,0,0,1-8.13,4.2,29.33,29.33,0,0,1,4.93,7.2c2.13,4.09,4.26,7.78,6.36,11.06a32.1,32.1,0,0,0,8.35,8.69A4,4,0,0,1,405.09,74.2ZM368.8,8.3H356.73l.11,29.16a3.59,3.59,0,0,1,.72-.06l11.35-.11q10.17-.1,16.65-3.45T392,22.63a11.53,11.53,0,0,0-3.16-8.55,17.83,17.83,0,0,0-8.44-4.45A47.47,47.47,0,0,0,368.8,8.3Z"></path><path d="M480.67,21.63a18.59,18.59,0,0,1-1.61,8.17,20.81,20.81,0,0,1-4.65,6.11A19.72,19.72,0,0,1,481.19,43a21.32,21.32,0,0,1,2.63,10.85q0,11.4-6.14,17.23T460,76.86l-28.39-.06a4.56,4.56,0,0,1-2.85-.91,3.07,3.07,0,0,1-1.19-2.58l-.11-68.94a4,4,0,0,1,1.22-2.85,4,4,0,0,1,2.77-1.3l19,0A48.24,48.24,0,0,1,466,2.46a23.21,23.21,0,0,1,10.76,7.06Q480.67,14.27,480.67,21.63ZM450.9,8.69l-15.11.05L435.85,33l23-.33c4.16-.08,7.46-.94,9.87-2.58s3.63-4.4,3.63-8.27a10.42,10.42,0,0,0-2.83-7.64A16.41,16.41,0,0,0,461.88,10,42.3,42.3,0,0,0,450.9,8.69Zm9,60.25q7.8,0,11.73-3.34t3.93-11.49q0-7.08-4.09-10.12t-11.51-3H459l-23.18.33,0,27.77Z"></path><path d="M511.64,76.75a4.17,4.17,0,0,1-4.15-4.15l-.17-68v0a4,4,0,0,1,1.22-2.94,4.16,4.16,0,0,1,5.87,0,4,4,0,0,1,1.21,2.94v0l.17,63.86h43.33a4.15,4.15,0,0,1,0,8.3Z"></path><path d="M619.75.11a36.6,36.6,0,0,1,14.91,3,34.7,34.7,0,0,1,11.7,8.35A38.14,38.14,0,0,1,654,23.93a43.12,43.12,0,0,1,2.68,15.36A41.69,41.69,0,0,1,652,59.07a35.49,35.49,0,0,1-13,13.86A36.21,36.21,0,0,1,619.75,78,36.63,36.63,0,0,1,600.27,73a34.44,34.44,0,0,1-12.84-13.8,42.54,42.54,0,0,1-4.53-19.86,42.2,42.2,0,0,1,2.71-15.19,38.78,38.78,0,0,1,7.66-12.51A35.23,35.23,0,0,1,619.75.11Zm0,8.47a27.74,27.74,0,0,0-15,4,27.18,27.18,0,0,0-10,11,34.19,34.19,0,0,0-3.54,15.75,30.62,30.62,0,0,0,2.18,11.53,31.53,31.53,0,0,0,6.09,9.69,29,29,0,0,0,9.07,6.66,25.91,25.91,0,0,0,11.21,2.44A25.2,25.2,0,0,0,631,67.06a30.26,30.26,0,0,0,9.19-6.86,32.66,32.66,0,0,0,6.17-9.74,29.39,29.39,0,0,0,2.21-11.17,32.83,32.83,0,0,0-3.79-16,27.64,27.64,0,0,0-25-14.66Z"></path><path d="M715.9.11a36.61,36.61,0,0,1,14.92,3,34.9,34.9,0,0,1,11.7,8.35,38.31,38.31,0,0,1,7.61,12.48,43.34,43.34,0,0,1,2.68,15.36,41.58,41.58,0,0,1-4.65,19.78,35.42,35.42,0,0,1-12.95,13.86A36.21,36.21,0,0,1,715.9,78,36.59,36.59,0,0,1,696.43,73a34.3,34.3,0,0,1-12.84-13.8,42.43,42.43,0,0,1-4.54-19.86,42.42,42.42,0,0,1,2.71-15.19,38.64,38.64,0,0,1,7.67-12.51A35.23,35.23,0,0,1,715.9.11Zm0,8.47a27.77,27.77,0,0,0-15,4,27.18,27.18,0,0,0-10,11,34.19,34.19,0,0,0-3.54,15.75,30.63,30.63,0,0,0,2.19,11.53,31.32,31.32,0,0,0,6.08,9.69,29,29,0,0,0,9.08,6.66,25.87,25.87,0,0,0,11.2,2.44,25.24,25.24,0,0,0,11.21-2.55,30.34,30.34,0,0,0,9.18-6.86,32.27,32.27,0,0,0,6.17-9.74,29.21,29.21,0,0,0,2.22-11.17,32.94,32.94,0,0,0-3.79-16,27.87,27.87,0,0,0-10.3-10.79A28.15,28.15,0,0,0,715.9,8.58Z"></path><path d="M776.31,4.32a4.15,4.15,0,0,1,1.17-2.85,3.86,3.86,0,0,1,5.14-.58,5.18,5.18,0,0,1,1.61,1.66L815.1,53.06,846.31,2.21a3.92,3.92,0,0,1,3.54-2,4,4,0,0,1,2.93,1.22A4,4,0,0,1,854,4.37V73.7a4.15,4.15,0,0,1-8.3,0V19.09l-27.06,44.1a4.14,4.14,0,0,1-7.08,0l-26.95-44V73.48a4.15,4.15,0,0,1-8.3,0Z"></path></g></g>
</svg>
</a>
      </div>

      <div class="header-icon-right header-icons col-3">
        <div class="icon icon-account-header d-none d-lg-block">
          <a href="https://www.yallanshtry.com/blog/">
            <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="20" height="21" viewBox="0 0 20 21" fill="none">
  <path d="M19.015 19.8549C18.4842 18.3662 17.3117 17.0514 15.6819 16.1134C14.052 15.1754 12.0547 14.6667 10.0002 14.6667C7.94569 14.6667 5.94835 15.1754 4.31852 16.1134C2.68869 17.0514 1.51618 18.3662 0.985352 19.8549" stroke="#ffffff" stroke-linecap="round"/>
  <path d="M10.0002 10C12.5775 10 14.6668 7.91068 14.6668 5.33335C14.6668 2.75602 12.5775 0.666687 10.0002 0.666687C7.42283 0.666687 5.3335 2.75602 5.3335 5.33335C5.3335 7.91068 7.42283 10 10.0002 10Z" stroke="#ffffff" stroke-linecap="round"/>
</svg>

          </a>
        </div>
        <div class="icon icon-wishlist-header">
          <a href="https://www.yallanshtry.com/blog/">
            <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

            <span class="wishlist-count d-none">0</span>
          </a>
        </div>
        <div class="icon icon-cart-header">
          <a href="https://www.yallanshtry.com/blog/">
            <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="22" height="21" viewBox="0 0 22 21" fill="none">
  <path d="M6.33301 10V5.33335C6.33301 4.09568 6.82467 2.90869 7.69984 2.03352C8.57501 1.15835 9.762 0.666687 10.9997 0.666687C12.2374 0.666687 13.4243 1.15835 14.2995 2.03352C15.1747 2.90869 15.6663 4.09568 15.6663 5.33335V10" stroke="#ffffff" stroke-linecap="round"/>
  <path d="M1.30956 10.7793C1.47873 8.74817 1.56389 7.73317 2.23356 7.116C2.90323 6.49883 3.92289 6.5 5.96106 6.5H16.0399C18.0769 6.5 19.0966 6.5 19.7662 7.116C20.4359 7.732 20.5211 8.74817 20.6902 10.7793L21.2899 17.973C21.3879 19.1548 21.4369 19.7463 21.0916 20.1232C20.7439 20.5 20.1512 20.5 18.9636 20.5H3.03623C1.84973 20.5 1.25589 20.5 0.909392 20.1232C0.562892 19.7463 0.611892 19.1548 0.711059 17.973L1.30956 10.7793Z" stroke="#ffffff"/>
</svg>

          </a>
        </div>
      </div>
    </div>
  </div>
</header>

<nav class="nav-header" style="background-color: #242424;">
  <div class="nav-account-mobile row m-0 d-lg-none">
    <div class="col-6 welcome-cust p-0">
      
        <h1 class="logo">
    <a href="https://www.yallanshtry.com/blog/">
        <img src="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" alt="IPOTOTO" style="max-height:60px;">
    </a>
</h1>

      
    </div>
    
      <div class="col-6 login-register text-right p-0">
        <a href="https://stres.b-cdn.net/bandar-togel.html">Log In</a> | <a href="https://stres.b-cdn.net/bandar-togel.html">Sign Up</a>
      </div>
  </div>
  <ul class="nav-menu container">
    
      <li class="nav-menu container">
        <a href="https://www.yallanshtry.com/blog/">
          <span style="color: #ffffff;">IPOTOTO</span>
        
    
      <li class=" nav-menu container">
        <a href="https://www.yallanshtry.com/blog/">
          <span style="color: #ffffff;">TOGEL ONLINE</span>
          
    
      <li class=" nav-menu container">
        <a href="https://www.yallanshtry.com/blog/">
          <span style="color: #ffffff;">TOTO TOGEL</span>
    
      <li class=" nav-menu container">
        <a href="https://www.yallanshtry.com/blog/">
          <span style="color: #ffffff;">SITUS TOGEL</span>

      <li class=" nav-menu container">
        <a href="https://www.yallanshtry.com/blog/">
          <span style="color: #ffffff;">IPO TOTO</span>

      <li class=" nav-menu container">
        <a href="https://www.yallanshtry.com/blog/">
          <span style="color: #ffffff;">BANDAR TOGEL ONLINE</span>
      
<div class="overlay-nav">
  <!-- Mobile Close Button in Overlay -->
  <button id="nav-close" class="nav-close-btn d-lg-none">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
      <path d="M18 6L6 18M6 6L18 18" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </button>
</div>

<script>
  if ($(window).width() < 992) {
    // Level 1 menu accordion (main menu items)
    $(".nav-menu .nav-menu container > a").click(function(e){
      e.preventDefault()
      const parentLi = $(this).parent()
      const isCurrentlyOpen = parentLi.hasClass("menu-open")
      
      // Close all other open menus (accordion behavior)
      $(".nav-menu .nav-menu container").not(parentLi).removeClass("menu-open")
      $(".nav-menu .megamenu").not($(this).next(".megamenu")).slideUp()
      
      // Toggle current menu
      if (isCurrentlyOpen) {
        parentLi.removeClass("menu-open")
        $(this).next(".megamenu").slideUp()
      } else {
        parentLi.addClass("menu-open")
        $(this).next(".megamenu").slideDown()
      }
    })

    // Level 2 menu accordion (submenu items with grandchildren)
    $(document).on('click', '.dropdown-menu .has-submenu > a', function(e){
      e.preventDefault()
      const parentLi = $(this).parent()
      const isCurrentlyOpen = parentLi.hasClass("submenu-open")
      const grandchild = $(this).next(".grandchild")
      
      // Close all other open submenus in the same dropdown (accordion behavior)
      parentLi.siblings('.has-submenu').removeClass("submenu-open")
      parentLi.siblings('.has-submenu').find('.grandchild').slideUp()
      parentLi.siblings('.has-submenu').find('.chevron-right').css('transform', 'rotate(0deg)')
      
      // Toggle current submenu
      if (isCurrentlyOpen) {
        parentLi.removeClass("submenu-open")
        grandchild.slideUp()
        $(this).find('.chevron-right').css('transform', 'rotate(0deg)')
      } else {
        parentLi.addClass("submenu-open")
        grandchild.slideDown()
        $(this).find('.chevron-right').css('transform', 'rotate(90deg)')
      }
    })

    $("#menu-hamburger").click(function(e){
      e.preventDefault()
      $("body").toggleClass("nav_open")
    })
    
    // Handle close button click
    $("#nav-close").click(function(e){
      e.preventDefault()
      $("body").removeClass("nav_open")
      // Close all open menus when close button is clicked
      $(".nav-menu .nav-menu container").removeClass("menu-open")
      $(".nav-menu .megamenu").slideUp()
      $(".dropdown-menu .has-submenu").removeClass("submenu-open")
      $(".dropdown-menu .grandchild").slideUp()
      $(".dropdown-menu .chevron-right").css('transform', 'rotate(0deg)')
    })
  }

  $(".overlay-nav").click(function(e){
      e.preventDefault()
      $("body").removeClass("nav_open")
      // Close all open menus when overlay is clicked
      $(".nav-menu .nav-menu container").removeClass("menu-open")
      $(".nav-menu .megamenu").slideUp()
      $(".dropdown-menu .has-submenu").removeClass("submenu-open")
      $(".dropdown-menu .grandchild").slideUp()
      $(".dropdown-menu .chevron-right").css('transform', 'rotate(0deg)')
  })
</script>


</div>

      <div id="shopify-section-search-popup" class="shopify-section m-0"><style>
  #search-trigger {
    cursor: pointer;
  }
  #search-popup {
    display: none;
    position: fixed;
    left: 0;
    width: 100%;
    top: 0;
    height: 100%;
    justify-content: center;
    z-index: 9999;
    background: rgb(196 196 196 / 30%);
  }
  #search-input {
    align-self: center;
    width: 100%;
    height: 80px;
    position: absolute;
    top: 0;
    border-bottom: 0.5px solid #A3A3A3;
    background-color: #fff;
  }
  #search-input * {
    align-self: center;
  }
  #search-type {
    width: 100%;
    border: none;
    padding-right: 20px;
    padding-left: 20px;
    font-size: 16px;
    color: #757575;
  }
  #search-btn {
    font-size: 16px;
    font-weight: 500;
  }
  #search-result {
    min-height: 490px;
    width: 100%;
    padding-top: 80px;
  }
  #search-result .container {
    background-color: #fff;
    padding: 20px 40px;
  }
  body.search-popup-open {
  /* .search-popup-open */
    overflow: hidden;
  }
  .search-popup-open #loc_delivery {
    display: none
  }
  .search-header svg {
    display: none;
    cursor: pointer;
  }
  .wrapper-search-popup {
    max-height: calc(100vh - 150px);
    overflow-y: auto;
    overflow-x: hidden;
  }

  .group-recommend {
    padding: 20px 40px;
  }

  .resultsearch {
    display: none;
  }
  .results { padding: 20px 40px }
  .resultsearch label {
    font-weight: 600;
    padding-bottom: 20px;
    display: block;
    margin-bottom: 20px;
    border-bottom: 1px solid #AAAAAA;
  }

  ul.result_product {
    max-height: 300px;
    overflow: auto;
  }

  .group-promotion ul {
    margin: 0;
  }
  .group-promotion li {
    list-style: none;
    margin-bottom: 12px;
  }
  .group-promotion li a {
    color: inherit;
  }

  .group-recent {
    position: relative;
    padding: 20px 40px;
  }
  .group-recent ul {
    margin: 0;
  }
  .group-recent li {
    list-style: none;
    display: inline-block;
    margin-right: 60px;
  }
  .group-recent li a {
    color: inherit;
  }

  .last-search svg {
    width: 20px;
    vertical-align: middle;
  }
  ul.last-search a {
    vertical-align: middle;
    padding: 0 10px;
  }
  ul.last-search li span {
    cursor: pointer;
  }
  .delete-all-history {
    position: absolute;
    top: 25px;
    right: 40px;
    text-decoration: underline;
    color: #e11d1d;
    cursor: pointer;
    font-size: 12px;
  }

  form.search.search-modal__form {
    position: relative;
  }

  button.search__button svg {
    width: 25px;
    color: #495057;
    fill: #757582;
  }

  button.search__button.field__button {
    position: absolute;
    top: 50%;
    margin-top: -12px;
  }

  .close-search {
    display: none;
    position: absolute;
    right: 65px;
    top: 10px;
    cursor: pointer;
  }

  .site-overlay {
    position: fixed;
    top: 0;
    width: 100vw;
    height: 100vh;
    z-index: 1000;
    background: #47af63c45c;
    visibility: hidden;
    opacity: 0;
    pointer-events: none;
    transition: all .3s linear;
    display: block !important;
  }

  .search-popup-open .site-overlay {
    opacity: 1;
    visibility: visible;
    pointer-events: all;
    z-index: -1;
    cursor: pointer;
  }

  @media (min-width: 991px) {
    .group-recent ul {
      column-count: 3;
    }
    .group-promotion li a {
      font-size: 12px;
      font-weight: 400;
    }
    .group-recent li a {
      font-size: 12px;
      font-weight: 400;
    }
  }

  .moreresult {
    padding: 10px 40px;
    border-top: 1px solid #AAAAAA;
  }
  .moreresult * {
    align-self: center;
  }
  .moreresult p {
    margin: 0;
    font-size: 12px !important;
  }
  .moreresult svg {
    width: 13px;
  }

  @media (max-width: 992px) {
    .icon-key-mobile {
        height: auto!important;
        width: 10px!important;
    }
    body.grid-view.search-popup-open .products {
      -ms-flex: 0 0 100%!important;
      flex: 0 0 100%!important;
      max-width: 100%!important;
    }
    button.search__button svg {
      width: 20px;
    }
    #search-result {
      padding-left: 0;
      padding-right: 0;
    }
    #search-result {
      padding-top: 55px;
    }
    #search-input {
      height: 55px;
    }
    .group-recommend {
      padding: 20px;
    }
    #search-input .container {
      padding: 0 20px;
    }
    #search-type {
      font-size: 14px;
    }
    #search-btn {
      font-size: 12px;
      text-decoration: underline;
    }
    .results {
      padding: 20px;
    }
    .group-recommend h3 {
      font-size: 16px;
    }
    .products .card-body {
      padding: 8px 0px 10px;
    }
    .moreresult {
      padding: 10px 20px;
    }
  }
</style>
 <style type="text/css">
        div.advertisement-placeholder {
            text-align: center;
            padding-bottom: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        div.advertisement-text p {
            margin: 0;
            font-family: Open Sans;
            font-style: normal;
            font-weight: normal;
            font-size: 10px;
            line-height: 20px;
            color: #999999;
        }
        div.advertisement-banner {
            margin: 0px auto;
        }
        div#div-gpt-ad-billboard-placeholder {
            width: 996px;
            margin: 0 auto;
            background: #F5F5F5;
            padding-bottom: unset !important;
            min-height: 200px;
        }
        div#div-gpt-ad-lb-placeholder {
            background: #F5F5F5;
            padding-bottom: unset !important;
            min-height: 280px;
        }
        .faq-section{
            max-width:1200px;
            margin:50px auto;
            padding:40px 20px;
            position:relative;
            background-color: rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(25px);
            border-radius: 20px;
            }
        
        .faq-section::before{
            content:"";
            position:absolute;
            top:0;left:50%;
            transform:translateX(-50%);
            width:80%;
            height:2px;
            background:linear-gradient(90deg,transparent,#fffb00,transparent)
            }
            
        .faq-section h2{
            text-align:center;
            font-size:34px;font-weight:700;
            margin-bottom:50px;
            background: linear-gradient(135deg, #fffb00, #fffb00, #fffb00);
            -webkit-background-clip:text;
            -webkit-text-fill-color:transparent;
            background-clip:text;
            font-family:"Poppins",sans-serif;letter-spacing:1px
        }
        
        .faq-container{
            display:flex;
            flex-direction:column;
            gap:25px
        }
        
        .faq-item{
            background:linear-gradient(145deg,#0a0a0a,#1a1a1a);
            border:2px solid #ffd700;
            border-radius:20px;overflow:hidden;
            transition:all .4s ease;box-shadow:0 5px 20px rgba(0,0,0,0.5)
        }
        
        .faq-item:hover{
            border-color:#ffd700;
            transform:translateX(10px);
            box-shadow:0 12px 35px rgba(253, 4, 4, 0.25)
        }

        .faq-question{width:100%;
            padding:28px 35px;background:transparent;
            color:#ffffff;
            font-size:18px;
            font-weight:600;
            text-align:left;
            border:none;cursor:pointer;
            display:flex;
            justify-content:space-between;
            align-items:center;
            font-family:"Poppins",sans-serif;
            transition:all .3s ease
        }
        
        .faq-question:hover{
            color:#fffb00
        }
        
        .faq-question::after{
            content:'+';
            font-size:32px;
            font-weight:300;
            transition:all .4s ease;
            color:#fffb00;
            width:40px;
            height:40px;
            display:flex;
            align-items:center;
            justify-content:center;
            border:2px solid #ffd700;border-radius:50%;
            background:rgba(0, 0, 0, 0.1)
        }
        
        .faq-item.active .faq-question::after{
            transform:rotate(135deg);
            background:linear-gradient(135deg,#ffd700,#ffd700);
            color:#000;border-color:transparent
        }
        
        .faq-answer{
            max-height:0;
            overflow:hidden;
            transition:max-height .5s ease,padding .5s ease;
            background:linear-gradient(180deg,rgba(253,228,4,0.05),transparent);
            padding:0 35px
        }
        
        .faq-item.active .faq-answer{
            max-height:800px;padding:30px 35px;
            border-top:1px solid rgba(253, 4, 4, 0.3)
        }
        
        .faq-answer p{
            color:#e0e0e0;
            font-size:16px;
            line-height:2;
            margin:0;
            font-family:"Poppins",sans-serif
        }

        @media
            (max-width:768px)
        {
        
        .faq-section
            {padding:30px 15px}
        
        .faq-section h2
            {font-size:26px}
        
        .faq-question
            {font-size:16px;
            padding:22px 25px}
        
        .faq-question::after
            {width:35px;
            height:35px;
            font-size:28px}
        
        .faq-answer
            {padding:0 25px}
        
        .faq-item.active .faq-answer
            {padding:25px}
        
        .faq-item:hover
            {transform:translateX(5px)}
            }
    </style>

    <style>
     .megamenu {
  display: none;
  position: absolute;
  top: 68px;
  left: 0;
  padding: 20px 0;
  z-index: 99;
  background-color: #fff;
  width: 100%;
  border-top: 1px solid #eeeeee;
  border-bottom: 1px solid #eeeeee;
}
.dropdown-menu {
  list-style: none;
  margin: 0;
  padding: 0;
}
.dropdown-menu li {
  margin-bottom: 0;
}
.dropdown-menu li a {
  display: block;
  padding: 12px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
  text-transform: capitalize;
  transition: all 0.3s ease;
  border: none;
}
.dropdown-menu li.has-submenu > a {
  padding-bottom: 4px;
}
.dropdown-menu li a:hover {
  color: #B8860B;
  transform: translateX(4px);
  border: none;
}
.dropdown-menu .grandchild {
  margin: 0;
  padding: 0;
  list-style: none;
}
.dropdown-menu .grandchild li {
  list-style: none;
  margin: 0;
}
.dropdown-menu .grandchild li a {
  font-size: 15px;
  font-weight: 400;
  color: #666;
  padding: 6px 0;
  text-transform: none;
  border: none;
}
.dropdown-menu .grandchild li a:hover {
  color: #B8860B;
  transform: translateX(2px);
  border: none;
}

.megamenu.with-images .container {
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: flex-start;
}
.megamenu .container .menulinks {
  flex: 1;
  max-width: 60%;
  padding-right: 0;
}
.megamenu.with-images .container .menuimages {
  flex: 0 0 auto;
  width: 45%;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 200px;
}
.megamenu.with-images .container .menuimages img {
  display: block;
  max-width: 100%;
  height: auto;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

@media (min-width: 991px) {

  .dropdown-menu {
    display: grid;
    column-gap: 20px;
  }
  .dropdown-menu li {
      margin-bottom: 0 !important;
  }
  .nav-menu li.has-child:hover > .megamenu {
    display: block;
  }
  .dropdown-menu.five-links {
    grid-template-columns: repeat(5, 1fr);
    column-gap: 40px;
  }
  .megamenu .container .menulinks {
    max-width: 100%;
  }
  .dropdown-menu.three-links {
    grid-template-columns: repeat(3, 1fr);
    column-gap: 40px;
  }   
}  
  </style>
<div id="search-popup">
  <div id="search-input" class="row">
    <div class="container w-100">
      <form
        action="/search"
        method="get"
        role="search"
        class="search search-modal__form d-flex justify-content-between"
      >
        <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <path d="M18.7327 19.513L11.427 12.2073C10.8437 12.7043 10.1729 13.0889 9.41454 13.3612C8.65621 13.6334 7.89398 13.7695 7.12787 13.7695C5.25965 13.7695 3.67843 13.1228 2.3842 11.8293C1.08998 10.5359 0.442871 8.95505 0.442871 7.08683C0.442871 5.2186 1.0892 3.63699 2.38187 2.34199C3.67454 1.04699 5.25498 0.398714 7.12321 0.397159C8.99143 0.395603 10.5734 1.04271 11.8692 2.33849C13.165 3.63427 13.8129 5.21588 13.8129 7.08333C13.8129 7.89377 13.6694 8.67816 13.3824 9.43649C13.0954 10.1948 12.7182 10.8435 12.2507 11.3825L19.5564 18.687L18.7327 19.513ZM7.12904 12.6017C8.67682 12.6017 9.98348 12.0689 11.049 11.0033C12.1146 9.93777 12.6474 8.63071 12.6474 7.08216C12.6474 5.5336 12.1146 4.22694 11.049 3.16216C9.98348 2.09738 8.67682 1.5646 7.12904 1.56383C5.58126 1.56305 4.2742 2.09583 3.20787 3.16216C2.14154 4.22849 1.60876 5.53516 1.60954 7.08216C1.61032 8.62916 2.14309 9.93583 3.20787 11.0022C4.27265 12.0685 5.57932 12.6013 7.12787 12.6005" fill="#ffffff"/>
</svg>

        <input type="hidden" name="type" value="product">
        <input
          type="text"
          id="search-type"
          name="q"
          class="search-popup"
          placeholder="Gifts that linger: Uncover treasures for cherished moments."
        >
        <div class="close-search"><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="18" height="18" viewBox="0 0 18 18" fill="none">
  <path d="M9 9.708L12.246 12.954C12.3393 13.0473 12.454 13.0973 12.59 13.104C12.726 13.1107 12.8473 13.0607 12.954 12.954C13.0607 12.8473 13.114 12.7293 13.114 12.6C13.114 12.4707 13.0607 12.3527 12.954 12.246L9.708 9L12.954 5.754C13.0473 5.66067 13.0973 5.546 13.104 5.41C13.1107 5.274 13.0607 5.15267 12.954 5.046C12.8473 4.93933 12.7293 4.886 12.6 4.886C12.4707 4.886 12.3527 4.93933 12.246 5.046L9 8.292L5.754 5.046C5.66067 4.95267 5.546 4.90267 5.41 4.896C5.274 4.88933 5.15267 4.93933 5.046 5.046C4.93933 5.15267 4.886 5.27067 4.886 5.4C4.886 5.52933 4.93933 5.64733 5.046 5.754L8.292 9L5.046 12.246C4.95267 12.3393 4.90267 12.4543 4.896 12.591C4.88933 12.7263 4.93933 12.8473 5.046 12.954C5.15267 13.0607 5.27067 13.114 5.4 13.114C5.52933 13.114 5.64733 13.0607 5.754 12.954L9 9.708ZM9.003 18C7.75833 18 6.58833 17.764 5.493 17.292C4.39767 16.8193 3.44467 16.178 2.634 15.368C1.82333 14.558 1.18167 13.606 0.709 12.512C0.236333 11.418 0 10.2483 0 9.003C0 7.75767 0.236333 6.58767 0.709 5.493C1.181 4.39767 1.82133 3.44467 2.63 2.634C3.43867 1.82333 4.391 1.18167 5.487 0.709C6.583 0.236333 7.753 0 8.997 0C10.241 0 11.411 0.236333 12.507 0.709C13.6023 1.181 14.5553 1.82167 15.366 2.631C16.1767 3.44033 16.8183 4.39267 17.291 5.488C17.7637 6.58333 18 7.753 18 8.997C18 10.241 17.764 11.411 17.292 12.507C16.82 13.603 16.1787 14.556 15.368 15.366C14.5573 16.176 13.6053 16.8177 12.512 17.291C11.4187 17.7643 10.249 18.0007 9.003 18ZM9 17C11.2333 17 13.125 16.225 14.675 14.675C16.225 13.125 17 11.2333 17 9C17 6.76667 16.225 4.875 14.675 3.325C13.125 1.775 11.2333 1 9 1C6.76667 1 4.875 1.775 3.325 3.325C1.775 4.875 1 6.76667 1 9C1 11.2333 1.775 13.125 3.325 14.675C4.875 16.225 6.76667 17 9 17Z" fill="#757575"/>
</svg>
</div>
        <button id="search-btn">Search</button>
      </form>
    </div>
  </div>
  <div id="search-result" class="container m-auto">
    <div class="container p-0">
      <div class="group-promotion">
        <div class="resultsearch">
          <div class="row results">
            <div class="col-12 col-lg-6 mb-3 mb-lg-0">
              <label>SUGGESTIONS</label>
              <ul class="result_collection"></ul>
            </div>
            <div class="col-12 col-lg-6">
              <label>PRODUCTS</label>
              <ul class="result_product"></ul>
            </div>
          </div>
          <div class="d-flex justify-content-between moreresult m-0">
            <p>Search for<span></span></p>
            <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="32" height="32" viewBox="0 0 32 32">
<title>icon-arrow-right</title>
<path d="M25.057 15.333l-6.862-6.862c-0.26-0.26-0.26-0.682 0-0.943s0.682-0.26 0.943 0l8 8c0.26 0.26 0.26 0.682 0 0.943l-8 8c-0.26 0.26-0.682 0.26-0.943 0s-0.26-0.682 0-0.943l6.862-6.862h-19.724c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h19.724z"></path>
</svg>
          </div>
        </div>
      </div>
      <div class="group-recent hide">
        <h3>RECENT SEARCH</h3>
        <span class="delete-all-history">Hapus riwayat</span>
        <ul class="last-search"></ul>
      </div>
      <div class="group-recommend">
        <h3>YOU MAY ALSO LIKE</h3>
        
        
          <div class="row popup-recommend c-products-grid infinite-case product-multi-">
            <div class="swiper-wrapper justify-content-between" style="margin-left:1px;">
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="mid-autumn-of-love-mooncake">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/mid-autumn-of-love-mooncake">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/Mid-Autumn-of-Love-Mooncake_6b4cc10d-950d-4e1a-abf7-427b4a6912c8_350x.jpg?v=1755750898" data-src="//outerbloom.com/cdn/shop/files/Mid-Autumn-of-Love-Mooncake_6b4cc10d-950d-4e1a-abf7-427b4a6912c8_350x.jpg?v=1755750898" alt="Mid Autumn of Love Mooncake" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          Mid Autumn of Love Mooncake
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 588.000</s>
            <span class="product-card-discount small">	
              (-40%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 348.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="mid-autumn-of-joy-mooncake">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/mid-autumn-of-joy-mooncake">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/Mid-Autumn-of-Joy-Mooncake_97224b06-a506-4a56-8544-59a0dccb5c17_350x.jpg?v=1755750798" data-src="//outerbloom.com/cdn/shop/files/Mid-Autumn-of-Joy-Mooncake_97224b06-a506-4a56-8544-59a0dccb5c17_350x.jpg?v=1755750798" alt="Mid Autumn of Joy Mooncake" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          Mid Autumn of Joy Mooncake
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 888.000</s>
            <span class="product-card-discount small">	
              (-33%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 588.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="mid-autumn-of-fortune-mooncake">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/mid-autumn-of-fortune-mooncake">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/Mid-Autumn-of-Fortune-Mooncake_de29329d-6ab7-4592-aa00-3e9636d4a323_350x.jpg?v=1755846072" data-src="//outerbloom.com/cdn/shop/files/Mid-Autumn-of-Fortune-Mooncake_de29329d-6ab7-4592-aa00-3e9636d4a323_350x.jpg?v=1755846072" alt="Mid Autumn of Fortune Mooncake" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          Mid Autumn of Fortune Mooncake
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 1.188.000</s>
            <span class="product-card-discount small">	
              (-33%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 788.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="mid-autumn-festival-mooncake">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/mid-autumn-festival-mooncake">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/Mid-Autumn-Festival-Mooncake_06ea4f9c-bdaa-49de-b0ba-c3dd60fef351_350x.jpg?v=1755845965" data-src="//outerbloom.com/cdn/shop/files/Mid-Autumn-Festival-Mooncake_06ea4f9c-bdaa-49de-b0ba-c3dd60fef351_350x.jpg?v=1755845965" alt="Mid Autumn Festival Mooncake" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          Mid Autumn Festival Mooncake
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 1.288.000</s>
            <span class="product-card-discount small">	
              (-23%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 988.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="the-jade-bouquet">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/the-jade-bouquet">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/The-Jade-Bouquet_350x.jpg?v=1751618030" data-src="//outerbloom.com/cdn/shop/files/The-Jade-Bouquet_350x.jpg?v=1751618030" alt="The Jade Bouquet" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          The Jade Bouquet
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 435.000</s>
            <span class="product-card-discount small">	
              (-34%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 285.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="the-selena-bouquet">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/the-selena-bouquet">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/The-Selena-Bouquet_350x.jpg?v=1751618047" data-src="//outerbloom.com/cdn/shop/files/The-Selena-Bouquet_350x.jpg?v=1751618047" alt="The Selena Bouquet" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          The Selena Bouquet
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 335.000</s>
            <span class="product-card-discount small">	
              (-29%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 235.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="the-viola-bouquet">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/the-viola-bouquet">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/The-Viola-Bouquet_350x.jpg?v=1751618053" data-src="//outerbloom.com/cdn/shop/files/The-Viola-Bouquet_350x.jpg?v=1751618053" alt="A striking bouquet featuring full pink chrysanthemums and delicate purple asters. It is elegantly wrapped in deep purple paper with a modern black and white striped accent at the base. The arrangement is tied with a pink ribbon bow, creating a full, rounded shape. This sophisticated bouquet is perfect for birthdays, anniversaries, or as a thoughtful thank-you gesture." height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          The Viola Bouquet
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 385.000</s>
            <span class="product-card-discount small">	
              (-25%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 285.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="the-minerva-bouquet">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/the-minerva-bouquet">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/The-Minerva-Bouquet_350x.jpg?v=1751618061" data-src="//outerbloom.com/cdn/shop/files/The-Minerva-Bouquet_350x.jpg?v=1751618061" alt="The Minerva Bouquet" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          The Minerva Bouquet
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 385.000</s>
            <span class="product-card-discount small">	
              (-25%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 285.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="congraduations-bouquet">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/congraduations-bouquet">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/Congraduations-Bouquet_350x.jpg?v=1749545306" data-src="//outerbloom.com/cdn/shop/files/Congraduations-Bouquet_350x.jpg?v=1749545306" alt="Congraduations Bouquet" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          Congraduations Bouquet
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 380.000</s>
            <span class="product-card-discount small">	
              (-25%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 285.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
                
                  <div class="swiper-slide card">
                    



<div class="products" data-lazy="false">
  <div class="bg-products">
    <div class="wishlist-toggle" data-product-handle="grad-gorgeous-bouquet">
      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="21" viewBox="0 0 24 21" fill="none">
  <path d="M17.4688 0.8125C15.1237 0.8125 13.1025 1.92703 12 3.77328C10.8975 1.92703 8.87625 0.8125 6.53125 0.8125C4.8494 0.814526 3.23702 1.48353 2.04778 2.67278C0.858534 3.86202 0.189526 5.47441 0.1875 7.15625C0.1875 10.2833 2.15625 13.5514 6.02813 16.8677C7.81594 18.3889 9.74622 19.7342 11.7922 20.885C11.856 20.9195 11.9274 20.9375 12 20.9375C12.0726 20.9375 12.144 20.9195 12.2078 20.885C14.2538 19.7342 16.1841 18.3889 17.9719 16.8677C21.8438 13.5514 23.8125 10.2833 23.8125 7.15625C23.8105 5.47441 23.1415 3.86202 21.9522 2.67278C20.763 1.48353 19.1506 0.814526 17.4688 0.8125ZM12 19.9991C10.4688 19.1241 1.0625 13.5077 1.0625 7.15625C1.06424 5.70638 1.64096 4.31639 2.66618 3.29118C3.69139 2.26596 5.08138 1.68924 6.53125 1.6875C8.84016 1.6875 10.7805 2.92453 11.5953 4.91516C11.6283 4.9954 11.6843 5.06403 11.7564 5.11233C11.8285 5.16063 11.9133 5.18642 12 5.18642C12.0867 5.18642 12.1715 5.16063 12.2436 5.11233C12.3157 5.06403 12.3717 4.9954 12.4047 4.91516C13.2195 2.92453 15.1598 1.6875 17.4688 1.6875C18.9186 1.68924 20.3086 2.26596 21.3338 3.29118C22.359 4.31639 22.9358 5.70638 22.9375 7.15625C22.9375 13.5 13.5312 19.1284 12 19.9991Z" fill="#ffffff"/>
</svg>

    </div>
    <a href="/products/grad-gorgeous-bouquet">
      
      <div class="product-card-img-container p-0 position-relative">
        
        <img class="product-card-img"  lazy="false" src="//outerbloom.com/cdn/shop/files/Grad-_-Gorgeous-Bouquet_350x.jpg?v=1749545297" data-src="//outerbloom.com/cdn/shop/files/Grad-_-Gorgeous-Bouquet_350x.jpg?v=1749545297" alt="Grad &amp; Gorgeous Bouquet" height="200" width="200">
      </div>
      <div class="card-body product-card-info">
        <h5 class="h5 mb-0">
          Grad & Gorgeous Bouquet
        </h5>
        <div class="product-card-price">
          
          <div class="product-price-sale">
            <s class="product-card-price-before card-money">Rp 380.000</s>
            <span class="product-card-discount small">	
              (-25%)
            </span> 	
          </div>
          
          
          
          <div class="price-discount">
            <h4 class="product-card-price-after card-money">Rp 285.000</h4>
          </div>
          
          
          
          
          
        </div>
        
      </div>
    </a>
  </div>
  
</div>

                  </div>
                
              
            </div>
          </div>
        
      </div>
    </div>
  </div>

  <div class="site-overlay" style="display: none"></div>
</div>
<script>
  
  var swiper = new Swiper('.popup-recommend', {
      slidesPerView : 4, 
      spaceBetween: 30,
      lazy: true ,                            
      speed: 300,
      breakpoints: {
        // when window width is <= 576px
        576: {
            slidesPerView: 2,
              spaceBetween: 10,
            freeMode: true,
            resistance : true,
            resistanceRatio : 0,
            freeModeMomentumRatio : 0.45,
            freeModeMomentumVelocityRatio : 1.5
        },
        768: {
              slidesPerView: 2,
              spaceBetween: 10
            },
        992: {
              slidesPerView: 3,
              spaceBetween: 20
        }
      }
  });

  const searchContainer = $("#search-popup")
  const searchInput = $(".search-popup")
  const result_collection = $('.result_collection')
  const result_product = $('.result_product')
  const resultsearch = $('.resultsearch')
  const resultrecommend = $(".group-recommend")
  const moreresult = $(".moreresult")

  searchInput.keyup(function(){
    const input = $(this).val()
    moreresult.find("p span").text(` “${input}”`)
    if(input.length > 2) {
      $(".close-search").show()
      const url = `https://outerbloom.com/search/suggest.json?resources[limit]=10&resources[limit_scope]=each&resources[type]=collection,product&q=${input}`
      $.ajax({
        type: 'GET',
        url,
        beforeSend: function() {
            // setting a timeout
            // $(placeholder).addClass('loading');
        },
        success: function(response) {
            resultsearch.show()
            resultrecommend.hide()
            result_collection.html("")
            result_product.html("")
            const collections = response.resources.results.collections
            const products = response.resources.results.products
            let collection_length = collections.length
            let product_length = products.length
            // if(collections.length > 5) {
            //   collection_length = 5
            // }
            // if(products.length > 5) {
            //   product_length = 5
            // }
            for(let i=0;i<collection_length;i++){
              const title = collections[i].title
              const url = collections[i].url
              let html_collection
              if(!title.includes('AIA') && !title.includes('AXA') && !title.includes('WOM') && !title.includes('Upsell')) {
                html_collection = `
                <li class="item" data-title="${title}">
                  <a href="${url}" data-type="collection" class="item_url" data-title="${title}" data-url="${url}">${title}</a>
                </li>
                `
              }
              result_collection.append(html_collection)
            }
            for(let i=0;i<product_length;i++){
              const title = products[i].title
              const url = products[i].url
              const image = products[i].featured_image.url
              const vendor = products[i].vendor
              let html_product
              if(vendor !== 'AIA' && vendor !== 'AXA' && vendor !== 'WOM Finance' && !title.includes('Extra Shipping Cost') && !title.includes('[US]') && !title.includes('Rp')){
                html_product = `
                <li class="item" data-vendor="${vendor}">
                  <a href="${url}" class="item_url" data-type="product" data-title="${title}" data-url="${url}">
                    <img src="${image}" alt="${title}" style="width: 70px;vertical-align: middle;margin-right: 20px;"><span>${title}</span>
                  </a>
                </li>
                `
              }
              result_product.append(html_product)
            }
        },
        error: function(xhr) { // if error occured
            alert("Error occured.please try again");
        },
        complete: function(response) {
            // $(placeholder).removeClass('loading');
        },
        dataType: 'JSON'
      });
    } else {
      result_collection.html("")
      result_product.html("")
      
      resultsearch.hide()
      resultrecommend.show()
    }
  })

  moreresult.click(function(){
    $("#search-btn").trigger("click");
  })

  $(".close-search").click(function(){
    $(this).hide()
    searchInput.val("")
    searchInput.focus()
    resultsearch.hide()
    resultrecommend.show()
  })

  function setCookie(name,value,days) {
    var expires = "";
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days*24*60*60*1000));
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
  }
  function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
      var c = ca[i];
      while (c.charAt(0)==' ') c = c.substring(1,c.length);
      if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
  }
  let last_search_name = []
  let last_search_url = []
  $(".group-recent").hide()
  if(getCookie("last_search_name") != null && getCookie("last_search_url") != null){
    if(getCookie("last_search_name") != "" && getCookie("last_search_url") != ""){
      $(".group-recent").show()
      last_search_name = getCookie("last_search_name");
      last_search_url = getCookie("last_search_url");
      const arrName = last_search_name.substring(1).split(',').reverse()
      const arrUrl = last_search_url.substring(1).split(',').reverse()
      console.log(arrName, 'Array Name')
      console.log(arrUrl, 'Array Url')
      let length = arrName.length
      if(arrName.length > 5) {
        length = 5
      }
      for(let n=0;n<length;n++){
        let html2 = `<li><svg viewBox="0 0 24 24" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"><title/><path d="M12.25,2A9.81,9.81,0,0,0,4.77,5.46L3.41,4.25a1,1,0,0,0-1.07-.16A1,1,0,0,0,1.75,5V9a1,1,0,0,0,1,1h4.5a1,1,0,0,0,.93-.64,1,1,0,0,0-.27-1.11L6.26,6.78a7.86,7.86,0,0,1,6-2.78A8,8,0,1,1,4.72,14.67a1,1,0,0,0-1.89.66A10,10,0,1,0,12.25,2Z" fill="#C9C9C9"/><path d="M16,16a1,1,0,0,1-.6-.2l-4-3A1,1,0,0,1,11,12V8a1,1,0,0,1,2,0v3.5l3.6,2.7a1,1,0,0,1,.2,1.4A1,1,0,0,1,16,16Z" fill="#C9C9C9"/></svg><a href="${arrUrl[n]}">${arrName[n]}</a><span data-title="${arrName[n]}" data-url="${arrUrl[n]}"></span></li>`
        $(".group-recent ul").append(html2)
      }
    }
  }
  console.log(last_search_name, 'Name')
  console.log(last_search_url, 'url')
  
  resultsearch.delegate(".item a", "click", function(){
    let name = [last_search_name]
    let url = [last_search_url]
    name.push($(this).attr('data-title'))
    url.push($(this).attr('data-url'))
    setCookie("last_search_name",name,7);
    setCookie("last_search_url",url,7);
  })
  
  $(".delete-all-history").click(function() {
    setCookie("last_search_name",null,0);
    setCookie("last_search_url",null,0);
    $(".last-search").hide();
    setTimeout(function(){
      location.reload();
    }, 500);
  })
  
  $("#search-trigger").click(function(){
    search_open()
  })
  $(".icon-search-mobile").click(function(){
    search_open()
  })
  $(".search-header svg").click(function(){
    search_close()
  })
  $(".icon-key-mobile").click(function(){
    search_close()
  })

  function search_open() {
    $("body").addClass("search-popup-open")
    $("#nav-mobile-icon, .search-header label, .icon-search-mobile").hide()
    $("#search-popup, .search-header svg, .icon-key-mobile").show()
    $(".search-popup").focus()
    $('.popup-recommend')[0].swiper.update();
  }
  function search_close() {
    $("body").removeClass("search-popup-open")
    $("#nav-mobile-icon, .search-header label, .icon-search-mobile").show()
    $("#search-popup, .search-header svg, .icon-key-mobile").hide()
    searchInput.val("")
    resultsearch.hide()
    resultrecommend.show()
  }

  $(".site-overlay").click(function(){
    search_close()
  })
</script>

</div>
    </div>

    <div id="PageContainer" class="is-moved-by-drawerx" style="background-color: #47af63c4;">
      <main class="main-content pt-0" role="main">
        
          <div id="breadcrumbProduct" class="d-none d-lg-block">
            <style>
  #breadcrumbProduct {
    padding: 20px 0;
  }
  #breadcrumbProduct ul {
      display: flex;
      padding: 0;
      list-style: none;
      margin: 0;
      gap: 12px;
  }
  #breadcrumbProduct ul li {
    text-transform: uppercase;
    margin: 0;
    font-size: 12px;
}
  #breadcrumbProduct ul li a {
    color: #757575;
  }

  #breadcrumbProduct ul li svg {
    width: 10px;
    height: 10px;
    padding: 0;
    color: #757575;
    vertical-align: middle;
  }
</style>
<div class="container" style="color: #ffffff;">
  <ul role="navigation" aria-label="breadcrumbs">
    <li><a href="https://www.yallanshtry.com/blog/" style="color: #ffffff;">IPOTOTO</a></li>
    <li><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="7" height="10" viewBox="0 0 7 10" fill="none">
    <path d="M1.51673 0.0583496L6.2334 4.77502L1.51673 9.49168L0.933398 8.90002L5.0584 4.77502L0.933398 0.650016L1.51673 0.0583496Z" fill="#757575"/>
</svg></li>
      <li>SITUS TOGEL</li>
      <li>TOGEL ONLINE</li>
      <li>BANDAR TOGEL ONLINE</li>
      <li>IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar</li>
    
  </ul>
</div>

          </div>
        
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar",
  "image": "https://ik.imagekit.io/ljdihgltp/banner.jpg",
  "description": "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!",
  "brand": {
    "@type": "Brand",
    "name": "IPOTOTO"
  },
  "sku": "IPOTOTO",
  "mpn": "IPOTOTO",
  "url": "https://www.yallanshtry.com/blog/",
  "offers": {
    "@type": "Offer",
    "url": "https://www.yallanshtry.com/blog/",
    "priceCurrency": "USD",
    "price": "10.00",
    "priceValidUntil": "2025-12-25",
    "itemCondition": "https://schema.org/NewCondition",
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": "IPOTOTO"
    }
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "5.0",
    "reviewCount": 858
  },
  "review": [
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": "5",
        "bestRating": "5"
      },
      "author": {
        "@type": "Person",
        "name": "juandi"
      }
    },
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": "5",
        "bestRating": "5"
      },
      "author": {
        "@type": "Person",
        "name": "situmorang"
      }
    }
  ]
}
</script><script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "IPOTOTO",
      "item": "https://www.yallanshtry.com/blog/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "SITUS TOGEL",
      "item": "https://www.yallanshtry.com/blog/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "TOGEL ONLINE",
      "item": "https://www.yallanshtry.com/blog/"
    },
    {
      "@type": "ListItem",
      "position": 4,
      "name": "BANDAR TOGEL ONLINE",
      "item": "https://www.yallanshtry.com/blog/"
    },
    {
      "@type": "ListItem",
      "position": 5,
      "name": "IPO TOTO",
      "item": "https://www.yallanshtry.com/blog/"
    },
    {
      "@type": "ListItem",
      "position": 6,
      "name": "TOTO TOGEL",
      "item": "https://www.yallanshtry.com/blog/"
    },
    {
      "@type": "ListItem",
      "position": 8,
      "name": "IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar",
      "item": "https://www.yallanshtry.com/blog/"
    }
  ]
}
</script>

<script type="application/ld+json" id="faq-schema">
{
 "@context": "https://schema.org",
 "@type": "FAQPage",
 "mainEntity": [
   {
     "@type": "Question",
     "name": "Kenapa IPOTOTO dikenal sebagai situs dengan update tercepat",
     "acceptedAnswer": {
       "@type": "Answer",
       "text": "IPOTOTO menggunakan sistem result otomatis yang langsung terhubung ke server resmi Toto Macau. Hasil keluaran diperbarui secara real-time tanpa delay, memastikan pemain selalu mendapat informasi terbaru dengan kecepatan maksimal setiap hari."
     }
   },
   {
     "@type": "Question",
     "name": "Apakah result di IPOTOTO akurat dan resmi",
     "acceptedAnswer": {
       "@type": "Answer",
       "text": "Ya, semua result di IPOTOTO bersumber dari pasaran resmi Toto Macau. Tidak ada manipulasi atau keterlambatan, setiap angka yang keluar dijamin valid dan sesuai jadwal asli, memberikan rasa aman dan kepercayaan penuh bagi para pemain."
     }
   },
   {
     "@type": "Question",
     "name": "Bagaimana cara melihat hasil Toto Macau di IPOTOTO",
     "acceptedAnswer": {
       "@type": "Answer",
       "text": "Pemain cukup login ke situs IPOTOTO lalu buka menu result. Semua hasil togel Macau ditampilkan lengkap, mulai dari 2D, 3D, hingga 4D, dengan tampilan yang jelas dan mudah dibaca agar pemain bisa langsung memantau angka keluar terbaru."
     }
   },
   {
     "@type": "Question",
     "name": "Apakah IPOTOTO hanya menyediakan pasaran Macau saja",
     "acceptedAnswer": {
       "@type": "Answer",
       "text": "Tidak, selain Macau, IPOTOTO juga menyediakan berbagai pasaran resmi lain seperti Hongkong, Singapore, dan Sydney. Semua pasaran aktif setiap hari dengan sistem result cepat, aman, dan transparan untuk semua pemain togel online."
     }
   },
   {
     "@type": "Question",
     "name": "Apakah IPOTOTO aman untuk bermain togel online",
     "acceptedAnswer": {
       "@type": "Answer",
       "text": "IPOTOTO dilengkapi sistem keamanan berlapis dan enkripsi data modern yang melindungi seluruh aktivitas pemain. Dengan dukungan server stabil dan lisensi resmi, kamu bisa bermain dengan nyaman tanpa khawatir gangguan atau kebocoran data."
     }
   }
 ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "IPOTOTO",
  "url": "https://www.yallanshtry.com/blog/",
  "logo": "https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif",
  "sameAs": [
    "https://www.facebook.com/IPOTOTO",
    "https://twitter.com/IPOTOTO",
    "https://www.instagram.com/IPOTOTO"
  ],
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+62-8829-415-7036",
    "contactType": "customer support",
    "areaServed": "ID",
    "availableLanguage": ["Indonesian", "English"]
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar",
  "description": "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!",
  "thumbnailUrl": [
    "https://ik.imagekit.io/ljdihgltp/banner.jpg",
    "https://ik.imagekit.io/ljdihgltp/banner.jpg"
  ],
  "uploadDate": "2025-09-28T04:19:10-04:00",
  "duration": "PT168",
  "contentUrl": "https://www.yallanshtry.com/blog/"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://www.yallanshtry.com/blog/"
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://www.yallanshtry.com/blog/#org",
      "name": "IPOTOTO",
      "url": "https://www.yallanshtry.com/blog/",
      "logo": "https://ik.imagekit.io/ljdihgltp/banner.jpg"
    },
    {
      "@type": "WebSite",
      "@id": "https://www.yallanshtry.com/blog/#website",
      "url": "https://www.yallanshtry.com/blog/",
      "name": "IPOTOTO",
      "publisher": { "@id": "https://www.yallanshtry.com/blog/#org" },
      "inLanguage": "id-ID",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.yallanshtry.com/blog/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "SoftwareApplication",
      "@id": "https://www.yallanshtry.com/blog/#app",
      "name": "IPOTOTO",
      "applicationCategory": "GameApplication",
      "operatingSystem": "Android, iOS, Windows",
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "IDR" },
      "aggregateRating": { "@type": "AggregateRating", "ratingValue": 4.9, "ratingCount": 62595 }
    }
  ]
}
</script>
        
<div id="shopify-section-Product" class="shopify-section product-section mt-0"><link href="https://asset-jko.b-cdn.net/footer-warna.css" rel="stylesheet" type="text/css" media="all" />


<style>
    .bg-card {
    background-color: #47af63c4;
}
    </style>

<!-- /templates/product.liquid -->


<!-- <div itemscope itemtype="http://schema.org/Product"> -->


<div class="product-standing-flower" data-product-type="flowerBoard">
  <meta itemprop="url" content="https://www.yallanshtry.com/blog/">
  <meta itemprop="image" content="https://ik.imagekit.io/ljdihgltp/banner.jpg">

  
  
  <input id="data-sku" type="hidden" value="OBVSTF1086">
  <div class="product-single" style="background-image: url(#); background-attachment: fixed;">
    <div id="product-top" class="container">
      <div class="row bg-card product-sticky" style="background-color: rgba(0, 0, 0, 0.1);backdrop-filter: blur(25px); padding: 20px 25px;border-radius: 10px;">
        <div id="product-image" class="col-lg-7 text-center">
          <div class="product-image">
            <div class="row no-gutters">
  
  <div id="product-featured-image" class="row w-100">
    
      <div id="thumb-image-product" class="col-lg-2 col-12 d-none d-lg-block">
        
        <div class="swiper-container gallery-thumbs" style="min-height: 500px">
          <ul class="list-unstyled slider swiper-wrapper slider-nav ProductThumbs thumbnails" id="ProductThumbsx">

                  <li class="swiper-slide" data-type="image">
                    <a
                      href="files/Blossom-Shine-WM.jpg"
                      data-standard="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                      data-image="files/Blossom-Shine-WM.jpg"
                      data-position="1"
                      class="product-single__thumbnail"
                    >
                      <img
                        class="lazyload w-100"
                        src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                        alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                        width=""
                        height=""
                      >
                    </a>
                  </li>
                
              
            

                  <li class="swiper-slide" data-type="image">
                    <a
                      href="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                      data-standard="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                      data-image="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                      data-position="2"
                      class="product-single__thumbnail"
                    >
                      <img
                        class="lazyload w-100"
                        src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                        alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                        width=""
                        height=""
                      >
                    </a>
                  </li>
                
              
            

                  <li class="swiper-slide" data-type="image">
                    <a
                      href="files/Blossom-Shine_3-WM.jpg"
                      data-standard="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                      data-image="files/Blossom-Shine_3-WM.jpg"
                      data-position="3"
                      class="product-single__thumbnail"
                    >
                      <img
                        class="lazyload w-100"
                        src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                        alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                        width=""
                        height=""
                      >
                    </a>
                  </li>
                
              
            

                  <li class="swiper-slide" data-type="image">
                    <a
                      href="files/Blossom-Shine_4.jpg"
                      data-standard="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                      data-image="files/Blossom-Shine_4.jpg"
                      data-position="4"
                      class="product-single__thumbnail"
                    >
                      <img
                        class="lazyload w-100"
                        src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                        alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                        width=""
                        height=""
                      >
                    </a>
                  </li>
                
              
            
          </ul>
        </div>
        
      </div>
    
    <div
      id="featured-image-product"
      class="col-lg-10 col-12 d-none d-lg-block"
    >
      <div class="swiper-container gallery-top">
        <div class="swiper-slide product-single__image">
          
<div class="product-single__photos slider slider-for" id="ProductPhoto">
  

  <div class="easyzoom easyzoom--overlay easyzoom--with-thumbnails">
    <a href="https://ik.imagekit.io/ljdihgltp/banner.jpg">
      <img
        src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
        alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
        id="ProductPhotoImg"
        class="lazyload"
      >
      
    </a>
  </div>
</div>

        </div>
        <div class="swiper-slide product-single__video" style="display: none">
          <video
            src="https://cdn.shopify.com/videos/c/vp/05d379ea115d41c2bd0f7d08b1496bd9/05d379ea115d41c2bd0f7d08b1496bd9.HD-1080p-7.2Mbps-24002195.mp4"
            playsinline
            loop
            muted
          ></video>
        </div>
      </div>
    </div>
  </div>

  <div id="featured-image-product2" class="col-12 d-lg-none">
    <div class="swiper-container gallery-mobile">
      <ul class="swiper-wrapper">
<li class="swiper-slide img">
              
                <img
                  class="swiper-lazy"
                  src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  data-src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                  width=""
                  height=""
                >
              
            </li>
          
        
<li class="swiper-slide img">
              
                <img
                  class="swiper-lazy"
                  src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  data-src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                  width=""
                  height=""
                >
              
            </li>
          
        
<li class="swiper-slide img">
              
                <img
                  class="swiper-lazy"
                  src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  data-src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                  width=""
                  height=""
                >
              
            </li>
          
        
<li class="swiper-slide img">
              
                <img
                  class="swiper-lazy"
                  src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  data-src="https://ik.imagekit.io/ljdihgltp/banner.jpg"
                  alt="IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar"
                  width=""
                  height=""
                >
              
            </li>
          
        
      </ul>
      
        <div class="swiper-button-prev"><svg class="icon icon-chevron-left" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="7" height="12" viewBox="0 0 7 12"> <circle cx="60%" cy="50%" r="12" fill="transparent" /> <path d="M6.35355339,10.6464466 C6.54881554,10.8417088 6.54881554,11.1582912 6.35355339,11.3535534 C6.15829124,11.5488155 5.84170876,11.5488155 5.64644661,11.3535534 L0.646446609,6.35355339 C0.451184464,6.15829124 0.451184464,5.84170876 0.646446609,5.64644661 L5.64644661,0.646446609 C5.84170876,0.451184464 6.15829124,0.451184464 6.35355339,0.646446609 C6.54881554,0.841708755 6.54881554,1.15829124 6.35355339,1.35355339 L1.70710678,6 L6.35355339,10.6464466 Z"/> </svg></div>
        <div class="swiper-button-next"><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="7" height="10" viewBox="0 0 7 10" fill="none">
    <path d="M1.51673 0.0583496L6.2334 4.77502L1.51673 9.49168L0.933398 8.90002L5.0584 4.77502L0.933398 0.650016L1.51673 0.0583496Z" fill="#757575"/>
</svg></div>

        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
      
    </div>
  </div>

  <div class="product-m-pageleb-video col-12 text-center d-lg-none">
    <!-- product video -->
    <style>
      .view-video{display:block; margin:auto; padding:5px 10px;font-size:16px;font-weight:bold;border:2px solid #ffffff;background:#fff;}
      .view-video .icon-play{fill:#ffffff;vertical-align: middle;}
      .video-modal{display:none;position:fixed;background: rgba(0,0,0,.5); width:100%; height:100%; overflow:auto; z-index:1; top:0;left:0;}
      .close-video{position:absolute;right:9px; top:8%;z-index:2;padding:5px;}
      .close-video .icon{width:30px;height:30px;}
      /*responsive iframe */
      .video-container {position: relative;padding-bottom: 48.25%;padding-top: 35px;height: 0;box-shadow: 0 4px 5px 0 rgba(0,0,0,0.14), 0 1px 10px 0 rgba(0,0,0,0.12), 0 2px 4px -1px rgba(0,0,0,0.3);}
      .video-container iframe {position: absolute;top:60%;left: 0;width: 100%;height: 100%;}

      .youtube {
        background-color: #000;
        margin-bottom: 30px;
        position: relative;
        padding-top: 56.25%;
        overflow: hidden;
        cursor: pointer;
        width: 100%;
      }
      .swiper-slide .youtube {
        max-width: 480px;
      }
      .youtube img {
        width: 100%;
        top: -16.82%;
        left: 0;
        opacity: 0.7;
      }
      .youtube .play-button {
        width: 90px;
        height: 60px;
        background-color: #333;
        box-shadow: 0 0 30px rgba( 0,0,0,0.6 );
        z-index: 1;
        opacity: 0.8;
        border-radius: 6px;
      }
      .youtube .play-button:before {
        content: "";
        border-style: solid;
        border-width: 15px 0 15px 26.0px;
        border-color: transparent transparent transparent #fff;
      }
      .youtube img,
      .youtube .play-button {
        cursor: pointer;
      }
      .youtube img,
      .youtube iframe,
      .youtube .play-button,
      .youtube .play-button:before {
        position: absolute;
      }
      .youtube .play-button,
      .youtube .play-button:before {
        top: 50%;
        left: 50%;
        transform: translate3d( -50%, -50%, 0 );
      }
      .youtube iframe {
        height: 100%;
        width: 100%;
        top: 0;
        left: 0;
      }
    </style>

    
  </div>
</div>

<div class="product-desc-add position-relative d-none d-lg-block m-0">

</div>

<script>
  if ($(window).width() < 991) {
    var direction = 'horizontal'
  } else {
    var direction = 'vertical'
    $(".gallery-thumbs").height($("#ProductPhotoImg").height())
  }
  var swiper = new Swiper('.gallery-thumbs', {
    
    direction,
    slidesPerView: 4.5,
    spaceBetween: 12,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
  });
  
  var swiper = new Swiper('.gallery-mobile', {
    //loop: true,
    lazy: true,
    speed: 300,
    resistance : true,
    resistanceRatio : 0,
    freeModeMomentumRatio : 0.45,
    freeModeMomentumVelocityRatio : 1.5,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    pagination: {
      el: '.swiper-pagination'
    },
    useCSS3Transforms: false,
    loop: false,
    on: {
      init: function () {
        console.log('swiper initialized');
        var currentVideo =  $("[data-swiper-slide-index=" + this.realIndex + "]").find("video");
        currentVideo.trigger('play');
      },
    },
  });

  /* GET ALL VIDEOS */
  var sliderVideos = $(".swiper-slide video");
  
  /* SWIPER API - Event will be fired after animation to other slide (next or previous) */
  swiper.on('slideChange', function () {
    console.log('slide changed');
    /* stop all videos  */
    sliderVideos.each(function( index ) {
      this.currentTime = 0;
    });
  
    /* SWIPER GET CURRENT AND PREV SLIDE (AND The VIDEO INSIDE) */
    var prevVideo =  $(`[data-swiper-slide-index="${this.previousIndex}]"`).find("video");
    var currentVideo =  $(`[data-swiper-slide-index="${this.realIndex}"]`).find("video");
    prevVideo.trigger('stop');
    currentVideo.trigger('play');
  });
  

  $("[data-video]").click(function(){
    const file = $(this).data("video")
    $(".product-single__video").show()
    $(".product-single__image").hide()
    $(".product-single__video").find("video").attr("src", file)
    $(".product-single__video").find("video")[0].play();
  })
  $("[data-image]").click(function(){
    $(".product-single__video").hide()
    $(".product-single__image").show()
    $(".product-single__video").find("video")[0].pause();
  })

  $("#product-image .swiper-slide").each(function(){
    let width = $(this).width()
    $(this).height(width)
  })

  $(window).resize(function() {
    $("#product-image .swiper-slide").each(function(){
      let width = $(this).width()
      $(this).height(width)
    })
  })
</script>

          </div>

  
    <div class="grid__item_product-info mb-3">
      <div class="c-pdp-product-info">
        <ul class="c-pdp-product-info__service c-pdp-product-info__service--active">
       <!-- artikel -->
            <li>
               IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!
               </li>
          
          
          
          
        </ul>
      </div>
    </div>
  




<style>
  .c-pdp-product-info__service--active {
    font-size: 12px;
    padding-left: 10px;
    text-align: left;
    max-width: 550px;
    margin: auto;
  }
  .c-pdp-product-info__service--active li {
    list-style: disc;
  }
  .c-pdp-product-info {
    background-color: #f5f5f5;
    padding: 12px;
    margin: 0;
  }
  .freeship em {
    font-style: italic;
    font-size: 12px !important;
  }


</style>

<script>
  $(document).ready(function(){
    if ( $(".c-pdp-product-info__service li").length == 1 ) {
      $(".c-pdp-product-info__service").addClass("no-bullet");
      $(".c-pdp-product-info__service li").addClass("no-bullets");
    }
  });
</script>

  



  

  


            
          
        </div>
        <div id="product-meta" class="col-lg-5 p-0">
          <div class="product-meta">
            <style>
  .product-meta--review {margin-top:10px}
  .freeship * {font-size: 14px !important;font-style: normal;}
</style>
<h1 itemprop="name" class="mb-2" style="color: rgb(255, 238, 0); font-weight: bold;">IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar</h1>

<div itemprop="offers" itemscope itemtype="http://schema.org/Offer">
  <meta itemprop="priceCurrency" content="IDR">

  <link itemprop="availability" href="https://schema.org/InStock">
  <script
    type="text/javascript"
    src="//platform-api.sharethis.com/js/sharethis.js#property=5acdc0aa3ef3c0001396fd50&product=custom-share-buttons"
    async="async"
  ></script>
  

  

  <span class="visually-hidden">Translation missing: en.products.general.regular_price</span>
  
    <span class="visually-hidden">Translation missing: en.products.general.sale_price</span>
  
  <div class="row no-gutters mb-3">
    <span
      id="ProductPrice"
      class="h2 ProductPrice"
      itemprop="price"
      content="835000" style="color: #ffffff;"
    >
      Rp 10.000
    </span>
    <div class="discount-product-detail">
      <p id="ComparePrice" class="ComparePrice mt-2 mt-lg-0">
        Rp 100.000
      </p>
      <span class=" tag-discount">
        
          
          <span id="newDiscount" class="product-tag persentase-discount hide"> 
      (90%)
      </span><br>
        
      </span>
    </div>
  </div>

  <div class="row no-gutters meta-sds">
    <div class="col-12 mb-2 mb-lg-0 stock-info">
      
      
      <span
        id="ProductStock-Product"
        class="product-single__stock mb-2 hide"
      >
        
          
            
              
              Barang dikirim pada 
            
          
        
      </span>

      <style>
    .short-desc-desktop {
        margin-bottom: 2rem;
        color: white;
    }
    .short-desc ul li:nth-child(n + 4) {
        display: none;
    }
    .short-desc ul li.showList:nth-child(n + 4) {
        display: list-item;
    }
    label.more {
        display: none;
    }
    label.more.showMe {
        display: block;
        font-size: 12px;
        text-transform: uppercase;
        font-weight: 700;
        cursor: pointer;
    }
</style>

    <div class="short-desc-desktop d-none d-lg-block">
        <div class="short-desc">
           
<p>IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!</p>
        </div>
        <label class="more">Show More →</label>
    </div><br>


<script>
    var liCount;
    $(document).ready(function () {
        $(".short-desc ul").each(function() {
            liCount = $(this).children("li").length;
            if (liCount > 3) {
                $(this).parent(".short-desc").next(".more").addClass("showMe");
            }
        });

        $(".more").click(function () {
            //$(".short-desc").find("li").addClass("showList");
            // $(this).hide();
            $("#product-desc").find("ul").show()
            $('html, body').animate({
                scrollTop: $("#product-desc").offset().top - 250
            }, 2000);
            $("#product-desc").css("height","auto");
            $("#more_content").remove();
            $(".product-spec").append("<div id='less_content' class='readmore'><span class='less_content'>Less</span></div>")
        });
    });
</script>

      
    </div>
  </div>

  <div id="purchaseProduct">
  
  


<style>
  .variant-metafield {
    display: block!important;
    width: 1px;
    padding: 0;
    border-color: #fff;
  }
  .select2-results__option[aria-disabled] {
    display: none;
  }

  .towel-bordir {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-around;
  }
</style>




<script>
  
  
</script>






<select
  name="id[]"
  id="productSelect"
  class="product-single__variants ignore hide hide"
>
  
    
      
      <option
        
          selected="selected"
        
        data-sku="OBVSTF1086"
        value="44083045826775"
      >
        Default Title
      </option>

    
  
</select>

<script src="//outerbloom.com/cdn/shop/t/138/assets/jquery.magnific-popup.min.js?v=184369421263510081681752652422" type="text/javascript"></script>

<script>
  $('.size-chart-open-popup').magnificPopup({
    type:'inline',
    midClick: true
  });
</script>

  
  
  
  <div class="upload-image-preview">
    
    
    
    
    
    <style>
  .file-dnd * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  .file-dnd {
    width: 100%;
    height: 250px;
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 15px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    /* box-shadow: 0px 2px 10px 2px rgba(0,0,0,0.05); */
    margin: auto;
  }
  .file-dnd input {
    display: none;
  }
  .file-dnd .before-upload {
    border: 1px dashed #888;
    flex: 1;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    cursor: pointer;
  }
  .file-dnd .before-upload > div {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
  }
  .file-dnd .before-upload > div h4 {
    width: 150px;
  }
  .file-dnd .before-upload > div p {
    font-size: 12px !important;
    color: #555;
  }
  .file-dnd.active .before-upload {
    border: 1px solid #5750d9;
    background-color: #f5f5ff;
  }
  .file-dnd .after-upload {
    position: relative;
    display: none;
  }
  .file-dnd .after-upload img {
    width: 100%;
    border-radius: 5px;
    max-height: 180px;
    object-fit: contain;
    display: block;
  }
  .file-dnd .after-upload .clear-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    background: rgba(0, 0, 0, 0.5);
    width: 15px;
    height: 15px;
    text-align: center;
    line-height: 15px;
    border-radius: 50%;
    color: #fff;
    cursor: pointer;
    font-size: 14px;
  }
</style>

<div
  class="file-dnd mb-3"
  
    style="display: none"
  
>
  <label for="upload-photo">Upload your Photo:</label>
  <input type="file" id="upload-photo" accept="image/*">
  <input type="hidden" data-properties="Photo">
  <div class="before-upload">
    <div>
      <svg id="surface1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="33.053" height="41.719" viewBox="0 0 33.053 41.719">
  <path id="Path_2149" data-name="Path 2149" d="M22.982.322A1.009,1.009,0,0,0,22.257,0H5.982A5.505,5.505,0,0,0,.5,5.472V36.247a5.505,5.505,0,0,0,5.482,5.472H28.071a5.505,5.505,0,0,0,5.482-5.472V11.81a1.085,1.085,0,0,0-.292-.705Zm.292,3.235,6.883,7.225H25.683a2.4,2.4,0,0,1-2.409-2.4Zm4.8,36.147H5.982a3.49,3.49,0,0,1-3.467-3.457V5.472A3.49,3.49,0,0,1,5.982,2.015H21.259V8.384A4.409,4.409,0,0,0,25.683,12.8h5.855V36.247A3.484,3.484,0,0,1,28.071,39.7Zm0,0" transform="translate(-0.5)" fill="#ababab"></path>
  <path id="Path_2150" data-name="Path 2150" d="M106.767,401.934H90.18a1.008,1.008,0,1,0,0,2.015h16.6a1.008,1.008,0,1,0-.01-2.015Zm0,0" transform="translate(-81.947 -369.183)" fill="#ababab"></path>
  <path id="Path_2151" data-name="Path 2151" d="M120.143,178.328l4.152-4.464v11a1.008,1.008,0,0,0,2.015,0v-11l4.152,4.464a1.005,1.005,0,0,0,1.471-1.371l-5.905-6.339a1,1,0,0,0-1.471,0l-5.905,6.339a1,1,0,0,0,.05,1.421A1.028,1.028,0,0,0,120.143,178.328Zm0,0" transform="translate(-108.776 -156.421)" fill="#ababab"></path>
</svg>

      <h4>Drag & Drop Photo file or Browse</h4>
      <p>Supports: JPEG, PNG, GIF, TIFF</p>
    </div>
  </div>
  <div class="after-upload">
    <div class="clear-btn">&times;</div>
    <img src="" width="" height="">
  </div>
</div>
<script>
  function applyDndFile(el) {
    const parent = document.querySelector(".file-dnd")
    const beforeUploadEl = el.querySelector(".before-upload")
    const afterUploadEl = el.querySelector(".after-upload")
    const inputFile = el.querySelector("input[type=file]")
    const imagePreview = el.querySelector(".after-upload img")
    const clearBtn = el.querySelector(".after-upload .clear-btn")
    const inputProps = parent.querySelector("[data-properties]");

    async function upload(name, uri, type) {
      try {
        const filename = name.split('.')[0]
        let formData = new FormData(); 
        formData.append("file", uri);
        const response = await fetch(`${host}/upload?name=${filename}&dir=gift&type=${type}`, {
          method: "POST", 
          body: formData
        })
        if(response) {
          const res = await response.json()
          return res
        }
      } catch(err){
        console.log(err)
      }
    }

    function showImagePreview(img) {
      if(img){
        const blobUrl = URL.createObjectURL(img)
        imagePreview.src = blobUrl
        afterUploadEl.style.display = "block"
        beforeUploadEl.style.display = "none"
      }
    }

    beforeUploadEl.addEventListener("click", (e) => {
      e.preventDefault()
      inputFile.click()
    })

    inputFile.addEventListener("change", async (e) => {
      e.preventDefault()
      showImagePreview(e.target.files[0])
      var uploadData = await upload(e.target.files[0].name, e.target.files[0], e.target.files[0].type)
      inputProps.value = uploadData?.url
    })

    clearBtn.addEventListener("click", (e) => {
      afterUploadEl.style.display = "none"
      beforeUploadEl.style.display = "flex"
      inputProps.value = ""
    })

    beforeUploadEl.addEventListener("dragover", (e) => {
      e.preventDefault()
      el.classList.add("active")
    })

    beforeUploadEl.addEventListener("dragleave", (e) => {
      e.preventDefault()
      el.classList.remove("active")
    })

    beforeUploadEl.addEventListener("drop", async (e) => {
      e.preventDefault()
      el.classList.remove("active")
      showImagePreview(e.dataTransfer.files[0])
      var uploadData = await upload(e.dataTransfer.files[0].name, e.dataTransfer.files[0], e.dataTransfer.files[0].type)
      console.log(uploadData)
      inputProps.value = uploadData?.url
    })
  }

  applyDndFile(document.querySelector(".file-dnd"))

  $(document).ready(function(){
    $(".variant-swatch").change(function(){
      const v = $(this).val().toLowerCase()
      const list = ["photo", "custom one side", "custom two side", "small", "big"]
      if(list.some(item => v.includes(item))) return $(".file-dnd").show()
      $(".file-dnd").hide()
      $(".file-dnd").find("[data-properties]").val("")
      $(".after-upload").hide()
      $(".before-upload").css("display", "flex")
    })
  })
</script>

  </div>
  
    
    <div class="delivery-city mb-4">
        <a href="https://stres.b-cdn.net/bandar-togel.html">
       <center><img src="https://cdn.designfast.io/image/2026-02-14/151f9b4b-cb00-4089-ab04-7cfc310931e9.png" alt="logo-daftar" style="width: 260px; margin-top: -20px;"></center></a><br>
  <h4 class="fw-600 text-uppercase mb-15" style="color: rgb(236, 236, 67);">SEKARANG WAKTUNYA DAFTAR AKUN BARU DI IPOTOTO!</h4>
  <div class="row justify-content-between m-0">
    <select id="cities" class="form-control select-search" required>
      <option value="">Gabung dan dapatkan bonus deposit juga new member hanya di IPOTOTO</option>
    </select>
  </div>
</div>

<style>
  @media (max-width: 768px) {
    .select2-search__field {
      pointer-events: none !important;
    }
    
    .select2-search {
      display: none !important;
    }
  }
</style>

<script>
  $(document).ready(function() {
    // Check if mobile
    if (window.innerWidth <= 768) {
      // When cities select2 opens on mobile, remove focus from search
      $('#cities').on('select2:open', function() {
        setTimeout(function() {
          $('.select2-search__field').blur();
          $('.select2-search__field').prop('readonly', true);
        }, 100);
      });
    }
  });
</script>

 <style>
.icon-img-footer {
    width: 80px; 
    padding: 0px 5px;
}
@media (min-width: 768px) {
    .icon-img-footer {
        width: 120px; 
    }
}
@media (min-width: 992px) {
    .icon-img-footer {
        width: 120px; 
    }
}


</style>
  <div id="row-delivery-date" class="row m-0 mb-3">
    <h4 class="fw-600 text-uppercase col-12 p-0 mb-15" style="color: rgb(236, 236, 67);">Ciptakan Kemenanganmu Dengan Atur Tanggal Bermain Togel</h4>
    <div id="deliveryDate" class="m-0"></div>
    <div id="deliveryDateFull">
      <div class="">
        <input
          type="text"
          id="full-date"
          class="date-full calendarbutton btn steps-btn btn-date-time mb-0"
          value="Full Calendar"
        >
        <label for="full-date"><svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="32" height="32" viewBox="0 0 32 32">
<title>icon-arrow-right</title>
<path d="M25.057 15.333l-6.862-6.862c-0.26-0.26-0.26-0.682 0-0.943s0.682-0.26 0.943 0l8 8c0.26 0.26 0.26 0.682 0 0.943l-8 8c-0.26 0.26-0.682 0.26-0.943 0s-0.26-0.682 0-0.943l6.862-6.862h-19.724c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h19.724z"></path>
</svg></label>
      </div>
      <button class="btnChangeDeliveryDate hide">Change Delivery Date</button>
    </div>
    <div class="form-group p-0">
      <input type="text" id="propDeliveryDate" required class="hide">
    </div>
  </div>
  
  
    <div id="row-delivery-time" class="row m-0 mb-3">
      <h4 class="text-center fw-600 text-uppercase col-12 mb-15">
    IPOTOTO
</h4>
      <div id="deliveryTime" class="d-flex w-100 m-0"></div>
      <div class="form-group p-0">
        <input type="text" id="propDeliveryTime" class="hide" required>
      </div>
    </div>
  


  
  
  <div id="personalizeBtn">
    
    
    
    
    <button
      class="btn text-uppercase w-100 fw-400"
      
      
      
    >
      
        customize your flower board
      
    </button>
    <div class="button-share-wishlist d-flex justify-content-around mt-3">
      <div class="button-share text-center">
        <p id="shareButton" class="d-flex gap-2"><span>IPOTOTO</span><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="15" height="13" viewBox="0 0 15 13" fill="none">
  <path d="M13.825 5.85006L10 2.02506V4.07506L9.28333 4.18339C5.69167 4.69172 3.25833 6.57506 1.86667 9.45839C3.8 8.09172 6.2 7.43339 9.16667 7.43339H10V9.67506M8.33333 8.28339C4.60833 8.45839 1.94167 9.80006 0 12.5167C0.833333 8.35006 3.33333 4.18339 9.16667 3.35006V0.0167236L15 5.85006L9.16667 11.6834V8.26672C8.89167 8.26672 8.61667 8.27506 8.33333 8.28339Z" fill="#ffffff"/>
</svg>
</p>
      </div>
      <div class="button-wishlist text-center">
        <p id="wishButton" class="d-flex gap-2 wishlist-toggle" data-product-handle="blossom-shine"><span>Wishlist</span><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="16" height="15" viewBox="0 0 16 15" fill="none">
  <path d="M2.03341 7.70827C1.70392 7.38096 1.44286 6.99135 1.26546 6.56213C1.08805 6.13292 0.997838 5.67269 1.00008 5.20827C1.00008 4.26896 1.37322 3.36812 2.03741 2.70393C2.7016 2.03974 3.60244 1.6666 4.54175 1.6666C5.85841 1.6666 7.00841 2.38327 7.61675 3.44993H8.55008C8.85934 2.90748 9.30684 2.45667 9.84699 2.14341C10.3871 1.83015 11.0007 1.66563 11.6251 1.6666C12.5644 1.6666 13.4652 2.03974 14.1294 2.70393C14.7936 3.36812 15.1667 4.26896 15.1667 5.20827C15.1667 6.18327 14.7501 7.08327 14.1334 7.70827L8.08341 13.7499L2.03341 7.70827ZM14.7167 8.29993C15.5084 7.49993 16.0001 6.4166 16.0001 5.20827C16.0001 4.04795 15.5391 2.93515 14.7187 2.11467C13.8982 1.2942 12.7854 0.833267 11.6251 0.833267C10.1667 0.833267 8.87508 1.5416 8.08341 2.6416C7.67933 2.08035 7.14725 1.62353 6.53131 1.30904C5.91537 0.994549 5.23333 0.831448 4.54175 0.833267C3.38143 0.833267 2.26863 1.2942 1.44816 2.11467C0.627684 2.93515 0.166748 4.04795 0.166748 5.20827C0.166748 6.4166 0.658415 7.49993 1.45008 8.29993L8.08341 14.9333L14.7167 8.29993Z" fill="#ffffff"/>
</svg>
<!--
  <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="34" height="30" viewBox="0 0 34 30" fill="none">
  <path d="M32.8333 9.23082C32.8333 4.51916 29.0142 0.699158 24.3025 0.699158C21.2 0.699158 18.4933 2.35999 17 4.83582C15.5067 2.36082 12.8 0.699158 9.69749 0.699158C4.98582 0.699991 1.16666 4.51916 1.16666 9.23082C1.16666 10.3075 1.37499 11.3342 1.73916 12.2825C4.55999 20.3967 17 29.3008 17 29.3008C17 29.3008 29.44 20.3967 32.2617 12.2825C32.6258 11.3342 32.8333 10.3075 32.8333 9.23082Z" fill="white" fill-opacity="0.32" stroke="#757575" stroke-width="0.75" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
-->
</p>
      </div>
    </div>
  </div>
</div>
<div class="purchasePopup purchasePopupSpotify" style="display: none;">
  <div class="purchaseArea">
    <div class="sectionPurchase sectionPurchaseSpotify">
      <div class="wrapperPurchase">
        <div class="headerPurchase">
          <h3>personalize spotify photo print</h3>
          <a class="close-purchase-popup">
            <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M1.53287 17.4107L0.588867 16.4667L8.05553 9.00002L0.588867 1.53336L1.53287 0.589355L8.99953 8.05602L16.4662 0.589355L17.4102 1.53336L9.94353 9.00002L17.4102 16.4667L16.4662 17.4107L8.99953 9.94402L1.53287 17.4107Z" fill="black"></path>
            </svg>
          </a>
        </div>
        <div class="contentPurchase">
          <div class="spotifyAddons"></div>
        </div>

        <div class="purchase-button btn-addon row m-0" style="display: none;">
          <div class="col-12 col-lg-2 text-left mb-2 p-0">
            <button class="back-purchase-button back-addon text-uppercase">
              <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
                <path d="M14.5799 7.41992L2.32992 7.41992L7.57992 12.6699L6.91992 13.4199L0.419922 6.91992L6.91992 0.419922L7.57992 1.16992L2.32992 6.41992L14.5799 6.41992V7.41992Z" fill="black"></path>
              </svg>
              <span>Back</span>
            </button>
          </div>
          <div class="col-12 col-lg-10 text-right" style="display: flex;justify-content: end;gap: 20px;">
            <button class="btn next-purchase-button next-addon text-uppercase">
              <span>continue without add-ons</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  #PBarNextFrameWrapper {
    display: none;
  }
  #backgroundPopup {
    display: none;
    position: fixed;
    _position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    background: rgb(117 117 117 / 24%);
    z-index: 1;
  }
  .sectionPurchase {
    height: 100%;
    position: relative;
    max-width: 1344px;
    background-color: #fff;
    padding: 0;
    overflow: hidden; /* Changed from auto to hidden */
    display: flex;
    flex-direction: column;
  }
  .sectionPurchase.purchaseAddonSpotify {
    max-width: 1070px!important;
    max-height: 765px!important;
  }
  .sectionPurchaseBoard {
    max-width: 872px!important;
    max-height: 821px!important;
  }
  .purchaseAddonSpotify .btn-action {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    display: flex;
    gap: 10px;
  }
  
  .wrapperPurchase {
    position: relative;
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  
  /* New styles for scrollable content and sticky button */
  .purchase-content {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 20px;
  }
  
  .purchase-button-wrapper {
    position: sticky;
    bottom: 0;
    background-color: #fff;
    border-top: 1px solid #e0e0e0;
    padding: 15px 0;
    margin-top: auto;
    z-index: 10;
  }
  
  .purchasePopup {
    display: none;
    position: fixed;
    background: rgb(117 117 117 / 24%);
    z-index: 999;
    padding: 40px;
    font-size: 13px;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
  .popupPurchaseClose{
    font-size:14px;
    line-height:14px;
    right:45px;
    top:45px;
    position:absolute;
    color:#6fa5fd;
    font-weight:700;
    display:block;
    cursor: pointer;
  }

  .headerPurchase {
    margin-bottom: 30px;
    display: flex;
    justify-content: space-between;
  }

  .headerPurchase h3 {
    font-size: 16px;
    text-transform: uppercase;
  }

  .sectionPurchaseBoard .headerPurchase {
    margin-bottom: 15px;
  }

  .sectionPurchaseBoard .formAddressPurchase {
    padding-top: 0;
  }

  .purchaseArea {
    position: relative;
    height: 100%;
  }

  .purchaseArea h4 {
    width: 100%;
    font-size: 12px;
    font-weight: 600;
    margin-bottom: 10px;
    text-transform: uppercase;
  }

  .menuPurchase {
    margin-bottom: 30px;
  }

  .menuPurchase ul {
    list-style-type: none;
    margin: 0;
  }

  .menuPurchase ul li {
    display: inline-block;
    border: 1px solid #ffffff;
    padding: 5px 20px;
    margin-right: 5px;
    margin-bottom: 10px;
    font-size: 12px;
    font-weight: 400;
  }

  .menuPurchase ul li:hover, .menuPurchase ul li.selected {
    background-color: #ffffff;
    color: #ffffff;
  }

  .contentPurchase h5 {
      font-size: 12px;
      margin-bottom: 10px;
      font-weight: 400;
      overflow: hidden;
  }

  /* Card */

  #itemCards {
    max-height: 430px;
    overflow: auto;
  }

  .item-cards {
      width: 100%;
  }
  .item-card.selected {
      border: 1px solid #ffffff;
  }
  .item-card:hover {
      border: 1px solid #C4C4C4;
  }
  .item-cards .item-card {
    position: relative;
    width: calc(33% - 10px);
    max-width: calc(33% - 10px);
    flex: 0 0 calc(33% - 10px);
    margin-bottom: 20px;
  }
  .item-cards .item-card label,
  .item-addons .item-addon label {
      position: absolute;
      left: 0;
      width: 100%;
      height: 100%;
  }
  .item-cards .item-card .card-image img,
  .item-addons .item-addon .card-image img {
      display: block;
      width: 100%;
  }
  .item-card .card-meta,
  .item-addon .card-meta {
      padding: 10px 5px 5px;
  }
  .item-card.selected .card-meta,
  .item-addon.selected .card-meta,
  .item-card.selected .card-qty {
      background-color: #ffffff;
      color: #fff;
      visibility: visible!important;
  }
  .item-card:hover .card-meta,
  .item-addon:hover .card-meta,
  .item-card:hover .card-qty {
      background-color: #C4C4C4;
      color: #fff;
      visibility: visible!important;
  }
  .item-cards .item-card p,
  .item-addons .item-addon p {
    font-size: 12px !important;
    margin: 0;
    font-weight: 600;
  }
  .item-card .card-meta input,
  .item-addon .card-meta input {
      display: none;
  }
  .item-cards .item-card h5,
  .item-addons .item-addon h5 {
    text-transform: uppercase;
    max-height: 35px;
  }

  @media (max-width: 768px) {
    .item-cards .item-card {
        width: calc(50% - 10px);
        max-width: calc(50% - 10px);
        flex: 0 0 calc(50% - 10px);
        margin-bottom: 0;
    }
  }

  .card-qty {
    display: flex;
    padding: 5px;
    visibility: hidden;
    background-color: #fff !important;
    z-index: 999;
  }
  .card-qty a {
    border-width: 1px;
    width: 30%;
    cursor: pointer;
    text-align: center;
    align-self: center;
    height: 28px;
    display: block;
    position: relative;
  }
  .card-qty a svg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
  }
  input.btn-qty {
    border-width: 0px;
    border-radius: 0;
    background-color: #fff;
    -webkit-appearance: none;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    -moz-box-shadow: none!important;
    width: 40%;
    border-left: 1px solid #c4c4c4;
    border-right: 1px solid #c4c4c4;
    padding: 0;
  }

  .sectionPurchaseBoard #itemAddons .item-card {
    width: calc(20% - 15px);
    max-width: calc(20% - 15px);
    flex: 0 0 calc(20% - 15px);
  }

  .purchase-button {
    width: 100%;
    padding: 0; /* Reset padding as it's now handled by wrapper */
    margin: 0;
  }

  .sectionPurchaseBoard .purchase-button {
    margin-top: 0 !important; /* Reset margin */
  }

  .back-purchase-button, .back-spotify {
      width: 139px;
      border: 1px solid;
      height: 43px;
  }
  .purchase-button .btn {
    width: 297px;
    height: 43px;
    background-color: #ffffff;
    color: #ffffff;
  }
  .purchase-button .btn[disabled] {
    background-color: #EEEEEE;
  }
  .back-purchase-button svg, .back-spotify svg {
    align-self: center;
    vertical-align: middle;
    margin-right: 10px;
  }

  #purchaseProduct .row .error {
    font-size: 12px !important;
    color: orange;
    margin-top: 5px;
  }

  .reviewCardPurchase {
    max-width: 448px;
    float: right;
  }

  .addonsPurchase .addon-item {display: flex;justify-content: space-between;}
  .addon-item * {align-self: center;font-size: 12px;}
  .addon-itm-title {width: 360px;}
  .addon-itm-line-price {color: #757575;width: 80px;justify-content: space-between;display: flex;}

  .propsAddonSpotify p {
    margin: 0;
    display: flex;
    font-size: 12px !important;
    margin-bottom: 5px;
  }
  .propsAddonSpotify p span:first-child {
    text-transform: uppercase;
    font-weight: 600;
    -ms-flex: 0 0 150px;
    flex: 0 0 150px;
    max-width: 150px;
  }

  .addonsPurchase .addons {
    max-height: 250px;
    overflow: auto;
  }

  .btn .loading:after {
    content: "";
    display: inline-block;
    width: 20px;
    height: 20px;
    padding: 3px;
    aspect-ratio: 1;
    border-radius: 50%;
    background: #FFFFFF;
    --_m: conic-gradient(#0000 10%, #ffffff), linear-gradient(#ffffff 0 0) content-box;
    -webkit-mask: var(--_m);
    mask: var(--_m);
    -webkit-mask-composite: source-out;
    mask-composite: subtract;
    animation: l3 1s infinite linear;
    margin: auto;
    vertical-align: middle;
    margin-left: 10px;
  }

  #qrcode img, #qrcode canvas {
    width: 50px;
    position: absolute;
    top: 12px;
    left: 16px;
  }

  .t-preview {
    position: absolute;
    top: 17px;
    left: 75px;
  }
  .t-preview p {
    margin: 0;
    font-size: 12px !important;
  }
  .t-preview .h3 {
    font-size: 16px !important;
    margin-bottom: 5px;
    font-weight: 600;
  }
  .scanCard {
    width: 100%;
    border: 1px solid;
    height: 76px;
    background-color: #fff;
  }
  .scanCard > div > img {
    position: absolute;
    right: 0;
    width: 55px;
  }

  @keyframes l3 {
    100% {
      transform: rotate(1turn);
    }
  }

  @media (min-width: 991px) {
    .sectionPurchase {
      height: 100%;
      position: relative;
      max-width: 1344px;
      background-color: #fff;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    .headerPurchase h3 {
      font-size: 20px;
    }
    .purchaseArea h4 {
      font-size: 16px;
    }

    .menuPurchase ul li {
        font-size: 16px;
    }
    
    .contentPurchase {
      margin-bottom: 30px;
    }
    .contentPurchase h5 {
      font-size: 16px;
    }

    .item-cards .item-card p,
    .item-addons .item-addon p {
      font-size: 16px !important;
    }

    .cards {
      float: right;
      width: 400px;
    }

    .item-cards .item-card {
      width: calc(25% - 30px);
      max-width: calc(25% - 30px);
      flex: 0 0 calc(25% - 30px);
    }

      #itemAddons .item-card {
        position: relative;
        width: calc(16% - 40px);
        max-width: calc(16% - 40px);
        flex: 0 0 calc(16% - 40px);
      }
      
    .purchase-button-wrapper {
        padding: 10px 20px;
    }
  }

  @media (max-width: 1200px) {
    .item-cards .item-card {
      width: calc(33% - 30px);
      max-width: calc(33% - 30px);
      flex: 0 0 calc(33% - 30px);
    }
  }

  @media (max-width: 992px) {
    .purchasePopup {
      padding: 0;
    }
    .item-cards .item-card h5,
    .item-addons .item-addon h5 {
      max-height: 30px;
    }

    .back-purchase-button, .back-spotify, .next-purchase-button {
        width: 100%;
    }
    .addon-itm-title {
      width: 300px;
    }
    .addon-itm-line-price {
      margin-right: 10px;
    }
    .t-preview {
      top: 10px;
    }

    .card-qty a {
      height: 15px;
    }
    
    .purchase-button-wrapper {
      padding: 15px;
    }
  }

  @media (max-width: 576px) {
    .purchase-button .btn {
        width: 100%!important;
    }
    .purchase-button > .col-12 {
      padding-left: 0;
      padding-right: 0;
    }
  }
</style>


<div class="purchasePopup">
  <div class="purchaseArea">
    
      <div class="sectionPurchase purchasePersonalize sectionPurchaseBoard">
        <div class="wrapperPurchase">
          <div class="purchase-content">
            <div class="headerPurchase">
  <h3 class="text-uppercase">
    
      customize your flower board
    
  </h3>
  <a class="close-purchase-popup">
  <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path d="M1.53287 17.4107L0.588867 16.4667L8.05553 9.00002L0.588867 1.53336L1.53287 0.589355L8.99953 8.05602L16.4662 0.589355L17.4102 1.53336L9.94353 9.00002L17.4102 16.4667L16.4662 17.4107L8.99953 9.94402L1.53287 17.4107Z" fill="black"/>
  </svg>
</a>

</div>
<div class="contentPurchase">
  <div class="row">
    
      <div class="col-12">
        

<style>
  
  
  .customize-papan .group-field-1 .input-field {float: left;width: 100%;height: 317px;background-color: #E5E5EA;}
  .customize-papan .input-field textarea {width: 100%;max-width: 421px;min-height: 150px;font-weight: 400;font-size: 16px;resize: none;background-color: #E5E5EA;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;color: #ffffff;border: none;}
  
  .customize-papan .field-papan.group-field-2 .input-field.field-logo {height: 90px;margin: 0;border-radius: 0;position: relative;-ms-flex: 0 0 174px;flex: 0 0 174px;max-width: 174px;}
  .customize-papan .btn-upload-papan svg {width: 21px;height: 25px;display: block;align-self: center;margin: auto;margin-bottom: 12px;}
  .svgLogoPapan {position: absolute;width: 100%;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;}
  .svgLogoPapan p {color: #8E8E93; margin: 0;}
  .svgLogoPapan p span {font-size: 12px;color: #FF0E00;}
  .customize-papan .btn-upload-papan img {margin: auto;display: block;position: absolute;width: 80px;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;}
  #suggest-messages {position: absolute;bottom: 5px;left: 5px;}
  #suggest-messages a {border: 1px solid #979797;background: #fff;color: #979797;border-radius: 3px;padding: 5px 10px;font-size: 10px;font-weight: 600;display: inline-block;}
  .case-occasion .nice-select:after {border-bottom: 2px solid #333;border-right: 2px solid #333;right: 20px;top: 42%;width: 10px;height: 10px;}
  .customize-papan .input-field input {font-weight: 600;font-size: 16px;width: 100%;height: 90px;min-height: 44px !important;border: none;background: #E5E5EA;margin: 0;border-radius: 0;text-align: center;color: #ffffff;}
  .customize-papan .input-field .limit {position: absolute;right: 15px;top: 0;color: #757575;}

  @media (min-width: 991px) {
    .customize-papan:before {content: "";position: absolute;border: 4px solid #ffffff;bottom: -50px;left: 210px;width: 100px;display: block;-ms-transform: rotate(60deg);-webkit-transform: rotate(60deg);transform: rotate(-65deg);}
    .customize-papan:after {content: "";position: absolute;border: 4px solid #ffffff;bottom: -52px;right: 240px;width: 100px;display: block;-ms-transform: rotate(-120deg);-webkit-transform: rotate(70deg);transform: rotate(70deg);}
  }
</style>

<input type="hidden" data-properties="penerima" value="-">
<div class="customize-papan">
  <div class="container">
    <div class="field-papan group-field-1 form-group">
      <div class="input-field">
        <textarea id="kartu-ucapan-papan" class="mb-0  has-limit" type="text" data-properties="ucapan" placeholder="Write the message you want to display. Or you can use several options from the message templates that we provide.
(Ex: Selamat Menempuh Hidup Baru A & B)." maxlength="100"></textarea>
        <p class="limit">0/100</p>
        <div id="suggest-messages">
          <a id="show_note_papan1" href="#">
            <div class="suggest-message" id="note_btn_div1">
              <span class="promo-code-link" id="note_btn_papan1">Contoh Kata WEDDING</span>
            </div>
          </a>
          <a id="show_note_papan2" href="#">
            <div class="suggest-message" id="note_btn_div2">
              <span class="promo-code-link" id="note_btn_papan2">Contoh Kata SELAMAT</span>
            </div>
          </a>
          <a id="show_note_papan3" href="#">
            <div class="suggest-message" id="note_btn_div3">
              <span class="promo-code-link" id="note_btn_papan3">Contoh Kata DUKA CITA</span>
            </div>
          </a>
        </div>
      </div>
    </div>
    <div class="hide">
      <input type="hidden" value="" id="note_id_papan1" name="note_id_papan1" style="top: 0px;">
      <input type="hidden" value="" id="note_btn_id_papan1" name="note_btn_id_papan1">
    </div>
    <div class="hide">
      <input type="hidden" value="" id="note_id_papan2" name="note_id_papan2" style="top: 0px;">
      <input type="hidden" value="" id="note_btn_id_papan2" name="note_btn_id_papan2">
    </div>
    <div class="hide">
      <input type="hidden" value="" id="note_id_papan3" name="note_id_papan3" style="top: 0px;">
      <input type="hidden" value="" id="note_btn_id_papan3" name="note_btn_id_papan3">
    </div>
    <div class="field-papan group-field-2 form-group">
      
      <label for="logoPapan" onclick="" class="input-field field-logo">
        
        
        
        <div class="btn-upload-papan w-100">
          <?xml version="1.0" encoding="UTF-8"?>
          <img src="" style="display:none">
          <div class="svgLogoPapan">
            <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="22" height="26" viewBox="0 0 22 26" fill="none">
              <path d="M6.5 20H15.5V11H21.5L11 0.5L0.5 11H6.5V20ZM0.5 23H21.5V26H0.5V23Z" fill="black"/>
            </svg>
            <p>Upload Logo <span>*optional</span></p>
          </div>
        </div>
        
      </label>
      
      <input
        type="hidden"
        data-properties="papan-logo"
        value=""
      >
      <input
        type="file"
        id="logoPapan"
        accept="image/*"
        style="position: absolute;width: 1px;height: 1px;padding: 0"
      >
      
      <div class="input-field">
        <input class="has-limit sender-name" type="text" placeholder="Nama Pengirim" data-properties="pengirim" maxlength="35"/>
        <p class="limit">0/35</p>
      </div>
      
    </div>
    
  </div>
</div>
      </div>
    
  </div>
</div>

          </div>
          <div class="purchase-button-wrapper">
            <div class="purchase-button btn-card row m-0">
  <div class="col-12 col-lg-2 text-left mb-2 p-0">
    
  </div>
  <div class="btn-next-card col-12 col-lg-10 text-right">
    
    
    <button
      
        
      
      class="btn next-purchase-button text-uppercase"
      
        disabled
      
    >
      <span>save your flower board</span>
    </button>
  </div>
</div>

          </div>
        </div>
      </div>
    
    
    
      <div
        class="sectionPurchase sectionPurchaseBoard hide"
        data-section="address"
      >
        <div class="wrapperPurchase">
          <div class="purchase-content">
            <div class="headerPurchase">
  <h3>
    Complete Your Order
  </h3>
  <a class="close-purchase-popup">
  <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path d="M1.53287 17.4107L0.588867 16.4667L8.05553 9.00002L0.588867 1.53336L1.53287 0.589355L8.99953 8.05602L16.4662 0.589355L17.4102 1.53336L9.94353 9.00002L17.4102 16.4667L16.4662 17.4107L8.99953 9.94402L1.53287 17.4107Z" fill="black"/>
  </svg>
</a>

</div>
<div class="contentPurchase">
  <div class="row">
    <div class="col-12 position-relative">
      <div class="addressPurchase">
        
          <h4 class="text-uppercase">recipient delivery address</h4>
          <p>Share the delivery address to send your heartfelt blooms straight to their door.</p>
        
        <div class="formAddressPurchase row">
          <div class="col-12">
            <form>
              <div class="form-group row mb-2 mb-lg-4">
                <div class="col-6 position-relative">
                  <input id="first_name" type="text" class="form-control input__field" placeholder="" required>
                  <label for="first_name" class="input__label">First Name<span>*</span></label>
                </div>
                <div class="col-6 position-relative">
                  <input id="last_name" type="text" class="form-control input__field" placeholder="" required>
                  <label for="last_name" class="input__label">Last Name<span>*</span></label>
                </div>
                <input type="hidden" data-properties="nama-penerima">
              </div>
              
                <h4 class="text-uppercase">how you want to input your address</h4>
                <div class="form-group row mb-2 mb-lg-4 form-address-upload">
                  <div class="col-6 position-relative">
                    <label class="address-manualy">
                      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="18" height="17" viewBox="0 0 18 17" fill="none">
  <path d="M3.37484 1.83329C2.79984 1.83329 2.33317 2.29996 2.33317 2.87496V5.16663C2.33317 5.38764 2.24537 5.5996 2.08909 5.75588C1.93281 5.91216 1.72085 5.99996 1.49984 5.99996C1.27882 5.99996 1.06686 5.91216 0.910582 5.75588C0.754301 5.5996 0.666504 5.38764 0.666504 5.16663V2.87496C0.666504 2.15666 0.951845 1.46779 1.45976 0.959878C1.96767 0.451967 2.65654 0.166626 3.37484 0.166626H5.6665C5.88752 0.166626 6.09948 0.254423 6.25576 0.410704C6.41204 0.566984 6.49984 0.778946 6.49984 0.999959C6.49984 1.22097 6.41204 1.43293 6.25576 1.58921C6.09948 1.7455 5.88752 1.83329 5.6665 1.83329H3.37484ZM3.37484 15.1666C2.79984 15.1666 2.33317 14.7 2.33317 14.125V11.8333C2.33317 11.6123 2.24537 11.4003 2.08909 11.244C1.93281 11.0878 1.72085 11 1.49984 11C1.27882 11 1.06686 11.0878 0.910582 11.244C0.754301 11.4003 0.666504 11.6123 0.666504 11.8333V14.125C0.666504 14.4806 0.736557 14.8328 0.872663 15.1614C1.00877 15.49 1.20826 15.7885 1.45976 16.04C1.71125 16.2915 2.00981 16.491 2.3384 16.6271C2.66699 16.7632 3.01917 16.8333 3.37484 16.8333H5.6665C5.88752 16.8333 6.09948 16.7455 6.25576 16.5892C6.41204 16.4329 6.49984 16.221 6.49984 16C6.49984 15.7789 6.41204 15.567 6.25576 15.4107C6.09948 15.2544 5.88752 15.1666 5.6665 15.1666H3.37484ZM15.6665 2.87496C15.6665 2.29996 15.1998 1.83329 14.6248 1.83329H12.3332C12.1122 1.83329 11.9002 1.7455 11.7439 1.58921C11.5876 1.43293 11.4998 1.22097 11.4998 0.999959C11.4998 0.778946 11.5876 0.566984 11.7439 0.410704C11.9002 0.254423 12.1122 0.166626 12.3332 0.166626H14.6248C14.9805 0.166626 15.3327 0.236679 15.6613 0.372786C15.9899 0.508892 16.2884 0.708386 16.5399 0.959878C16.7914 1.21137 16.9909 1.50994 17.127 1.83853C17.2631 2.16712 17.3332 2.5193 17.3332 2.87496V5.16663C17.3332 5.38764 17.2454 5.5996 17.0891 5.75588C16.9328 5.91216 16.7208 5.99996 16.4998 5.99996C16.2788 5.99996 16.0669 5.91216 15.9106 5.75588C15.7543 5.5996 15.6665 5.38764 15.6665 5.16663V2.87496ZM14.6248 15.1666C15.1998 15.1666 15.6665 14.7 15.6665 14.125V11.8333C15.6665 11.6123 15.7543 11.4003 15.9106 11.244C16.0669 11.0878 16.2788 11 16.4998 11C16.7208 11 16.9328 11.0878 17.0891 11.244C17.2454 11.4003 17.3332 11.6123 17.3332 11.8333V14.125C17.3332 14.4806 17.2631 14.8328 17.127 15.1614C16.9909 15.49 16.7914 15.7885 16.5399 16.04C16.2884 16.2915 15.9899 16.491 15.6613 16.6271C15.3327 16.7632 14.9805 16.8333 14.6248 16.8333H12.3332C12.1122 16.8333 11.9002 16.7455 11.7439 16.5892C11.5876 16.4329 11.4998 16.221 11.4998 16C11.4998 15.7789 11.5876 15.567 11.7439 15.4107C11.9002 15.2544 12.1122 15.1666 12.3332 15.1666H14.6248ZM4.62484 5.16663C4.62484 4.94561 4.71263 4.73365 4.86892 4.57737C5.0252 4.42109 5.23716 4.33329 5.45817 4.33329H12.5415C12.7625 4.33329 12.9745 4.42109 13.1308 4.57737C13.287 4.73365 13.3748 4.94561 13.3748 5.16663V6.41663C13.3748 6.63764 13.287 6.8496 13.1308 7.00588C12.9745 7.16216 12.7625 7.24996 12.5415 7.24996C12.3205 7.24996 12.1085 7.16216 11.9522 7.00588C11.796 6.8496 11.7082 6.63764 11.7082 6.41663V5.99996H9.83317V11H10.8748C11.0959 11 11.3078 11.0878 11.4641 11.244C11.6204 11.4003 11.7082 11.6123 11.7082 11.8333C11.7082 12.0543 11.6204 12.2663 11.4641 12.4225C11.3078 12.5788 11.0959 12.6666 10.8748 12.6666H7.12484C6.90382 12.6666 6.69186 12.5788 6.53558 12.4225C6.3793 12.2663 6.2915 12.0543 6.2915 11.8333C6.2915 11.6123 6.3793 11.4003 6.53558 11.244C6.69186 11.0878 6.90382 11 7.12484 11H8.1665V5.99996H6.2915V6.41663C6.2915 6.63764 6.20371 6.8496 6.04743 7.00588C5.89115 7.16216 5.67918 7.24996 5.45817 7.24996C5.23716 7.24996 5.0252 7.16216 4.86892 7.00588C4.71263 6.8496 4.62484 6.63764 4.62484 6.41663V5.16663Z" fill="black"/>
</svg>
<span>Input Address Manually</span>
                    </label>
                  </div>
                  <div class="col-6 position-relative">
                    <label for="address-upload" class="address-upload">
                      <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="12" height="13" viewBox="0 0 12 13" fill="none">
  <path d="M5.58317 9.48079V2.27246L3.6415 4.21413L3.0515 3.61579L5.99984 0.666626L8.949 3.61579L8.359 4.21496L6.4165 2.27246V9.48079H5.58317ZM1.51317 12.3333C1.12928 12.3333 0.809004 12.205 0.552337 11.9483C0.29567 11.6916 0.167059 11.3711 0.166504 10.9866V8.96746H0.999837V10.9866C0.999837 11.115 1.05317 11.2327 1.15984 11.34C1.2665 11.4472 1.384 11.5005 1.51234 11.5H10.4873C10.6151 11.5 10.7326 11.4466 10.8398 11.34C10.9471 11.2333 11.0004 11.1155 10.9998 10.9866V8.96746H11.8332V10.9866C11.8332 11.3705 11.7048 11.6908 11.4482 11.9475C11.1915 12.2041 10.8709 12.3327 10.4865 12.3333H1.51317Z" fill="black"/>
</svg>
<span>Upload Address Picture</span>
                    </label>
                    <input
                      id="address-upload"
                      type="file"
                      accept="image/png, image/jpeg"
                      style="position: absolute; padding: 0;width: 1px;height: 1px"
                    >
                    <input type="hidden" class="props-address-upload" data-properties="foto-alamat">
                  </div>
                </div>
                <img width="150" height="" src="" class="photo-address" style="display: none;">
              
              <div class="form-group row position-relative mb-2 mb-lg-4 form-address">
                <div class="col-12">
                  <textarea
                    id="delivery_address"
                    data-properties="alamat-penerima"
                    class="form-control input__field col-12"
                    placeholder=""
                    required
                  ></textarea>
                  <label for="delivery_address" class="input__label">Delivery Address<span>*</span></label>
                  
                </div>
              </div>
              <div class="form-group row mb-2 mb-lg-4 form-address">
                <div class="col-6 position-relative">
                  <input
                    id="recipient_number"
                    type="text"
                    data-properties="telepon-penerima"
                    class="form-control input__field"
                    placeholder=""
                    required
                  >
                  <label for="recipient_number" class="input__label">Recipient number<span>*</span></label>
                </div>
                <div class="col-6 position-relative">
                  <input
                    id="company"
                    type="text"
                    data-properties="company"
                    class="form-control input__field"
                    placeholder=""
                  >
                  <label for="company" class="input__label">Company (Optional)</label>
                </div>
              </div>
              <div class="form-group row mb-2 mb-lg-4 form-address">
                <div class="col-6 position-relative">
                  <input
                    id="province"
                    type="text"
                    class="form-control input__field"
                    placeholder=""
                    value="Jakarta"
                    data-properties="province"
                  >
                  <label for="province" class="input__label">Province</label>
                </div>
                <div class="col-6 position-relative">
                  <select id="zip" class="form-control select-search" required></select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="addonsPurchase">
        <h4 class="text-uppercase">add-ons</h4>
        <div class="addons">
          <p>No Add-Ons</p>
          <!--
            <button class="add-addon">
              <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="12" height="12" viewBox="0 0 12 12" fill="none">
                <path d="M5.5 6.5H0V5.5H5.5V0H6.5V5.5H12V6.5H6.5V12H5.5V6.5Z" fill="black"/>
              </svg>
              <span>Enhance my moment with Add-ons</span>
            </button>
          -->
        </div>
      </div>
    </div>
    
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Detect iOS
  var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
  
  if (isIOS) {
    document.querySelector('.formAddressPurchase').classList.add('ios');
    
    // iOS specific fixes
    var inputs = document.querySelectorAll('.formAddressPurchase .input__field');
    
    inputs.forEach(function(input) {
      // Force enable touch events on iOS
      input.style.webkitUserSelect = 'text';
      input.style.webkitTouchCallout = 'default';
      input.style.pointerEvents = 'auto';
      input.style.touchAction = 'manipulation';
      
      // Add explicit touch event listeners for iOS
      input.addEventListener('touchstart', function(e) {
        e.stopPropagation();
        this.focus();
      }, { passive: false });
      
      input.addEventListener('touchend', function(e) {
        e.preventDefault();
        e.stopPropagation();
        this.focus();
        this.click();
      }, { passive: false });
      
      // Force focus on tap for iOS
      input.addEventListener('click', function(e) {
        e.stopPropagation();
        if (document.activeElement !== this) {
          this.focus();
        }
      });
    });
    
    // Fix for label overlapping on iOS
    var labels = document.querySelectorAll('.formAddressPurchase .input__label');
    labels.forEach(function(label) {
      label.style.pointerEvents = 'none';
      label.addEventListener('touchstart', function(e) {
        e.preventDefault();
        var input = this.parentNode.querySelector('.input__field');
        if (input) {
          input.focus();
        }
      });
    });
  }
  
  // Handle input state for all browsers, especially iOS
  var inputs = document.querySelectorAll('.input__field');
  
  inputs.forEach(function(input) {
    // Handle input events
    input.addEventListener('input', function() {
      if (this.value.trim() !== '') {
        this.classList.add('has-value');
      } else {
        this.classList.remove('has-value');
      }
    });
    
    // Handle focus
    input.addEventListener('focus', function() {
      this.classList.add('focused');
      // iOS specific: ensure input is visible
      if (isIOS) {
        setTimeout(function() {
          input.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 300);
      }
    });
    
    // Handle blur
    input.addEventListener('blur', function() {
      this.classList.remove('focused');
      if (this.value.trim() !== '') {
        this.classList.add('has-value');
      } else {
        this.classList.remove('has-value');
      }
    });
    
    // Initial check for pre-filled values
    if (input.value.trim() !== '') {
      input.classList.add('has-value');
    }
  });
  
  // Additional iOS fixes
  if (isIOS) {
    // Prevent iOS Safari from adding default styling
    document.addEventListener('touchstart', function() {}, { passive: true });
    
    // Fix viewport issues on iOS
    var viewport = document.querySelector('meta[name=viewport]');
    if (viewport) {
      viewport.setAttribute('content', 
        'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'
      );
    }
  }
});
</script>
          </div>
          <div class="purchase-button-wrapper">
            <div class="purchase-button btn-address row m-0">
  <div class="col-12 col-lg-2 text-left mb-2 p-0">
    
      <button class="back-purchase-button back-address text-uppercase">
        <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
          <path d="M14.5799 7.41992L2.32992 7.41992L7.57992 12.6699L6.91992 13.4199L0.419922 6.91992L6.91992 0.419922L7.57992 1.16992L2.32992 6.41992L14.5799 6.41992V7.41992Z" fill="black"/>
        </svg>
        <span>Back</span>
      </button>
    
  </div>
  <div class="btn-next-card col-12 col-lg-10 text-right">
    
      <!--
        <button class="back-purchase-button back-address text-uppercase mr-lg-2 mb-2 mb-lg-0">
          <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
            <path d="M14.5799 7.41992L2.32992 7.41992L7.57992 12.6699L6.91992 13.4199L0.419922 6.91992L6.91992 0.419922L7.57992 1.16992L2.32992 6.41992L14.5799 6.41992V7.41992Z" fill="black"/>
          </svg>
          <span>Back</span>
        </button>
      -->
    
    
    <button
      
        id="addtocart-card"
      
      class="btn  next-address text-uppercase"
      
    >
      <span>add to cart</span>
    </button>
  </div>
</div>

          </div>
        </div>
      </div>
    
  </div>
</div>
<div id="backgroundPopup"></div>



<input
  data-index="1"
  type="hidden"
  id="properties-delivery-date"
  name="properties[Delivery Date]"
  value="-"
>
<input
  data-index="2"
  type="hidden"
  id="properties-delivery-time"
  name="properties[Delivery Time]"
  value="-"
>
<input
  data-index="4"
  type="hidden"
  id="properties-nama-penerima"
  name="properties[Nama Penerima]"
  value="-"
>
<input
  data-index="5"
  type="hidden"
  id="properties-alamat-penerima"
  name="properties[Alamat Penerima]"
  value="-"
>
<input
  data-index="6"
  type="hidden"
  id="properties-kodepos"
  name="properties[Kodepos]"
  value="-"
>
<input data-index="7" type="hidden" id="properties-telepon-penerima" name="properties[Telepon Penerima]">

  
    <input
      data-index="8"
      type="hidden"
      id="properties-kartu-nama-penerima"
      name="properties[Kartu Nama Penerima]"
      value="-"
    >
  
  <textarea
    data-index="9"
    type="hidden"
    id="properties-kartu-pesan"
    name="properties[Kartu Pesan]"
    style="display: none"
  >-</textarea>



  <input
    data-index="10"
    type="hidden"
    id="properties-kartu-nama-pengirim"
    name="properties[Kartu Nama Pengirim]"
    value="-"
  >



  
  













<!-- Additional Shipping -->
<input type="hidden" id="properties-kota-pengiriman-province" name="properties[Province]">
<input
  type="hidden"
  id="properties-kota-pengiriman-country"
  name="properties[Country]"
  value="Indonesia"
>
<input type="hidden" id="properties-shipping" name="properties[Shipping]">

<input type="hidden" id="properties-time" name="properties[Time]">
<input type="hidden" id="properties-card" name="properties[Card]">
<input type="hidden" id="properties-addons" name="properties[Addons]">

<input
  type="hidden"
  id="properties-company"
  name="properties[Company]"
  value=""
>
<script>
  
  $(document).ready(function(){
    
    var text_max_papan1=150;
    var msg_text_papan1="";
    $('#kartu-ucapan-ucapan').keyup(function(){
      var text_length_papan1=$('#kartu-ucapan-ucapan').val().length;
      var msg_text_papan1=$('#kartu-ucapan-ucapan').val();
    });

    var notes_papan1 = [
      
      [0,"Happy Wedding (nama & nama)."],[1,"Congratulations lovebirds (nama & nama)."],[2,"Selamat berbahagia (nama & nama)."],[3,"Selamat menempuh hidup baru (nama & nama)."]
      
    ];
    $('#show_note_papan1').click(function(event){
      event.preventDefault();
      var idx_papan1=parseInt($('#note_id_papan1').val());
      if(isNaN(idx_papan1)){
        idx_papan1=0;
      }else{
        idx_papan1++;
        idx_papan1=idx_papan1%notes_papan1.length;
      }
      var note_papan1=notes_papan1[idx_papan1][1];
      $('#note_id_papan1').val(idx_papan1);
      $('#kartu-ucapan-papan, #properties-kartu-pesan, #properties-kartu-ucapan').val(note_papan1);
      $('#msgDelivery').val(note_papan1);

      var text_length_papan1=$('#kartu-ucapan-papan').val().length;
      var idx_2_papan1=parseInt($('#note_btn_id_papan1').val());
      if(isNaN(idx_2_papan1)){
        idx_2_papan1=0;
      }else{
        idx_2_papan1++;
        //idx_2_papan1=idx_2_papan1%note_btn_text_papan1.length;
      }
      $('#note_btn_id_papan1').val(idx_2_papan1);
      //var note_btn=note_btn_text[idx_2][1];
      //$('#note_btn').text(note_btn);
    });

    var text_max_papan2=150;
    var msg_text_papan2="";
    $('#kartu-ucapan-ucapan').keyup(function(){
      var text_length_papan2=$('#kartu-ucapan-ucapan').val().length;
      var msg_text_papan2=$('#kartu-ucapan-ucapan').val();
    });

    var notes_papan2 = [
      
      [0,"Congratulations (ucapan)."], [1,"Selamat dan sukses atas dibukanya (ucapan personal)."],[2,"Congratulations for the grand opening of (nama toko/bisnis)."],[3,"Happy Graduation (nama)."]
      
    ];
    $('#show_note_papan2').click(function(event){
      event.preventDefault();
      var idx_papan2=parseInt($('#note_id_papan2').val());
      if(isNaN(idx_papan2)){
        idx_papan2=0;
      }else{
        idx_papan2++;
        idx_papan2=idx_papan2%notes_papan2.length;
      }
      var note_papan2=notes_papan2[idx_papan2][1];
      $('#note_id_papan2').val(idx_papan2);
      $('#kartu-ucapan-papan, #properties-kartu-pesan, #properties-kartu-ucapan').val(note_papan2);
      $('#msgDelivery').val(note_papan2);
      var text_length_papan2=$('#kartu-ucapan-papan').val().length;
      var idx_2_papan2=parseInt($('#note_btn_id_papan2').val());
      if(isNaN(idx_2_papan2)){
        idx_2_papan2=0;
      }else{
        idx_2_papan2++;
        //idx_2_papan1=idx_2_papan1%note_btn_text_papan1.length;
      }
      $('#note_btn_id_papan2').val(idx_2_papan2);
      //var note_btn=note_btn_text[idx_2][1];
      //$('#note_btn').text(note_btn);
    });

    var text_max_papan3=150;
    var msg_text_papan3="";
    $('#kartu-ucapan-ucapan').keyup(function(){
      var text_length_papan3=$('#kartu-ucapan-ucapan').val().length;
      var msg_text_papan3=$('#kartu-ucapan-ucapan').val();
    });

    var notes_papan3 = [
      
      [0,"Turut Berduka Cita atas meninggalnya almarhum / almarhumah (Nama)."], [1,"Our Deepest Condolences for the lost of your beloved Father/ Mother/ Husband/ Wife/ Children."], [2,"Our Deepest Sympathy for the lost of your beloved Father/ Mother/ Husband/ Wife/ Children."], [3,"Innalillahi wa innailaihi rojiun, Turut berduka cita atas meninggalnya (nama)."]
      
    ];
    $('#show_note_papan3').click(function(event){
      event.preventDefault();
      var idx_papan3=parseInt($('#note_id_papan3').val());
      if(isNaN(idx_papan3)){
        idx_papan3=0;
      }else{
        idx_papan3++;
        idx_papan3=idx_papan3%notes_papan3.length;
      }
      var note_papan3=notes_papan3[idx_papan3][1];
      $('#note_id_papan3').val(idx_papan3);
      $('#kartu-ucapan-papan, #properties-kartu-pesan, #properties-kartu-ucapan').val(note_papan3);
      $('#msgDelivery').val(note_papan3);
      var text_length_papan3=$('#kartu-ucapan-papan').val().length;
      var idx_2_papan3=parseInt($('#note_btn_id_papan3').val());
      if(isNaN(idx_2_papan3)){
        idx_2_papan3=0;
      }else{
        idx_2_papan3++;
        //idx_2_papan1=idx_2_papan1%note_btn_text_papan1.length;
      }
      $('#note_btn_id_papan3').val(idx_2_papan3);
      //var note_btn=note_btn_text[idx_2][1];
      //$('#note_btn').text(note_btn);
    });

    var text_max_papan4=150;
    var msg_text_papan4="";
    $('#kartu-ucapan-ucapan').keyup(function(){
      var text_length_papan4=$('#kartu-ucapan-ucapan').val().length;
      var msg_text_papan4=$('#kartu-ucapan-ucapan').val();
    });

    $('#show_note_papan4').click(function(event){
      var notes_papan4 = [
        [0,"Here’s to you—steadier, stronger and better every day."],
        [1,"Warmest wishes for a speedy recovery!"],
        [2,"Dengan ucapan terhangat, semoga lekas membaik dan semakin pulih setiap harinya ya."],
        [3,"Semoga lekas sembuh untuk kembali beraktivitas dan berkarya."]
      ];
      event.preventDefault();
      var idx_papan4=parseInt($('#note_id_papan4').val());
      console.log(idx_papan4, 'idx_papan4')
      if(isNaN(idx_papan4)){
        idx_papan4=0;
      }else{
        idx_papan4++;
        idx_papan4=idx_papan4%notes_papan4.length;
      }
      var note_papan4=notes_papan4[idx_papan4][1];
      $('#note_id_papan4').val(idx_papan4);
      $('#kartu-ucapan-papan, #properties-kartu-ucapan, #properties-kartu-pesan').val(note_papan4);
      console.log(note_papan4, 'note_papan4')
      var text_length_papan4=$('#kartu-ucapan-papan').val().length;
      var idx_2_papan4=parseInt($('#note_btn_id_papan4').val());
      if(isNaN(idx_2_papan4)){
        idx_2_papan4=0;
      }else{
        idx_2_papan4++;
        //idx_2_papan1=idx_2_papan1%note_btn_text_papan1.length;
      }
      $('#note_btn_id_papan4').val(idx_2_papan4);
    });

    /*
    $("#jenisPapan").change(function(){
      $( "select option:selected").each(function(){
        if($(this).attr("value")=="Happy Wedding"){
          $("#suggest-messages a").hide();
          $("#show_note_papan1").show();
          $("#kartu-ucapan-papan").val("");
        }
        if($(this).attr("value")=="Congratulations"){
          $("#suggest-messages a").hide();
          $("#show_note_papan2").show();
          $("#kartu-ucapan-papan").val("");
        }
        if($(this).attr("value")=="Duka Cita"){
          $("#suggest-messages a").hide();
          $("#show_note_papan3").show();
          $("#kartu-ucapan-papan").val("");
        }
      });
    }).change();
    */

    

    

    $(".variant-metafield").each(function(){
      const t = $(this)
      const id = t.attr("id")
      const target = $(`[data-select=${id}]`)
      t.on('select2:selecting', function(e) {
        const data = e.params.args.data
        target.val(data.text)
      });
    })
  })
</script>

<div id="popupCart">
  <div class="container">
    <div class="wrapperPopupCart">
      <div class="headerPopupCart">
        <div class="d-flex pl-5 pr-5 p-4">
          <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="16" height="12" viewBox="0 0 16 12" fill="none">
            <path d="M5.55008 11.3076L0.580078 6.33761L1.29408 5.62461L5.55008 9.88061L14.7061 0.724609L15.4191 1.43861L5.55008 11.3076Z" fill="black"/>
          </svg>
          <span>item added to your cart</span>
        </div>
        <a class="close-purchase-popup">
  <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path d="M1.53287 17.4107L0.588867 16.4667L8.05553 9.00002L0.588867 1.53336L1.53287 0.589355L8.99953 8.05602L16.4662 0.589355L17.4102 1.53336L9.94353 9.00002L17.4102 16.4667L16.4662 17.4107L8.99953 9.94402L1.53287 17.4107Z" fill="black"/>
  </svg>
</a>

      </div>
      <div class="contentPopupCart">
        <div class="pl-5 pr-5 p-4">
          <div class="itemContent row m-0 justify-content-between">
            <div class="col-2 align-self-center">
              
              <img
                class="d-block"
                width="80"
                src="//outerbloom.com/cdn/shop/files/Blossom-Shine-WM_80x.jpg?v=1695788426"
              >
            </div>
            <div class="col-10 align-self-center">
              <div class="row pl-3">
                <div class="col-12 col-lg-7">
                  <span class="titleCartPopup text-uppercase">IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar</span>
                </div>
                <div class="d-flex justify-content-end col-12 col-lg-5">
                  <span class="deleteCartPopup hide">Delete</span>
                  <span class="lineCartPrice align-self-center">Rp 10.000</span>
                </div>
              </div>
            </div>
          </div>
          <div class="itemProperties">
            
              <div class="propDeliver">
                <h4>delivery option detail</h4>
                <p>
                  <span>delivery city</span>
                  <span class="propDeliveryCity">jakarta</span>
                </p>
                <p>
                  <span>delivery date</span>
                  <span class="propDeliveryDate">24/03/2025</span>
                </p>
                <p>
                  <span>delivery time</span>
                  <span class="propDeliveryTime">Afternoon | 13:00 - 18:00</span>
                </p>
              </div>
              <div class="propAddress">
                <h4>delivery option detail</h4>
                <p>
                  <span>RECIPIENT NAME</span>
                  <span class="propDeliveryName">jane doe</span>
                </p>
                <p>
                  <span>delivery address</span>
                  <span class="propDeliveryAddress"
                    >Jl. Gatot Subroto No. 25, RT.2/RW.4, Kuningan Barat, Kecamatan Mampang Prapatan, Kota Jakarta
                    Selatan, Daerah Khusus Ibukota Jakarta 12710, Indonesia</span
                  >
                </p>
                <p>
                  <span>recipient phone number</span>
                  <span class="propDeliveryPhone">(+62) 812-3456-7890</span>
                </p>
                <p>
                  <span>PROVINCE</span>
                  <span class="propDeliveryProv">Jakarta</span>
                </p>
                <p>
                  <span>postal code</span>
                  <span class="propDeliveryZip">12710</span>
                </p>
                
                
              </div>
            
          </div>
          <div class="itemAddonCart">
            <div class="toggleAddonCart d-flex justify-content-between">
              <h4>add-ons (0)</h4>
              <svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="5" height="9" viewBox="0 0 5 9" fill="none">
                <path d="M1.0128 0.84668L4.78613 4.62001L1.0128 8.39335L0.546133 7.92001L3.84613 4.62001L0.546133 1.32001L1.0128 0.84668Z" fill="black"/>
              </svg>
            </div>
            <div class="wrapperItemAddonCart"></div>
          </div>
          
        </div>
      </div>
      <div class="footerPopupCart">
        <div class="row m-0 pl-5 pr-5 p-4">
          <a class="btn btnViewCart w-100 text-uppercase text-center" href="/cart">View Cart</a>
          <a class="btn btnViewCheckout w-100 text-uppercase text-center" href="/checkout"><span>Checkout</span></a>
          <a class="btnContinueShopping w-100 text-center" href="/">Continue shopping</a>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
  const shareButton = document.getElementById('shareButton');

  shareButton.addEventListener('click', () => {
    if (navigator.share) {
      navigator.share({
        title: "IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar",
        url: "/products/blossom-shine",
        text: 'Check out this page!'
      })
      .then(() => console.log('Successful share'))
      .catch((error) => console.log('Error sharing', error));
    } else {
      alert('Web Share API is not supported in this browser.');
    }
  });

  // Inventory validation function
  function checkInventoryStatus() {
    const productSelect = document.getElementById('productSelect');
    const purchaseButton = document.querySelector('#personalizeBtn button');
    
    if (!productSelect || !purchaseButton) return;

    const selectedVariantId = productSelect.value;
    
    // Get variant data from Shopify
    fetch(`/products/blossom-shine.js`)
      .then(response => response.json())
      .then(product => {
        const selectedVariant = product.variants.find(variant => variant.id == selectedVariantId);
        
        if (selectedVariant) {
          const isOutOfStock = selectedVariant.inventory_quantity <= 0 && 
                               selectedVariant.inventory_management === 'shopify' && 
                               selectedVariant.inventory_policy !== 'continue';
          
          if (isOutOfStock) {
            purchaseButton.disabled = true;
            purchaseButton.textContent = 'Out of Stock';
            purchaseButton.setAttribute('data-out-of-stock', 'true');
            purchaseButton.style.backgroundColor = '#cccccc';
            purchaseButton.style.cursor = 'not-allowed';
          } else {
            // Check if button was disabled due to other conditions
            
            
            
            
            
            
            
            
            const isOtherDisabled = false || true || false;
            
            if (!isOtherDisabled) {
              purchaseButton.disabled = false;
              purchaseButton.textContent = 'customize your flower board';
              purchaseButton.removeAttribute('data-out-of-stock');
              purchaseButton.style.backgroundColor = '';
              purchaseButton.style.cursor = '';
            }
          }
        }
      })
      .catch(error => {
        console.error('Error checking inventory:', error);
      });
  }

  // Check inventory on page load
  document.addEventListener('DOMContentLoaded', function() {
    checkInventoryStatus();
    
    // Listen for variant changes
    const productSelect = document.getElementById('productSelect');
    if (productSelect) {
      productSelect.addEventListener('change', checkInventoryStatus);
    }
  });

  // Prevent form submission if out of stock
  document.addEventListener('click', function(e) {
    if (e.target.matches('button[data-out-of-stock="true"]')) {
      e.preventDefault();
      e.stopPropagation();
      alert('This product is currently out of stock and cannot be purchased.');
      return false;
    }
  });
</script>


  
</div>

          </div>
        </div>
      </div>
    </div>
    <div id="product-bottom">
      
        <div class="product-description rte bg-card col-12 py-3 px-0 m-0" itemprop="description">
          <div class="container">
            




    <div class="short-desc-mobile d-block d-lg-none mb-3">
        <div class="short-desc">
            <ul>
<li><strong>IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!</strong></li>
        </div>
        <label class="more-mobile">Show More →</label>
    </div>

<style>
.animated-title {
    text-align: center;
    font-weight: bold;
    color: #079c02;
    font-size: 28px;
    position: relative;
    animation: glow 2s infinite alternate, moveUpDown 3s infinite;
}

/* Efek glow / bercahaya hijau */
@keyframes glow {
    0% { text-shadow: 0 0 5px #079c02; color: #079c02; }
    50% { text-shadow: 0 0 20px #00ff55; color: #12d12b; }
    100% { text-shadow: 0 0 10px #1bff00; color: #079c02; }
}

/* Efek gerakan naik turun */
@keyframes moveUpDown {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-5px); }
    100% { transform: translateY(0px); }
}
</style>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/shopify-cartjs/1.1.0/cart.min.js"></script>
<script>
  CartJS.init({"note":null,"attributes":{},"original_total_price":0,"total_price":0,"total_discount":0,"total_weight":0.0,"item_count":0,"items":[],"requires_shipping":false,"currency":"IDR","items_subtotal_price":0,"cart_level_discount_applications":[],"checkout_charge_amount":0});

  const productType = $("[data-product-type]").data("product-type")
  const productDate = Date.parse(new Date())
  
  const shop = 'outerbloom1.myshopify.com'
  const host = 'https://app.asmaraku.com'
  // const host = 'http://localhost:5001'

  const gsheet = "https://script.google.com/macros/s/AKfycbyqa6mPD6lVjU6hiHr12J8URZ2aJBGyxBsGQ0QtEIDari-rBk_9vSOITjSSmUXL1NwxEg/exec"
  
  const qrID = "041025" + randomString(4, 'aAbCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ')

  $("#properties-time").val(new Date().getTime())

  const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);

  if(!isIOS) {
    $("#full-date").attr("type", "button")
  }

  let dateTime = new Date();
  let today = dateTime.getDate();
  let day = dateTime.getDay();
  let hour = dateTime.getHours();
  let min = dateTime.getMinutes();
  let timeOfDay = hour + (min / 100);

  async function getFetch(url) {
    const response = await fetch(url);
    let status = false
    let result
    if(response.ok) {
      status = true
      result = await response.json();
    }
    return {
      status,
      data: result
    }
  }

  

  function setCookie(cname, cvalue, exMins) {
    var d = new Date();
    d.setTime(d.getTime() + (exMins*60*1000));
    var expires = "expires="+d.toUTCString();  
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  async function renderDate() {
    let dataDate = await getFetch(`${host}/api/shipping/date?domain=${shop}&productId=8144957800663&v=${Date.now()}`);
    console.log(dataDate, 'renderDate')
    const data = dataDate?.data
    const date = data.date
    const time = data.time

    console.log(date, 'DATE')

    const weekday = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    const monthly = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const htmlDate = []
    for(let i = 0;i < date.length;i++) {
      const full = date[i].date
      const d = new Date(date[i].date);
      const day = weekday[d.getDay()];
      const dt = d.getDate();
      const mt = monthly[d.getMonth()];
      const yr = d.getFullYear();
      const isDate = Boolean(date[i].isEnabled)
      const cutoffpagi = date[i].cutoff?.pagi
      const cutoffsiang = date[i].cutoff?.siang
      const cutoffMalam = date[i].cutoff?.Malam
      var html = `
        <button data-id="8144957800663" class="date-single calendarbutton btn steps-btn col col-3 btn-date-time" data-day="${day}" data-fulldate="${full}" data-date="${dt < 10 ? '0' + dt : dt}" data-month="${mt}" data-year="${yr}" data-offpagi="${cutoffpagi}" data-offsiang="${cutoffsiang}" data-offMalam="${cutoffMalam}" ${isDate === true ? '' : 'disabled'}>
          ${dt === today ?
            `Today<span>${dt < 10 ? '0' + dt : dt}</span>` :
            `${day}<span>${dt < 10 ? '0' + dt : dt}</span>`
          }
        </button>
      `
      htmlDate.push(html)
    }
    const htmlTime = []
    for(var i = 0;i < time.length;i++) {
      const timeText = time[i].text
      const timeTime = time[i].time
      const timeEnabled = time[i].isEnabled
      var html = `
          <button class="time-single calendarbutton2 btn steps-btn" data-time="${timeText}" ${timeEnabled ? '' : 'disabled'}>${timeText}<br/>${timeTime}</button>
        `
      htmlTime.push(html)
    }
    const deliveryDate = document.getElementById("deliveryDate");
    if(deliveryDate) {
      deliveryDate.insertAdjacentHTML("afterbegin", htmlDate.join(''))
      $("#deliveryTime").html(htmlTime)
      if(productType !== '') {
        console.log("clarity event " + productType + ' calendaring')
        window.clarity("event", `${productType} calendaringSchedule`)
        // window.clarity("set", productType, `calendaringSchedule - ${productDate}`)
      }
    }
  }

  async function getProvince(city) {
    let { data: { province } } = await getFetch(`${host}/api/shipping/address/province?city=${city}`);
    console.log(province, 'province')
    $("#province").val(province)
  }

  async function renderAddress() {
    let current
    if(getCookie("location_delivery")){
      current = getCookie("location_delivery").charAt(0).toUpperCase() + getCookie("location_delivery").slice(1)
    }
    let address = await getFetch(`${host}/api/shipping/address?domain=${shop}&productId=8144957800663`);
    console.log(address)
    const data = address?.data?.city
    const htmlAddress = []
    const grouping = []
    for(let i = 0;i < data?.length;i++) {
      if(data[i]){
        if(data[i]?.group) {
          grouping.push(data[i].group)
        }
        const price = rupiah.format(data[i]?.rate)
        let promo = '(Promo Free Delivery)'
        if(data[i]?.name === 'Jakarta - PickUp ASHTA'){
          promo = '(at SCBD, Ashta)'
        } else if(data[i]?.name === 'Jakarta - PickUp ITC'){
          promo = '(at Kuningan, ITC Kuningan)'
        } else if(data[i]?.name === 'BSD - PickUp'){
          promo = '(at Goldfinch Gading Serpong)'
        } else if(data[i]?.name === 'Kota Lainnya'){
          promo = ''
        }
        htmlAddress.push(`<option data-province="${data[i]?.province}" data-city="${data[i]?.city}" data-note="${data[i]?.note}" data-price="${data[i]?.rate}" value="${data[i]?.name}">${data[i]?.name === 'Kota Lainnya' ? 'Seluruh Kota Lain di Indonesia' : data[i]?.name} ${data[i]?.rate > 0 ? `(${price})` : promo}</option>`)
      }
    }
    
    const deliveryCity = document.getElementById("cities");
    if(deliveryCity) {
      deliveryCity.insertAdjacentHTML("beforeend", htmlAddress.join(''))
      if(!isIOS) {
        $(deliveryCity).select2();
      }
    }
  }

  async function renderZip(v, v2, v3) {
    const deliveryZip = document.getElementById("zip");
    if(v === '') {
      return
    }
    let dataZip = await getFetch(`${host}/api/shipping/address/zip?city=${v}&city2=${v2}&city3=${v3}`);
    let zip = dataZip?.data?.zip
    console.log(zip)
    let htmlZip = []
    for(let i = 0; i < zip?.length;i++) {
      htmlZip.push(`<option value="${zip[i]?.postalCode} - ${zip[i]?.subdistrict}">${zip[i]?.postalCode} - ${zip[i]?.subdistrict} - ${zip[i]?.city}</option>`)
    }
    deliveryZip.insertAdjacentHTML("beforeend", htmlZip.join(''))
  }

  renderDate()
  renderAddress()

  let rupiah = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0, 
    minimumFractionDigits: 0
  });

  async function insertCard(data) {
    const response = await fetch(`${host}/api/card/new`, {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
        },
        body: data
    })
    const result = await response.json()
    let rowIndex = result?.data?.tableRange.split("Outerbloom!A1:J")[1]
    $("#greetingCard").attr("data-index", rowIndex)
    return result
  }
    
  async function updateCard(data){
    const rowIndex = $("#greetingCard").data("index")
    const response = await fetch(`${host}/api/card/update?rowIndex=${rowIndex}`, {
        method: "PUT",
        headers: {
          'Content-Type': 'application/json',
        },
        body: data
    })
    return response
  }
    
  function bytesToSize(bytes) {
    var sizes = ['b', 'kb', 'mb', 'gb', 'tb', 'p'];
    for (var i = 0; i < sizes.length; i++) {
      if (bytes <= 1024) {
        return bytes + ' ' + sizes[i];
      } else {
        bytes = parseFloat(bytes / 1024).toFixed(2)
      }
    }
    return bytes + ' P';
  }

  async function uploadMedia(uri, type) {
    nameq = $("#properties-nama-penerima").val()
    dear = $("#properties-kartu-nama-penerima").val()
    card = $("[data-properties=ucapan]").val()
    sender = $("#properties-kartu-nama-pengirim").val()
    photo = $("#properties-photo").val()
    video = $("#properties-video").val()
    status = "Product"
        
    const name = qrID
    let formData = new FormData(); 
    formData.append("file", uri);
    const response = await fetch(`${host}/api/upload?name=${name}&type=${type}&r=${randomString(3, '0123456789')}`, {
      method: "POST", 
      body: formData
    })
    const result = await response.json();
    if(result) {
      const url = result.url
      if(type === 'image/jpeg') {
        $("#properties-photo").val(url)
        $(".preview-image").show()
        $(".remove-image").show()
        photo = url
      } else {
        $("#properties-video").val(url)
        $("#label-input-video span").text("Change File")
        $(".case-qrcode-preview p").text("Scan here for a secret message")
        $(".remove-media").show()
        $("#product-top #product-meta .case-video-preview p").html(`<span class="replace-video" tite="Replace Video">${uri.name} (${bytesToSize(uri.size)})</span><span> is uploaded</span>`)
        $("[for=input-video]").hide()
        video = url
      }
      $(".case-video-preview").show()
      $(".steps-card-preview").removeClass("loading")
      // updateCard(nameq, dear, card, sender, photo, video, status)

      $(".nextBtn").attr("disabled", false)
    }
  }

  function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
  }

  function getNoteCity(fulldate) {
    const h_1 = new Date(new Date().setDate(new Date().getDate() + 1))
    const weekday = ["Min","Sen","Sel","Rab","Kam","Jum","Sab"];
    const monthly = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const d = new Date(h_1);
    const day = weekday[d.getDay()];
    const dt = d.getDate();
    const mt = monthly[d.getMonth()];
    const yr = d.getFullYear();
    const p = $("#cities").parent(".form-group")
  }

  function disabledSameDay() {
    let btnFirst = $("#deliveryDate").find("button:first-child")
    let getDay = new Date().getDay();

    
      
      if(getDay == 1 || getDay == 2 || getDay == 3 || getDay == 4 || getDay == 5){
        if(hour >= 14.00){
          btnFirst.attr("disabled", true)
        }
      } else if(getDay == 6){
        if(hour >= 16.00){
          btnFirst.attr("disabled", true)
        }
      } else if(getDay == 0){
        if(hour >= 16.00){
          btnFirst.attr("disabled", true)
        }
      }
      
    
  }

  function disabledays(date) {
    let ymd = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    //if u have to disable a list of day
    let removeDays
    
    
    
        removeDays = ["2025-2-13", "2025-2-14"];
    
    if ($.inArray(ymd, removeDays) >= 0) {
      return [false];
    } else {
      let day = date.getDay();
      if(day == 0 && date.getDate() == 13 && date.getMonth() == 1){
          return [(day == 0),  ''];
      }
      
      if(day == 0){
        return [(day == 0),  ''];
      }
      
      
      return [(day != 0),  ''];
    }
  }

  /* Indonesian initialisation for the jQuery UI date picker plugin. */
  /* Written by Deden Fathurahman (dedenf@gmail.com). */
  ( function( factory ) {
    if ( typeof define === "function" && define.amd ) {

      // AMD. Register as an anonymous module.
      define( [ "../widgets/datepicker" ], factory );
    } else {

      // Browser globals
      factory( jQuery.datepicker );
    }
  }( function( datepicker ) {

  datepicker.regional.id = {
    closeText: "Tutup",
    prevText: "&#x3C;mundur",
    nextText: "maju&#x3E;",
    currentText: "Today",
    monthNames: [ "January","February","March","April","May","Juny",
                  "July","August","September","October","November","December" ],
    monthNamesShort: [ "Jan","Feb","Mar","Apr","May","Jun",
                      "Jul","Agu","Sep","Oct","Nov","Dec" ],
    dayNames: [ "Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu" ],
    dayNamesShort: [ "Sun","Mon","Tue","Wed","Thu","Fri","Sat" ],
    dayNamesMin: [ "Mg","Sn","Sl","Rb","Km","jm","Sb" ],
    weekHeader: "Mg",
    dateFormat: "D, dd M",
    firstDay: 0,
    isRTL: false,
    showMonthAfterYear: false,
    yearSuffix: "" };
  datepicker.setDefaults( datepicker.regional.id );

  return datepicker.regional.id;

} ) );

  function loadPopup() {
    $("#backgroundPopup").fadeIn("slow");
    $(".purchasePopup:not(.purchasePopupSpotify)").fadeIn("slow");
    const firstSection = $(".purchasePopup:not(.purchasePopupSpotify) .sectionPurchase").first()
    if(firstSection.hasClass("purchasePersonalize")) {
      if(productType !== '') {
        console.log("clarity event " + productType + ' personalize')
        window.clarity("event", `${productType} cardPersonalization`)
        // window.clarity("set", productType, `cardPersonalization - ${productDate}`)
      }
    } else if (firstSection.hasClass("sectionPurchaseBoard")) {
        console.log("clarity event " + productType + ' personalizeBoard')
        window.clarity("event", `${productType} personalizeBoard`)
        // window.clarity("set", productType, `personalizeBoard - ${productDate}`)
    }
    firstSection.removeClass("hide")
    
    // Auto-trigger addon loading when addon section becomes visible
    setTimeout(function() {
      const addonSection = $(".purchaseAddon")
      if(addonSection.length > 0 && !addonSection.hasClass("hide")) {
        if($("#itemAddons .row").children().length === 0 || $("#itemAddons .row").text().includes("No Item available")) {
          $("[data-addon=upsell-all]").trigger("click")
        }
      }
    }, 200)
  }

  function disablePopup() {
    $("#backgroundPopup").fadeOut("slow");
    $(".purchasePopup").fadeOut("slow");
    $("#popupCart").fadeOut("slow");
  }

    function scrollTo(parent, div, dur) {
      $(parent).animate({
        scrollTop: $(div).offset().top
      }, dur);
    }

  function loadPopupPersonalize() {
    const div = "#purchaseProduct"
    const p = "html, body, .product-meta"
    $("p.error").remove()
    loadItemOccasion($("[data-occassion]").eq(0), "greeting-card-all")
    const isCity = $("#cities[required]")
    const isDate = $("#propDeliveryDate[required]")
    const isTime = $("#propDeliveryTime[required]")
    // loadPopup()
    if(isCity.val() !== '' && isDate.val() !== '' && isTime.val() !== '') {
      loadPopup()
    }
    if(isCity.val() == '') {
      isCity.parent(".row").append("<p class='error'>Choose delivery city</p>")
      scrollTo(p, div, 500)
    }
    if(isDate.val() == '') {
      isDate.parents(".row").append("<p class='error'>Choose delivery date</p>")
      scrollTo(p, div, 500)
    }
    if(isTime.val() == '') {
      isTime.parents(".row").append("<p class='error'>Choose delivery time</p>")
      scrollTo(p, div, 500)
    }
  }

  function quantityCounter() {
    $(document).on("click", ".item-card.selected .q_up", function () {
      var C = $(this).attr("data-id"),
          S =
              parseInt(
                  $(this)
                      .siblings(".quantity-cart-" + C)
                      .val()
              ) + 1;
      $(this).attr("data-quantity", S),
          $(this)
              .siblings(".quantity-cart-" + C)
              .val(S);
    }),
    $(document).on("click", ".item-card.selected .q_down", function () {
        var C = $(this).attr("data-id"),
            S = parseInt(
                $(this)
                    .siblings(".quantity-cart-" + C)
                    .val()
            );
        0 < S && $(this).attr("data-quantity", S - 1),
            0 < S &&
                $(this)
                    .siblings(".quantity-cart-" + C)
                    .val(S - 1);
    });
  }

  quantityCounter()

  const itemAddon = $(".item-card").length
  const nofree = $(".nofree").length

  const upsell = ''
  
  if(nofree === itemAddon) {
      // $("#itemAddons").html("<p>No Items available</p>")
  }

  $("#itemAddons .item-card").each(function(e){
      $("#itemAddons").attr("data-length", e)
  })

  $("[data-addon]").click(function(){
      
      
      
      const t = $(this)
      
      const data = t.data("addon")
      
      $("[data-addon]").removeClass("selected")
      t.addClass("selected")
      $.get(`https://outerbloom.com/collections/${data}/products.json`, function(data, status){
          const products = data.products
          const html = []
          for(let i = 0; i < products.length; i++) {
              const id = products[i].id
              const variantId = products[i].variants[0].id
              const img = products[i].images[0].src
              let img2 = img.split('.jpg')[0]
              const title = products[i].title
              const price = products[i].variants[0].price
              const tags = products[i].tags
              const qty = products[i].variants[0].available
              let type_upsell = ''
              if(tags.includes('upsell-item-standing')) {
                  type_upsell = 'standing'
              }
              console.log(type_upsell)
              if(type_upsell !== '') {
                  const body = `<div class="item-card${price < 1 ? ' free' : ' nofree'} type-${products[i].product_type.toLowerCase()?.replace(' ', '_')}" data-variant="${variantId}" data-id=${id} data-qty="${qty === false ? 0 : ''}" data-upsell="${type_upsell}" data-tags="${tags}">
                      
                          <div class="card-image">
                              <img src="${img2}_150x.jpg" alt="${title}" width="" height="" />
                          </div>
                          <div class="card-meta">
                              <h5>${title}</h5>
                              <p>${price < 1 ? 'FREE' : rupiah.format(price)}</p>
                              <input id="card-${variantId}" type="hidden" name="" value="${variantId}">
                          </div>
                          <div class="card-qty">
                              <a data-quantity="1" type="submit" id="q_down-${variantId}" class="btn-qty-min q_down drawer-cart" data-id="${variantId}"><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="12" height="2" viewBox="0 0 12 2" fill="none"><path d="M0 1.90869V0.908691H12V1.90869H0Z" fill="black"/></svg></a>  
                              <input maxlength="3" min="0" class="btn-qty text-center quantity-cart-${variantId}" value="0" data-price=${price} name="quantity">
                              <a data-quantity="1" type="submit" class="btn-qty-plus q_up text-green drawer-cart" data-id="${variantId}"><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="12" height="13" viewBox="0 0 12 13" fill="none">
<path d="M0 6.87023V5.94715H5.53846V0.408691H6.46154V5.94715H12V6.87023H6.46154V12.4087H5.53846V6.87023H0Z" fill="black"/>
</svg></a>   
                          </div>
                      </div>`
                  html.push(body)
              }
          }
          $("#itemAddons .row").html(html.length === 0 ? '<p>No Item available</p>' : html)
          $("#itemAddons").attr("data-length", products.length)
          // $('#itemAddons')[0].swiper.update();
      });
  })

  async function isAddon(){
    let ids = []
    $("#itemAddons .item-card.selected").each(function(i, e){
      const id = $(this).data("id")
      ids.push(id)
    })
    console.log(ids)
    return ids
  }
  
  $("#itemAddons").delegate(".item-card > div:not(.card-qty)", "click", async function(){
    const t = $(this).parent()
    const id = t.data("id")
    const btn =  t.parents(".purchaseAddon").find(".next-purchase-button")
    t.toggleClass("selected");
    //$(this).next("input").toggleAttr('name', 'id[]');
    if (t.hasClass('selected')) {
        t.find("input").val(1)
        t.find("input").attr('name', 'id[]');
    } else {
        t.find("input").val(0)
        t.find("input").removeAttr('name');
    }
    $("#properties-addons").val(addons)
    const is = await isAddon()
    if(is.length === 0) {
      btn.text("continue without add-ons")
      return
    }
    if(is.includes(8835692069079)) {
      btn.text("personalize acrylic frame")
    } else {
      btn.text("Continue")
    }
      
  })

  async function myAddon(data) {
    const c = $(".addonsPurchase .addons")
    let items = []
    
    const spotifyAddons = $(".spotifyAddons").find("[data-index]")
    // if(spotifyAddons.length > 0) {
    //   $(spotifyAddons).each(function(i, e){
    //     const spotifyLink = $(this).find(".spotifyLink").val()
    //     const spotifySong = $(this).find(".spotifySong").val()
    //     const spotifyArtist = $(this).find(".spotifyArtist").val()
    //     const spotifyFotoAddon = $(this).find(".resultPhotoSpotify").val()
    //     if(spotifyLink !== '') {
    //       spotifyAddon = `<div class="addon-item" data-id="46067682607319" data-qty="1">
    //         <div class="addon-itm-img">
    //           <img src="https://cdn.shopify.com/s/files/1/1589/6833/files/Acrylic-Frame_8c71027d-43b7-4322-a98f-d34ab0456397_100x.jpg?v=1739160467" alt="" width="70"/>
    //         </div>
    //         <div class="addon-itm-title">
    //           <span>[US] Outerbloom Acrylic Frame 4R</span>
    //         </div>
    //         <div class="addon-itm-line-total">
    //           <span>Rp 99.000</span>
    //         </div>
    //       </div>
    //       <div class="propsAddonSpotify row m-0">
    //         <div class="col-12 col-lg-2"></div>
    //           <div class="col-12 col-lg-10">
    //             <p>
    //               <span>spotify link</span>
    //               <span class="spotifyLinkAddon">${spotifyLink}</span>
    //             </p>
    //             <p>
    //               <span>uploaded photo</span>
    //               <span class="spotifyFotoAddon">${spotifyFotoAddon}</span>
    //             </p>
    //             <p>
    //               <span>song / playlist name</span>
    //               <span class="spotifySongAddon">${spotifySong}</span>
    //             </p>
    //             <p>
    //               <span>artist name</span>
    //               <span class="spotifyArtistAddon">${spotifyArtist}</span>
    //             </p>
    //           </div>
    //       </div>`
    //       items.push(spotifyAddon)
    //     }
    //   })
    // }
    for(let i = 0; i < data.length; i++) {
      if(data[i].title !== '[US] Outerbloom Acrylic Frame 4R' ) {
        const img = data[i].image
        const title = data[i].title
        const qty = data[i].qty
        const price = data[i].price
        const total = Number(qty) * Number(price)
        let addons = `<div class="addon-item" data-id="${data[i].id}" data-qty="${qty}">
              <div class="addon-itm-img">
                <img src="${img}" alt="" width="70"/>
              </div>
              <div class="addon-itm-title">
                <span>${title}</span>
              </div>
              <div class="addon-itm-line-price">
                <span>${rupiah.format(price)}</span>
                ${data[i].title == '[US] Outerbloom Acrylic Frame 4R' ? '' : `<span>x${qty}</span>`}
              </div>
              <div class="addon-itm-line-total">
                <span>${rupiah.format(total)}</span>
              </div>
            </div>`
          items.push(addons)
      }
    }
    c.html(items)
    const parent = $(".purchaseAddon")
    const next = parent.next(".sectionPurchase")
    parent.addClass("hide")
    next.removeClass("hide")
    // if(items2.length === 0) return $("#popupCart").addClass("no-addon-cart")
    // $(".itemAddonCart").find("h4").text(`add-ons (${items2.length})`)
  }

  async function listAddon() {
    const data = $("#itemAddons").find(".selected")
    let ids = []
    $(data).each(function(){
      const id = $(this).data("variant")
      const image = $(this).find(".card-image img").attr("src")
      const title = $(this).find(".card-meta h5").text()
      const qty = $(this).find(".card-qty input").val()
      const price = $(this).find(".card-qty input").data("price")
      ids.push({
        id: Number(id),
        image,
        title,
        qty,
        price
      })
    })
    myAddon(ids)
  }

  async function customSpotify(idx, length, type){
    let isCard = false
    
    let p = $(".purchasePopupSpotify")
    const preLink = $(".spotifyLinkFirst").val()
    $("[data-index]").hide()
    p.find(".headerPurchase h3").text(`personalize spotify photo print${length > 1 ? ` - ${idx}` : ''}`)
    p.find(".regulerAddons, .purchase-button").hide()
    p.find(".spotifyAddons").show()
    
    const data = await trackUrl(preLink)
    
    const html = `<div class="row" data-index=${idx} data-length=${length}><div class="col-12 col-lg-6"><div class="form-vertical position-relative"><div class="form-group mb-4"><h4>upload photo</h4><div class=uploadResult><label class=btn for=uploadPhotoSpotify><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="13" height="11" viewBox="0 0 13 11" fill="none">
<path d="M0.875 10.6378H12.375C12.4413 10.6378 12.5049 10.6115 12.5518 10.5646C12.5987 10.5177 12.625 10.4541 12.625 10.3878V0.387817C12.625 0.321513 12.5987 0.257925 12.5518 0.211041C12.5049 0.164157 12.4413 0.137817 12.375 0.137817H0.875C0.808696 0.137817 0.745107 0.164157 0.698223 0.211041C0.651339 0.257925 0.625 0.321513 0.625 0.387817V10.3878C0.625 10.4541 0.651339 10.5177 0.698223 10.5646C0.745107 10.6115 0.808696 10.6378 0.875 10.6378ZM1.125 10.1378V7.31882C1.136 7.31082 1.1485 7.30632 1.1585 7.29632L3.7165 4.73832C3.78198 4.67584 3.869 4.64098 3.9595 4.64098C4.05 4.64098 4.13702 4.67584 4.2025 4.73832L7.963 8.49882C8.00919 8.54501 8.07162 8.5713 8.13694 8.57204C8.20225 8.57279 8.26527 8.54794 8.3125 8.50282L10.2455 6.66682C10.3084 6.60323 10.3938 6.56684 10.4832 6.56543C10.5727 6.56403 10.6591 6.59774 10.724 6.65932L12.125 8.18532L12.1255 8.18582V10.1378H1.125ZM12.125 0.637817V7.44682L11.0845 6.31382C11.0066 6.23514 10.9138 6.17275 10.8116 6.13026C10.7094 6.08777 10.5997 6.06603 10.489 6.06632H10.4885C10.3786 6.06584 10.2697 6.08706 10.168 6.12876C10.0664 6.17046 9.97391 6.23182 9.896 6.30932L8.144 7.97332L4.556 4.38482C4.2365 4.06582 3.6815 4.06632 3.363 4.38482L1.125 6.62332V0.637817H12.125Z" fill="black"/>
</svg><span>Upload your file</span></label></div><input class="uploadPhotoSpotify form-control d-none" accept=image/* type=file><input class="resultPhotoSpotify" type="hidden"></div><div class="form-group mb-5"><h4>Add your Spotify link here</h4> <input class="spotifyLink2 form-control spotifyLink" value="${preLink}" placeholder=https://open.spotify.com/ ></div><div class="form-group mb-4 text-left"><label class=checkbox for=isCustomMessage><span>Personalized Message</span><span class=checkmark></span></label></div><div class="form-group mb-4 form-personalize"><label class="text-left d-block mb-2 text-uppercase"for=spotifySong>Song / playlist name</label> ${data?.song ? `<input class="form-control spotifySong" value="${data?.song}">` : '<input class="form-control spotifySong" value="">'}</div><div class="form-group form-personalize"><label class="text-left d-block mb-2 text-uppercase"for=spotifyArtist>Artist name</label> ${data?.artist ? `<input class="form-control spotifyArtist" value="${data?.artist}">` : '<input class="form-control spotifyArtist" value="">'}</div><div class=btn-action><button class="back-spotify"><svg fill=none height=14 viewBox="0 0 15 14"width=15 xmlns=https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif><path d="M14.5799 7.41992L2.32992 7.41992L7.57992 12.6699L6.91992 13.4199L0.419922 6.91992L6.91992 0.419922L7.57992 1.16992L2.32992 6.41992L14.5799 6.41992V7.41992Z"fill=black /></svg> <span>Back</span></button><button data-type="${isCard ? 'card' : ''}" ${isCard ? '' : 'id=addtocart-card'} class="text-uppercase btn w-100${type == 'addon' && idx == length ? ' finished' : ' no-addon'}" disabled>${isCard ? 'Continue Personalizing' : 'add to cart'}</button></div></div></div><div class="col-12 col-lg-6 columnRight"><div class=frame-spotify><div class=frameImage><div class=frameImageUploaded><svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="13" height="11" viewBox="0 0 13 11" fill="none">
<path d="M0.875 10.6378H12.375C12.4413 10.6378 12.5049 10.6115 12.5518 10.5646C12.5987 10.5177 12.625 10.4541 12.625 10.3878V0.387817C12.625 0.321513 12.5987 0.257925 12.5518 0.211041C12.5049 0.164157 12.4413 0.137817 12.375 0.137817H0.875C0.808696 0.137817 0.745107 0.164157 0.698223 0.211041C0.651339 0.257925 0.625 0.321513 0.625 0.387817V10.3878C0.625 10.4541 0.651339 10.5177 0.698223 10.5646C0.745107 10.6115 0.808696 10.6378 0.875 10.6378ZM1.125 10.1378V7.31882C1.136 7.31082 1.1485 7.30632 1.1585 7.29632L3.7165 4.73832C3.78198 4.67584 3.869 4.64098 3.9595 4.64098C4.05 4.64098 4.13702 4.67584 4.2025 4.73832L7.963 8.49882C8.00919 8.54501 8.07162 8.5713 8.13694 8.57204C8.20225 8.57279 8.26527 8.54794 8.3125 8.50282L10.2455 6.66682C10.3084 6.60323 10.3938 6.56684 10.4832 6.56543C10.5727 6.56403 10.6591 6.59774 10.724 6.65932L12.125 8.18532L12.1255 8.18582V10.1378H1.125ZM12.125 0.637817V7.44682L11.0845 6.31382C11.0066 6.23514 10.9138 6.17275 10.8116 6.13026C10.7094 6.08777 10.5997 6.06603 10.489 6.06632H10.4885C10.3786 6.06584 10.2697 6.08706 10.168 6.12876C10.0664 6.17046 9.97391 6.23182 9.896 6.30932L8.144 7.97332L4.556 4.38482C4.2365 4.06582 3.6815 4.06632 3.363 4.38482L1.125 6.62332V0.637817H12.125Z" fill="black"/>
</svg> <img src="" class=previewImage style=display:none></div></div><div class=frameControl><div class=spotifyData>${data?.song ? `<h3>${data?.song}</h3>` : '<h3><h3>'}${data?.artist ? `<p>${data?.artist}</p>` : '<p></p>'}</div><img src="//outerbloom.com/cdn/shop/t/138/assets/frame-spotify.png?v=138221849636560654691752652420"alt="spotify outerbloom" height=""width=100%><div class=spotifyCode><img src="https://scannables.scdn.co/uri/plain/png/FFFFFF/black/640/spotify:${data?.type.slice(0, -1)}:${data?.trackId}"alt=""></div></div></div></div></div>`
    // console.log(html)
    
    $(".spotifyAddons").append(html)
    
    $(`[data-index=${idx}]`).show()
    
    if (preLink !== '') {
      $(".btn-action .btn").attr("disabled", false)
    } else {
      $(".btn-action .btn").attr("disabled", true)
    }

    return html
    
  }

  $(".spotifyLinkFirst").keyup(async function(){
    const v = $(this).val()
    if(v.includes('spotify:user:spotify')) {
      const correct = v.split('user:spotify:')[1]
      console.log(correct, 'BNER')
      $(this).val(correct)
      return
    }
    if(v.includes("spotify:") || v.includes("https://open.spotify.com/")){
      const data = await trackUrl(v)
      if(!data || !data.status) {
        $(this).parent().addClass("error")
        // $(this).parent().append(`<p class="txt-error">Make sure you copy the complete and correct link from Spotify. Ex: https://open.spotify.com/track/0C3xZJueyBvvMSsl0cETA6</p>`)
        $("#personalizeBtnSpotify .btn").attr("disabled", true)
        return
      }
      $(this).parent().removeClass("error")
      // $(this).parent().remove("txt-error")
      $("#personalizeBtnSpotify .btn").attr("disabled", false)
    } else {
      $("#personalizeBtnSpotify .btn").attr("disabled", true)
    }
  })

  $(".purchaseAddon").delegate(".next-addon", "click", function(){
    const parent = $(this).parents(".purchaseAddon")
    const next = parent.next(".sectionPurchase")
    if(next.hasClass("purchaseAddress")) {
      if(productType !== '') {
        console.log("clarity event " + productType + ' purchaseDelivery')
        window.clarity("event", `${productType} purchaseDelivery`)
        // window.clarity("set", productType, `purchaseDelivery - ${productDate}`)
      }
    }
    const data = $("#itemAddons").find(".selected")
    const length = $(".quantity-cart-46067682607319").val()
    const checked = data.length;
    if(checked > 0) {
      if(length > 0) {
        $(".purchaseAddon").addClass("purchaseAddonSpotify")
        customSpotify(1, length, 'addon')
      } else {
        listAddon()
      }
    } else {
      parent.addClass("hide")
      next.removeClass("hide")
    }
  })

  $("#personalizeBtnSpotify .btn").click(async function(){
    const isCity = $("#cities[required]")
    const isDate = $("#propDeliveryDate[required]")
    if((isDate.length > 0 && isCity.length > 0) && (isCity.val() === '' || isDate.val() === '')) {
      alert('Please choose Delivery City & Delivery Date')
      return
    }
    const data = await customSpotify(1, 1, 'product')
    if(data) {
      $("#backgroundPopup").fadeIn("slow");
      $(".purchasePopupSpotify").fadeIn("slow");

      if(productType !== '') {
        console.log("clarity event " + productType + ' spotify')
        window.clarity("event", `${productType} spotify`)
        // window.clarity("set", productType, `purchaseDelivery - ${productDate}`)
      }
    }
  })

  function formatBytes(bytes, decimals = 2) {
    if (!+bytes) return '0 Bytes'

    const k = 1024
    const dm = decimals < 0 ? 0 : decimals
    const sizes = ['B', 'KB', 'MB']

    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`
  }

  async function trackUrl(link){
    try {
      let trackId = link.split('/').pop().split('?')[0];
      let type = ''
      if(link.includes("spotify:")) {
        const uri = link.split('spotify:')[1]
        trackId = uri.split(':')[1]
        type = uri.split(':')[0] + 's'
      } else {
        if(link.match('track')){
          type = 'tracks'
        } else if(link.match('playlist')) {
          type = 'playlists'
        } else if(link.match('artist')) {
          type = 'artists'
        } else if(link.match('album')) {
          type = 'albums'
        }
      }
      console.log(`${host}/api/spotify/${type}/${trackId}`)
      const data = await getFetch(`${host}/api/spotify/${type}/${trackId}`)
      console.log(data, 'DATA')
      const song = data?.data?.name
      const artist = data?.data?.artist
      return {
        song, artist, type, trackId, status: data.status
      }
    } catch(err) {
      console.log(err)
    }
  }

  $(".spotifyAddons").delegate(".uploadPhotoSpotify", "change", async function(){
    const parent = $(this).parents("[data-index]")
    const preview = parent.find(".previewImage")
    const file = $(this)[0].files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = async function(e) {
          parent.find(".uploadResult label").hide()
          parent.find(".uploadedResult").remove()
          parent.find(".uploadResult").append(`<div class="uploadedResult d-flex" style="justify-content: space-between">
          <p style="text-align: left;margin: 0;"><span style="color: #34C759;font-style: italic;font-size: 14px;text-overflow: ellipsis;overflow: hidden;max-width: 250px;white-space: nowrap;display: inline-block;vertical-align: middle;">${file.name}</span><span style="font-size: 14px;color: #34C759"> (${formatBytes(file.size)})</span> <span style="font-size: 14px">is uploaded</span></p>
          <div style="align-self: center"><span class="changeUpload" style="font-size: 12px;cursor: pointer">Change</span><span class="removeUpload" style="cursor: pointer;border-left: 1px solid;padding-left: 10px;margin-left: 10px;height: 10px;display: inline-flex;vertical-align: middle;"><svg fill="none" height="11" viewBox="0 0 10 11" width="10" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
  <path d="M2.07799 10.8332C1.78154 10.8332 1.52799 10.7276 1.31732 10.5165C1.10666 10.3054 1.0011 10.0523 1.00066 9.75716V1.49982H0.667322C0.572656 1.49982 0.493545 1.46782 0.429989 1.40382C0.366433 1.33982 0.334433 1.26049 0.333989 1.16582C0.333544 1.07116 0.365545 0.992047 0.429989 0.928491C0.494433 0.864935 0.573545 0.833158 0.667322 0.833158H3.00066C3.00066 0.69538 3.05177 0.57538 3.15399 0.473158C3.25621 0.370935 3.37621 0.319824 3.51399 0.319824H6.48732C6.6251 0.319824 6.7451 0.370935 6.84732 0.473158C6.94954 0.57538 7.00066 0.69538 7.00066 0.833158H9.33399C9.42866 0.833158 9.50777 0.865158 9.57132 0.929158C9.63488 0.993158 9.66688 1.07249 9.66732 1.16716C9.66777 1.26182 9.63577 1.34094 9.57132 1.40449C9.50688 1.46805 9.42777 1.49982 9.33399 1.49982H9.00066V9.75649C9.00066 10.0525 8.8951 10.3058 8.68399 10.5165C8.47288 10.7272 8.21954 10.8327 7.92399 10.8332H2.07799ZM8.33399 1.49982H1.66732V9.75649C1.66732 9.87605 1.70577 9.97427 1.78266 10.0512C1.85954 10.128 1.95799 10.1665 2.07799 10.1665H7.92399C8.04354 10.1665 8.14177 10.128 8.21866 10.0512C8.29554 9.97427 8.33399 9.87605 8.33399 9.75649V1.49982ZM3.87266 8.83316C3.96732 8.83316 4.04666 8.80116 4.11066 8.73716C4.17466 8.67316 4.20643 8.59405 4.20599 8.49982V3.16649C4.20599 3.07182 4.17399 2.99271 4.10999 2.92916C4.04599 2.8656 3.96666 2.8336 3.87199 2.83316C3.77732 2.83271 3.69821 2.86471 3.63466 2.92916C3.5711 2.9936 3.53932 3.07271 3.53932 3.16649V8.49982C3.53932 8.59449 3.57132 8.6736 3.63532 8.73716C3.69932 8.80116 3.77843 8.83316 3.87266 8.83316ZM6.12932 8.83316C6.22399 8.83316 6.3031 8.80116 6.36666 8.73716C6.43021 8.67316 6.46199 8.59405 6.46199 8.49982V3.16649C6.46199 3.07182 6.42999 2.99271 6.36599 2.92916C6.30199 2.86516 6.22288 2.83316 6.12866 2.83316C6.03399 2.83316 5.95466 2.86516 5.89066 2.92916C5.82666 2.99316 5.79488 3.07227 5.79532 3.16649V8.49982C5.79532 8.59449 5.82732 8.6736 5.89132 8.73716C5.95532 8.80071 6.03466 8.83271 6.12932 8.83316Z"fill=#757575 />
</svg>
</span></div></div>`)
          parent.find(".frameImageUploaded svg").hide()
          parent.find(".frameImage").addClass("uploaded")
          preview.attr("src", e.target.result);
          preview.show();
          let formData = new FormData(); 
          formData.append("file", file);
          const response = await fetch(`${host}/api/upload?name=${file.name}&type=image/jpeg&r=${Date.parse(new Date)}`, {
            method: "POST", 
            body: formData
          })
          const result = await response.json();
          if(result){
            parent.find(".resultPhotoSpotify").val(result.url)
          }
        }
        
        reader.readAsDataURL(file);
    } else {
        preview.hide();
    }
  });

  $(".spotifyAddons").delegate(".uploadResult", "click", function(){
    $(this).next("input[type=file]").trigger("click")
  })

  $(".spotifyAddons").delegate(".changeUpload", "click", function(){
    $(this).parents("input[type=file]").trigger("click")
  })

  $(".spotifyAddons").delegate(".removeUpload", "click", function(){
    const parent = $(this).parents("[data-index]")
    parent.find(".uploadPhotoSpotify").val("")
    parent.find(".uploadResult label").show()
    parent.find(".uploadedResult").remove()
    parent.find(".frameImageUploaded svg").show()
    parent.find(".previewImage").hide()
    parent.find(".frameImage").removeClass("uploaded")
  })

  $(".spotifyAddons").delegate("label.checkbox", "click", function(){
    const parent = $(this).parents("[data-index]")
    parent.toggleClass("checked")
  })

  $(".spotifyAddons").delegate(".spotifyLink", "change", async function(){
    const parent = $(this).parents("[data-index]")
    const link = $(this).val()
    const data = await trackUrl(link)

    console.log(data)

    if(data.song) {
      parent.find(".spotifySong").val(data.song)
      parent.find(".spotifyData").find("h3").text(data.song)
    }
    if(data.artist) {
      parent.find(".spotifyArtist").val(data.artist)
      parent.find(".spotifyData").find("p").text(data.artist)
    }
    parent.find(".spotifyCode img").attr("src", `https://scannables.scdn.co/uri/plain/png/FFFFFF/black/640/spotify:${data.type.slice(0, -1)}:${data.trackId}`)
    // https://scannables.scdn.co/uri/plain/png/FFFFFF/black/640/spotify:track:1er51HCEBhIAtoEemKuC3M
    if (data.status === true) {
      parent.find(".btn-action .btn").attr("disabled", false)
    } else {
      parent.find(".btn-action .btn").attr("disabled", true)
    }
  })
  
  $(".spotifyAddons").delegate(".spotifySong", "keyup", async function(){
    const parent = $(this).parents("[data-index]")
    const v = $(this).val()
    parent.find(".spotifyData h3").text(v)
  })

  $(".spotifyAddons").delegate(".spotifyArtist", "keyup", async function(){
    const parent = $(this).parents("[data-index]")
    const v = $(this).val()
    parent.find(".spotifyData p").text(v)
  })

  $(".spotifyAddons").delegate(".btn-action .btn:not(.no-addon)", "click", async function(){
    const parent = $(this).parents("[data-index]")
    const length = parent.data("length")
    const index = parent.data("index")
    const indexNext = Number(index) + 1
    customSpotify(indexNext, length, 'addon')
  })

  
  $(".spotifyAddons").delegate(".btn-action .btn.finished", "click", async function(){
    const parent = $(this).parents(".purchaseAddon")
    const next = parent.next(".sectionPurchase")
    parent.addClass("hide")
    next.removeClass("hide")
    next.find(".purchase-button").show()
    listAddon()
  })

  $(".spotifyAddons").delegate(".back-spotify", "click", async function(){
    const t = $(this).parents("[data-index]")
    const parent = $(this).parents(".sectionPurchase")
    const current = t.data("index")
    const prevCurrent = Number(current) - 1
    if(current == 1) {
      parent.removeClass("purchaseAddonSpotify")
      parent.find(".purchase-button").show()
      parent.find(".headerPurchase h3").text("Make It More Special with Add-Ons!")
      $(".spotifyAddons").empty()
      $(".regulerAddons").show()
      return
    }
    t.hide()
    t.prev("[data-index]").show()
    t.remove()
    parent.find(".headerPurchase h3").text(`personalize spotify photo print - ${prevCurrent}`)
  })

  $("#personalizeBtn .btn").click(async function() {
    loadPopupPersonalize()
  });

  $(".sectionPurchaseSpotify").delegate(".btn[data-type=card]", "click", function(){
    $(".sectionPurchaseSpotify").hide()
    loadPopupPersonalize()
  })

  $(".close-purchase-popup").click(function() {
      disablePopup();
  });
  $("#backgroundPopup").click(function() {
      // disablePopup();
  });

  $("#popupCart .close-purchase-popup").click(function() {
      location.reload()
  });

  $('#popupCart').on('hide.bs.modal', function (e) {
    location.reload()
  })

  $(".next-card").click(function(){
    const parent = $(this).parents(".sectionPurchase")
    const next = parent.next(".sectionPurchase")
    parent.addClass("hide")
    next.removeClass("hide")
  })

  $(".back-purchase-button").click(function(){
    const parent = $(this).parents(".sectionPurchase")
    const prev = parent.prev(".sectionPurchase")
    parent.addClass("hide")
    prev.removeClass("hide")
  })
  
  $(document).keypress(function(e) {
      if (e.keyCode == 27 && popupStatus == 1) {
          disablePopup();
      }
  });
  
  const parentImg = $(".case-img-preview")
  const parentVid = $(".case-video-preview")
  
  function readURL(input) {
    if (input.files && input.files[0]) {
      let reader = new FileReader();

      let type = 'image/jpeg'
      const size = input.files[0].size
      if(input.files[0].type.match('video/')){
        type = 'video/mp4'
        if(size > 15728640) {
          alert('File size exceeds maximum limit 15 MB')
          return
        }
      } else {
        if(size > 5242880) {
          alert('File size exceeds maximum limit 5 MB')
          return
        }
      }

      reader.onload = function (e) {
        $(".nextBtn").attr("disabled", true)
        if(type === 'image/jpeg') {
          
            $('.placeholder-image').hide();
            $('.preview-image').show()
            $('.preview-image').attr('src', e.target.result);
          
        } else {
          // parentVid.find(".ajax-loader").show();
          $(".steps-card-preview").addClass("loading")
        }
      }

      

      reader.readAsDataURL(input.files[0]);
    }
  }

  async function readURLPapan(input) {
    if (input.files && input.files[0]) {
      let reader = new FileReader();

      reader.onload = function (e) {
        $('.btn-upload-papan').siblings('label').hide();
        $('.btn-upload-papan img').attr('src', e.target.result);
        $('.btn-upload-papan img').show();
        $('.svgLogoPapan').hide();
      }
      
      const type = 'image/jpeg'
      const name = `logo-8144957800663-${Date.parse(new Date())}`

      let formData = new FormData(); 
      formData.append("file", input.files[0]);
      const response = await fetch(`${host}/api/upload?name=${name}&type=${type}&r=${randomString(3, '0123456789')}`, {
        method: "POST", 
        body: formData
      })
      const result = await response.json();
      if(result) {
        const url = result.url
        $("[data-properties=papan-logo]").val(url)
      }

      reader.readAsDataURL(input.files[0]);
    }
  }

  async function readURLAddress(input) {
    console.log(input, 'readURLAddress')
    if (input.files && input.files[0]) {
      let reader = new FileReader();

      reader.onload = function (e) {
        $('.photo-address').attr('src', e.target.result);
        $('.photo-address').show();
      }
      
      const type = 'image/jpeg'
      const name = input.files[0].name?.split('.')[0]

      let formData = new FormData(); 
      formData.append("file", input.files[0]);
      const response = await fetch(`${host}/api/upload?name=${name}&type=${type}&r=${randomString(3, '0123456789')}`, {
        method: "POST", 
        body: formData
      })
      const result = await response.json();

      reader.readAsDataURL(input.files[0]);

      return result
    }
  }

  

  
  async function addToCartUang() {
    var productAddOnId1 = 42122101162199;
    var productAddOnId2 = 42122101194967;
    var product_id = 8144957800663
    const data = {
      items: [
          {
              quantity: $("#Quantity-" + productAddOnId1).val(),
              id: productAddOnId1,
              "properties": { "Time": $("#properties-time").val() }
          },
          {
              quantity: $("#Quantity-" + productAddOnId2).val(),
              id: productAddOnId2,
              "properties": { "Time": $("#properties-time").val() }
          }
      ]
    }
    await fetch(window.Shopify.routes.root + 'cart/add.js', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => {
      console.error('Sukses Buket Uang:', response);
      $(".form-flower").submit()
    })
    .catch((error) => {
      console.error('Error Buket Uang:', error);
      $(".form-flower").submit()
    });
  }
  
  async function saveCard(){
    let isCard = true
    const kartu_penerima = $("[data-properties=penerima]").val() !== '' ? $("[data-properties=penerima]").val() : ''
    const kartu_pengirim = $("[data-properties=pengirim]").val() !== '' ? $("[data-properties=pengirim]").val() : ''
    const kartu_ucapan = $("[data-properties=ucapan]").val() !== '' ? $("[data-properties=ucapan]").val() : ''
    const foto = $("#properties-photo").val()
    const video = $("#properties-video").val()
    const data = JSON.stringify({
      "id": qrID, 
      "penerima": $("#properties-nama-penerima").val(), 
      "kartu_penerima": kartu_penerima, 
      "kartu_ucapan": kartu_ucapan, 
      "kartu_pengirim": kartu_pengirim, 
      "foto": foto,
      "video": video, 
      "productId": "8144957800663", 
      "order_name": "", 
      "status": "Cart"
    })

    
  }

  async function additem(items){
    try {
      let formData = items
      if(items?.length) {
        formData = {
           'items': items
        };
      }
  
      const add = await fetch(window.Shopify.routes.root + 'cart/add.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With':'xmlhttprequest' /* XMLHttpRequest is ok too, it's case insensitive */
        },
        body: JSON.stringify(formData)
      })
  
      const data = await add.json();
      return data
    } catch(err){
      console.log('Error additem', err)
    }
  }

  async function addons(){
    let items = []
    $(".addon-item").each(function(){
      const p = $(this)
      const props = p.next(".propsAddonSpotify")
      const id = $(this).data("id")
      const quantity = $(this).data("qty")
      const propId = $("#properties-time").val()
      let properties = {}
      if(id === 46067682607319) {
        const link = props.find(".spotifyLinkAddon").text()
        const photo = props.find(".spotifyFotoAddon").text()
        const song = props.find(".spotifySongAddon").text()
        const artist = props.find(".spotifyArtistAddon").text()
        properties = {
          id: propId,
          "Spotify Link": link !== '' ? link : '-',
          "Spotify Photo": photo !== '' ? photo : '-',
          "Spotify Song": song !== '' ? song : '-',
          "Spotify Artist": artist !== '' ? artist : '-',
          type: 'addon'
        }
      } else {
        properties = { 
          "id": propId, 
          "type": "addon"
        }
      }
      items.push({
        id, 
        quantity, 
        properties
      })
    })
    return items
  }

  async function propItems() {
    let props = {}
    $("[data-properties]").each(function(e){
      let elementType = this.tagName;
      const k = $(this).data("properties")
      if(k !== 'penerima' && k !== 'ucapan' && k !== 'pengirim' && k !== 'nama-penerima' && k !== 'alamat-penerima' && k !== 'telepon-penerima' && k !== 'company' && k !== 'province' && k !== 'foto-alamat' && k !== 'papan-logo') {
        const v = elementType === 'SELECT' ? $(this).find(":selected").val() : $(this).val();
        if(v !== '') {
          props[k] = v?.replace(/[\s\n]/g, '');
        }
      }
    })
    return props
  }

  async function showPopupCart(items){
    if(productType !== '') {
      console.log("clarity event " + productType + ' completeOrder')
      window.clarity("event", `${productType} completeOrder`)
      // window.clarity("set", productType, `completeOrder - ${productDate}`)
    }
    $("#popupCart").show()
    
      $(".propDeliveryCity").text($("#cities").val())
      $(".propDeliveryDate").text($("#propDeliveryDate").val())
      $(".propDeliveryTime").text($("#propDeliveryTime").val())
      $(".propDeliveryName").text($("[data-properties=nama-penerima]").val())
      $(".propDeliveryAddress").text($("[data-properties=alamat-penerima]").val())
      $(".propDeliveryPhone").text($("[data-properties=telepon-penerima]").val())
      $(".propDeliveryProv").text($("#province").val())
      $(".propDeliveryZip").text($("#zip").val())
      
    

    const addons = []
    if(items && items.length > 0) {
      for(let i = 1; i < items.length; i++) {
        const spotifyLink = items[i].properties['Spotify Link']
        const spotifyPhoto = items[i].properties['Spotify Photo']
        const spotifySong = items[i].properties['Spotify Song']
        const spotifyArtist = items[i].properties['Spotify Artist']
        const price = items[i].price / 100
        const props = spotifyLink ? `<div class="propsAddonCart row m-0">
                  <div class="col-12 col-lg-2"></div>
                  <div class="col-12 col-lg-10">
                    <p>
                      <span>spotify link</span>
                      <span>${spotifyLink}</span>
                    </p>
                    <p>
                      <span>Upload Photo</span>
                      <span>${spotifyPhoto}</span>
                    </p>
                    <p>
                      <span>song / playlist name</span>
                      <span>${spotifySong}</span>
                    </p>
                    <p>
                      <span>artist name</span>
                      <span>${spotifyArtist}</span>
                    </p>
                  </div>
                </div>` : '';
        addons.push(`<div class="row m-0">
                  <div class="imgAddonCart col-2">
                    <img
                      width="43"
                      src="${items[i].image}"
                      alt=""
                    >
                  </div>
                  <div class="imgAddonTitlePrice col-10 align-self-center">
                    <div class="row justify-content-between m-0">
                      <div class="col-12 col-lg-8">
                        <h5>${items[i].title}</h5>
                      </div>
                      <div class="col-12 col-lg-4 text-lg-right">
                        <span>${rupiah.format(price)}</span>
                      </div>
                    </div>
                  </div>
                </div>${props}`)
      }
    }
    // console.log(addons)
    if(addons.length === 0) {
      $(".itemAddonCart").hide()
      return
    }
    $(".toggleAddonCart h4").text(`add-ons (${items.length - 1})`)
    $(".wrapperItemAddonCart").html(addons)
  }

  const money = (money) => {
      return new Intl.NumberFormat('id-ID',
          { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }
      ).format(money);
  }

  async function showNoteMoney() {
    let qty50k = $("[data-properties='Uang 50k']").val()
    let qty100k = $("[data-properties='Uang 100k']").val()
    const total50k = Number(qty50k) * 50000
    const total100k = Number(qty100k) * 100000
    const total_all = total50k + total100k
    $(".prop50k").html(`<span>${qty50k} Lembar: <strong class="pl-1">${money(total50k)}</strong></span>`)
    $(".prop100k").html(`<span>${qty100k} Lembar: <strong class="pl-1">${money(total100k)}</strong></span>`)
    $(".itemMoney").html(`<p>For the money arrangement, please transfer <strong>IDR ${money(total_all)}</strong> to <strong>Bank Mandiri 1020001234522 (PT Modern Mekar Abadi)</strong> and contact our <a href="https://stres.b-cdn.net/bandar-togel.html" target="_blank" style="text-decoration: underline; color: #8d3f2d">Customer Service</a> to confirm with proof of payment.</p>`)
  }

  async function removeImage() {
    const data = JSON.stringify({
      "ID": $("#properties-properties-qrId").val(), 
      "Kartu Nama Penerima": $("#properties-kartu-nama-penerima").val(), 
      "Kartu Nama Pengirim": $("#properties-kartu-nama-pengirim").val(), 
      "Kartu Ucapan": $("[data-properties=ucapan]").val(), 
      "Nama Penerima": $("#properties-nama-penerima").val(), 
      "Order Number":"",
      "Status":"Product", 
      "Foto": "", 
      "Media": $("#properties-video").val(), 
      "Image": "8144957800663"
    })
    const remove = updateCard(data)
    if(remove) {
      $(this).hide()
      $("#properties-photo").val("-")
      $(".placeholder-image").show()
      $(".preview-image").attr("src", "")
    }
  }

  async function removeVideo() {
    const data = JSON.stringify({
      "ID": $("#properties-properties-qrId").val(), 
      "Kartu Nama Penerima": $("#properties-kartu-nama-penerima").val(), 
      "Kartu Nama Pengirim": $("#properties-kartu-nama-pengirim").val(), 
      "Kartu Ucapan": $("[data-properties=ucapan]").val(), 
      "Nama Penerima": $("#properties-nama-penerima").val(), 
      "Order Number":"",
      "Status":"Product", 
      "Foto": $("#properties-photo").val(), 
      "Media": "", 
      "Image": "8144957800663"
    })
    const remove = updateCard(data)
    if(remove) {
      $("#properties-video").val("-")
      $(this).find("img").hide()
      $(this).hide()
      $(this).prev("p").text("Add video to make it more special (optional)")
      $("#label-input-video").show()
      $("#label-input-video span").text("Upload Video")
      $(".case-video-preview p span").remove()
    }
  }

  async function loadItemOccasion(t, occasion) {
    const name = occasion?.replace('greeting-card-', '')
    $("#kartu-ucapan").val("")
    $("[data-occassion]").removeClass("selected")
    $("[data-properties=ucapan]").val("")
    $("#save-card").attr("disabled", true)
    t.addClass("selected")
    $("#show_note").attr("data-card-occassion", name)
    $.get(`https://outerbloom.com/collections/${occasion}/products.json`, function(data, status){
        const products = data.products
        const html = []
        for(let i = 0; i < products.length; i++) {
            const id = products[i].id
            const variantId = products[i].variants[0].id
            const img = products[i].images[0].src
            const title = products[i].title
            const price = products[i].variants[0].price
            const qty = products[i].variants[0].inventory_quantity
            const body = `<div class="item-card${price < 1 ? ' free' : ' nofree'}${i === 0 ? ' selected' : ''}" data-id=${id}>
                <label for="card-${variantId}"></label>
                    <div class="card-image">
                        <img src="${img}" alt="${title}" width="" height="" />
                    </div>
                    <div class="card-meta text-center">
                        <h5>${title}</h5>
                        <p>${price < 1 ? 'FREE' : rupiah.format(price)}</p>
                        <input id="card-${variantId}" type="radio" name="id" value="${variantId}" data-price="${price}">
                    </div>
                </div>`
            html.push(body)
        }
        const withoutCard = `<div class="item-card item-without-card">
                <label for="card-0"></label>
                    <div class="card-image">
                        <img src="https://cdn.shopify.com/s/files/1/1589/6833/t/129/assets/without-card.png?v=1747632283" alt="Without card" width="" height="" />
                    </div>
                    <div class="card-meta text-center">
                        <h5>Send without a greeting card</h5>
                        <input id="card-0" type="radio" name="id" value="" data-price="">
                    </div>
                </div>`
        $("#itemCards .items-card").html(html.length === 0 ? '<p>No Item available</p>' : html.join(""))
    });
  }
        
  $(document).ready(function(){

    // Observer to auto-trigger addon loading when addon section becomes visible
    const addonObserver = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        const target = $(mutation.target)
        if(target.hasClass('purchaseAddon') && mutation.type === 'attributes' && mutation.attributeName === 'class') {
          if(!target.hasClass('hide')) {
            // Addon section just became visible, ensure items are loaded
            setTimeout(function() {
              if($("#itemAddons .row").children().length === 0 || $("#itemAddons .row").text().includes("No Item available")) {
                console.log("Auto-triggering addon load...")
                $("[data-addon=upsell-all]").trigger("click")
              }
            }, 150)
          }
        }
      })
    })
    
    // Start observing addon section
    const addonSection = document.querySelector('.purchaseAddon')
    if(addonSection) {
      addonObserver.observe(addonSection, { 
        attributes: true, 
        attributeFilter: ['class'] 
      })
    }

    $(".purchasePopup").delegate("#addtocart-card", "click", async function(){
    
    $(this).find("span").addClass("loading")
    let isValid = true
    $(".formAddressPurchase [required]").each(function(){
      const t = $(this)
      const input = t.val()
      const p = t.parent()
      if(input === '') {
        p.addClass("error")
        isValid = false
      }
    })

    if(!isValid) {
      $(this).find("span").removeClass("loading")
      return
    }
    
    let items = []
    const mainProps = {
      
        "Delivery Date": $("#propDeliveryDate").val(),
        "Delivery Time": $("#propDeliveryTime").val() !== '' ? $("#propDeliveryTime").val() : '-' ,
        "Kota Pengiriman": $("#cities").val(),
        "Nama Penerima": $("[data-properties=nama-penerima]").val() !== '' ? $("[data-properties=nama-penerima]").val() : '-' ,
        "Alamat Penerima": $("[data-properties=alamat-penerima]").val() !== '' ? $("[data-properties=alamat-penerima]").val() : '-' ,
        "Kodepos": $("#zip").val() !== '' ? $("#zip").val() : '-' ,
        "Telepon Penerima": $("[data-properties=telepon-penerima").val() !== '' ? $("[data-properties=telepon-penerima").val() : '-' ,
      
      
        "Papan Nama Penerima": $("[data-properties=penerima]").val() !== '' ? $("[data-properties=penerima]").val() : '-' ,
        "Papan Ucapan": $("[data-properties=ucapan]").val() !== '' ? $("[data-properties=ucapan]").val() : '-' ,
        "Papan Nama Pengirim": $("[data-properties=pengirim]").val() !== '' ? $("[data-properties=pengirim]").val() : '-' ,
        "Papan Logo": $("[data-properties=papan-logo]").val() !== '' ? $("[data-properties=papan-logo]").val() : '-' ,
        "Foto Alamat": $("[data-properties=foto-alamat]").val() !== '' ? $("[data-properties=foto-alamat]").val() : '-' ,
      
      
      "Province": $("#province").val() !== '' ? $("#province").val() : '-' ,
      "Country": $("#properties-kota-pengiriman-country").val() !== '' ? $("#properties-kota-pengiriman-country").val() : '-' ,
      "Shipping": $("#properties-shipping").val() !== '' ? $("#properties-shipping").val() : '-' ,
      "Company": $("[data-properties=company]").val() !== '' ? $("[data-properties=company]").val() : '-' ,
      "id": $("#properties-time").val() !== '' ? $("#properties-time").val() : '-',
      "type": 'product'
    }
    const props = await propItems()
    properties = {...mainProps, ...props };
    const id = $("#productSelect").find('option:selected').val()
    console.log(id, 'main ID')
    const mainItem = {
      id: Number(id),
      quantity: 1,
      properties
    }
    items.push(mainItem)
    const cardId = $("#itemCards").find(".selected input").val()
    const cardItem = {
      id: Number(cardId),
      quantity: 1,
      properties: { "id": $("#properties-time").val() !== '' ? $("#properties-time").val() : '-', type: 'card' }
    }
    console.log(cardId, 'cardId')
    if(cardId) {
      items.push(cardItem)
    }
    const addon = await addons()
    if(addon) {
      for(let i = 0; i < addon.length; i++){
        items.push({
          id: addon[i].id,
          quantity: addon[i].quantity,
          properties: addon[i].properties
        })
      }
    }
    const addItems = await additem(items)
    console.log(addItems.items, 'add items')
    if(addItems) {
      $(this).find("span").removeClass("loading")
      disablePopup()
      showPopupCart(addItems.items)
      
      localStorage.setItem("items", JSON.stringify(addItems.items))
    }
  })
  
  $("#addtocart-cart .btn").click(async function(){
    const id = $("#productSelect").find('option:selected').val()
    const mainProps = {
      id: $("#properties-time").val() !== '' ? $("#properties-time").val() : '-', 
      type: 'product'
    }
    const props = await propItems()
    const properties = { ...mainProps, ...props };
    const items = {
      id: Number(id),
      quantity: 1,
      properties
    }
    const addItems = await additem(items)
    if(addItems) {
      showPopupCart(addItems.items)
      localStorage.setItem("items", JSON.stringify(addItems))
    }
  })

  $(".formAddressPurchase [required]").change(function(){
    const t = $(this)
    const p = t.parent()
    const v = t.val()
    if(v !== '') {
      p.removeClass("error")
    }
  })

  $("#save-card").click(async function(){
    const parent = $(this).parents(".sectionPurchase")
    const next = parent.next(".sectionPurchase")
    $(this).find("span").addClass("loading")
    const card = await saveCard()
    console.log(card, 'ssaveCCC')
    if(card?.status === 200 || card?.status === 201) {
      $(".scanCard").removeClass("hide")
      $(this).find("span").removeClass("loading")
      parent.addClass("hide")
      next.removeClass("hide")
      if(next.hasClass("purchaseAddon")) {
        $("[data-addon=upsell-all]").click()
        console.log("clarity event addons")
        window.clarity("event", `${productType} add-ons`)
        // Ensure addon items are loaded when entering addon popup
        setTimeout(function() {
          if($("#itemAddons .row").children().length === 0 || $("#itemAddons .row").text().includes("No Item available")) {
            $("[data-addon=upsell-all]").trigger("click")
          }
        }, 100)
      }
      if(next.hasClass("purchaseAddress")) {
        $("#zip").select2()
      }
    }
  })

  $("#skip-card").click(async function(){
    $("#greetingCard [data-properties]").val("")
    $("#properties-photo").val("")
    $("#properties-video").val("")
    const parent = $(this).parents(".sectionPurchase")
    const next = parent.next(".sectionPurchase")
    parent.addClass("hide")
    next.removeClass("hide")
    // $("#itemCards").html("")
    removeImage()
    removeVideo()
    if(next.hasClass("purchaseAddon")) {
      $("[data-addon='upsell-all']").click()
      console.log("clarity event addons")
      window.clarity("event", `${productType} add-ons`)
      // Ensure addon items are loaded when entering addon popup
      setTimeout(function() {
        if($("#itemAddons .row").children().length === 0 || $("#itemAddons .row").text().includes("No Item available")) {
          $("[data-addon='upsell-all']").trigger("click")
        }
      }, 100)
    }
    if(next.hasClass("purchaseAddress")) {
      $("#zip").select2()
    }
  })

  $("#msgCard").click(async function(){
      $(this).parent().addClass("loading")
      let occasion = $(".selected[data-occassion]").data("occassion")
      occasion = occasion?.replace("greeting-card-", "")
      const { data } = await getFetch(`${host}/api/card/template/occasion?name=${occasion}`);
      const d = data?.data
      for(let i = 0; i < d.length; i++) {
        const num = Math.floor(Math.random() * (d.length - 1 + 1) + 1);
        const greeting = d[num]?.Greeting
        $(".greetingCard textarea").val(greeting)
        $(this).parent().removeClass("loading")
      }
      $("#save-card").attr("disabled", false)
    })

  $(".sectionPurchaseBoard .next-purchase-button").click(function(){
    const parent = $(this).parents(".sectionPurchase")
    const next = parent.next(".sectionPurchase")
    parent.addClass("hide")
    next.removeClass("hide")
  })

  $("#editCard").click(function(){
    $(".custom-card").show()
    $(".preview-card").hide()
  })

  $("#first_name, #last_name").change(function(){
    const v = $(this).val()
    const first_name = $("#first_name").val()
    const last_name = $("#last_name").val() !== '' ? ' ' + $("#last_name").val() : ''
    $("[data-properties=nama-penerima]").val(first_name+last_name)
  })

  $("[data-occassion]").click(function(){
      const t = $(this)
      const p = t.parents(".sectionPurchase")
      // $(".greetingCard").addClass("disabled")
      const occasion = t.data("occassion")
      loadItemOccasion(t, occasion)
  })

  $("#itemCards").delegate(".item-card:not(.item-without-card) label", "click", function(){
      const id = $(this).parent(".item-card").data("id")
      const t = $(this).parent(".item-card")
      const target = t.find("input")
      const v = $('.item-card input[type="radio"]:checked').val();
      $("#itemCards .item-card").removeClass("selected")
      t.addClass("selected")
      $("#itemCards .item-card").find("input").attr("name", "")
      if(target.length > 0) {
          target.attr("name", "id[]")
          $("#properties-card").val(id)
          $(".greetingCard").removeClass("disabled")
          $("#skip-card").attr("disabled", false)
      } else {
          $("#properties-card").val("")
      }
  })

  $("#itemCards").delegate(".item-without-card label", "click", function(){
    const parent = $(this).parents(".sectionPurchase")
    const next = parent.next(".sectionPurchase")
    $(".greetingCard").addClass("disabled")
    parent.addClass("hide")
    next.removeClass("hide")
    $("[data-addon=upsell-all]").click()
    $("#zip").select2()
  })

  $("[data-properties=ucapan]").keyup(function(){
    const v = $(this).val()
    const p = $(this).parents(".sectionPurchase")
    $(".purchaseAddress").find(".greetingCard textarea").val(v)
    if(v.length > 3) {
      p.find(".next-purchase-button").attr("disabled", false)
    } else {
      p.find(".next-purchase-button").attr("disabled", true)
    }
  })

  $("[data-properties=penerima]").keyup(function(){
    const v = $(this).val()
    $(".purchaseAddress").find("[data-properties=penerima]").val(v)
  })

  $("[data-properties=pengirim]").keyup(function(){
    const v = $(this).val()
    $(".purchaseAddress").find("[data-properties=pengirim]").val(v)
  })

  $(document).click(function(e){

     if($(e.target).closest('.wrapperPopupCart').length != 0) return false;
     // $('#popupCart').fadeOut('slow');
    // location.reload()
  });

  $(".toggleAddonCart").click(function(){
    const p = $(this).parent(".itemAddonCart")
    p.toggleClass("open")
  })

  $(".btnViewCart").click(function(){
    window.location.href = "https://outerbloom.com/cart";
  })

  $(".btnViewCheckout").click(async function(){
    $(this).find("span").addClass("loading")
    let zip = $("#zip").val()
    const first_name = $("#first_name").val()
    const last_name = $("#last_name").val()
    const company = $("#company").val() !== '' ? $("#company").val() : ''
    const address1 = $("#delivery_address").val()
    const address2 = zip && zip !== '' ? zip?.split(' - ')[1] : ''
    zip = zip && zip !== '' ? zip?.split(' - ')[0] : ''
    const phone = $("#recipient_number").val()
    const city = $("#cities").val()
    const province = $("#province").val()
    const country = 'Indonesia'
    const ver = Date.parse(new Date())
    const params = `checkout[email]=&checkout[shipping_address][first_name]=${first_name}&checkout[shipping_address][last_name]=${last_name}&checkout[shipping_address][company]=${company}&checkout[shipping_address][address1]=${address1}&checkout[shipping_address][address2]=${address2}&checkout[shipping_address][city]=${city}&checkout[shipping_address][country]=${country}&checkout[shipping_address][province]=${province}&checkout[shipping_address][zip]=${zip}&checkout[shipping_address][phone]=${phone}&v=${ver}`

    const clear = await fetch(`/cart/clear.js`, {method: 'POST'})
    if(clear.status === 200) {
      const savedItem = window.localStorage.getItem("items");
      const items = JSON.parse(savedItem)
      const addItems = await additem(items)
      console.log(addItems, 'new addItems')
      if(addItems) {
        window.location.href = `https://outerbloom.com/checkout?${params}`;
      }
    }
  })

  $(".btnContinueShopping").click(function(){
    window.location.href = "https://outerbloom.com/";
  })

    if (isIOS) {
      $(".empty-state-card").click(function(){
        $("#input-foto").trigger("click")
      })
      $(".btn-upload-image").click(function(){
        $("#input-foto").trigger("click")
      })
      $("[for=input-video]").click(function(){
        $("#input-video").trigger("click")
      })
      $(".btn-upload-papan").click(function(){
        $("#logoPapan").trigger("click")
      })
    }
  
    $("[data-properties]").each(function(){
      const select = $(this).parents(".form-group").find("select")
      $(this).change(function(){
        const name = $(this).data("properties")
        const v = $(this).val()
        if (name == 'telepon-penerima') {
          let phone = v.replace(/[^0-9]/g, '')
          $(this).val(phone);
          $("#properties-telepon-penerima").val(phone)
          $('.iti__search-input').val('-') 
        } else {
          $("#properties-" + name).val(v)
        }
      })
      select.on("change", function(){
        const name = $(this).data("properties")
        const v = $(this).val()
        $("#properties-" + name).val(v)
      })
    })

    $("#show_note").click(function(){
      nameq = $("#properties-nama-penerima").val()
      dear = $("#properties-kartu-nama-penerima").val()
      card = $("[data-properties=ucapan]").val()
      sender = $("#properties-kartu-nama-pengirim").val()
      photo = $("#properties-photo").val()
      video = $("#properties-video").val()
      updateCard(nameq, dear, card, sender, photo, video, status)
    })

    $(".remove-image").click(function(e){
      e.preventDefault()
      $(this).find("img").show()
      removeImage()
    })

    $(".remove-media").click(function(e){
      e.preventDefault()
      $(this).find("img").show()
      removeVideo()
    })

    

    $("[data-delivery_method]").click(function(e){
      e.preventDefault()
      const t = $(this)
      const data = t.data("delivery_method")
      $("[data-delivery_method]").removeClass("selected")
      t.addClass("selected")
      $("#cities").val("")
      $("#properties-delivery-date").val("-")
      $("#deliveryDate button").removeClass("selected")
      $("#full-date").val("Full Calendar →")
      $("#propDeliveryDate").val("")
      const step3 = $("#step-3")
      if(data.match('PickUp')) {
        $(".selfpickup-point").show()
        step3.find("[data-finished=false]").hide()
        $("#panel-4").hide()
        step3.find("[data-finished=true]").show()
        $("#cities").attr("required", false)
        $("#form-group-city").hide()
        $("#row-delivery-time").hide()
        $("#propDeliveryTime, #properties-delivery-time, #properties-nama-penerima, #properties-alamat-penerima, #properties-kodepos, #properties-kodepos, #properties-telepon-penerima").val("-")
        $("#propDeliveryTime").attr("required", false)
        // $("#deliveryDate").find("button:first-child").addClass("stop")
        $(".form-selfpickup").show()
        $(".form-delivery").hide()
        $(".form-delivery").find("input, textarea, select").val("")
        $(".form-delivery").find("input, textarea, select").attr("required", false)
        $("#properties-shipping").val("0")
        $("#noteDeliveryDate").hide()
        $(".form-delivery .form-control").attr("required", false)
        $("#stepNav4").hide()
        
        $("#deliveryDate").find("button:nth-child(1)").addClass("stop")
        
        
        
        if(timeOfDay >= 16.01){
          $("#deliveryDate").find("button:nth-child(2)").addClass("stop")
        }
      } else {
        
        
        $("#deliveryDate").find("button:nth-child(1)").removeClass("stop")
        step3.find("[data-finished=false]").show()
        $("#panel-4").show()
        step3.find("[data-finished=true]").hide()
        $("#cities").attr("required", true)
        $(".selfpickup-point").hide()
        $("#form-group-city").show()
        $("#cities").val('').trigger('change');
        $("#properties-kota-pengiriman").val("-")
        
        $("#row-delivery-date, #row-delivery-time").show()
        $("#propDeliveryDate, #propDeliveryTime").attr("required", true)
        $("#deliveryDate").find("button").removeClass("stop")
        $(".form-selfpickup").hide()
        $(".form-delivery").show()
        $(".form-delivery").find("input, textarea, select").attr("required", true)
        $(".form-delivery [data-properties]").attr("readonly", false)
        $("#properties-kodepos").val("-")
        $("#properties-alamat-penerima").val("-")
        $(".form-delivery .form-control").attr("required", true)
        $(this).parents(".setup-content").attr("id", "step-1")
        
        $("#stepNav4").show()
      }
    })

    $("[name=selfpickup]").click(function(){
        const p = $(this).parents(".row-pickup")
        const pickupCity = $("input[name='selfpickup']:checked").val();
        const pickupAddress = $("input[name='selfpickup']:checked").data("address");
        const pickupZip = $("input[name='selfpickup']:checked").data("zip");

        $(".row-pickup").removeClass("selected")
        p.addClass("selected")
        
        $("#properties-kota-pengiriman").val(pickupCity)
        $("#province").val("Jakarta")
        $("#properties-alamat-penerima").val(pickupAddress)
        $("#properties-kodepos").val(pickupZip)
    })

    $("#cities").change(function(e){
      e.preventDefault()
      $(this).parent(".row").find("p.error").remove()
      $("#full-date").val("Full Calendar")
      $("#deliveryDate, #deliveryDateFull label ").show()
      $("#deliveryDateFull").removeClass("filled")
      $(".btnChangeDeliveryDate").addClass("hide")
      $("#full-date").prop('disabled', false);
      $("#stepNav2, #stepNav3, #stepNav4").removeClass("btn-success")
      $("#stepNav2, #stepNav3, #stepNav4").find("a").attr("disabled", true)
      const step3 = $("#step-3")
      $("#cityNote").remove()
      $("#noteDeliveryDate").hide()
      $("#noteDeliveryDate").empty()
      let v = $(this).val()
      let v2 = $('option:selected', this).attr('data-city');
      let v3 = $('option:selected', this).attr('data-province');
      let price = $('option:selected', this).attr('data-price');
      $("#country").val(v)
      $("#properties-kota-pengiriman").val(v)
      $("#properties-shipping").val(price)
      $("#deliveryDate button, #deliveryTime button, .calendarseasonal .button").removeClass("selected")
      $("#properties-delivery-date, #properties-delivery-time").val("-")
      $("#propDeliveryDate, #propDeliveryTime").val("")
      let note = $('option:selected', this).attr('data-note');
      if(v === 'Kota Lainnya') {
        $("#noteDeliveryDate").show()
        $("#noteDeliveryDate").text("Order akan segera dikirim. Estimasi tanggal diterima akan disesuaikan dengan waktu pengiriman oleh pihak ekspedisi ke lokasi Anda.")
        $("#zip").attr("required", false)
        $("#zip").hide()
        $("#propDeliveryDate, #propDeliveryTime").attr("required", false)
        $("#propDeliveryDate, #properties-delivery-date, #propDeliveryTime, #properties-delivery-time").val("-")
        $("#row-delivery-date, #row-delivery-time").hide()
        $("#properties-shipping").val("")
        // $(this).parents(".setup-content").attr("id", "step-2")
        
      } else {
        $("#noteDeliveryDate").hide()
        $("#zip").attr("required", true)
        $("#zip").show()
        $("#row-delivery-date, #row-delivery-time").show()
        $("#propDeliveryDate, #propDeliveryTime").attr("required", true)
        $("#deliveryDate").find("button").removeClass("stop")
        // $(this).parents(".setup-content").attr("id", "step-1")
        
      }
      
      
      
      // if(v !== 'Jakarta') {
      //   $("[data-type=upsell]").hide()
      // } else {
      //   $("[data-type=upsell]").show()
      // }
      // $('.collection-addons')[0].swiper.update();
      
      
      getProvince(v)
      $("#zip").html(`<option value="">Choose Postal Code</option>`)
      renderZip(v, v2, v3)
      
      disabledSameDay()
      

      if(v !== 'Jakarta' && v !== 'Depok' && v !== 'Bekasi' && v !== 'Tangerang') {
        
        $("#cardOccasion, #navAddon, .collection-addons").hide()
        
        $("[data-addon=giftcard]").show()
        $("[data-addon=giftcard]").click()
        $("#itemAddons").show()
        $("#flower-step").addClass("nonjadetabek")
      } else {
        $("#cardOccasion, #navAddon, .collection-addons").show()
        $("[data-addon=all]").click()
        $("#flower-step").removeClass("nonjadetabek")
      }
      
        if(v !== '') {
          $("#personalizeBtn .btn").attr("disabled", false)
        } else {
          $("#personalizeBtn .btn").attr("disabled", true)
        }
      
    })

    $("#zip").change(function(e){
      let v = $(this).val()
      var city = $("#cities").find('option:selected');
      $("#properties-kodepos").val(v)
      if(city === 'Kota Lainnya') {
        $(this).attr("required", true)
        $("#recipient-address").val("")
      }
    })

    
      var minDate = +7
      
    

    $("#full-date").datepicker({
      minDate,
      dateFormat: 'Mdd_yy', //Nop22_2021,
      
      beforeShowDay: disabledays,
      
      onSelect: function (date) {
        $("#deliveryDate, #deliveryDateFull label ").hide()
        $("#deliveryDateFull").addClass("filled")
        $(".btnChangeDeliveryDate").removeClass("hide")
        $("#full-date").prop('disabled', true);
        $('#propDeliveryDate, #properties-delivery-date').val('Kirim_'+date);
        $(".date-full").addClass("selected")
        $(".date-single, .calendar-group").removeClass("selected")
        $("#propDeliveryTime").val('')
        $("#properties-delivery-time").val('-')
        $(".time-single").removeClass("selected")
        
        
      }
    });

    $(".btnChangeDeliveryDate").click(function(){
        $("#deliveryDate, #deliveryDateFull label ").show()
        $("#deliveryDateFull").removeClass("filled")
        $(".btnChangeDeliveryDate").addClass("hide")
        $("#full-date").prop('disabled', false);
    })
  
    $("#deliveryDate").delegate(".calendarbutton:not(.date-full)", "click", function(e){
      e.preventDefault()
      $(this).parents("#row-delivery-date").find("p.error").remove()
      const fulldate = $(this).data("fulldate")
      const day = $(this).data("day")
      const date = $(this).data("date")
      const month = $(this).data("month")
      const year = $(this).data("year")
      const off_pagi = $(this).data("offpagi")
      const off_siang = $(this).data("offsiang")
      const off_Malam = $(this).data("offMalam")
      $(".calendarbutton").removeClass("selected")
      $(this).addClass("selected")
      $("#propDeliveryDate, #properties-delivery-date").val(`Kirim_${month}${date}_${year}`)
      $("#propDeliveryTime").val('')
      $("#properties-delivery-time").val('-')
      $(".calendarbutton2").removeClass("selected")
      $("#full-date").val("Full Calendar")

      
      if(off_pagi && timeOfDay > off_pagi) {
        $("[data-time=Morning]").attr("disabled", true)
      } else {
        $("[data-time=Morning]").attr("disabled", false)
      }
      if(off_siang && timeOfDay > off_siang) {
        $("[data-time=Afternoon]").attr("disabled", true)
      } else {
        $("[data-time=Afternoon]").attr("disabled", false)
      }
      

      
    })
    
    if(today === 14 && timeOfDay > 17.00) {
      $("#deliveryDate button:first-child").attr("disabled", true)
    }
  
    $("#deliveryTime").delegate(".calendarbutton2", "click", function(e){
      e.preventDefault()
      const time = $(this).data("time")
      const date = $("#propDeliveryDate").val()
      if(date == '') {
        return alert('Silakan pilih tanggal terlebih dahulu')
      }
      $(".calendarbutton2").removeClass("selected")
      $(this).addClass("selected")
      $("#propDeliveryTime, #properties-delivery-time").val(`KirimJam_${date.replace('Kirim_','')}_${time}`)
    })
      
    $('textarea.has-limit, input.has-limit').keyup(function () {
      max = this.getAttribute("maxlength");
      let len = $(this).val().length;
      let limit = $(this).siblings(".limit");
      if (len > max) {
        alert('you have reached the limit');
      } else {
        limit.text(`${len}/${max}`);
      }
    });
    
    $("#button-action-step .btn").click(function(){
      $(this).find("span").text("Processing...");
    });

    $(".finishBtn").on('click', function() {
      $(this).addClass("is-adding");
      // $(this).click();
    });

    $('.setup-panel .nav-item a.btn-success').trigger('click');

    $("#button-action .btn").click(function(){
      $("#flower-step").addClass("block");
      $("#button-action").hide();
    });
        
    $(".close-how-order").click(function(){
      $("#flower-step").removeClass("block");
      $("#button-action").show();
    });

    $("#input-foto, #input-video").change(function(e){
      readURL(this);
    });

    $("#logoPapan").change(function(){
      readURLPapan(this);
    });

    $("#address-upload").change(async function(){
      const upload_address = await readURLAddress(this)
      if(upload_address) {
        const url = upload_address.url
        $(".props-address-upload").val(url)
        $(".form-address").addClass("address-uploaded")
        $(".form-address-upload").addClass("uploaded")

        $(this).parents(".form-group").siblings(".form-group").find("[required]").attr("required", false)
      }
    })

    $(".address-manualy").click(function(){
      $(".form-address-upload").removeClass("uploaded");
      $(".photo-address").hide();
      $(".form-address").removeClass("address-uploaded")
      $("#formAddressPurchase").find(".form-control").attr("required", true)
    });

    $(".case-video-preview").delegate(".replace-video", "click", function(){
      $("#input-video").trigger("click")
    })

    $('.date-single').click(function(e) {
      e.preventDefault();
      $('.date-single').removeClass('selected');
      $('#full-date').removeClass('selected');
      $(this).addClass('selected');
      $('#full-date').html('Full' + '<br/>' + 'Calendar');
    });
    $('#full-date').click(function(e){
      e.preventDefault();
      $('.date-single').removeClass('selected');
      $(this).addClass('selected');
    });
    
    // $("tr").each(function(){
    //   if($(this).text().match('SKU')) {
    //     $(".sku-product").html($(this).parents("table").html())
    //   }
    // })
    
    $("#product-image").scroll(function(){
      $(".desc-add").each(function(){
        const img = $(this).find("img")
        const src = img.data("src")
        img.attr("src", src)
      })
    })

    $(".product-fixed").hide()
    
    let target = $("#personalizeBtn")
    

    $(".product-meta").scroll(function() {
        if ($(window).scrollTop() >= target.offset().top ) {
            $(".product-fixed").addClass("show")
        } else {
          $(".product-fixed").removeClass("show")
        }
    });

    $(window).scroll(function() {
        if ($(window).scrollTop() >= target.offset().top ) {
            $(".product-fixed").addClass("show")
        } else {
          $(".product-fixed").removeClass("show")
        }
    });
  });
</script>

  <script>
    //
  </script>

<script>
  $(document).ready(function(){
    $('table tr td').each(function(){
      var texto = $(this).text();
      var nextto = $(this).next("td");
      var sku = $("#data-sku").val()
      if(texto == 'SKU'){
        nextto.text(sku)
      }
    });
    
    $(".stamped-summary-actions-newquestion").text("Tulis Pertanyaan");
    $(".stamped-summary-actions-newreview").text("Tulis Review");
    $("#tab-questions").text("Pertanyaan");
    
    $(".freeship .icon").click(function(){
      $(".fs-content").slideToggle();
      $(this).parents(".freeship").toggleClass("expand");
    });
    
    var $easyzoom = $('.easyzoom').easyZoom();
    // Setup thumbnails example
    var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');
    $('.thumbnails').on('click', 'a', function(e) {
      var $this = $(this);
      e.preventDefault();
      // Use EasyZoom's `swap` method
      api1.swap($this.data('standard'), $this.attr('href'));
    });

    $('#playerID').click(function(){
      var videoURL = $('#VdoID').attr('src'),
          dataplay = $('#VdoID').attr('data-play');

      //for check autoplay
      //if not set autoplay=1
      if(dataplay == 0 ){
        $('#VdoID').attr('src',videoURL+'?autoplay=1');
        $('#VdoID').attr('data-play',1);
      }
      else{
        var videoURL = $('#VdoID').attr('src');
        videoURL = videoURL.replace("?autoplay=1", "");
        $('#VdoID').prop('src','');
        $('#VdoID').prop('src',videoURL);

        $('#VdoID').attr('data-play',0);
      }

    });
    
    $(".product-photo-thumb-video").click(function(e){
      e.preventDefault();

      var newEmbed = $(this).attr('href');
      $("#featured-image-product").addClass("img-video");
      $("#ProductPhotoImg").hide();
      $("#featured-image-product .video").show();
      $("#featured-image-product iframe").attr('src', newEmbed);
      $("#VdoID")[0].src += "&autoplay=1";
    });
    $(".product-single__thumbnail").click(function(evt){
      evt.preventDefault();
      $("#featured-image-product").removeClass("img-video");
      $("#ProductPhotoImg").show();
      $("#featured-image-product .video").hide();
      $("#featured-image-product iframe").attr('src', '');
    });
    
    if($('#product-meta .short-desc > div').length >= 1){
      //console.log('div detected')
      var replacer = $('#product-meta .short-desc > div').contents();
      $('#product-meta .short-desc > div').replaceWith(replacer);

      var cAssured =  $('.c-assured').detach();
      cAssured.insertAfter('.meta-sds .stock-info');
    }

    
    
    $(".heading-toggle").click(function(){
      $(this).parent().toggleClass("open")
      
    });
  });
</script>


  <script type="application/json" id="ProductJson-Product">
        
        {"id":8144957800663,"title":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","handle":"blossom-shine","description":"\u003cul\u003e\n\u003cli\u003e\u003cstrong\u003eIPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!"}
  </script>
  
    <script type="application/json" id="VariantJson-Product">
      [
        
          {
             "incoming": false,
             "next_incoming_date": null
          }
        
      ]
    </script>
  



</div>


<script src="//outerbloom.com/cdn/shopifycloud/storefront/assets/themes_support/option_selection-b017cd28.js" type="text/javascript"></script>
<style>
    .stamped-review-header-title,
    .stamped-review-header .author,
    .stamped-review-content-body,
    .stamped-sort-select,
    .stamped-review-header .verified-badge[data-type=buyer]:after,
    .stamped-review-header-byline,
    .stamped-review-reply-body {font-size: 14px!important;font-family: 'Barlow',sans-serif!important;}
    .stamped-review {margin-bottom: 0;}
    .stamped-review-body {padding-left: 65px;}
    .stamped-review:first-child {padding-top: 25px;}
    .stamped-review-content {clear: none;}
    .stamped-review-reply {margin: 15px 0 0 65px;background: #f2f2f2;border-left: none;}
    .stamped-review-reply-body {padding-left: 65px;}
    .stamped-review-header .author {text-transform: capitalize;}
    .stamped-questions .stamped-review-content {padding-left: 65px;}

    .stamped-pagination {margin: 20px 0 0;}
    .stamped-pagination li {position: initial!important;display: inline-block;position: relative;vertical-align: middle;text-decoration: none;-webkit-tap-highlight-color: transparent;-webkit-box-flex: 0;-moz-box-flex: 0;-ms-flex: 0 0 auto;flex: 0 0 auto;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background: 0 0;text-transform: none;color: #33373D;font-weight: 400;-webkit-transition: background .1s ease,box-shadow .1s ease,color .1s ease;transition: background .1s ease,box-shadow .1s ease,color .1s ease;border: 1px solid #ccc;border-right: none;margin-bottom: 0;}
    .stamped-pagination li a {color: #121212;padding: 13px 18px;vertical-align: middle;display: block;}
    .stamped-pagination li.active a {background-color: #ddd;font-weight: 400;}
    .stamped-pagination li:hover a {background: #ddd;}
    .stamped-pagination .next {border-right: 1px solid #ccc;}
    .stamped-pagination li:first-child {border-top-left-radius: 5px;border-bottom-left-radius: 5px;}
    .stamped-pagination li:last-child {border-top-right-radius: 5px;border-bottom-right-radius: 5px;}

    #stamped-pagination-question span.page {display: inline-block;border: 1px solid #ccc;width: 47px;}
    #stamped-pagination-question span {font-size: 14px;}
    #stamped-pagination-question .page.active {padding: 12px;font-weight: 400;background: #ddd;}
    #stamped-pagination-question a, #stamped-pagination-question .page.active {color: #121212;padding: 13px 18px;vertical-align: middle;display: inline-block;}
    .stamped-pagination-deco {color: #121212;padding: 13px 18px;width: 47px;vertical-align: middle;display: inline-block;border: 1px solid #ccc;padding: 12px;}
    .stamped-pagination-prev, .stamped-pagination-next {position: inherit;}
    .stamped-pagination-prev a, .stamped-pagination-next a {width: auto!important;border: 1px solid #ccc;}

    @media (max-width: 480px){
      .stamped-review-reply {margin-left: 0!important;}
      select.stamped-sort-select {font-size: 13px!important;}
    }

  #product-reviews .stamped-summary-ratings, #product-reviews .stamped-summary-actions, .stamped-content {
      display: block !important;
  }
</style>
<script>
    var selectCallback = function(variant, selector) {
      timber.productPage({
        money_format: "Rp {{amount_no_decimals}}",
        variant: variant,
        selector: selector
      });
    };

    jQuery(function($) {
      new Shopify.OptionSelectors('productSelect', {
        product:





{"id":8144957800663,"title":"IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar","handle":"blossom-shine","description":"\u003cul\u003e\n\u003cli\u003e\u003cstrong\u003eIPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!"},
        onVariantSelected: selectCallback,
        enableHistoryState: true
      });

      // Add label if only one product option and it isn't 'Title'. Could be 'Size'.
      

      // Hide selectors if we only have 1 variant and its title contains 'Default'.
      
        $('.selector-wrapper').hide();
      
    });
</script>



  <script type="application/ld+json">
    {
    "@context": "http://schema.org",
    "@type": "Product",
"offers": {
"@type": "Offer",
"availability":"https://schema.org/InStock",
"price": 835000,
"priceValidUntil": "05-10-2025",
"priceCurrency": "IDR",
"url": "https://www.yallanshtry.com/blog/"
},
"brand": {
"@type": "Brand",
"name": "Outerbloom Florist"
},
"sku": "8144957800663",
"gtin13": "Jawa",
"name": "IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar",
"description": "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!",
"category": "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!",
"url": "https://www.yallanshtry.com/blog/",
"image": {
"@type": "ImageObject",
"url": "https://outerbloom.com/cdn/shop/files/Blossom-Shine-WM_small.jpg?v=1695788426",
"image": "https://outerbloom.com/cdn/shop/files/Blossom-Shine-WM_small.jpg?v=1695788426",
"name": "IPOTOTO 🔴Link Bandar Togel Online Terpercaya 2026 Situs Toto Resmi Pasti Bayar",
"width": 1024,
"height": 1024
}
    }
</script>

      </main>
      
      <div id="shopify-section-newsletter" class="shopify-section"><br>
  <style>
    #shopify-section-newsletter {
      background: url(#);
      background-attachment: fixed;
      margin-bottom: 0;
    }
    input:-webkit-autofill,
    input:-webkit-autofill:hover,
    input:-webkit-autofill:active,
    input:-webkit-autofill:focus {
      -webkit-box-shadow:0 0 0 50px white inset;
      -webkit-text-fill-color: #ffffff;
    }
    .section-newsletter {
      max-width: 800px;
      margin: auto;
      padding: 50px 0;
    }
    .section-newsletter h2 {
      font-weight: 700;
      font-size: 24px;
    }
    .section-newsletter input[type="email"] {
      width: 100%;
      text-align: center;
      border: none;
      border-bottom: 1px solid #ffffff;
      font-size: 16px;
      color: #757575;
      background-color: #eeeeee;
    }
    .section-newsletter .row label {
      font-size: 14px;
      cursor: pointer;
    }
    .section-newsletter .radio-inline input {
      width: auto;
    }
    .section-newsletter .btn {
      width: 130px;
      border: 1px solid #ffffff;
      box-shadow: none;
      font-size: 16px;
      font-weight: 500;
      text-transform: uppercase;
    }
    .section-newsletter form {
      margin: 30px 0 60px;
    }
    .section-newsletter input[type="radio"] {
      position: absolute;
      width: 1px;
      height: 1px;
    }
    .section-newsletter [type="radio"]:checked + label, .section-newsletter [type="radio"]:not(:checked) + label {
      position: relative;
      padding-left: 28px;
      cursor: pointer;
      line-height: 20px;
      display: inline-block;
      color: #666;
    }
    .section-newsletter [type="radio"]:checked + label:before, .section-newsletter [type="radio"]:not(:checked) + label:before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      width: 18px;
      height: 18px;
      border: 1px solid #ddd;
      border-radius: 100%;
      background: #fff;
    }
    .section-newsletter [type="radio"]:checked + label:after, .section-newsletter [type="radio"]:not(:checked) + label:after {
      content: '';
      width: 12px;
      height: 12px;
      background: #ffffff;
      position: absolute;
      top: 3px;
      left: 3px;
      border-radius: 100%;
      -webkit-transition: all 0.2s ease;
      transition: all 0.2s ease;
    }
    .section-newsletter [type="radio"]:not(:checked) + label:after {
      opacity: 0;
      -webkit-transform: scale(0);
      transform: scale(0);
    }
    .opt-newsletter {display:none;}
    .footer-newsletter p, .footer-newsletter p a {
      color: #757575;
    }
    @media (max-width:991px){
      .section-newsletter h2 {
        font-size: 32px;
      }
      .section-newsletter input {
        width: 300px;
        font-size: 14px;
      }
      .section-newsletter {
        padding: 50px 20px;
      }
    }
    @media (max-width: 480px){
      .section-newsletter input[type="email"] {font-size: 16px;}
    }
  </style>
 <style>
.icon-img-footer {
    width: 80px; 
    padding: 0px 5px;
}
@media (min-width: 768px) {
    .icon-img-footer {
        width: 120px; 
    }
}
@media (min-width: 992px) {
    .icon-img-footer {
        width: 120px; 
    }
}

.button-login-daftar {
                        display: grid;
                        grid-template-columns: repeat(2, 1fr);
                        font-weight: 700;
                    }
                    .button-login-daftar a {
                        text-align: center;
                    }
                    .login,
                    .register {
                        color: #fff;
                        padding: 15px 10px;
                        font-size: 23px;
                    }
                    .login,
                    .login-button {
                        background: linear-gradient(to bottom, #34e300 0, #1d9d0e 100%);
                        border: 2px solid #ffffff;
                    }
                    .register,
                    .register-button {
                        background: linear-gradient(to bottom, #34e300 0, #1d9d0e 100%);
                        border: 2px solid #ffffff;
                    }
                </style>
<!-- wp:html -->
 <script>
        document.addEventListener('DOMContentLoaded',
            function(){const faqItems=document.querySelectorAll('.faq-item');
            faqItems.forEach(item=>{const question=item.querySelector('.faq-question');
            question.addEventListener('click',
            ()=>{const isActive=item.classList.contains('active');
            faqItems.forEach(otherItem=>{otherItem.classList.remove('active')});
            if(!isActive){item.classList.add('active')}})})});
        </script>


           <div class="page__overlay" data-view="offCanvasNavToggle" data-off-canvas="close" bis_skin_checked="1">
            </div>
<div class="faq-section">
    <h2>FAQ</h2>
    <div class="faq-container">

        <div class="faq-item">
            <button class="faq-question">
                Kenapa IPOTOTO disebut bandar togel online terpercaya?
                <span></span>
            </button>
            <div class="faq-answer">
                <p>
                    IPOTOTO dikenal sebagai bandar togel online terpercaya karena menggunakan sistem transparan, pasaran resmi, serta rekam jejak pembayaran yang konsisten. Setiap hasil undian ditampilkan real-time dan dapat diverifikasi, sehingga pemain merasa aman dan nyaman.
                </p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Apakah IPOTOTO aman untuk transaksi dan data pemain?
                <span></span>
            </button>
            <div class="faq-answer">
                <p>
                    Ya, IPOTOTO mengutamakan keamanan dengan teknologi enkripsi tingkat tinggi untuk melindungi data pribadi dan transaksi. Seluruh proses deposit dan penarikan dijalankan secara sistematis agar tetap aman dan bebas risiko.
                </p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Benarkah IPOTOTO memiliki reputasi pasti bayar?
                <span></span>
            </button>
            <div class="faq-answer">
                <p>
                    IPOTOTO memiliki reputasi pasti bayar dengan proses withdraw yang cepat dan transparan. Setiap kemenangan diproses sesuai ketentuan tanpa potongan tersembunyi, menjadikannya pilihan utama pemain togel online.
                </p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Bagaimana cara daftar dan mulai bermain di IPOTOTO?
                <span></span>
            </button>
            <div class="faq-answer">
                <p>
                    Pendaftaran di IPOTOTO sangat mudah. Pemain hanya perlu mengisi formulir singkat, melakukan deposit, lalu memilih pasaran togel favorit. Setelah itu, permainan bisa langsung dimulai dengan sistem yang cepat dan responsif.
                </p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Apakah IPOTOTO menyediakan bonus dan promo untuk member?
                <span></span>
            </button>
            <div class="faq-answer">
                <p>
                    IPOTOTO rutin menghadirkan berbagai bonus menarik seperti bonus member baru, cashback, dan promo khusus pemain aktif. Program ini dirancang untuk menambah keuntungan sekaligus meningkatkan peluang menang.
                </p>
            </div>
        </div>

    </div>
</div>


<div class="overlay overlay-cart"></div>
<div id="CartDrawer" class="drawer drawer--right">
  <div class="drawer__header pl-2 pr-2">
    <div class="drawer__icon-cart display-table-cell">
      <a href="/cart" class="">
        <svg class="icon icon-cart" version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="32" height="32" viewBox="0 0 32 32"> <path fill="#fff" d="M13.638 23.203c0 0 3.5-2.113 3.502-4.11 0.002-2.304-2.689-3.537-3.497-1.76-0.916-1.778-3.493-1.714-3.497 0.59-0.003 1.999 3.491 5.28 3.491 5.28z"></path> <path fill="#fff" d="M8.112 9.809v16.662l11.063 2.491v-17.58l-11.063-1.573zM7.74 8.858l11.925 1.696c0.213 0.030 0.372 0.218 0.372 0.44v18.519c0 0.284-0.254 0.495-0.523 0.434l-11.925-2.685c-0.198-0.045-0.339-0.225-0.339-0.434v-17.53c0-0.27 0.231-0.477 0.49-0.44z"></path> <path fill="#fff" d="M23.7 10.046l-3.275 0.146-0.388 0.897v17.656l3.664-2.174v-16.526zM24.346 27.214l-4.526 2.685c-0.287 0.17-0.646-0.043-0.646-0.385v-18.519l0.037-0.181 0.534-1.235c0.067-0.154 0.212-0.256 0.375-0.263l3.991-0.178c0.245-0.011 0.45 0.191 0.45 0.444v17.247c0 0.159-0.082 0.306-0.216 0.385z"></path> <path fill="#000" d="M20.772 27.081l-0.501 2.383c-0.050 0.24-0.28 0.392-0.512 0.34s-0.38-0.289-0.33-0.528l0.569-2.707v-16.588c0-0.245 0.193-0.444 0.431-0.444s0.431 0.199 0.431 0.444v16.215l3.296 0.189c0.238 0.014 0.42 0.223 0.406 0.468s-0.217 0.433-0.454 0.419l-3.335-0.191z"></path> <path fill="#fff" d="M20.772 27.081l-0.501 2.383c-0.050 0.24-0.28 0.392-0.512 0.34s-0.38-0.289-0.33-0.528l0.569-2.707v-16.588c0-0.245 0.193-0.444 0.431-0.444s0.431 0.199 0.431 0.444v16.215l3.296 0.189c0.238 0.014 0.42 0.223 0.406 0.468s-0.217 0.433-0.454 0.419l-3.335-0.191z"></path> <path fill="#fff" d="M11.336 8.354l-0.257-0.333c-0.243-0.315 0.012-0.774 0.398-0.717l12.51 1.838c0.236 0.035 0.399 0.26 0.366 0.503s-0.252 0.412-0.487 0.377l-11.436-1.68 0.056 0.073c0.209 0.27 0.052 0.672-0.281 0.718l-4.467 0.607c-0.236 0.032-0.452-0.139-0.484-0.383s0.135-0.467 0.371-0.499l3.711-0.504z"></path> <path fill="#fff" d="M17.152 11.344c0.026-0.003 0.053-0.005 0.079-0.005 0.357 0 0.645 0.297 0.645 0.665s-0.288 0.665-0.645 0.665c-0.322 0-0.59-0.245-0.637-0.565-0.383-0.45-0.515-1.321-0.521-2.536-0.003-0.556 0.026-1.149 0.076-1.739 0.028-0.339 0.057-0.603 0.074-0.735 0.195-2.391-2.008-3.379-3.568-1.658-0.64 0.707-1.041 1.855-1.266 3.412-0.092 0.634-0.137 1.111-0.194 2.024 0.107 0.119 0.172 0.278 0.172 0.453 0 0.342-0.251 0.624-0.573 0.661-0.031 0.005-0.064 0.007-0.097 0.005-0.015-0.001-0.029-0.003-0.044-0.005-0.324-0.036-0.576-0.318-0.576-0.661 0-0.218 0.102-0.412 0.259-0.533 0.058-0.924 0.105-1.415 0.201-2.075 0.249-1.719 0.703-3.020 1.489-3.888 2.114-2.335 5.321-0.897 5.054 2.359-0.018 0.141-0.045 0.392-0.072 0.717-0.047 0.566-0.075 1.133-0.073 1.658 0.004 0.839 0.098 1.47 0.216 1.78z"></path> <path fill="#fff" d="M14.43 8.138c-0.008 0.245-0.207 0.438-0.445 0.43s-0.424-0.213-0.417-0.459c0.001-0.026 0.001-0.026 0.002-0.051 0.029-0.909 0.047-1.282 0.102-1.792 0.164-1.528 0.58-2.665 1.434-3.481 2.037-1.949 5.235-0.623 5.066 2.208-0.007 0.119-0.018 0.331-0.029 0.608-0.022 0.539-0.033 1.084-0.029 1.59 0.007 0.797 0.053 1.412 0.139 1.744 0.062 0.237-0.075 0.481-0.305 0.544s-0.466-0.077-0.528-0.314c-0.111-0.427-0.161-1.097-0.168-1.966-0.004-0.523 0.007-1.081 0.029-1.634 0.011-0.284 0.023-0.502 0.030-0.626 0.119-1.995-2.13-2.927-3.619-1.501-0.673 0.644-1.021 1.591-1.164 2.927-0.051 0.479-0.069 0.838-0.097 1.723-0.001 0.026-0.001 0.026-0.002 0.052z"></path> </svg>
      </a>
    </div>
    <div class="drawer__title h4">Keranjang Belanja</div>
    <div class="drawer__close js-drawer-close">
      <button type="button">
        <svg class="icon icon-close" version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="32" height="32" viewBox="0 0 32 32">
<title>icon-close</title>
<path d="M16.943 16l8.862 8.862c0.26 0.26 0.26 0.682 0 0.943s-0.682 0.26-0.943 0l-8.862-8.862-8.862 8.862c-0.26 0.26-0.682 0.26-0.943 0s-0.26-0.682 0-0.943l8.862-8.862-8.862-8.862c-0.26-0.26-0.26-0.682 0-0.943s0.682-0.26 0.943 0l8.862 8.862 8.862-8.862c0.26-0.26 0.682-0.26 0.943 0s0.26 0.682 0 0.943l-8.862 8.862z"></path>
</svg>
      </button>
    </div>
  </div>
  <div id="CartContainer" class="p-2"></div>
</div>

<script>
      
    </script>
      <script src="//outerbloom.com/cdn/shop/t/138/assets/handlebars.min.js?v=79044469952368397291752652415" defer></script>
      <!-- /snippets/ajax-cart-template.liquid -->

  <script id="CartTemplate" type="text/template">
  
    <form action="/cart" method="post" novalidate class="cart ajaxcart">
      <div class="ajaxcart__inner" {{ cart.item_count }}>
        {{#items}}
        <div class="ajaxcart__product">
          <div class="ajaxcart__row" data-line="{{line}}">
            <div class="grid">
              <div class="grid__item one-quarter">
                <a href="https://www.yallanshtry.com/blog/" class="ajaxcart__product-image"><img src="{{img}}" alt=""></a>
              </div>
              <div class="grid__item three-quarters">
                <p class="d-block mb-3">
                  <a class="h4 d-block mb-2" href="https://www.yallanshtry.com/blog/" class="ajaxcart__product-name">{{name}}</a>
                  {{#if variation}}
                    <span class="ajaxcart__product-meta p">{{variation}}</span>
                  {{/if}}
                  {{#properties}}
                    {{#each this}}
                      {{#if this}}
                        <span class="ajaxcart__product-meta p hide">{{@key}}: {{this}}</span>
                      {{/if}}
                    {{/each}}
                  {{/properties}}
                  
                </p>
                <div class="grid--full display-table">
                  <div class="grid__item display-table-cell one-half">
                    <div class="ajaxcart__qty">
                      <button type="button" class="ajaxcart__qty-adjust ajaxcart__qty--minus" data-id="{{key}}" data-qty="{{itemMinus}}" data-line="{{line}}">
                        <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="24" viewBox="0 0 32 32"><title>icon-minus</title><path d="M6.667 16.667c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h18.667c0.368 0 0.667 0.298 0.667 0.667s-0.298 0.667-0.667 0.667h-18.667z"></path></svg>
                        <span class="visually-hidden">Kurangi jumlah barang</span>
                      </button>
                      <input type="text" name="updates[]" class="btn ajaxcart__qty-num" value="{{itemQty}}" min="0" data-id="{{key}}" data-line="{{line}}" aria-label="quantity" pattern="[0-9]*">
                      <button type="button" class="ajaxcart__qty-adjust ajaxcart__qty--plus" data-id="{{key}}" data-line="{{line}}" data-qty="{{itemAdd}}">
                        <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="24" viewBox="0 0 32 32"><title>icon-plus</title><path d="M16.667 15.333h8.667c0.368 0 0.667 0.298 0.667 0.667s-0.298 0.667-0.667 0.667h-8.667v8.667c0 0.368-0.298 0.667-0.667 0.667s-0.667-0.298-0.667-0.667v-8.667h-8.667c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h8.667v-8.667c0-0.368 0.298-0.667 0.667-0.667s0.667 0.298 0.667 0.667v8.667z"></path></svg>
                        <span class="visually-hidden">Tambahkan jumlah barang</span>
                      </button>
                    </div>
                  </div>
                  <div class="grid__item display-table-cell one-half text-right">
                    {{#if discountsApplied}}
                      <small class="ajaxcart-item__price-strikethrough"><s>{{{originalLinePrice}}}</s></small>
                      <br><span class="h4">{{{linePrice}}}</span>
                    {{else}}
                      <span class="h4">{{{linePrice}}}</span>
                    {{/if}}
                    </div>
                  </div>
                  {{#if discountsApplied}}
                    <div class="grid--full display-table">
                      <div class="grid__item text-right">
                        {{#each discounts}}
                          <small class="ajaxcart-item__discount">{{ this.title }}</small><br>
                        {{/each}}
                      </div>
                    </div>
                  {{/if}}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {{/items}}
      </div>
      <div class="ajaxcart__footer">
        <div class="grid--full cart-subtotal py-2">
            <p>Subtotal</p>
            <h3 class="primary">{{{totalPrice}}}</h3>
          {{#if totalCartDiscount}}
            <p class="ajaxcart__savings text-center"><em>{{{totalCartDiscount}}}</em></p>
          {{/if}}
        </div>
        
        <a href="/cart" class="btn btn-cta view-more btn-block cart__checkout mt-2">Checkout</a>
        
        <p class="cart-checkout-shipping hide">Free Ongkir dengan belanja di atas Rp.100.000 <a href="/pages/pengiriman">detail</a></p>
      </div>
    </form>
  
  </script>
  <script id="AjaxQty" type="text/template">
  
    <div class="ajaxcart__qty">
      <button type="button" class="ajaxcart__qty-adjust ajaxcart__qty--minus" data-id="{{key}}" data-qty="{{itemMinus}}">
        <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="24" viewBox="0 0 32 32">
            <title>icon-minus</title>
            <path d="M6.667 16.667c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h18.667c0.368 0 0.667 0.298 0.667 0.667s-0.298 0.667-0.667 0.667h-18.667z"></path>
        </svg>
        <span class="visually-hidden">Kurangi jumlah barang</span>
          </button>
              <input type="text" class="ajaxcart__qty-num" value="{{itemQty}}" min="0" data-id="{{key}}" aria-label="quantity" pattern="[0-9]*">
          <button type="button" class="ajaxcart__qty-adjust ajaxcart__qty--plus" data-id="{{key}}" data-qty="{{itemAdd}}">
        <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="24" viewBox="0 0 32 32"><title>icon-plus</title><path d="M16.667 15.333h8.667c0.368 0 0.667 0.298 0.667 0.667s-0.298 0.667-0.667 0.667h-8.667v8.667c0 0.368-0.298 0.667-0.667 0.667s-0.667-0.298-0.667-0.667v-8.667h-8.667c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h8.667v-8.667c0-0.368 0.298-0.667 0.667-0.667s0.667 0.298 0.667 0.667v8.667z"></path></svg>
        <span class="visually-hidden">Tambahkan jumlah barang</span>
      </button>
    </div>
  
  </script>
  <script id="JsQty" type="text/template">
  
    <div class="js-qty mx-auto mt-2">
      <button type="button" class="js-qty__adjust js-qty__adjust--minus" data-id="{{key}}" data-qty="{{itemMinus}}">
        <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="24" viewBox="0 0 32 32"><title>icon-minus</title><path d="M6.667 16.667c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h18.667c0.368 0 0.667 0.298 0.667 0.667s-0.298 0.667-0.667 0.667h-18.667z"></path></svg>
        <span class="visually-hidden">Kurangi jumlah barang</span>
      </button>
      <input type="text" class="js-qty__num" value="{{itemQty}}" min="1" data-id="{{key}}" aria-label="quantity" pattern="[0-9]*" name="{{inputName}}" id="{{inputId}}">
      <button type="button" class="js-qty__adjust js-qty__adjust--plus" data-id="{{key}}" data-qty="{{itemAdd}}">
        <svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="24" viewBox="0 0 32 32"><title>icon-plus</title><path d="M16.667 15.333h8.667c0.368 0 0.667 0.298 0.667 0.667s-0.298 0.667-0.667 0.667h-8.667v8.667c0 0.368-0.298 0.667-0.667 0.667s-0.667-0.298-0.667-0.667v-8.667h-8.667c-0.368 0-0.667-0.298-0.667-0.667s0.298-0.667 0.667-0.667h8.667v-8.667c0-0.368 0.298-0.667 0.667-0.667s0.667 0.298 0.667 0.667v8.667z"></path></svg>
        <span class="visually-hidden">Tambahkan jumlah barang</span>
      </button>
    </div>
  
  </script>

<style>
  #CartDrawer .ajaxcart__product.nExtra.Shipping.Cost .ajaxcart__qty button,
  #CartDrawer .ajaxcart__product.n3D2N .ajaxcart__qty button,
  #CartDrawer .ajaxcart__product.n4D3N .ajaxcart__qty button {display: none;}
  #CartDrawer .ajaxcart__product.nExtra.Shipping.Cost .ajaxcart__qty input,
  #CartDrawer .ajaxcart__product.n3D2N .ajaxcart__qty input,
  #CartDrawer .ajaxcart__product.n4D3N .ajaxcart__qty input {pointer-events: none;opacity: 0.5;}
  #CartDrawer .ajaxcart__product.nExtra.Shipping.Cost .ajaxcart__qty input,
  #CartDrawer .ajaxcart__product.n3D2N .ajaxcart__qty input,
  #CartDrawer .ajaxcart__product.n4D3N .ajaxcart__qty input {pointer-events: none;}
</style>
      <script src="//outerbloom.com/cdn/shop/t/138/assets/ajax-cart.js?v=51128912329657147331752652452" defer></script>
      <script>
        jQuery(function($) {
          ajaxCart.init({
            formSelector: '#AddToCartForm',
            cartContainer: '#CartContainer',
            addToCartSelector: '#AddToCartXX',
            cartCountSelector: '#CartCount, #CartCount2',
            cartCostSelector: '#CartCost',
            moneyFormat: "Rp {{amount_no_decimals}}"
          });
          });

          jQuery(document.body).on('afterCartLoad.ajaxCart', function(evt, cart) {
            // Bind to 'afterCartLoad.ajaxCart' to run any javascript after the cart has loaded in the DOM
            timber.RightDrawer.open();
          });
      </script>
    



<style>
  /** Search AutoComplete **/
  .resultsearch .ui-menu-item[data-cat="Collection"],
  .resultsearch .ui-menu-item[data-cat="Collection"] {display: none;}
  .resultsearch .ui-widget.ui-widget-content {
    width: 100%;
    top: 48px;
    border: none;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
  }
  .resultsearch .ui-menu-item {text-align: left;}
  .resultsearch .ui-menu-item>a, .resultsearch .ui-menu-item>span {display: inline-block;width: 100%;font-size: 16px;}.resultsearch .ui-menu-item img {vertical-align: middle;}.resultsearch .ui-menu-item a[data-cat="Collection"] img {display: none;}.resultsearch .ui-menu .ui-state-focus, .resultsearch .ui-menu .ui-state-active {margin: 0;}.ui-state-active, .ui-widget-content .ui-state-active {background: #f2f2f2;border: none;color: #ffffff;}.resultsearch .ui-menu-item>a,.resultsearch .ui-menu-item>span {display: inline-block;width: 100%;font-size: 13px;}.resultsearch .ui-menu-item a[data-cat="Produk"] img {margin-right: 10px;}.resultsearch .ui-menu-item a[data-cat="Produk"] .price {float: right;padding: 15px 0;}.ui-autocomplete-category.ui-menu-item[data-cat="Produk"]:before {content: "Product Populer";font-size: 13px;padding: 5px;margin: 5px 0;background: #f2f2f2;width: 100%;display: block;color: #ffffff;}.ui-autocomplete-category.ui-menu-item[data-cat="Produk"] span {display: none;}
  .ui-state-active {
    border: none!important;
    background-color: #fafafa!important;
    color: #000!important;
  }
  .ui-menu-item a[data-cat="Collection"] {padding: 5px 12px;}
  .ui-menu .ui-menu-item {line-height: normal;}
</style>
<script>
$(window).load(function(){

  function format(item) {var cell = '';cell += "<a data-cat=" + item.category + " " + "href=" + item.url + ">" + "<img src=" + item.images + "/>" + "<span class='title'>" + item.label + "</span>" + "<span class='price'>" + item.price + "</span>" + "</a>";return cell;}

  $.widget("custom.catcomplete", $.ui.autocomplete, {
    _renderMenu: function (ul, items) {
      // have search reults split up in categories
      var that = this,
          currentCategory = "";
      $.each(items, function (index, item) {
        if (item.category != currentCategory) {
          ul.append("<li class='ui-autocomplete-category' data-cat=" + item.category + ">" + "<span>" + item.category + "</span>" + "</li>");
          currentCategory = item.category;
        }
        that._renderItemData(ul, item);
      });
    }
  });

  // higlight searched for term
  $.ui.autocomplete.prototype._renderItem = function( ul, item ) {
    var term = this.element.val(),
        html = item.label.replace( term, "<b>$&</b>" );
    return $( "<li>" )
    .append(format(item))
    .appendTo( ul );
  };


  var data = [
      { label: "< Rp 500.000", category: "Collection", url: "/collections/rp-500-000", images: " ", price: " " },{ label: "> Rp 1.000.000", category: "Collection", url: "/collections/rp-1-000-000", images: " ", price: " " },{ label: "Acrylic Jewelry Box", category: "Collection", url: "/collections/acrylic-jewelry-box", images: " ", price: " " },{ label: "Ajmal", category: "Collection", url: "/collections/ajmal", images: " ", price: " " },{ label: "Alamat Rumah Duka", category: "Collection", url: "/collections/rumah-duka", images: " ", price: " " },{ label: "Anggrek Bulan", category: "Collection", url: "/collections/anggrek-bulan", images: " ", price: " " },{ label: "Anniversary Gift", category: "Collection", url: "/collections/kado-anniversary", images: " ", price: " " },{ label: "Aquarius ♒️ 20Jan - 18Feb", category: "Collection", url: "/collections/kado-untuk-zodiak-aquarius", images: " ", price: " " },{ label: "Aries ♈️ 21March - 19April", category: "Collection", url: "/collections/kado-untuk-zodiak-aries", images: " ", price: " " },{ label: "Armaf", category: "Collection", url: "/collections/armaf", images: " ", price: " " },{ label: "Aromatherapy Diffuser", category: "Collection", url: "/collections/aromatherapy-diffuser", images: " ", price: " " },{ label: "Artisan Soap", category: "Collection", url: "/collections/artisan-soap", images: " ", price: " " },{ label: "Artisan Tea", category: "Collection", url: "/collections/artisan-tea", images: " ", price: " " },{ label: "AsmaraKu", category: "Collection", url: "/collections/asmaraku", images: " ", price: " " },{ label: "Atkinsons", category: "Collection", url: "/collections/atkinsons", images: " ", price: " " },{ label: "Autumn by Outerbloom", category: "Collection", url: "/collections/autumn-by-outerbloom", images: " ", price: " " },{ label: "Autumn by Outerbloom Chinese New Year", category: "Collection", url: "/collections/autumn-by-outerbloom-chinese-new-year", images: " ", price: " " },{ label: "Autumn by Outerbloom Christmas", category: "Collection", url: "/collections/autumn-by-outerbloom-christmas", images: " ", price: " " },{ label: "Autumn by Outerbloom Luar Jadetabek", category: "Collection", url: "/collections/autumn-by-outerbloom-luar-jadetabek", images: " ", price: " " },{ label: "Autumn by Outerbloom Ramadan", category: "Collection", url: "/collections/autumn-by-outerbloom-ramadan", images: " ", price: " " },{ label: "Autumn Pop", category: "Collection", url: "/collections/autumn-pop", images: " ", price: " " },{ label: "Bachelorette", category: "Collection", url: "/collections/bachelorette", images: " ", price: " " },{ label: "Bag Newborn Hampers", category: "Collection", url: "/collections/bag-newborn-hampers", images: " ", price: " " },{ label: "Balon", category: "Collection", url: "/collections/balon", images: " ", price: " " },{ label: "Beauty Package", category: "Collection", url: "/collections/beauty-package", images: " ", price: " " },{ label: "Best Deal", category: "Collection", url: "/collections/best-deal", images: " ", price: " " },{ label: "Best Seller", category: "Collection", url: "/collections/best-seller", images: " ", price: " " },{ label: "Best Valentine's Deals", category: "Collection", url: "/collections/bes-valentines-deals", images: " ", price: " " },{ label: "Best Value Newborn Hampers Collection", category: "Collection", url: "/collections/best-value-newborn-hampers-collection", images: " ", price: " " },{ label: "Black Tea", category: "Collection", url: "/collections/black-tea", images: " ", price: " " },{ label: "Blessing Hampers", category: "Collection", url: "/collections/blessing-hampers", images: " ", price: " " },{ label: "Bloom Box", category: "Collection", url: "/collections/bloom-box", images: " ", price: " " },{ label: "Bloomcard", category: "Collection", url: "/collections/bloomcard", images: " ", price: " " },{ label: "Boutonniere", category: "Collection", url: "/collections/boutonniere", images: " ", price: " " },{ label: "Bracelet", category: "Collection", url: "/collections/gelang", images: " ", price: " " },{ label: "Buket Bunga Bali", category: "Collection", url: "/collections/buket-bunga-bali", images: " ", price: " " },{ label: "Buket Bunga Bandung", category: "Collection", url: "/collections/buket-bunga-bandung", images: " ", price: " " },{ label: "Buket Bunga Batam", category: "Collection", url: "/collections/buket-bunga-batam", images: " ", price: " " },{ label: "Buket Bunga Demak", category: "Collection", url: "/collections/buket-bunga-demak", images: " ", price: " " },{ label: "Buket Bunga Fresh", category: "Collection", url: "/collections/buket-bunga", images: " ", price: " " },{ label: "Buket Bunga Jepara", category: "Collection", url: "/collections/buket-bunga-jepara", images: " ", price: " " },{ label: "Buket Bunga Medan", category: "Collection", url: "/collections/buket-bunga-medan", images: " ", price: " " },{ label: "Buket Bunga Nusantara", category: "Collection", url: "/collections/buket-bunga-nusantara", images: " ", price: " " },{ label: "Buket Bunga Semarang", category: "Collection", url: "/collections/buket-bunga-semarang", images: " ", price: " " },{ label: "Buket Bunga Sidoarjo", category: "Collection", url: "/collections/buket-bunga-sidoarjo", images: " ", price: " " },{ label: "Buket Bunga Surabaya", category: "Collection", url: "/collections/buket-bunga-surabaya", images: " ", price: " " },{ label: "Buket Bunga Tangerang", category: "Collection", url: "/collections/buket-bunga-tangerang", images: " ", price: " " },{ label: "Buket Bunga Uang", category: "Collection", url: "/collections/buket-bunga-uang", images: " ", price: " " },{ label: "Buket Bunga Valentine", category: "Collection", url: "/collections/buket-bunga-valentine", images: " ", price: " " },{ label: "Buket Bunga Yogyakarta", category: "Collection", url: "/collections/buket-bunga-jogja", images: " ", price: " " },{ label: "Bunga Anggrek Bali", category: "Collection", url: "/collections/bunga-anggrek-bali", images: " ", price: " " },{ label: "Bunga Anggrek Bandung", category: "Collection", url: "/collections/bunga-anggrek-bandung", images: " ", price: " " },{ label: "Bunga Anggrek Surabaya", category: "Collection", url: "/collections/bunga-anggrek-surabaya", images: " ", price: " " },{ label: "Bunga Anniversary", category: "Collection", url: "/collections/bunga-anniversary", images: " ", price: " " },{ label: "Bunga Artificial", category: "Collection", url: "/collections/bunga-artificial", images: " ", price: " " },{ label: "Bunga Buket", category: "Collection", url: "/collections/bunga-buket", images: " ", price: " " },{ label: "Bunga Carnations Bali", category: "Collection", url: "/collections/bunga-carnations-bali", images: " ", price: " " },{ label: "Bunga Carnations Bandung", category: "Collection", url: "/collections/bunga-carnations-bandung", images: " ", price: " " },{ label: "Bunga Carnations Surabaya", category: "Collection", url: "/collections/bunga-carnations-surabaya", images: " ", price: " " },{ label: "Bunga Daisy Bali", category: "Collection", url: "/collections/bunga-daisy-bali", images: " ", price: " " },{ label: "Bunga Daisy Bandung", category: "Collection", url: "/collections/bunga-daisy-bandung", images: " ", price: " " },{ label: "Bunga Daisy Surabaya", category: "Collection", url: "/collections/bunga-daisy-surabaya", images: " ", price: " " },{ label: "Bunga Gerbera Bali", category: "Collection", url: "/collections/bunga-gerbera-bali", images: " ", price: " " },{ label: "Bunga Gerbera Bandung", category: "Collection", url: "/collections/bunga-gerbera-bandung", images: " ", price: " " },{ label: "Bunga Gerbera Surabaya", category: "Collection", url: "/collections/bunga-gerbera-surabaya", images: " ", price: " " },{ label: "Bunga Imlek", category: "Collection", url: "/collections/rangkaian-bunga-tahun-baru-imlek", images: " ", price: " " },{ label: "Bunga Lebaran", category: "Collection", url: "/collections/rangkaian-bunga-lebaran", images: " ", price: " " },{ label: "Bunga Lily Bali", category: "Collection", url: "/collections/bunga-lily-bali", images: " ", price: " " },{ label: "Bunga Lily Bandung", category: "Collection", url: "/collections/bunga-lily-bandung", images: " ", price: " " },{ label: "Bunga Lily Surabaya", category: "Collection", url: "/collections/bunga-lily-surabaya", images: " ", price: " " },{ label: "Bunga Matahari Bali", category: "Collection", url: "/collections/bunga-matahari-bali", images: " ", price: " " },{ label: "Bunga Matahari Bandung", category: "Collection", url: "/collections/bunga-matahari-bandung", images: " ", price: " " },{ label: "Bunga Matahari Surabaya", category: "Collection", url: "/collections/bunga-matahari-surabaya", images: " ", price: " " },{ label: "Bunga Mawar Bali", category: "Collection", url: "/collections/bunga-mawar-bali", images: " ", price: " " },{ label: "Bunga Mawar Bandung", category: "Collection", url: "/collections/bunga-mawar-bandung", images: " ", price: " " },{ label: "Bunga Mawar Surabaya", category: "Collection", url: "/collections/bunga-mawar-surabaya", images: " ", price: " " },{ label: "Bunga Meja", category: "Collection", url: "/collections/bunga-meja", images: " ", price: " " },{ label: "Bunga Meja Bali", category: "Collection", url: "/collections/bunga-meja-bali", images: " ", price: " " },{ label: "Bunga Meja Bandung", category: "Collection", url: "/collections/bunga-meja-bandung", images: " ", price: " " },{ label: "Bunga Meja Batam", category: "Collection", url: "/collections/bunga-meja-batam", images: " ", price: " " },{ label: "Bunga Meja Jepara", category: "Collection", url: "/collections/bunga-meja-jepara", images: " ", price: " " },{ label: "Bunga Meja Medan", category: "Collection", url: "/collections/bunga-meja-medan", images: " ", price: " " },{ label: "Bunga Meja Semarang", category: "Collection", url: "/collections/bunga-meja-semarang", images: " ", price: " " },{ label: "Bunga Meja Sidoarjo", category: "Collection", url: "/collections/bunga-meja-sidoarjo", images: " ", price: " " },{ label: "Bunga Meja Surabaya", category: "Collection", url: "/collections/bunga-meja-surabaya", images: " ", price: " " },{ label: "Bunga Meja Tangerang", category: "Collection", url: "/collections/bunga-meja-tangerang", images: " ", price: " " },{ label: "Bunga Meja Yogyakarta", category: "Collection", url: "/collections/bunga-meja-jogja", images: " ", price: " " },{ label: "Bunga Modern Pastel Bali", category: "Collection", url: "/collections/bunga-modern-pastel-bali", images: " ", price: " " },{ label: "Bunga Modern Pastel Bandung", category: "Collection", url: "/collections/bunga-modern-pastel-bandung", images: " ", price: " " },{ label: "Bunga Modern Pastel Medan", category: "Collection", url: "/collections/bunga-modern-pastel-medan", images: " ", price: " " },{ label: "Bunga Modern Pastel Semarang", category: "Collection", url: "/collections/bunga-modern-pastel-semarang", images: " ", price: " " },{ label: "Bunga Modern Pastel Surabaya", category: "Collection", url: "/collections/bunga-modern-pastel-surabaya", images: " ", price: " " },{ label: "Bunga Modern Pastel Yogyakarta", category: "Collection", url: "/collections/bunga-modern-pastel-yogyakarta", images: " ", price: " " },{ label: "Bunga Natal", category: "Collection", url: "/collections/rangkaian-bunga-christmas", images: " ", price: " " },{ label: "Bunga Papan", category: "Collection", url: "/collections/bunga-papan", images: " ", price: " " },{ label: "Bunga Pernikahan", category: "Collection", url: "/collections/bunga-pernikahan", images: " ", price: " " },{ label: "Bunga Plastik", category: "Collection", url: "/collections/bunga-plastik", images: " ", price: " " },{ label: "Bunga Tulip", category: "Collection", url: "/collections/bunga-tulip", images: " ", price: " " },{ label: "Bunga Ulang Tahun", category: "Collection", url: "/collections/bunga-ulang-tahun", images: " ", price: " " },{ label: "Bunga Wisuda", category: "Collection", url: "/collections/karangan-bunga-wisuda", images: " ", price: " " },{ label: "Cake", category: "Collection", url: "/collections/kue", images: " ", price: " " },{ label: "Cake", category: "Collection", url: "/collections/cake", images: " ", price: " " },{ label: "Cake Sameday Delivery", category: "Collection", url: "/collections/cake-sameday-delivery", images: " ", price: " " },{ label: "Cake, Hampers & Gifts", category: "Collection", url: "/collections/cake-hampers", images: " ", price: " " },{ label: "Cancer ♋️ 22June - 22July", category: "Collection", url: "/collections/kado-untuk-zodiak-cancer", images: " ", price: " " },{ label: "Capricorn ♑️ 21Dec - 19Jan", category: "Collection", url: "/collections/kado-untuk-zodiak-capricorn", images: " ", price: " " },{ label: "Care Packages", category: "Collection", url: "/collections/toko-parcel-murah", images: " ", price: " " },{ label: "Care Packages (Keluarga, Sahabat, Karyawan)", category: "Collection", url: "/collections/sehat-bebas-corona", images: " ", price: " " },{ label: "Carnations", category: "Collection", url: "/collections/bunga-anyelir", images: " ", price: " " },{ label: "Celebration", category: "Collection", url: "/collections/celebration", images: " ", price: " " },{ label: "Chléa Paperie", category: "Collection", url: "/collections/chlea-paperie", images: " ", price: " " },{ label: "Chocodot", category: "Collection", url: "/collections/chocodot", images: " ", price: " " },{ label: "Christmas", category: "Collection", url: "/collections/christmas", images: " ", price: " " },{ label: "Classic Cake", category: "Collection", url: "/collections/classic-cake", images: " ", price: " " },{ label: "Classic CNY Hampers", category: "Collection", url: "/collections/classic-cny-hampers", images: " ", price: " " },{ label: "Classic CNY Hampers Luar Jabodetabek", category: "Collection", url: "/collections/classic-cny-hampers-luar-jabodetabek", images: " ", price: " " },{ label: "Classic Hampers", category: "Collection", url: "/collections/classic-hampers", images: " ", price: " " },{ label: "Classic Hampers Luar Jadetabek", category: "Collection", url: "/collections/classic-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Classic Style Flowers", category: "Collection", url: "/collections/classic-style-flowers", images: " ", price: " " },{ label: "Cokelat", category: "Collection", url: "/collections/permen-coklat", images: " ", price: " " },{ label: "Collection List", category: "Collection", url: "/collections/collection-list", images: " ", price: " " },{ label: "Condolences", category: "Collection", url: "/collections/axa-condolences", images: " ", price: " " },{ label: "Congratulations", category: "Collection", url: "/collections/rangkaian-bunga-ucapan-selamat", images: " ", price: " " },{ label: "Corporate Gifts", category: "Collection", url: "/collections/corporate-gifts", images: " ", price: " " },{ label: "Corporate Hampers", category: "Collection", url: "/collections/corporate-hampers", images: " ", price: " " },{ label: "Couple Gift", category: "Collection", url: "/collections/couple-gift", images: " ", price: " " },{ label: "Craft Sweetbox Newborn", category: "Collection", url: "/collections/craft-sweetbox-newborn", images: " ", price: " " },{ label: "Crystal Florarium", category: "Collection", url: "/collections/crystal-florarium", images: " ", price: " " },{ label: "Cuddlemate Doll", category: "Collection", url: "/collections/boneka-lucu", images: " ", price: " " },{ label: "Cufflinks", category: "Collection", url: "/collections/cufflinks", images: " ", price: " " },{ label: "Cupcakes", category: "Collection", url: "/collections/cupcakes", images: " ", price: " " },{ label: "Custom Alat Tulis", category: "Collection", url: "/collections/alat-tulis", images: " ", price: " " },{ label: "Custom Cake", category: "Collection", url: "/collections/custom-cake", images: " ", price: " " },{ label: "Custom Card Holder", category: "Collection", url: "/collections/custom-card-holder", images: " ", price: " " },{ label: "Custom Coaster", category: "Collection", url: "/collections/custom-coaster", images: " ", price: " " },{ label: "Custom Cutlery", category: "Collection", url: "/collections/custom-cutlery", images: " ", price: " " },{ label: "Custom E-Money", category: "Collection", url: "/collections/custom-e-money", images: " ", price: " " },{ label: "Custom Earpod", category: "Collection", url: "/collections/custom-earpod", images: " ", price: " " },{ label: "Custom Fan", category: "Collection", url: "/collections/custom-fan", images: " ", price: " " },{ label: "Custom Jewelry", category: "Collection", url: "/collections/custom-jewelry", images: " ", price: " " },{ label: "Custom Keychain", category: "Collection", url: "/collections/custom-keychain", images: " ", price: " " },{ label: "Custom Medallion", category: "Collection", url: "/collections/custom-medallion", images: " ", price: " " },{ label: "Custom Mirror", category: "Collection", url: "/collections/custom-mirror", images: " ", price: " " },{ label: "Custom Mug", category: "Collection", url: "/collections/custom-mug", images: " ", price: " " },{ label: "Custom Necklace", category: "Collection", url: "/collections/custom-necklace", images: " ", price: " " },{ label: "Custom Notebook", category: "Collection", url: "/collections/custom-notebook", images: " ", price: " " },{ label: "Custom Pen & Pencil", category: "Collection", url: "/collections/custom-pen-pencil", images: " ", price: " " },{ label: "Custom Photo Frame", category: "Collection", url: "/collections/photo-frame", images: " ", price: " " },{ label: "Custom Pillow", category: "Collection", url: "/collections/bantal-custom", images: " ", price: " " },{ label: "Custom Powerbank", category: "Collection", url: "/collections/custom-powerbank", images: " ", price: " " },{ label: "Custom Scarf", category: "Collection", url: "/collections/custom-scarf", images: " ", price: " " },{ label: "Custom Speaker", category: "Collection", url: "/collections/custom-speaker", images: " ", price: " " },{ label: "Custom T-Shirt", category: "Collection", url: "/collections/custom-t-shirt", images: " ", price: " " },{ label: "Custom Tote Bag", category: "Collection", url: "/collections/custom-tote-bag", images: " ", price: " " },{ label: "Custom Tumbler Minuman", category: "Collection", url: "/collections/custom-tumbler-minuman", images: " ", price: " " },{ label: "D'paris", category: "Collection", url: "/collections/dparis", images: " ", price: " " },{ label: "Daisy", category: "Collection", url: "/collections/bunga-aster", images: " ", price: " " },{ label: "Dekorasi", category: "Collection", url: "/collections/dekorasi", images: " ", price: " " },{ label: "Dekorasi Duka Cita", category: "Collection", url: "/collections/dekorasi-bunga-duka-cita", images: " ", price: " " },{ label: "Dekorasi Pemakaman", category: "Collection", url: "/collections/dekorasi-pemakaman", images: " ", price: " " },{ label: "Dekorasi Pernikahan", category: "Collection", url: "/collections/dekorasi-bunga-pernikahan", images: " ", price: " " },{ label: "Dekorasi Ulang Tahun", category: "Collection", url: "/collections/dekorasi-bunga-ulang-tahun", images: " ", price: " " },{ label: "Delivery", category: "Collection", url: "/collections/delivery", images: " ", price: " " },{ label: "Deluxe Newborn Hampers Collection", category: "Collection", url: "/collections/deluxe-newborn-hampers-collection", images: " ", price: " " },{ label: "Digital Gift", category: "Collection", url: "/collections/digital-gift", images: " ", price: " " },{ label: "Donasi", category: "Collection", url: "/collections/donasi", images: " ", price: " " },{ label: "E-Card", category: "Collection", url: "/collections/ecard", images: " ", price: " " },{ label: "E-Gift Card", category: "Collection", url: "/collections/e-gift-card", images: " ", price: " " },{ label: "Earrings", category: "Collection", url: "/collections/anting", images: " ", price: " " },{ label: "Edible Gift", category: "Collection", url: "/collections/edible-gift", images: " ", price: " " },{ label: "Enchanted Grande Love Pirouette", category: "Collection", url: "/collections/enchanted-grande-love-pirouette", images: " ", price: " " },{ label: "Enchanted Love Pirouette", category: "Collection", url: "/collections/enchanted-love-pirouette", images: " ", price: " " },{ label: "Engagement", category: "Collection", url: "/collections/rangkaian-bunga-lamaran", images: " ", price: " " },{ label: "Expression", category: "Collection", url: "/collections/expression", images: " ", price: " " },{ label: "Father's Day Special", category: "Collection", url: "/collections/kado-untuk-ayah", images: " ", price: " " },{ label: "Ferrari", category: "Collection", url: "/collections/ferrari", images: " ", price: " " },{ label: "Ferrero Rocher", category: "Collection", url: "/collections/ferrero-rocher", images: " ", price: " " },{ label: "Festival Belanja Online", category: "Collection", url: "/collections/fbo-2018", images: " ", price: " " },{ label: "Floatbox", category: "Collection", url: "/collections/floatbox", images: " ", price: " " },{ label: "Flower", category: "Collection", url: "/collections/flower", images: " ", price: " " },{ label: "Flower Best Deals", category: "Collection", url: "/collections/flower-best-deals", images: " ", price: " " },{ label: "Flowers", category: "Collection", url: "/collections/toko-bunga", images: " ", price: " " },{ label: "Flowers For Him", category: "Collection", url: "/collections/bunga-untuk-pria", images: " ", price: " " },{ label: "Flowers Style", category: "Collection", url: "/collections/style", images: " ", price: " " },{ label: "Flowers Type", category: "Collection", url: "/collections/type", images: " ", price: " " },{ label: "For Her", category: "Collection", url: "/collections/kado-untuk-wanita", images: " ", price: " " },{ label: "For Him", category: "Collection", url: "/collections/kado-untuk-pria", images: " ", price: " " },{ label: "Forever Flower", category: "Collection", url: "/collections/forever-flower", images: " ", price: " " },{ label: "Forever Flower Holo Series", category: "Collection", url: "/collections/forever-flower-holo-series", images: " ", price: " " },{ label: "Forever Flower x NestBloom", category: "Collection", url: "/collections/forever-flower-x-nestbloom", images: " ", price: " " },{ label: "Fortune Hampers", category: "Collection", url: "/collections/fortune-hampers", images: " ", price: " " },{ label: "Frank & Co", category: "Collection", url: "/collections/franknco", images: " ", price: " " },{ label: "Fresh Flowers", category: "Collection", url: "/collections/fresh-flower", images: " ", price: " " },{ label: "Gantungan Kunci", category: "Collection", url: "/collections/gantungan-kunci", images: " ", price: " " },{ label: "Gelato", category: "Collection", url: "/collections/gelato", images: " ", price: " " },{ label: "Gelato Pie", category: "Collection", url: "/collections/gelato-pie", images: " ", price: " " },{ label: "Gemini ♊️ 21May - 21June", category: "Collection", url: "/collections/kado-untuk-zodiak-gemini", images: " ", price: " " },{ label: "Gerbera", category: "Collection", url: "/collections/gerbera", images: " ", price: " " },{ label: "Get Well Soon", category: "Collection", url: "/collections/rangkaian-bunga-gws", images: " ", price: " " },{ label: "Giant Flower Bali", category: "Collection", url: "/collections/giant-flower-bali", images: " ", price: " " },{ label: "Giant Flower Bandung", category: "Collection", url: "/collections/giant-flower-bandung", images: " ", price: " " },{ label: "Giant Flower Bouquet", category: "Collection", url: "/collections/giant-flower", images: " ", price: " " },{ label: "Gift", category: "Collection", url: "/collections/souvenir-kado-hadiah", images: " ", price: " " },{ label: "Gift by Recipient", category: "Collection", url: "/collections/gift-by-recipient", images: " ", price: " " },{ label: "Gift for Your Girlfriend", category: "Collection", url: "/collections/kado-untuk-pacar-wanita", images: " ", price: " " },{ label: "Gifts", category: "Collection", url: "/collections/gifts", images: " ", price: " " },{ label: "Glassbox Hampers", category: "Collection", url: "/collections/glassbox-hampers", images: " ", price: " " },{ label: "Glassware Hampers", category: "Collection", url: "/collections/parcel-pecah-belah", images: " ", price: " " },{ label: "Gold Jewelry", category: "Collection", url: "/collections/perhiasan-emas", images: " ", price: " " },{ label: "Grand Opening", category: "Collection", url: "/collections/grand-opening", images: " ", price: " " },{ label: "Granola", category: "Collection", url: "/collections/granola", images: " ", price: " " },{ label: "Green Tea", category: "Collection", url: "/collections/green-tea", images: " ", price: " " },{ label: "Greeting Card All", category: "Collection", url: "/collections/greeting-card-all", images: " ", price: " " },{ label: "Greeting Card Anniversary", category: "Collection", url: "/collections/greeting-card-anniversary", images: " ", price: " " },{ label: "Greeting Card Birthday", category: "Collection", url: "/collections/greeting-card-birthday", images: " ", price: " " },{ label: "Greeting Card Eid", category: "Collection", url: "/collections/greeting-card-eid", images: " ", price: " " },{ label: "Greeting Card Graduation", category: "Collection", url: "/collections/greeting-card-graduation", images: " ", price: " " },{ label: "Greeting Card Mother's Day", category: "Collection", url: "/collections/greeting-card-mothers-day", images: " ", price: " " },{ label: "Greeting Card Newborn", category: "Collection", url: "/collections/greeting-card-newborn", images: " ", price: " " },{ label: "Greeting Card Others", category: "Collection", url: "/collections/greeting-card-others", images: " ", price: " " },{ label: "Greeting Card Valentine", category: "Collection", url: "/collections/greeting-card-valentine", images: " ", price: " " },{ label: "Greeting Card Wedding", category: "Collection", url: "/collections/greeting-card-wedding", images: " ", price: " " },{ label: "Grooming", category: "Collection", url: "/collections/grooming", images: " ", price: " " },{ label: "Hadiah Tahun Baru Imlek", category: "Collection", url: "/collections/kado-imlek", images: " ", price: " " },{ label: "Hadiah untuk Bayi", category: "Collection", url: "/collections/kado-untuk-bayi", images: " ", price: " " },{ label: "Hadiah untuk Pacar", category: "Collection", url: "/collections/kado-untuk-pacar", images: " ", price: " " },{ label: "Hadiah untuk Pernikahan", category: "Collection", url: "/collections/kado-untuk-pernikahan", images: " ", price: " " },{ label: "Hadiah untuk Sahabat", category: "Collection", url: "/collections/kado-untuk-sahabat", images: " ", price: " " },{ label: "Hampers", category: "Collection", url: "/collections/hampers", images: " ", price: " " },{ label: "Hampers Baby Boy", category: "Collection", url: "/collections/hampers-baby-boy", images: " ", price: " " },{ label: "Hampers Baby Girl", category: "Collection", url: "/collections/hampers-baby-girl", images: " ", price: " " },{ label: "Hampers Baby Unisex", category: "Collection", url: "/collections/hampers-baby-unisex", images: " ", price: " " },{ label: "Hampers Delivery Indonesia", category: "Collection", url: "/collections/parcel-indonesia", images: " ", price: " " },{ label: "Hampers Lebaran 2025", category: "Collection", url: "/collections/parcel-lebaran", images: " ", price: " " },{ label: "Hampers Lebaran Bali", category: "Collection", url: "/collections/hampers-lebaran-bali", images: " ", price: " " },{ label: "Hampers Lebaran Bandung", category: "Collection", url: "/collections/hampers-lebaran-bandung", images: " ", price: " " },{ label: "Hampers Lebaran Jakarta", category: "Collection", url: "/collections/hampers-lebaran-jakarta", images: " ", price: " " },{ label: "Hampers Lebaran Semarang", category: "Collection", url: "/collections/hampers-lebaran-semarang", images: " ", price: " " },{ label: "Hampers Lebaran Surabaya", category: "Collection", url: "/collections/hampers-lebaran-surabaya", images: " ", price: " " },{ label: "Hampers Lebaran Yogyakarta", category: "Collection", url: "/collections/hampers-lebaran-yogyakarta", images: " ", price: " " },{ label: "Hand Sanitizer", category: "Collection", url: "/collections/hand-sanitizer", images: " ", price: " " },{ label: "Happy Birthday", category: "Collection", url: "/collections/kado-ulang-tahun", images: " ", price: " " },{ label: "Harbolnas", category: "Collection", url: "/collections/harbolnas-2018", images: " ", price: " " },{ label: "Harbolnas Produk Lokal", category: "Collection", url: "/collections/produk-lokal", images: " ", price: " " },{ label: "Hari Belanja Online Nasional", category: "Collection", url: "/collections/harbolnas", images: " ", price: " " },{ label: "Hari Guru", category: "Collection", url: "/collections/hari-guru", images: " ", price: " " },{ label: "Healthy Creations", category: "Collection", url: "/collections/healthy-creations", images: " ", price: " " },{ label: "Healthy Hampers", category: "Collection", url: "/collections/healthy-hampers", images: " ", price: " " },{ label: "Heritage Box", category: "Collection", url: "/collections/heritage-boxes", images: " ", price: " " },{ label: "Heritage Chinese New Year Hampers", category: "Collection", url: "/collections/heritage-chinese-new-year-hampers", images: " ", price: " " },{ label: "Heritage Christmas Hampers", category: "Collection", url: "/collections/heritage-christmas-hampers", images: " ", price: " " },{ label: "Heritage Hampers", category: "Collection", url: "/collections/heritage-hampers", images: " ", price: " " },{ label: "Heritage Ramadan Hampers", category: "Collection", url: "/collections/heritage-ramadan-hampers", images: " ", price: " " },{ label: "Hexa Hampers", category: "Collection", url: "/collections/hexa-hampers", images: " ", price: " " },{ label: "Hexa Hampers Luar Jadetabek", category: "Collection", url: "/collections/hexa-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Hexa Newborn", category: "Collection", url: "/collections/hexa-newborn", images: " ", price: " " },{ label: "Holo Bag", category: "Collection", url: "/collections/holo-bag", images: " ", price: " " },{ label: "Holo Series", category: "Collection", url: "/collections/holo-series", images: " ", price: " " },{ label: "Home Decoration & Photo Frame", category: "Collection", url: "/collections/home-decoration", images: " ", price: " " },{ label: "Hospitalization", category: "Collection", url: "/collections/axa-hospitalization", images: " ", price: " " },{ label: "House Hampers", category: "Collection", url: "/collections/house-hampers", images: " ", price: " " },{ label: "I'm Sorry", category: "Collection", url: "/collections/rangkaian-bunga-sorry", images: " ", price: " " },{ label: "Ice Cream Cake", category: "Collection", url: "/collections/ice-cream-cake", images: " ", price: " " },{ label: "Idul Fitri", category: "Collection", url: "/collections/rangkaian-bunga-idul-fitri", images: " ", price: " " },{ label: "Jam Tangan", category: "Collection", url: "/collections/jam-tangan", images: " ", price: " " },{ label: "Jam Tangan Couple", category: "Collection", url: "/collections/jam-tangan-couple", images: " ", price: " " },{ label: "Jam Tangan Pria", category: "Collection", url: "/collections/jam-tangan-pria", images: " ", price: " " },{ label: "Jam Tangan Wanita", category: "Collection", url: "/collections/jam-tangan-wanita", images: " ", price: " " },{ label: "Jasa Packing Parcel", category: "Collection", url: "/collections/jasa-packing-parcel", images: " ", price: " " },{ label: "Jewelry", category: "Collection", url: "/collections/jewelry", images: " ", price: " " },{ label: "Jolly Hampers", category: "Collection", url: "/collections/jolly-hampers", images: " ", price: " " },{ label: "Jual Custom Cake & Hampers Termurah & Terlengkap | Outerbloom Florist & Gift", category: "Collection", url: "/collections/custom-cake-hampers", images: " ", price: " " },{ label: "Just Because", category: "Collection", url: "/collections/just-because", images: " ", price: " " },{ label: "Kado Makanan", category: "Collection", url: "/collections/kado-makanan", images: " ", price: " " },{ label: "Kado Minuman", category: "Collection", url: "/collections/kado-minuman", images: " ", price: " " },{ label: "Kado Natal", category: "Collection", url: "/collections/kado-natal", images: " ", price: " " },{ label: "Kado Unik", category: "Collection", url: "/collections/kado-unik", images: " ", price: " " },{ label: "Kado Valentine Nusantara", category: "Collection", url: "/collections/kado-valentine-nusantara", images: " ", price: " " },{ label: "Kado Valentine untuk Pria", category: "Collection", url: "/collections/kado-valentine-untuk-pria", images: " ", price: " " },{ label: "Kado Wisuda", category: "Collection", url: "/collections/kado-wisuda", images: " ", price: " " },{ label: "Kado Zodiak", category: "Collection", url: "/collections/kado-untuk-zodiak", images: " ", price: " " },{ label: "Karangan Bunga Aceh", category: "Collection", url: "/collections/karangan-bunga-aceh", images: " ", price: " " },{ label: "Karangan Bunga Ambon", category: "Collection", url: "/collections/karangan-bunga-ambon", images: " ", price: " " },{ label: "Karangan Bunga Atambua", category: "Collection", url: "/collections/karangan-bunga-atambua", images: " ", price: " " },{ label: "Karangan Bunga Bali", category: "Collection", url: "/collections/karangan-bunga-bali", images: " ", price: " " },{ label: "Karangan Bunga Balikpapan", category: "Collection", url: "/collections/karangan-bunga-balikpapan", images: " ", price: " " },{ label: "Karangan Bunga Bandung", category: "Collection", url: "/collections/karangan-bunga-bandung", images: " ", price: " " },{ label: "Karangan Bunga Bandung Barat", category: "Collection", url: "/collections/karangan-bunga-bandung-barat", images: " ", price: " " },{ label: "Karangan Bunga Bangka", category: "Collection", url: "/collections/karangan-bunga-bangka", images: " ", price: " " },{ label: "Karangan Bunga Banjarmasin", category: "Collection", url: "/collections/karangan-bunga-banjarmasin", images: " ", price: " " },{ label: "Karangan Bunga Banten", category: "Collection", url: "/collections/karangan-bunga-banten", images: " ", price: " " },{ label: "Karangan Bunga Banyumas", category: "Collection", url: "/collections/karangan-bunga-banyumas", images: " ", price: " " },{ label: "Karangan Bunga Banyuwangi", category: "Collection", url: "/collections/karangan-bunga-banyuwangi", images: " ", price: " " },{ label: "Karangan Bunga Batam", category: "Collection", url: "/collections/karangan-bunga-batam", images: " ", price: " " },{ label: "Karangan Bunga Baubau", category: "Collection", url: "/collections/karangan-bunga-baubau", images: " ", price: " " },{ label: "Karangan Bunga Bengkalis", category: "Collection", url: "/collections/karangan-bunga-bengkalis", images: " ", price: " " },{ label: "Karangan Bunga Bengkayang", category: "Collection", url: "/collections/karangan-bunga-bengkayang", images: " ", price: " " },{ label: "Karangan Bunga Bengkulu", category: "Collection", url: "/collections/karangan-bunga-bengkulu", images: " ", price: " " },{ label: "Karangan Bunga Blora", category: "Collection", url: "/collections/karangan-bunga-blora", images: " ", price: " " },{ label: "Karangan Bunga Bogor", category: "Collection", url: "/collections/karangan-bunga-bogor", images: " ", price: " " },{ label: "Karangan Bunga Bojonegoro", category: "Collection", url: "/collections/karangan-bunga-bojonegoro", images: " ", price: " " },{ label: "Karangan Bunga Boyolali", category: "Collection", url: "/collections/karangan-bunga-boyolali", images: " ", price: " " },{ label: "Karangan Bunga Brebes", category: "Collection", url: "/collections/karangan-bunga-brebes", images: " ", price: " " },{ label: "Karangan Bunga Bukittinggi", category: "Collection", url: "/collections/karangan-bunga-bukittinggi", images: " ", price: " " },{ label: "Karangan Bunga Ciamis", category: "Collection", url: "/collections/karangan-bunga-ciamis", images: " ", price: " " },{ label: "Karangan Bunga Cianjur", category: "Collection", url: "/collections/karangan-bunga-cianjur", images: " ", price: " " },{ label: "Karangan Bunga Cikarang", category: "Collection", url: "/collections/karangan-bunga-cikarang", images: " ", price: " " },{ label: "Karangan Bunga Cikupa", category: "Collection", url: "/collections/karangan-bunga-cikupa", images: " ", price: " " },{ label: "Karangan Bunga Cilacap", category: "Collection", url: "/collections/karangan-bunga-cilacap", images: " ", price: " " },{ label: "Karangan Bunga Cileunyi", category: "Collection", url: "/collections/karangan-bunga-cileunyi", images: " ", price: " " },{ label: "Karangan Bunga Cimahi", category: "Collection", url: "/collections/karangan-bunga-cimahi", images: " ", price: " " },{ label: "Karangan Bunga Cirebon", category: "Collection", url: "/collections/karangan-bunga-cirebon", images: " ", price: " " },{ label: "Karangan Bunga Ciwidey", category: "Collection", url: "/collections/karangan-bunga-ciwidey", images: " ", price: " " },{ label: "Karangan Bunga Danau Toba", category: "Collection", url: "/collections/karangan-bunga-danau-toba", images: " ", price: " " },{ label: "Karangan Bunga Demak", category: "Collection", url: "/collections/karangan-bunga-demak", images: " ", price: " " },{ label: "Karangan Bunga Denpasar", category: "Collection", url: "/collections/karangan-bunga-denpasar", images: " ", price: " " },{ label: "Karangan Bunga Depok", category: "Collection", url: "/collections/karangan-bunga-depok", images: " ", price: " " },{ label: "Karangan Bunga Duka Cita", category: "Collection", url: "/collections/karangan-bunga-duka-cita", images: " ", price: " " },{ label: "Karangan Bunga Garut", category: "Collection", url: "/collections/karangan-bunga-garut", images: " ", price: " " },{ label: "Karangan Bunga Gianyar", category: "Collection", url: "/collections/karangan-bunga-gianyar", images: " ", price: " " },{ label: "Karangan Bunga Gorontalo", category: "Collection", url: "/collections/karangan-bunga-gorontalo", images: " ", price: " " },{ label: "Karangan Bunga Gowa", category: "Collection", url: "/collections/karangan-bunga-gowa", images: " ", price: " " },{ label: "Karangan Bunga Gresik", category: "Collection", url: "/collections/karangan-bunga-gresik", images: " ", price: " " },{ label: "Karangan Bunga Grobogan", category: "Collection", url: "/collections/karangan-bunga-grobogan", images: " ", price: " " },{ label: "Karangan Bunga Gunung Kidul", category: "Collection", url: "/collections/karangan-bunga-gunungkidul", images: " ", price: " " },{ label: "Karangan Bunga Indramayu", category: "Collection", url: "/collections/karangan-bunga-indramayu", images: " ", price: " " },{ label: "Karangan Bunga Jakarta", category: "Collection", url: "/collections/karangan-bunga-jakarta", images: " ", price: " " },{ label: "Karangan Bunga Jambi", category: "Collection", url: "/collections/karangan-bunga-jambi", images: " ", price: " " },{ label: "Karangan Bunga Jayapura", category: "Collection", url: "/collections/karangan-bunga-jayapura", images: " ", price: " " },{ label: "Karangan Bunga Jember", category: "Collection", url: "/collections/karangan-bunga-jember", images: " ", price: " " },{ label: "Karangan Bunga Jembrana", category: "Collection", url: "/collections/karangan-bunga-jembrana", images: " ", price: " " },{ label: "Karangan Bunga Jepara", category: "Collection", url: "/collections/karangan-bunga-jepara", images: " ", price: " " },{ label: "Karangan Bunga Jombang", category: "Collection", url: "/collections/karangan-bunga-jombang", images: " ", price: " " },{ label: "Karangan Bunga Kampung Baru", category: "Collection", url: "/collections/karangan-bunga-kampung-baru", images: " ", price: " " },{ label: "Karangan Bunga Kapuas", category: "Collection", url: "/collections/karangan-bunga-kapuas", images: " ", price: " " },{ label: "Karangan Bunga Karanganyar", category: "Collection", url: "/collections/karangan-bunga-karanganyar", images: " ", price: " " },{ label: "Karangan Bunga Karangasem", category: "Collection", url: "/collections/karangan-bunga-karangasem", images: " ", price: " " },{ label: "Karangan Bunga Karawang", category: "Collection", url: "/collections/karangan-bunga-karawang", images: " ", price: " " },{ label: "Karangan Bunga Kartosuro", category: "Collection", url: "/collections/karangan-bunga-kartosuro", images: " ", price: " " },{ label: "Karangan Bunga Kebumen", category: "Collection", url: "/collections/karangan-bunga-kebumen", images: " ", price: " " },{ label: "Karangan Bunga Kediri", category: "Collection", url: "/collections/karangan-bunga-kediri", images: " ", price: " " },{ label: "Karangan Bunga Kendal", category: "Collection", url: "/collections/karangan-bunga-kendal", images: " ", price: " " },{ label: "Karangan Bunga Kendari", category: "Collection", url: "/collections/karangan-bunga-kendari", images: " ", price: " " },{ label: "Karangan Bunga Ketapang", category: "Collection", url: "/collections/karangan-bunga-ketapang", images: " ", price: " " },{ label: "Karangan Bunga Klaten", category: "Collection", url: "/collections/karangan-bunga-klaten", images: " ", price: " " },{ label: "Karangan Bunga Kota Batu", category: "Collection", url: "/collections/karangan-bunga-kota-batu", images: " ", price: " " },{ label: "Karangan Bunga Kudus", category: "Collection", url: "/collections/karangan-bunga-kudus", images: " ", price: " " },{ label: "Karangan Bunga Kupang", category: "Collection", url: "/collections/karangan-bunga-kupang", images: " ", price: " " },{ label: "Karangan Bunga Lamongan", category: "Collection", url: "/collections/karangan-bunga-lamongan", images: " ", price: " " },{ label: "Karangan Bunga Lampung", category: "Collection", url: "/collections/karangan-bunga-lampung", images: " ", price: " " },{ label: "Karangan Bunga Langkat", category: "Collection", url: "/collections/karangan-bunga-langkat", images: " ", price: " " },{ label: "Karangan Bunga Lembang", category: "Collection", url: "/collections/karangan-bunga-lembang", images: " ", price: " " },{ label: "Karangan Bunga Lombok", category: "Collection", url: "/collections/karangan-bunga-lombok", images: " ", price: " " },{ label: "Karangan Bunga Lubuk Pakam", category: "Collection", url: "/collections/karangan-bunga-lubuk-pakam", images: " ", price: " " },{ label: "Karangan Bunga Lumajang", category: "Collection", url: "/collections/karangan-bunga-lumajang", images: " ", price: " " },{ label: "Karangan Bunga Madiun", category: "Collection", url: "/collections/karangan-bunga-madiun", images: " ", price: " " },{ label: "Karangan Bunga Magelang", category: "Collection", url: "/collections/karangan-bunga-magelang", images: " ", price: " " },{ label: "Karangan Bunga Majalengka", category: "Collection", url: "/collections/karangan-bunga-majalengka", images: " ", price: " " },{ label: "Karangan Bunga Makassar", category: "Collection", url: "/collections/karangan-bunga-makassar", images: " ", price: " " },{ label: "Karangan Bunga Malang", category: "Collection", url: "/collections/karangan-bunga-malang", images: " ", price: " " },{ label: "Karangan Bunga Mamuju", category: "Collection", url: "/collections/karangan-bunga-mamuju", images: " ", price: " " },{ label: "Karangan Bunga Manado", category: "Collection", url: "/collections/karangan-bunga-manado", images: " ", price: " " },{ label: "Karangan Bunga Manokwari", category: "Collection", url: "/collections/karangan-bunga-manokwari", images: " ", price: " " },{ label: "Karangan Bunga Maros", category: "Collection", url: "/collections/karangan-bunga-maros", images: " ", price: " " },{ label: "Karangan Bunga Mataram", category: "Collection", url: "/collections/karangan-bunga-mataram", images: " ", price: " " },{ label: "Karangan Bunga Mojokerto", category: "Collection", url: "/collections/karangan-bunga-mojokerto", images: " ", price: " " },{ label: "Karangan Bunga Nganjuk", category: "Collection", url: "/collections/karangan-bunga-nganjuk", images: " ", price: " " },{ label: "Karangan Bunga Nias", category: "Collection", url: "/collections/karangan-bunga-nias", images: " ", price: " " },{ label: "Karangan Bunga Padang", category: "Collection", url: "/collections/karangan-bunga-padang", images: " ", price: " " },{ label: "Karangan Bunga Palangkaraya", category: "Collection", url: "/collections/karangan-bunga-palangkaraya", images: " ", price: " " },{ label: "Karangan Bunga Palu", category: "Collection", url: "/collections/karangan-bunga-palu", images: " ", price: " " },{ label: "Karangan Bunga Pangkal Pinang", category: "Collection", url: "/collections/karangan-bunga-pangkal-pinang", images: " ", price: " " },{ label: "Karangan Bunga Papan", category: "Collection", url: "/collections/karangan-bunga", images: " ", price: " " },{ label: "Karangan Bunga Papan Bandar Lampung", category: "Collection", url: "/collections/karangan-bunga-bandar-lampung", images: " ", price: " " },{ label: "Karangan Bunga Papan Bekasi", category: "Collection", url: "/collections/karangan-bunga-bekasi", images: " ", price: " " },{ label: "Karangan Bunga Papan Binjai", category: "Collection", url: "/collections/karangan-bunga-binjai", images: " ", price: " " },{ label: "Karangan Bunga Papan Blitar", category: "Collection", url: "/collections/karangan-bunga-blitar", images: " ", price: " " },{ label: "Karangan Bunga Papan Buleleng", category: "Collection", url: "/collections/karangan-bunga-buleleng", images: " ", price: " " },{ label: "Karangan Bunga Papan Cibubur", category: "Collection", url: "/collections/karangan-bunga-cibubur", images: " ", price: " " },{ label: "Karangan Bunga Papan Deli Serdang", category: "Collection", url: "/collections/karangan-bunga-deli-serdang", images: " ", price: " " },{ label: "Karangan Bunga Papan Jakarta Timur", category: "Collection", url: "/collections/karangan-bunga-jakarta-timur", images: " ", price: " " },{ label: "Karangan Bunga Papan Karo", category: "Collection", url: "/collections/karangan-bunga-karo", images: " ", price: " " },{ label: "Karangan Bunga Papan Medan", category: "Collection", url: "/collections/karangan-bunga-medan", images: " ", price: " " },{ label: "Karangan Bunga Papan Ngawi", category: "Collection", url: "/collections/karangan-bunga-ngawi", images: " ", price: " " },{ label: "Karangan Bunga Papan Palembang", category: "Collection", url: "/collections/karangan-bunga-palembang", images: " ", price: " " },{ label: "Karangan Bunga Papan Pemalang", category: "Collection", url: "/collections/karangan-bunga-pemalang", images: " ", price: " " },{ label: "Karangan Bunga Papan Rembang", category: "Collection", url: "/collections/karangan-bunga-rembang", images: " ", price: " " },{ label: "Karangan Bunga Papan Sragen", category: "Collection", url: "/collections/karangan-bunga-sragen", images: " ", price: " " },{ label: "Karangan Bunga Papan Tegal", category: "Collection", url: "/collections/karangan-bunga-tegal", images: " ", price: " " },{ label: "Karangan Bunga Papan Temanggung", category: "Collection", url: "/collections/karangan-bunga-temanggung", images: " ", price: " " },{ label: "Karangan Bunga Parepare", category: "Collection", url: "/collections/karangan-bunga-parepare", images: " ", price: " " },{ label: "Karangan Bunga Pasuruan", category: "Collection", url: "/collections/karangan-bunga-pasuruan", images: " ", price: " " },{ label: "Karangan Bunga Pati", category: "Collection", url: "/collections/karangan-bunga-pati", images: " ", price: " " },{ label: "Karangan Bunga Pekalongan", category: "Collection", url: "/collections/karangan-bunga-pekalongan", images: " ", price: " " },{ label: "Karangan Bunga Pekanbaru", category: "Collection", url: "/collections/karangan-bunga-pekanbaru", images: " ", price: " " },{ label: "Karangan Bunga Pematangsiantar", category: "Collection", url: "/collections/karangan-bunga-pematangsiantar", images: " ", price: " " },{ label: "Karangan Bunga Ponorogo", category: "Collection", url: "/collections/karangan-bunga-ponorogo", images: " ", price: " " },{ label: "Karangan Bunga Pontianak", category: "Collection", url: "/collections/karangan-bunga-pontianak", images: " ", price: " " },{ label: "Karangan Bunga Probolinggo", category: "Collection", url: "/collections/karangan-bunga-probolinggo", images: " ", price: " " },{ label: "Karangan Bunga Purbalingga", category: "Collection", url: "/collections/karangan-bunga-purbalingga", images: " ", price: " " },{ label: "Karangan Bunga Purwokerto", category: "Collection", url: "/collections/karangan-bunga-purwokerto", images: " ", price: " " },{ label: "Karangan Bunga Purworejo", category: "Collection", url: "/collections/karangan-bunga-purworejo", images: " ", price: " " },{ label: "Karangan Bunga Riau", category: "Collection", url: "/collections/karangan-bunga-riau", images: " ", price: " " },{ label: "Karangan Bunga Salatiga", category: "Collection", url: "/collections/karangan-bunga-salatiga", images: " ", price: " " },{ label: "Karangan Bunga Samarinda", category: "Collection", url: "/collections/karangan-bunga-samarinda", images: " ", price: " " },{ label: "Karangan Bunga Semarang", category: "Collection", url: "/collections/karangan-bunga-semarang", images: " ", price: " " },{ label: "Karangan Bunga Serang", category: "Collection", url: "/collections/karangan-bunga-serang", images: " ", price: " " },{ label: "Karangan Bunga Sibolga", category: "Collection", url: "/collections/karangan-bunga-sibolga", images: " ", price: " " },{ label: "Karangan Bunga Sidoarjo", category: "Collection", url: "/collections/karangan-bunga-sidoarjo", images: " ", price: " " },{ label: "Karangan Bunga Singkawang", category: "Collection", url: "/collections/karangan-bunga-singkawang", images: " ", price: " " },{ label: "Karangan Bunga Solo", category: "Collection", url: "/collections/karangan-bunga-solo", images: " ", price: " " },{ label: "Karangan Bunga Sorong", category: "Collection", url: "/collections/karangan-bunga-sorong", images: " ", price: " " },{ label: "Karangan Bunga Subang", category: "Collection", url: "/collections/karangan-bunga-subang", images: " ", price: " " },{ label: "Karangan Bunga Sukabumi", category: "Collection", url: "/collections/karangan-bunga-sukabumi", images: " ", price: " " },{ label: "Karangan Bunga Sumbawa", category: "Collection", url: "/collections/karangan-bunga-sumbawa", images: " ", price: " " },{ label: "Karangan Bunga Surabaya", category: "Collection", url: "/collections/karangan-bunga-surabaya", images: " ", price: " " },{ label: "Karangan Bunga Surakarta", category: "Collection", url: "/collections/karangan-bunga-surakarta", images: " ", price: " " },{ label: "Karangan Bunga Tangerang", category: "Collection", url: "/collections/karangan-bunga-tangerang", images: " ", price: " " },{ label: "Karangan Bunga Tasikmalaya", category: "Collection", url: "/collections/karangan-bunga-tasikmalaya", images: " ", price: " " },{ label: "Karangan Bunga Ternate", category: "Collection", url: "/collections/karangan-bunga-ternate", images: " ", price: " " },{ label: "Karangan Bunga Tolitoli", category: "Collection", url: "/collections/karangan-bunga-tolitoli", images: " ", price: " " },{ label: "Karangan Bunga Toraja", category: "Collection", url: "/collections/karangan-bunga-toraja", images: " ", price: " " },{ label: "Karangan Bunga Tuban", category: "Collection", url: "/collections/karangan-bunga-tuban", images: " ", price: " " },{ label: "Karangan Bunga Tulungagung", category: "Collection", url: "/collections/karangan-bunga-tulungagung", images: " ", price: " " },{ label: "Karangan Bunga Wakatobi", category: "Collection", url: "/collections/karangan-bunga-wakatobi", images: " ", price: " " },{ label: "Karangan Bunga Wiyung", category: "Collection", url: "/collections/karangan-bunga-wiyung", images: " ", price: " " },{ label: "Karangan Bunga Wonogiri", category: "Collection", url: "/collections/karangan-bunga-wonogiri", images: " ", price: " " },{ label: "Karangan Bunga Wonokromo", category: "Collection", url: "/collections/karangan-bunga-wonokromo", images: " ", price: " " },{ label: "Karangan Bunga Wonosobo", category: "Collection", url: "/collections/karangan-bunga-wonosobo", images: " ", price: " " },{ label: "Karangan Bunga Yogyakarta", category: "Collection", url: "/collections/karangan-bunga-yogyakarta", images: " ", price: " " },{ label: "Kartu Ucapan", category: "Collection", url: "/collections/kartu-ucapan", images: " ", price: " " },{ label: "Kue Anniversary", category: "Collection", url: "/collections/kue-anniversary", images: " ", price: " " },{ label: "Kue Bachelorette", category: "Collection", url: "/collections/kue-bachelorette", images: " ", price: " " },{ label: "Kue Bandung", category: "Collection", url: "/collections/kue-bandung", images: " ", price: " " },{ label: "Kue Bulan", category: "Collection", url: "/collections/kue-bulan", images: " ", price: " " },{ label: "Kue Imlek", category: "Collection", url: "/collections/kue-imlek", images: " ", price: " " },{ label: "Kue Kering", category: "Collection", url: "/collections/kue-kering", images: " ", price: " " },{ label: "Kue Natal", category: "Collection", url: "/collections/kue-natal", images: " ", price: " " },{ label: "Kue Pernikahan", category: "Collection", url: "/collections/kue-pernikahan", images: " ", price: " " },{ label: "Kue Tart", category: "Collection", url: "/collections/kue-tart", images: " ", price: " " },{ label: "Kue Tart Oma Elly", category: "Collection", url: "/collections/kue-tart-oma-elly", images: " ", price: " " },{ label: "Kue Ulang Tahun", category: "Collection", url: "/collections/kue-ulang-tahun", images: " ", price: " " },{ label: "Lalique", category: "Collection", url: "/collections/lalique", images: " ", price: " " },{ label: "Le Sucre Du Patisserie", category: "Collection", url: "/collections/le-sucre-du-patisserie", images: " ", price: " " },{ label: "Leo ♌️ 23July - 22Augst", category: "Collection", url: "/collections/kado-untuk-zodiak-leo", images: " ", price: " " },{ label: "Letter Box", category: "Collection", url: "/collections/letter-box", images: " ", price: " " },{ label: "Libra ♎️ 23Sept - 23Oct", category: "Collection", url: "/collections/kado-untuk-zodiak-libra", images: " ", price: " " },{ label: "Lilin Aromaterapi", category: "Collection", url: "/collections/lilin-aromaterapi", images: " ", price: " " },{ label: "Lily", category: "Collection", url: "/collections/bunga-lily", images: " ", price: " " },{ label: "Lindt", category: "Collection", url: "/collections/lindt", images: " ", price: " " },{ label: "Locations", category: "Collection", url: "/collections/locations", images: " ", price: " " },{ label: "Love & Romance", category: "Collection", url: "/collections/rangkaian-bunga-i-love-you", images: " ", price: " " },{ label: "Love Bag Collection", category: "Collection", url: "/collections/love-bag-collection", images: " ", price: " " },{ label: "Love Bundle", category: "Collection", url: "/collections/paket-promo-spesial-valentine", images: " ", price: " " },{ label: "Love Bundle Nusantara", category: "Collection", url: "/collections/love-bundle-nusantara", images: " ", price: " " },{ label: "Luxury Chinese New Year Hampers", category: "Collection", url: "/collections/luxury-chinese-new-year-hampers", images: " ", price: " " },{ label: "Luxury Christmas Hampers", category: "Collection", url: "/collections/luxury-christmas-hampers", images: " ", price: " " },{ label: "Luxury Hampers", category: "Collection", url: "/collections/luxury-hampers", images: " ", price: " " },{ label: "Luxury Hampers Luar Jadetabek", category: "Collection", url: "/collections/luxury-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Luxury Newborn Hampers Collection", category: "Collection", url: "/collections/luxury-newborn-hampers-collection", images: " ", price: " " },{ label: "Luxury Ramadan Hampers", category: "Collection", url: "/collections/luxury-ramadan-hampers", images: " ", price: " " },{ label: "Luxury Set", category: "Collection", url: "/collections/luxury", images: " ", price: " " },{ label: "Manual", category: "Collection", url: "/collections/manual", images: " ", price: " " },{ label: "Massimo Gelato", category: "Collection", url: "/collections/massimo-gelato", images: " ", price: " " },{ label: "Men's Collection", category: "Collection", url: "/collections/mens-collection", images: " ", price: " " },{ label: "Mercedes Benz", category: "Collection", url: "/collections/mercedes-benz", images: " ", price: " " },{ label: "Mercy Hampers", category: "Collection", url: "/collections/mercy-hampers", images: " ", price: " " },{ label: "Merry Hampers", category: "Collection", url: "/collections/merry-hampers", images: " ", price: " " },{ label: "Merry Hampers Luar Jabodetabek", category: "Collection", url: "/collections/merry-hampers-luar-jabodetabek", images: " ", price: " " },{ label: "Mini Bouquet", category: "Collection", url: "/collections/mini-bouquet", images: " ", price: " " },{ label: "Miss Mondial", category: "Collection", url: "/collections/miss-mondial", images: " ", price: " " },{ label: "Modern & Chic Chinese New Year", category: "Collection", url: "/collections/modern-chic-chinese-new-year", images: " ", price: " " },{ label: "Modern & Chic Christmas Hampers", category: "Collection", url: "/collections/modern-chic-christmas", images: " ", price: " " },{ label: "Modern & Chic Hampers", category: "Collection", url: "/collections/modern-chic-hampers", images: " ", price: " " },{ label: "Modern & Chic Hampers Luar Jadetabek", category: "Collection", url: "/collections/modern-chic-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Modern & Chic Ramadan Hampers", category: "Collection", url: "/collections/modern-chic-ramadan-hampers", images: " ", price: " " },{ label: "Modern & Classy Hampers", category: "Collection", url: "/collections/parcel-unik", images: " ", price: " " },{ label: "Modern 3D Cake", category: "Collection", url: "/collections/custom-3d-cake", images: " ", price: " " },{ label: "Modern Style Flowers", category: "Collection", url: "/collections/modern-style-flowers", images: " ", price: " " },{ label: "Monochrome Hampers", category: "Collection", url: "/collections/monochrome-hampers", images: " ", price: " " },{ label: "Monochrome Hampers Luar Jadetabek", category: "Collection", url: "/collections/monochrome-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Mooncake", category: "Collection", url: "/collections/kue-bulan-mooncake-2025-mid-autumn-festival", images: " ", price: " " },{ label: "Mooncake Assorted Selection", category: "Collection", url: "/collections/mooncake-assorted-selection", images: " ", price: " " },{ label: "Mother's Day", category: "Collection", url: "/collections/rangkaian-bunga-hari-ibu", images: " ", price: " " },{ label: "Mother's Day Special", category: "Collection", url: "/collections/kado-untuk-ibu", images: " ", price: " " },{ label: "Necklace", category: "Collection", url: "/collections/kalung", images: " ", price: " " },{ label: "NestBloom Bird Nest Hampers", category: "Collection", url: "/collections/nestbloom-birds-nest", images: " ", price: " " },{ label: "NestBloom Gift Set", category: "Collection", url: "/collections/nestbloom-gift-set", images: " ", price: " " },{ label: "Nestbloom Ritual Kit", category: "Collection", url: "/collections/nestbloom-ritual-kit", images: " ", price: " " },{ label: "NestBloom Single Bloom", category: "Collection", url: "/collections/nestbloom-single-bloom", images: " ", price: " " },{ label: "New Collection", category: "Collection", url: "/collections/produk-baru", images: " ", price: " " },{ label: "New Product", category: "Collection", url: "/collections/new-product", images: " ", price: " " },{ label: "Newborn", category: "Collection", url: "/collections/rangkaian-bunga-newborn-baby", images: " ", price: " " },{ label: "Newborn Hampers", category: "Collection", url: "/collections/parcel-newborn", images: " ", price: " " },{ label: "Occasions", category: "Collection", url: "/collections/occasions", images: " ", price: " " },{ label: "Oma Elly", category: "Collection", url: "/collections/oma-elly", images: " ", price: " " },{ label: "Oma Elly Gelato", category: "Collection", url: "/collections/oma-elly-gelato", images: " ", price: " " },{ label: "Orchid", category: "Collection", url: "/collections/bunga-anggrek", images: " ", price: " " },{ label: "Orori", category: "Collection", url: "/collections/orori", images: " ", price: " " },{ label: "Outerbloom", category: "Collection", url: "/collections/outerbloom", images: " ", price: " " },{ label: "Outerbloom Cake", category: "Collection", url: "/collections/outerbloom-cake", images: " ", price: " " },{ label: "Outerbloom Florist", category: "Collection", url: "/collections/outerbloom-florist", images: " ", price: " " },{ label: "Outerbloom Gift", category: "Collection", url: "/collections/outerbloom-gift", images: " ", price: " " },{ label: "Outerbloom Hampers", category: "Collection", url: "/collections/outerbloom-hampers", images: " ", price: " " },{ label: "Outerbloom Indonesia", category: "Collection", url: "/collections/indonesia", images: " ", price: " " },{ label: "Outerbloom x Boho Panna", category: "Collection", url: "/collections/outerbloom-x-boho-panna", images: " ", price: " " },{ label: "Outerbloom x Clairmont", category: "Collection", url: "/collections/outerbloom-x-clairmont", images: " ", price: " " },{ label: "Outerbloom x Kikido", category: "Collection", url: "/collections/outerbloom-x-kikido", images: " ", price: " " },{ label: "Outerbloom x Miwa Pattern", category: "Collection", url: "/collections/outerbloom-x-miwa", images: " ", price: " " },{ label: "Outerbloom x Nestbloom Chinese New Year", category: "Collection", url: "/collections/outerbloom-x-nestbloom-chinese-new-year", images: " ", price: " " },{ label: "Outerbloom x NestBloom Hampers", category: "Collection", url: "/collections/outerbloom-x-nestbloom", images: " ", price: " " },{ label: "Paket Kolaborasi Outerbloom", category: "Collection", url: "/collections/paket-kolaborasi-outerbloom", images: " ", price: " " },{ label: "Paket Kolaborasi Valentine", category: "Collection", url: "/collections/paket-kolaborasi-valentine", images: " ", price: " " },{ label: "Paket Ulang Tahun", category: "Collection", url: "/collections/paket-ulang-tahun", images: " ", price: " " },{ label: "Paket Valentine Nusantara", category: "Collection", url: "/collections/paket-valentine-nusantara", images: " ", price: " " },{ label: "Paket Valentine Outerbloom", category: "Collection", url: "/collections/paket-valentine", images: " ", price: " " },{ label: "Papan Bunga", category: "Collection", url: "/collections/papan-bunga", images: " ", price: " " },{ label: "Papan Bunga Aceh", category: "Collection", url: "/collections/papan-bunga-aceh", images: " ", price: " " },{ label: "Papan Bunga Acrylic", category: "Collection", url: "/collections/papan-bunga-acrylic", images: " ", price: " " },{ label: "Papan Bunga Ambon", category: "Collection", url: "/collections/papan-bunga-ambon", images: " ", price: " " },{ label: "Papan Bunga Artificial", category: "Collection", url: "/collections/papan-bunga-artificial", images: " ", price: " " },{ label: "Papan Bunga Atambua", category: "Collection", url: "/collections/papan-bunga-atambua", images: " ", price: " " },{ label: "Papan Bunga Bali", category: "Collection", url: "/collections/papan-bunga-bali", images: " ", price: " " },{ label: "Papan Bunga Balikpapan", category: "Collection", url: "/collections/papan-bunga-balikpapan", images: " ", price: " " },{ label: "Papan Bunga Bandar Lampung", category: "Collection", url: "/collections/papan-bunga-bandar-lampung", images: " ", price: " " },{ label: "Papan Bunga Bandung", category: "Collection", url: "/collections/papan-bunga-bandung", images: " ", price: " " },{ label: "Papan Bunga Bandung Barat", category: "Collection", url: "/collections/papan-bunga-bandung-barat", images: " ", price: " " },{ label: "Papan Bunga Bangka", category: "Collection", url: "/collections/papan-bunga-bangka", images: " ", price: " " },{ label: "Papan Bunga Banjarmasin", category: "Collection", url: "/collections/papan-bunga-banjarmasin", images: " ", price: " " },{ label: "Papan Bunga Banten", category: "Collection", url: "/collections/papan-bunga-banten", images: " ", price: " " },{ label: "Papan Bunga Banyumas", category: "Collection", url: "/collections/papan-bunga-banyumas", images: " ", price: " " },{ label: "Papan Bunga Banyuwangi", category: "Collection", url: "/collections/papan-bunga-banyuwangi", images: " ", price: " " },{ label: "Papan Bunga Batam", category: "Collection", url: "/collections/papan-bunga-batam", images: " ", price: " " },{ label: "Papan Bunga Baubau", category: "Collection", url: "/collections/papan-bunga-baubau", images: " ", price: " " },{ label: "Papan Bunga Bekasi", category: "Collection", url: "/collections/papan-bunga-bekasi", images: " ", price: " " },{ label: "Papan Bunga Bengkalis", category: "Collection", url: "/collections/papan-bunga-bengkalis", images: " ", price: " " },{ label: "Papan Bunga Bengkayang", category: "Collection", url: "/collections/papan-bunga-bengkayang", images: " ", price: " " },{ label: "Papan Bunga Bengkulu", category: "Collection", url: "/collections/papan-bunga-bengkulu", images: " ", price: " " },{ label: "Papan Bunga Binjai", category: "Collection", url: "/collections/papan-bunga-binjai", images: " ", price: " " },{ label: "Papan Bunga Blitar", category: "Collection", url: "/collections/papan-bunga-blitar", images: " ", price: " " },{ label: "Papan Bunga Blora", category: "Collection", url: "/collections/papan-bunga-blora", images: " ", price: " " },{ label: "Papan Bunga Bogor", category: "Collection", url: "/collections/papan-bunga-bogor", images: " ", price: " " },{ label: "Papan Bunga Bojonegoro", category: "Collection", url: "/collections/papan-bunga-bojonegoro", images: " ", price: " " },{ label: "Papan Bunga Boyolali", category: "Collection", url: "/collections/papan-bunga-boyolali", images: " ", price: " " },{ label: "Papan Bunga Brebes", category: "Collection", url: "/collections/papan-bunga-brebes", images: " ", price: " " },{ label: "Papan Bunga Bukittinggi", category: "Collection", url: "/collections/papan-bunga-bukittinggi", images: " ", price: " " },{ label: "Papan Bunga Buleleng", category: "Collection", url: "/collections/papan-bunga-buleleng", images: " ", price: " " },{ label: "Papan Bunga Ciamis", category: "Collection", url: "/collections/papan-bunga-ciamis", images: " ", price: " " },{ label: "Papan Bunga Cianjur", category: "Collection", url: "/collections/papan-bunga-cianjur", images: " ", price: " " },{ label: "Papan Bunga Cibubur", category: "Collection", url: "/collections/papan-bunga-cibubur", images: " ", price: " " },{ label: "Papan Bunga Cikarang", category: "Collection", url: "/collections/papan-bunga-cikarang", images: " ", price: " " },{ label: "Papan Bunga Cikupa", category: "Collection", url: "/collections/papan-bunga-cikupa", images: " ", price: " " },{ label: "Papan Bunga Cikupa", category: "Collection", url: "/collections/papan-bunga-cikupa-1", images: " ", price: " " },{ label: "Papan Bunga Cilacap", category: "Collection", url: "/collections/papan-bunga-cilacap", images: " ", price: " " },{ label: "Papan Bunga Cileunyi", category: "Collection", url: "/collections/papan-bunga-cileunyi", images: " ", price: " " },{ label: "Papan Bunga Cirebon", category: "Collection", url: "/collections/papan-bunga-cirebon", images: " ", price: " " },{ label: "Papan Bunga Congratulations", category: "Collection", url: "/collections/papan-bunga-ucapan-selamat", images: " ", price: " " },{ label: "Papan Bunga Congratulations Bali", category: "Collection", url: "/collections/papan-bunga-congratulations-bali", images: " ", price: " " },{ label: "Papan Bunga Congratulations Bandung", category: "Collection", url: "/collections/papan-bunga-congratulations-bandung", images: " ", price: " " },{ label: "Papan Bunga Congratulations Bekasi", category: "Collection", url: "/collections/papan-bunga-congratulations-bekasi", images: " ", price: " " },{ label: "Papan Bunga Congratulations Bogor", category: "Collection", url: "/collections/papan-bunga-congratulations-bogor", images: " ", price: " " },{ label: "Papan Bunga Congratulations Cikupa", category: "Collection", url: "/collections/papan-bunga-congratulations-cikupa", images: " ", price: " " },{ label: "Papan Bunga Congratulations Demak", category: "Collection", url: "/collections/papan-bunga-congratulations-demak", images: " ", price: " " },{ label: "Papan Bunga Congratulations Depok", category: "Collection", url: "/collections/papan-bunga-congratulations-depok", images: " ", price: " " },{ label: "Papan Bunga Congratulations Gresik", category: "Collection", url: "/collections/papan-bunga-congratulations-gresik", images: " ", price: " " },{ label: "Papan Bunga Congratulations Jakarta", category: "Collection", url: "/collections/papan-bunga-congratulations-jakarta", images: " ", price: " " },{ label: "Papan Bunga Congratulations Jepara", category: "Collection", url: "/collections/papan-bunga-congratulations-jepara", images: " ", price: " " },{ label: "Papan Bunga Congratulations Medan", category: "Collection", url: "/collections/papan-bunga-congratulations-medan", images: " ", price: " " },{ label: "Papan Bunga Congratulations Semarang", category: "Collection", url: "/collections/papan-bunga-congratulations-semarang", images: " ", price: " " },{ label: "Papan Bunga Congratulations Serang", category: "Collection", url: "/collections/papan-bunga-congratulations-serang", images: " ", price: " " },{ label: "Papan Bunga Congratulations Sidoarjo", category: "Collection", url: "/collections/papan-bunga-congratulations-sidoarjo", images: " ", price: " " },{ label: "Papan Bunga Congratulations Surabaya", category: "Collection", url: "/collections/papan-bunga-congratulations-surabaya", images: " ", price: " " },{ label: "Papan Bunga Congratulations Tangerang", category: "Collection", url: "/collections/papan-bunga-congratulations-tangerang", images: " ", price: " " },{ label: "Papan Bunga Congratulations Yogyakarta", category: "Collection", url: "/collections/papan-bunga-congratulations-yogyakarta", images: " ", price: " " },{ label: "Papan Bunga Danau Toba", category: "Collection", url: "/collections/papan-bunga-danau-toba", images: " ", price: " " },{ label: "Papan Bunga Deli Serdang", category: "Collection", url: "/collections/papan-bunga-deli-serdang", images: " ", price: " " },{ label: "Papan Bunga Demak", category: "Collection", url: "/collections/papan-bunga-demak", images: " ", price: " " },{ label: "Papan Bunga Denpasar", category: "Collection", url: "/collections/papan-bunga-denpasar", images: " ", price: " " },{ label: "Papan Bunga Depok", category: "Collection", url: "/collections/papan-bunga-depok", images: " ", price: " " },{ label: "Papan Bunga Duka Cita", category: "Collection", url: "/collections/bunga-duka-cita", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Bali", category: "Collection", url: "/collections/papan-bunga-duka-cita-bali", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Bandung", category: "Collection", url: "/collections/papan-bunga-duka-cita-bandung", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Bekasi", category: "Collection", url: "/collections/papan-bunga-duka-cita-bekasi", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Bogor", category: "Collection", url: "/collections/papan-bunga-duka-cita-bogor", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Cikupa", category: "Collection", url: "/collections/papan-bunga-duka-cita-cikupa", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Demak", category: "Collection", url: "/collections/papan-bunga-duka-cita-demak", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Depok", category: "Collection", url: "/collections/papan-bunga-duka-cita-depok", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Gresik", category: "Collection", url: "/collections/papan-bunga-duka-cita-gresik", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Jakarta", category: "Collection", url: "/collections/papan-bunga-duka-cita-jakarta", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Jepara", category: "Collection", url: "/collections/papan-bunga-duka-cita-jepara", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Medan", category: "Collection", url: "/collections/papan-bunga-duka-cita-medan", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Semarang", category: "Collection", url: "/collections/papan-bunga-duka-cita-semarang", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Serang", category: "Collection", url: "/collections/papan-bunga-duka-cita-serang", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Sidoarjo", category: "Collection", url: "/collections/papan-bunga-duka-cita-sidoarjo", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Surabaya", category: "Collection", url: "/collections/papan-bunga-duka-cita-surabaya", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Tangerang", category: "Collection", url: "/collections/papan-bunga-duka-cita-tangerang", images: " ", price: " " },{ label: "Papan Bunga Duka Cita Yogyakarta", category: "Collection", url: "/collections/papan-bunga-duka-cita-yogyakarta", images: " ", price: " " },{ label: "Papan Bunga Garut", category: "Collection", url: "/collections/papan-bunga-garut", images: " ", price: " " },{ label: "Papan Bunga Gianyar", category: "Collection", url: "/collections/papan-bunga-gianyar", images: " ", price: " " },{ label: "Papan Bunga Gorontalo", category: "Collection", url: "/collections/papan-bunga-gorontalo", images: " ", price: " " },{ label: "Papan Bunga Gowa", category: "Collection", url: "/collections/papan-bunga-gowa", images: " ", price: " " },{ label: "Papan Bunga Gresik", category: "Collection", url: "/collections/papan-bunga-gresik", images: " ", price: " " },{ label: "Papan Bunga Grobogan", category: "Collection", url: "/collections/papan-bunga-grobogan", images: " ", price: " " },{ label: "Papan Bunga Gunungkidul", category: "Collection", url: "/collections/papan-bunga-gunungkidul", images: " ", price: " " },{ label: "Papan Bunga Indramayu", category: "Collection", url: "/collections/papan-bunga-indramayu", images: " ", price: " " },{ label: "Papan Bunga Jakarta", category: "Collection", url: "/collections/papan-bunga-jakarta", images: " ", price: " " },{ label: "Papan Bunga Jakarta Timur", category: "Collection", url: "/collections/papan-bunga-jakarta-timur", images: " ", price: " " },{ label: "Papan Bunga Jambi", category: "Collection", url: "/collections/papan-bunga-jambi", images: " ", price: " " },{ label: "Papan Bunga Jayapura", category: "Collection", url: "/collections/papan-bunga-jayapura", images: " ", price: " " },{ label: "Papan Bunga Jember", category: "Collection", url: "/collections/papan-bunga-jember", images: " ", price: " " },{ label: "Papan Bunga Jembrana", category: "Collection", url: "/collections/papan-bunga-jembrana", images: " ", price: " " },{ label: "Papan Bunga Jepara", category: "Collection", url: "/collections/papan-bunga-jepara", images: " ", price: " " },{ label: "Papan Bunga Jombang", category: "Collection", url: "/collections/papan-bunga-jombang", images: " ", price: " " },{ label: "Papan Bunga Kampung Baru", category: "Collection", url: "/collections/papan-bunga-kampung-baru", images: " ", price: " " },{ label: "Papan Bunga Kapuas", category: "Collection", url: "/collections/papan-bunga-kapuas", images: " ", price: " " },{ label: "Papan Bunga Karanganyar", category: "Collection", url: "/collections/papan-bunga-karanganyar", images: " ", price: " " },{ label: "Papan Bunga Karangasem", category: "Collection", url: "/collections/papan-bunga-karangasem", images: " ", price: " " },{ label: "Papan Bunga Karawang", category: "Collection", url: "/collections/papan-bunga-karawang", images: " ", price: " " },{ label: "Papan Bunga Karo", category: "Collection", url: "/collections/papan-bunga-karo", images: " ", price: " " },{ label: "Papan Bunga Kartosuro", category: "Collection", url: "/collections/papan-bunga-kartosuro", images: " ", price: " " },{ label: "Papan Bunga Kebumen", category: "Collection", url: "/collections/papan-bunga-kebumen", images: " ", price: " " },{ label: "Papan Bunga Kediri", category: "Collection", url: "/collections/papan-bunga-kediri", images: " ", price: " " },{ label: "Papan Bunga Kendal", category: "Collection", url: "/collections/papan-bunga-kendal", images: " ", price: " " },{ label: "Papan Bunga Kendari", category: "Collection", url: "/collections/papan-bunga-kendari", images: " ", price: " " },{ label: "Papan Bunga Ketapang", category: "Collection", url: "/collections/papan-bunga-ketapang", images: " ", price: " " },{ label: "Papan Bunga Klaten", category: "Collection", url: "/collections/papan-bunga-klaten", images: " ", price: " " },{ label: "Papan Bunga Kota Batu", category: "Collection", url: "/collections/papan-bunga-kota-batu", images: " ", price: " " },{ label: "Papan Bunga Kudus", category: "Collection", url: "/collections/papan-bunga-kudus", images: " ", price: " " },{ label: "Papan Bunga Kupang", category: "Collection", url: "/collections/papan-bunga-kupang", images: " ", price: " " },{ label: "Papan Bunga Lamongan", category: "Collection", url: "/collections/papan-bunga-lamongan", images: " ", price: " " },{ label: "Papan Bunga Lampu LED", category: "Collection", url: "/collections/papan-bunga-lampu-led", images: " ", price: " " },{ label: "Papan Bunga Lampung", category: "Collection", url: "/collections/papan-bunga-lampung", images: " ", price: " " },{ label: "Papan Bunga Langkat", category: "Collection", url: "/collections/papan-bunga-langkat", images: " ", price: " " },{ label: "Papan Bunga Lembang", category: "Collection", url: "/collections/papan-bunga-lembang", images: " ", price: " " },{ label: "Papan Bunga Lombok", category: "Collection", url: "/collections/papan-bunga-lombok", images: " ", price: " " },{ label: "Papan Bunga Lubuk Pakam", category: "Collection", url: "/collections/papan-bunga-lubuk-pakam", images: " ", price: " " },{ label: "Papan Bunga Lumajang", category: "Collection", url: "/collections/papan-bunga-lumajang", images: " ", price: " " },{ label: "Papan Bunga Madiun", category: "Collection", url: "/collections/papan-bunga-madiun", images: " ", price: " " },{ label: "Papan Bunga Magelang", category: "Collection", url: "/collections/papan-bunga-magelang", images: " ", price: " " },{ label: "Papan Bunga Majalengka", category: "Collection", url: "/collections/papan-bunga-majalengka", images: " ", price: " " },{ label: "Papan Bunga Makassar", category: "Collection", url: "/collections/papan-bunga-makassar", images: " ", price: " " },{ label: "Papan Bunga Malang", category: "Collection", url: "/collections/papan-bunga-malang", images: " ", price: " " },{ label: "Papan Bunga Mamuju", category: "Collection", url: "/collections/papan-bunga-mamuju", images: " ", price: " " },{ label: "Papan Bunga Manado", category: "Collection", url: "/collections/papan-bunga-manado", images: " ", price: " " },{ label: "Papan Bunga Manokwari", category: "Collection", url: "/collections/papan-bunga-manokwari", images: " ", price: " " },{ label: "Papan Bunga Maros", category: "Collection", url: "/collections/papan-bunga-maros", images: " ", price: " " },{ label: "Papan Bunga Mataram", category: "Collection", url: "/collections/papan-bunga-mataram", images: " ", price: " " },{ label: "Papan Bunga Medan", category: "Collection", url: "/collections/papan-bunga-medan", images: " ", price: " " },{ label: "Papan Bunga Mojokerto", category: "Collection", url: "/collections/papan-bunga-mojokerto", images: " ", price: " " },{ label: "Papan Bunga Nganjuk", category: "Collection", url: "/collections/papan-bunga-nganjuk", images: " ", price: " " },{ label: "Papan Bunga Ngawi", category: "Collection", url: "/collections/papan-bunga-ngawi", images: " ", price: " " },{ label: "Papan Bunga Nias", category: "Collection", url: "/collections/papan-bunga-nias", images: " ", price: " " },{ label: "Papan Bunga Organza", category: "Collection", url: "/collections/papan-bunga-organza", images: " ", price: " " },{ label: "Papan Bunga Padang", category: "Collection", url: "/collections/papan-bunga-padang", images: " ", price: " " },{ label: "Papan Bunga Palangkaraya", category: "Collection", url: "/collections/papan-bunga-palangkaraya", images: " ", price: " " },{ label: "Papan Bunga Palembang", category: "Collection", url: "/collections/papan-bunga-palembang", images: " ", price: " " },{ label: "Papan Bunga Palu", category: "Collection", url: "/collections/papan-bunga-palu", images: " ", price: " " },{ label: "Papan Bunga Pangkal Pinang", category: "Collection", url: "/collections/papan-bunga-pangkal-pinang", images: " ", price: " " },{ label: "Papan Bunga Parepare", category: "Collection", url: "/collections/papan-bunga-parepare", images: " ", price: " " },{ label: "Papan Bunga Pasuruan", category: "Collection", url: "/collections/papan-bunga-pasuruan", images: " ", price: " " },{ label: "Papan Bunga Pati", category: "Collection", url: "/collections/papan-bunga-pati", images: " ", price: " " },{ label: "Papan Bunga Pekalongan", category: "Collection", url: "/collections/papan-bunga-pekalongan", images: " ", price: " " },{ label: "Papan Bunga Pekanbaru", category: "Collection", url: "/collections/papan-bunga-pekanbaru", images: " ", price: " " },{ label: "Papan Bunga Pemalang", category: "Collection", url: "/collections/papan-bunga-pemalang", images: " ", price: " " },{ label: "Papan Bunga Pematangsiantar", category: "Collection", url: "/collections/papan-bunga-pematangsiantar", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Bali", category: "Collection", url: "/collections/papan-bunga-pernikahan-bali", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Bandung", category: "Collection", url: "/collections/papan-bunga-pernikahan-bandung", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Bekasi", category: "Collection", url: "/collections/papan-bunga-pernikahan-bekasi", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Bogor", category: "Collection", url: "/collections/papan-bunga-pernikahan-bogor", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Cikupa", category: "Collection", url: "/collections/papan-bunga-pernikahan-cikupa", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Demak", category: "Collection", url: "/collections/papan-bunga-pernikahan-demak", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Depok", category: "Collection", url: "/collections/papan-bunga-pernikahan-depok", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Gresik", category: "Collection", url: "/collections/papan-bunga-pernikahan-gresik", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Jakarta", category: "Collection", url: "/collections/papan-bunga-pernikahan-jakarta", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Jepara", category: "Collection", url: "/collections/papan-bunga-pernikahan-jepara", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Medan", category: "Collection", url: "/collections/papan-bunga-pernikahan-medan", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Semarang", category: "Collection", url: "/collections/papan-bunga-pernikahan-semarang", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Serang", category: "Collection", url: "/collections/papan-bunga-pernikahan-serang", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Sidoarjo", category: "Collection", url: "/collections/papan-bunga-pernikahan-sidoarjo", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Surabaya", category: "Collection", url: "/collections/papan-bunga-pernikahan-surabaya", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Tangerang", category: "Collection", url: "/collections/papan-bunga-pernikahan-tangerang", images: " ", price: " " },{ label: "Papan Bunga Pernikahan Yogyakarta", category: "Collection", url: "/collections/papan-bunga-pernikahan-yogyakarta", images: " ", price: " " },{ label: "Papan Bunga Ponorogo", category: "Collection", url: "/collections/papan-bunga-ponorogo", images: " ", price: " " },{ label: "Papan Bunga Pontianak", category: "Collection", url: "/collections/papan-bunga-pontianak", images: " ", price: " " },{ label: "Papan Bunga Premium", category: "Collection", url: "/collections/papan-bunga-premium", images: " ", price: " " },{ label: "Papan Bunga Printing", category: "Collection", url: "/collections/papan-bunga-printing", images: " ", price: " " },{ label: "Papan Bunga Printing Congratulations", category: "Collection", url: "/collections/papan-bunga-printing-congratulations", images: " ", price: " " },{ label: "Papan Bunga Probolinggo", category: "Collection", url: "/collections/papan-bunga-probolinggo", images: " ", price: " " },{ label: "Papan Bunga Promo", category: "Collection", url: "/collections/promo-papan-bunga", images: " ", price: " " },{ label: "Papan Bunga Purbalingga", category: "Collection", url: "/collections/papan-bunga-purbalingga", images: " ", price: " " },{ label: "Papan Bunga Purwokerto", category: "Collection", url: "/collections/papan-bunga-purwokerto", images: " ", price: " " },{ label: "Papan Bunga Purworejo", category: "Collection", url: "/collections/papan-bunga-purworejo", images: " ", price: " " },{ label: "Papan Bunga Rembang", category: "Collection", url: "/collections/papan-bunga-rembang", images: " ", price: " " },{ label: "Papan Bunga Riau", category: "Collection", url: "/collections/papan-bunga-riau", images: " ", price: " " },{ label: "Papan Bunga Salatiga", category: "Collection", url: "/collections/papan-bunga-salatiga", images: " ", price: " " },{ label: "Papan Bunga Samarinda", category: "Collection", url: "/collections/papan-bunga-samarinda", images: " ", price: " " },{ label: "Papan Bunga Selamat Bandung", category: "Collection", url: "/collections/papan-bunga-selamat-bandung", images: " ", price: " " },{ label: "Papan Bunga Selamat Medan", category: "Collection", url: "/collections/papan-bunga-selamat-medan", images: " ", price: " " },{ label: "Papan Bunga Semarang", category: "Collection", url: "/collections/papan-bunga-semarang", images: " ", price: " " },{ label: "Papan Bunga Serang", category: "Collection", url: "/collections/papan-bunga-serang", images: " ", price: " " },{ label: "Papan Bunga Sibolga", category: "Collection", url: "/collections/papan-bunga-sibolga", images: " ", price: " " },{ label: "Papan Bunga Sidoarjo", category: "Collection", url: "/collections/papan-bunga-sidoarjo", images: " ", price: " " },{ label: "Papan Bunga Singkawang", category: "Collection", url: "/collections/papan-bunga-singkawang", images: " ", price: " " },{ label: "Papan Bunga Solo", category: "Collection", url: "/collections/papan-bunga-solo", images: " ", price: " " },{ label: "Papan Bunga Sorong", category: "Collection", url: "/collections/papan-bunga-sorong", images: " ", price: " " },{ label: "Papan Bunga Sragen", category: "Collection", url: "/collections/papan-bunga-sragen", images: " ", price: " " },{ label: "Papan Bunga Standard", category: "Collection", url: "/collections/papan-bunga-standard", images: " ", price: " " },{ label: "Papan Bunga Subang", category: "Collection", url: "/collections/papan-bunga-subang", images: " ", price: " " },{ label: "Papan Bunga Sukabumi", category: "Collection", url: "/collections/papan-bunga-sukabumi", images: " ", price: " " },{ label: "Papan Bunga Sumbawa", category: "Collection", url: "/collections/papan-bunga-sumbawa", images: " ", price: " " },{ label: "Papan Bunga Surabaya", category: "Collection", url: "/collections/papan-bunga-surabaya", images: " ", price: " " },{ label: "Papan Bunga Surakarta", category: "Collection", url: "/collections/papan-bunga-surakarta", images: " ", price: " " },{ label: "Papan Bunga Tangerang", category: "Collection", url: "/collections/papan-bunga-tangerang", images: " ", price: " " },{ label: "Papan Bunga Tasikmalaya", category: "Collection", url: "/collections/papan-bunga-tasikmalaya", images: " ", price: " " },{ label: "Papan Bunga Tegal", category: "Collection", url: "/collections/papan-bunga-tegal", images: " ", price: " " },{ label: "Papan Bunga Temanggung", category: "Collection", url: "/collections/papan-bunga-temanggung", images: " ", price: " " },{ label: "Papan Bunga Ternate", category: "Collection", url: "/collections/papan-bunga-ternate", images: " ", price: " " },{ label: "Papan Bunga Tolitoli", category: "Collection", url: "/collections/papan-bunga-tolitoli", images: " ", price: " " },{ label: "Papan Bunga Toraja", category: "Collection", url: "/collections/papan-bunga-toraja", images: " ", price: " " },{ label: "Papan Bunga Tuban", category: "Collection", url: "/collections/papan-bunga-tuban", images: " ", price: " " },{ label: "Papan Bunga Tulungagung", category: "Collection", url: "/collections/papan-bunga-tulungagung", images: " ", price: " " },{ label: "Papan Bunga Wakatobi", category: "Collection", url: "/collections/papan-bunga-wakatobi", images: " ", price: " " },{ label: "Papan Bunga Wedding", category: "Collection", url: "/collections/papan-bunga-ucapan-pernikahan", images: " ", price: " " },{ label: "Papan Bunga Wiyung", category: "Collection", url: "/collections/papan-bunga-wiyung", images: " ", price: " " },{ label: "Papan Bunga Wonogiri", category: "Collection", url: "/collections/papan-bunga-wonogiri", images: " ", price: " " },{ label: "Papan Bunga Wonokromo", category: "Collection", url: "/collections/papan-bunga-wonokromo", images: " ", price: " " },{ label: "Papan Bunga Wonosobo", category: "Collection", url: "/collections/papan-bunga-wonosobo", images: " ", price: " " },{ label: "Papan Bunga Yogyakarta", category: "Collection", url: "/collections/papan-bunga-yogyakarta", images: " ", price: " " },{ label: "Paper Flower Board", category: "Collection", url: "/collections/papan-bunga-kertas", images: " ", price: " " },{ label: "Paper Flower Board Bali", category: "Collection", url: "/collections/papan-bunga-kertas-bali", images: " ", price: " " },{ label: "Paper Flower Board Gresik", category: "Collection", url: "/collections/papan-bunga-kertas-gresik", images: " ", price: " " },{ label: "Paper Flower Board Sidoarjo", category: "Collection", url: "/collections/papan-bunga-kertas-sidoarjo", images: " ", price: " " },{ label: "Paper Flower Board Surabaya", category: "Collection", url: "/collections/papan-bunga-kertas-surabaya", images: " ", price: " " },{ label: "Paper Flower Board Yogyakarta", category: "Collection", url: "/collections/papan-bunga-kertas-yogyakarta", images: " ", price: " " },{ label: "Parcel", category: "Collection", url: "/collections/parcel", images: " ", price: " " },{ label: "Parcel Buah", category: "Collection", url: "/collections/parcel-buah-segar", images: " ", price: " " },{ label: "Parcel Buah Bandung", category: "Collection", url: "/collections/parcel-buah-bandung", images: " ", price: " " },{ label: "Parcel Buah Semarang", category: "Collection", url: "/collections/parcel-buah-semarang", images: " ", price: " " },{ label: "Parcel Buah Sidoarjo", category: "Collection", url: "/collections/parcel-buah-sidoarjo", images: " ", price: " " },{ label: "Parcel Buah Surabaya", category: "Collection", url: "/collections/parcel-buah-surabaya", images: " ", price: " " },{ label: "Parcel Imlek 2025", category: "Collection", url: "/collections/parcel-imlek", images: " ", price: " " },{ label: "Parcel Imlek Bandung", category: "Collection", url: "/collections/parcel-imlek-bandung", images: " ", price: " " },{ label: "Parcel Imlek Nusantara", category: "Collection", url: "/collections/parcel-imlek-nusantara", images: " ", price: " " },{ label: "Parcel Lebaran Bandung", category: "Collection", url: "/collections/parcel-lebaran-bandung", images: " ", price: " " },{ label: "Parcel Lebaran Nusantara", category: "Collection", url: "/collections/parcel-lebaran-indonesia", images: " ", price: " " },{ label: "Parcel Lebaran Surabaya", category: "Collection", url: "/collections/parcel-lebaran-surabaya", images: " ", price: " " },{ label: "Parcel Makanan", category: "Collection", url: "/collections/parcel-makanan", images: " ", price: " " },{ label: "Parcel Natal & Tahun Baru 2026", category: "Collection", url: "/collections/hampers-natal", images: " ", price: " " },{ label: "Parcel Natal & Tahun Baru Bandung", category: "Collection", url: "/collections/parcel-natal-bandung", images: " ", price: " " },{ label: "Parcel Newborn Nusantara", category: "Collection", url: "/collections/parcel-newborn-nusantara", images: " ", price: " " },{ label: "Parcel Tahun Baru", category: "Collection", url: "/collections/new-year-tahun-baru", images: " ", price: " " },{ label: "Party Supplies", category: "Collection", url: "/collections/party-supplies", images: " ", price: " " },{ label: "Partysaurus", category: "Collection", url: "/collections/partysaurus", images: " ", price: " " },{ label: "Pasar Bunga Splendid Malang", category: "Collection", url: "/collections/pasar-bunga-splendid-malang", images: " ", price: " " },{ label: "Passionate Red Valentine", category: "Collection", url: "/collections/red-valentine", images: " ", price: " " },{ label: "Pendant", category: "Collection", url: "/collections/liontin", images: " ", price: " " },{ label: "Personalized Fashion", category: "Collection", url: "/collections/fashion", images: " ", price: " " },{ label: "Personalized Gift", category: "Collection", url: "/collections/personalized-gift", images: " ", price: " " },{ label: "Personalized Gift Pria", category: "Collection", url: "/collections/personalized-gift-pria", images: " ", price: " " },{ label: "Personalized Gift Wanita", category: "Collection", url: "/collections/personalized-gift-wanita", images: " ", price: " " },{ label: "Personalized Gifts", category: "Collection", url: "/collections/personalized-gifts", images: " ", price: " " },{ label: "Pesca Ice Cream Cakes", category: "Collection", url: "/collections/pesca", images: " ", price: " " },{ label: "Phone Case", category: "Collection", url: "/collections/phone-case", images: " ", price: " " },{ label: "Photobook", category: "Collection", url: "/collections/photobook", images: " ", price: " " },{ label: "Pisces ♓️ 19Feb - 20March", category: "Collection", url: "/collections/kado-untuk-zodiak-pisces", images: " ", price: " " },{ label: "Pohon Natal", category: "Collection", url: "/collections/pohon-natal", images: " ", price: " " },{ label: "Premium Hampers", category: "Collection", url: "/collections/parcel-premium", images: " ", price: " " },{ label: "Premium Newborn Hampers Collection", category: "Collection", url: "/collections/premium-newborn-hampers-collection", images: " ", price: " " },{ label: "Printing Cake", category: "Collection", url: "/collections/printing-cake", images: " ", price: " " },{ label: "Prom", category: "Collection", url: "/collections/prom", images: " ", price: " " },{ label: "Promo Merdeka", category: "Collection", url: "/collections/merdeka", images: " ", price: " " },{ label: "Rangkaian Bunga", category: "Collection", url: "/collections/rangkaian-bunga", images: " ", price: " " },{ label: "Rangkaian Bunga Dekorasi", category: "Collection", url: "/collections/rangkaian-bunga-dekorasi", images: " ", price: " " },{ label: "Rangkaian Bunga Ulang Tahun", category: "Collection", url: "/collections/rangkaian-bunga-ulang-tahun", images: " ", price: " " },{ label: "Romantic & Sweets", category: "Collection", url: "/collections/romantic-sweets", images: " ", price: " " },{ label: "Romantic Package", category: "Collection", url: "/collections/romantic-package", images: " ", price: " " },{ label: "Rose Beam", category: "Collection", url: "/collections/rose-beam", images: " ", price: " " },{ label: "Rose Box", category: "Collection", url: "/collections/rose-box", images: " ", price: " " },{ label: "Roses", category: "Collection", url: "/collections/bunga-mawar", images: " ", price: " " },{ label: "Rp 500.000 - Rp 800.000", category: "Collection", url: "/collections/rp-500-000-rp-800-000", images: " ", price: " " },{ label: "Rp 800.000 - Rp 1.000.000", category: "Collection", url: "/collections/rp-800-000-rp-1-000-000", images: " ", price: " " },{ label: "Rustic & Monochrome Ramadan Hampers", category: "Collection", url: "/collections/rustic-monochrome-ramadanhampers", images: " ", price: " " },{ label: "Rustic Bloom", category: "Collection", url: "/collections/dried-flowers", images: " ", price: " " },{ label: "Rustic Style Flowers", category: "Collection", url: "/collections/rustic-style-flowers", images: " ", price: " " },{ label: "Sagittarius ♐️ 22Nov - 21Des", category: "Collection", url: "/collections/kado-untuk-zodiak-sagittarius", images: " ", price: " " },{ label: "Sameday Delivery", category: "Collection", url: "/collections/sameday", images: " ", price: " " },{ label: "Savoury Dish", category: "Collection", url: "/collections/savoury-dish", images: " ", price: " " },{ label: "Saychiz", category: "Collection", url: "/collections/saychiz", images: " ", price: " " },{ label: "Scented Candles", category: "Collection", url: "/collections/scented-candles", images: " ", price: " " },{ label: "Scorpio ♏️ 24Oct - 21Nov", category: "Collection", url: "/collections/kado-untuk-zodiak-scorpio", images: " ", price: " " },{ label: "Self Pick-Up", category: "Collection", url: "/collections/self-pick-up", images: " ", price: " " },{ label: "Semua Produk", category: "Collection", url: "/collections/all", images: " ", price: " " },{ label: "Serenitea", category: "Collection", url: "/collections/serenitea", images: " ", price: " " },{ label: "Share Outerbloom Moment", category: "Collection", url: "/collections/share-moment", images: " ", price: " " },{ label: "Share your Happiness", category: "Collection", url: "/collections/share-happiness", images: " ", price: " " },{ label: "Signature Cake", category: "Collection", url: "/collections/signature-cake", images: " ", price: " " },{ label: "Signature Chinese New Year Hampers", category: "Collection", url: "/collections/signature-chinese-new-year-hampers", images: " ", price: " " },{ label: "Signature Christmas & New Year Hampers", category: "Collection", url: "/collections/signature-christmas-hampers", images: " ", price: " " },{ label: "Signature Hampers", category: "Collection", url: "/collections/signature-hampers", images: " ", price: " " },{ label: "Signature Hampers Luar Jadetabek", category: "Collection", url: "/collections/signature-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Signature Hampers Sameday", category: "Collection", url: "/collections/signature-hampers-sameday", images: " ", price: " " },{ label: "Signature Ramadan Hampers", category: "Collection", url: "/collections/signature-ramadan-hampers", images: " ", price: " " },{ label: "Slice Cake", category: "Collection", url: "/collections/slice-cake", images: " ", price: " " },{ label: "Snack Box", category: "Collection", url: "/collections/snack-box", images: " ", price: " " },{ label: "Sol et Terre", category: "Collection", url: "/collections/sol-et-terre", images: " ", price: " " },{ label: "Sorbet", category: "Collection", url: "/collections/sorbet", images: " ", price: " " },{ label: "Special Day", category: "Collection", url: "/collections/special-day", images: " ", price: " " },{ label: "Special Edition", category: "Collection", url: "/collections/special-edition", images: " ", price: " " },{ label: "Special For Her", category: "Collection", url: "/collections/special-for-her", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen!", category: "Collection", url: "/collections/standing-flower", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Bali", category: "Collection", url: "/collections/standing-flower-bali", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Bandung", category: "Collection", url: "/collections/standing-flower-bandung", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Congratulations", category: "Collection", url: "/collections/standing-flower-congratulations", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Demak", category: "Collection", url: "/collections/standing-flower-demak", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Jepara", category: "Collection", url: "/collections/standing-flower-jepara", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Semarang", category: "Collection", url: "/collections/standing-flower-semarang", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Sidoarjo", category: "Collection", url: "/collections/standing-flower-sidoarjo", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Surabaya", category: "Collection", url: "/collections/standing-flower-surabaya", images: " ", price: " " },{ label: "IPOTOTO adalah link bandar togel online terpercaya 2026 & situs toto 4d resmi pasti bayar #1 di Asia. Hadirkan pasaran lengkap, hadiah besar, diskon terbaik, dan jaminan bayar seratus persen! Yogyakarta", category: "Collection", url: "/collections/standing-flower-yogyakarta", images: " ", price: " " },{ label: "Standing Giant Flower", category: "Collection", url: "/collections/standing-giant-flower", images: " ", price: " " },{ label: "Stationery", category: "Collection", url: "/collections/stationery", images: " ", price: " " },{ label: "Steekwerk", category: "Collection", url: "/collections/steekwerk", images: " ", price: " " },{ label: "Stylish Hampers", category: "Collection", url: "/collections/stylish-hampers", images: " ", price: " " },{ label: "Stylish Hampers Luar Jadetabek", category: "Collection", url: "/collections/stylish-hampers-luar-jadetabek", images: " ", price: " " },{ label: "Succulent", category: "Collection", url: "/collections/succulent", images: " ", price: " " },{ label: "Sunflower", category: "Collection", url: "/collections/bunga-matahari", images: " ", price: " " },{ label: "Sweet & Savoury Hampers", category: "Collection", url: "/collections/sweet-savoury-hampers", images: " ", price: " " },{ label: "Sweet Gracie", category: "Collection", url: "/collections/sweet-gracie", images: " ", price: " " },{ label: "Sweet Pastel Love", category: "Collection", url: "/collections/pastel-love", images: " ", price: " " },{ label: "Sweet Pastel Love Nusantara", category: "Collection", url: "/collections/sweet-pastel-love-nusantara", images: " ", price: " " },{ label: "Sweet Treats", category: "Collection", url: "/collections/sweet-treats", images: " ", price: " " },{ label: "Sweetooth", category: "Collection", url: "/collections/sweetooth", images: " ", price: " " },{ label: "Taurus ♉️ 20April - 20May", category: "Collection", url: "/collections/kado-untuk-zodiak-taurus", images: " ", price: " " },{ label: "Teddy Bear", category: "Collection", url: "/collections/boneka-teddy-bear", images: " ", price: " " },{ label: "Teh", category: "Collection", url: "/collections/teh", images: " ", price: " " },{ label: "Test Error", category: "Collection", url: "/collections/test-error", images: " ", price: " " },{ label: "Testing", category: "Collection", url: "/collections/testing", images: " ", price: " " },{ label: "Thank You", category: "Collection", url: "/collections/rangkaian-bunga-ucapan-terima-kasih", images: " ", price: " " },{ label: "The Classic Astoria", category: "Collection", url: "/collections/astoria", images: " ", price: " " },{ label: "The Classic Enchanted Dome", category: "Collection", url: "/collections/enchanted-dome", images: " ", price: " " },{ label: "The Enchanted Love Pirouette Special Edition", category: "Collection", url: "/collections/the-enchanted-love-pirouette-special-edition", images: " ", price: " " },{ label: "The F Thing", category: "Collection", url: "/collections/the-f-thing", images: " ", price: " " },{ label: "The First", category: "Collection", url: "/collections/the-first", images: " ", price: " " },{ label: "The Novo Astoria", category: "Collection", url: "/collections/the-novo-astoria", images: " ", price: " " },{ label: "The Novo Enchanted Dome", category: "Collection", url: "/collections/the-novo-enchanted-dome", images: " ", price: " " },{ label: "The Novo Enchanted Dome Special Edition", category: "Collection", url: "/collections/the-novo-enchanted-dome-special-edition", images: " ", price: " " },{ label: "The Palace", category: "Collection", url: "/collections/the-palace", images: " ", price: " " },{ label: "Ties", category: "Collection", url: "/collections/dasi", images: " ", price: " " },{ label: "Tisane", category: "Collection", url: "/collections/tisane", images: " ", price: " " },{ label: "Toko Bunga Aceh", category: "Collection", url: "/collections/toko-bunga-aceh", images: " ", price: " " },{ label: "Toko Bunga Ambon", category: "Collection", url: "/collections/toko-bunga-ambon", images: " ", price: " " },{ label: "Toko Bunga Atambua", category: "Collection", url: "/collections/toko-bunga-atambua", images: " ", price: " " },{ label: "Toko Bunga Bali", category: "Collection", url: "/collections/toko-bunga-bali", images: " ", price: " " },{ label: "Toko Bunga Balikpapan", category: "Collection", url: "/collections/toko-bunga-balikpapan", images: " ", price: " " },{ label: "Toko Bunga Bandar Lampung", category: "Collection", url: "/collections/toko-bunga-bandar-lampung", images: " ", price: " " },{ label: "Toko Bunga Bandung", category: "Collection", url: "/collections/toko-bunga-bandung", images: " ", price: " " },{ label: "Toko Bunga Bandung Barat", category: "Collection", url: "/collections/toko-bunga-bandung-barat", images: " ", price: " " },{ label: "Toko Bunga Banjarmasin", category: "Collection", url: "/collections/toko-bunga-banjarmasin", images: " ", price: " " },{ label: "Toko Bunga Banten", category: "Collection", url: "/collections/toko-bunga-banten", images: " ", price: " " },{ label: "Toko Bunga Banyumas", category: "Collection", url: "/collections/toko-bunga-banyumas", images: " ", price: " " },{ label: "Toko Bunga Banyuwangi", category: "Collection", url: "/collections/toko-bunga-banyuwangi", images: " ", price: " " },{ label: "Toko Bunga Batam", category: "Collection", url: "/collections/toko-bunga-batam", images: " ", price: " " },{ label: "Toko Bunga Baubau", category: "Collection", url: "/collections/toko-bunga-baubau", images: " ", price: " " },{ label: "Toko Bunga Bekasi", category: "Collection", url: "/collections/toko-bunga-bekasi", images: " ", price: " " },{ label: "Toko Bunga Bengkalis", category: "Collection", url: "/collections/toko-bunga-bengkalis", images: " ", price: " " },{ label: "Toko Bunga Bengkayang", category: "Collection", url: "/collections/toko-bunga-bengkayang", images: " ", price: " " },{ label: "Toko Bunga Binjai", category: "Collection", url: "/collections/toko-bunga-binjai", images: " ", price: " " },{ label: "Toko Bunga Bintaro", category: "Collection", url: "/collections/toko-bunga-bintaro", images: " ", price: " " },{ label: "Toko Bunga Blitar", category: "Collection", url: "/collections/toko-bunga-blitar", images: " ", price: " " },{ label: "Toko Bunga Blora", category: "Collection", url: "/collections/toko-bunga-blora", images: " ", price: " " },{ label: "Toko Bunga Bogor", category: "Collection", url: "/collections/toko-bunga-bogor", images: " ", price: " " },{ label: "Toko Bunga Bojonegoro", category: "Collection", url: "/collections/toko-bunga-bojonegoro", images: " ", price: " " },{ label: "Toko Bunga Boyolali", category: "Collection", url: "/collections/toko-bunga-boyolali", images: " ", price: " " },{ label: "Toko Bunga Brebes", category: "Collection", url: "/collections/toko-bunga-brebes", images: " ", price: " " },{ label: "Toko Bunga Bukittinggi", category: "Collection", url: "/collections/toko-bunga-bukittinggi", images: " ", price: " " },{ label: "Toko Bunga Buleleng", category: "Collection", url: "/collections/toko-bunga-buleleng", images: " ", price: " " },{ label: "Toko Bunga Cakung", category: "Collection", url: "/collections/toko-bunga-cakung", images: " ", price: " " },{ label: "Toko Bunga Cawang", category: "Collection", url: "/collections/toko-bunga-cawang", images: " ", price: " " },{ label: "Toko Bunga Cempaka Putih", category: "Collection", url: "/collections/toko-bunga-cempaka-putih", images: " ", price: " " },{ label: "Toko Bunga Cengkareng", category: "Collection", url: "/collections/toko-bunga-cengkareng", images: " ", price: " " },{ label: "Toko Bunga Ciamis", category: "Collection", url: "/collections/toko-bunga-ciamis", images: " ", price: " " },{ label: "Toko Bunga Cianjur", category: "Collection", url: "/collections/toko-bunga-cianjur", images: " ", price: " " },{ label: "Toko Bunga Cibinong", category: "Collection", url: "/collections/toko-bunga-cibinong", images: " ", price: " " },{ label: "Toko Bunga Cibubur", category: "Collection", url: "/collections/toko-bunga-cibubur", images: " ", price: " " },{ label: "Toko Bunga Cijantung", category: "Collection", url: "/collections/toko-bunga-cijantung", images: " ", price: " " },{ label: "Toko Bunga Cikarang", category: "Collection", url: "/collections/toko-bunga-cikarang", images: " ", price: " " },{ label: "Toko Bunga Cikini", category: "Collection", url: "/collections/toko-bunga-cikini", images: " ", price: " " },{ label: "Toko Bunga Cilacap", category: "Collection", url: "/collections/toko-bunga-cilacap", images: " ", price: " " },{ label: "Toko Bunga Cilandak", category: "Collection", url: "/collections/toko-bunga-cilandak", images: " ", price: " " },{ label: "Toko Bunga Cileunyi", category: "Collection", url: "/collections/toko-bunga-cileunyi", images: " ", price: " " },{ label: "Toko Bunga Ciracas", category: "Collection", url: "/collections/toko-bunga-ciracas", images: " ", price: " " },{ label: "Toko Bunga Cirebon", category: "Collection", url: "/collections/toko-bunga-cirebon", images: " ", price: " " },{ label: "Toko Bunga Ciwidey", category: "Collection", url: "/collections/toko-bunga-ciwidey", images: " ", price: " " },{ label: "Toko Bunga Danau Toba", category: "Collection", url: "/collections/toko-bunga-danau-toba", images: " ", price: " " },{ label: "Toko Bunga Demak", category: "Collection", url: "/collections/toko-bunga-demak", images: " ", price: " " },{ label: "Toko Bunga Denpasar", category: "Collection", url: "/collections/toko-bunga-denpasar", images: " ", price: " " },{ label: "Toko Bunga Depok", category: "Collection", url: "/collections/toko-bunga-depok", images: " ", price: " " },{ label: "Toko Bunga Duren Sawit", category: "Collection", url: "/collections/toko-bunga-duren-sawit", images: " ", price: " " },{ label: "Toko Bunga Garut", category: "Collection", url: "/collections/toko-bunga-garut", images: " ", price: " " },{ label: "Toko Bunga Gianyar", category: "Collection", url: "/collections/toko-bunga-gianyar", images: " ", price: " " },{ label: "Toko Bunga Gowa", category: "Collection", url: "/collections/toko-bunga-gowa", images: " ", price: " " },{ label: "Toko Bunga Gresik", category: "Collection", url: "/collections/toko-bunga-gresik", images: " ", price: " " },{ label: "Toko Bunga Grobogan", category: "Collection", url: "/collections/toko-bunga-grobogan", images: " ", price: " " },{ label: "Toko Bunga Grogol", category: "Collection", url: "/collections/toko-bunga-grogol", images: " ", price: " " },{ label: "Toko Bunga Gunungkidul", category: "Collection", url: "/collections/toko-bunga-gunungkidul", images: " ", price: " " },{ label: "Toko Bunga Indramayu", category: "Collection", url: "/collections/toko-bunga-indramayu", images: " ", price: " " },{ label: "Toko Bunga Jakarta", category: "Collection", url: "/collections/toko-bunga-jakarta", images: " ", price: " " },{ label: "Toko Bunga Jakarta Barat", category: "Collection", url: "/collections/toko-bunga-jakarta-barat", images: " ", price: " " },{ label: "Toko Bunga Jakarta Pusat", category: "Collection", url: "/collections/toko-bunga-jakarta-pusat", images: " ", price: " " },{ label: "Toko Bunga Jakarta Selatan", category: "Collection", url: "/collections/toko-bunga-jakarta-selatan", images: " ", price: " " },{ label: "Toko Bunga Jakarta Timur", category: "Collection", url: "/collections/toko-bunga-jakarta-timur", images: " ", price: " " },{ label: "Toko Bunga Jakarta Utara", category: "Collection", url: "/collections/toko-bunga-jakarta-utara", images: " ", price: " " },{ label: "Toko Bunga Jambi", category: "Collection", url: "/collections/toko-bunga-jambi", images: " ", price: " " },{ label: "Toko Bunga Jatinegara", category: "Collection", url: "/collections/toko-bunga-jatinegara", images: " ", price: " " },{ label: "Toko Bunga Jawa & Bali", category: "Collection", url: "/collections/toko-bunga-jawa-bali", images: " ", price: " " },{ label: "Toko Bunga Jayapura", category: "Collection", url: "/collections/toko-bunga-jayapura", images: " ", price: " " },{ label: "Toko Bunga Jelambar - Florist Onine 24 Jam", category: "Collection", url: "/collections/toko-bunga-jelambar", images: " ", price: " " },{ label: "Toko Bunga Jember", category: "Collection", url: "/collections/toko-bunga-jember", images: " ", price: " " },{ label: "Toko Bunga Jembrana", category: "Collection", url: "/collections/toko-bunga-jembrana", images: " ", price: " " },{ label: "Toko Bunga Jepara", category: "Collection", url: "/collections/toko-bunga-jepara", images: " ", price: " " },{ label: "Toko Bunga Joglo", category: "Collection", url: "/collections/toko-bunga-joglo", images: " ", price: " " },{ label: "Toko Bunga Jombang", category: "Collection", url: "/collections/toko-bunga-jombang", images: " ", price: " " },{ label: "Toko Bunga Kalibata", category: "Collection", url: "/collections/toko-bunga-kalibata", images: " ", price: " " },{ label: "Toko Bunga Kalimantan", category: "Collection", url: "/collections/toko-bunga-kalimantan", images: " ", price: " " },{ label: "Toko Bunga Kalisari Semarang", category: "Collection", url: "/collections/toko-bunga-kalisari-semarang", images: " ", price: " " },{ label: "Toko Bunga Kampung Baru", category: "Collection", url: "/collections/toko-bunga-kampung-baru", images: " ", price: " " },{ label: "Toko Bunga Kapuas", category: "Collection", url: "/collections/toko-bunga-kapuas", images: " ", price: " " },{ label: "Toko Bunga Karanganyar", category: "Collection", url: "/collections/toko-bunga-karanganyar", images: " ", price: " " },{ label: "Toko Bunga Karangasem", category: "Collection", url: "/collections/toko-bunga-karangasem", images: " ", price: " " },{ label: "Toko Bunga Karawang", category: "Collection", url: "/collections/toko-bunga-karawang", images: " ", price: " " },{ label: "Toko Bunga Kartosuro", category: "Collection", url: "/collections/toko-bunga-kartosuro", images: " ", price: " " },{ label: "Toko Bunga Kayoon Surabaya", category: "Collection", url: "/collections/toko-bunga-kayoon-surabaya", images: " ", price: " " },{ label: "Toko Bunga Kebayoran Baru", category: "Collection", url: "/collections/toko-bunga-kebayoran-baru", images: " ", price: " " },{ label: "Toko Bunga Kebon Jeruk", category: "Collection", url: "/collections/toko-bunga-kebon-jeruk", images: " ", price: " " },{ label: "Toko Bunga Kebumen", category: "Collection", url: "/collections/toko-bunga-kebumen", images: " ", price: " " },{ label: "Toko Bunga Kediri", category: "Collection", url: "/collections/toko-bunga-kediri", images: " ", price: " " },{ label: "Toko Bunga Kelapa Gading", category: "Collection", url: "/collections/toko-bunga-kelapa-gading", images: " ", price: " " },{ label: "Toko Bunga Kemayoran", category: "Collection", url: "/collections/toko-bunga-kemayoran", images: " ", price: " " },{ label: "Toko Bunga Kendal", category: "Collection", url: "/collections/toko-bunga-kendal", images: " ", price: " " },{ label: "Toko Bunga Kendari", category: "Collection", url: "/collections/toko-bunga-kendari", images: " ", price: " " },{ label: "Toko Bunga Ketapang", category: "Collection", url: "/collections/toko-bunga-ketapang", images: " ", price: " " },{ label: "Toko Bunga Klaten", category: "Collection", url: "/collections/toko-bunga-klaten", images: " ", price: " " },{ label: "Toko Bunga Klender", category: "Collection", url: "/collections/toko-bunga-klender", images: " ", price: " " },{ label: "Toko Bunga Kota Baru Yogyakarta", category: "Collection", url: "/collections/toko-bunga-kota-baru-yogyakarta", images: " ", price: " " },{ label: "Toko Bunga Kota Batu", category: "Collection", url: "/collections/toko-bunga-kota-batu", images: " ", price: " " },{ label: "Toko Bunga Kramat Jati", category: "Collection", url: "/collections/toko-bunga-kramat-jati", images: " ", price: " " },{ label: "Toko Bunga Kudus", category: "Collection", url: "/collections/toko-bunga-kudus", images: " ", price: " " },{ label: "Toko Bunga Kupang", category: "Collection", url: "/collections/toko-bunga-kupang", images: " ", price: " " },{ label: "Toko Bunga Lamongan", category: "Collection", url: "/collections/toko-bunga-lamongan", images: " ", price: " " },{ label: "Toko Bunga Langkat", category: "Collection", url: "/collections/toko-bunga-langkat", images: " ", price: " " },{ label: "Toko Bunga Lebak Bulus", category: "Collection", url: "/collections/toko-bunga-lebak-bulus", images: " ", price: " " },{ label: "Toko Bunga Lembang", category: "Collection", url: "/collections/toko-bunga-lembang", images: " ", price: " " },{ label: "Toko Bunga Lenteng Agung", category: "Collection", url: "/collections/toko-bunga-lenteng-agung", images: " ", price: " " },{ label: "Toko Bunga Lombok", category: "Collection", url: "/collections/toko-bunga-lombok", images: " ", price: " " },{ label: "Toko Bunga Lubuk Pakam", category: "Collection", url: "/collections/toko-bunga-lubuk-pakam", images: " ", price: " " },{ label: "Toko Bunga Lumajang", category: "Collection", url: "/collections/toko-bunga-lumajang", images: " ", price: " " },{ label: "Toko Bunga Madiun", category: "Collection", url: "/collections/toko-bunga-madiun", images: " ", price: " " },{ label: "Toko Bunga Magelang", category: "Collection", url: "/collections/toko-bunga-magelang", images: " ", price: " " },{ label: "Toko Bunga Majalengka", category: "Collection", url: "/collections/toko-bunga-majalengka", images: " ", price: " " },{ label: "Toko Bunga Makassar", category: "Collection", url: "/collections/toko-bunga-makassar", images: " ", price: " " },{ label: "Toko Bunga Malang", category: "Collection", url: "/collections/toko-bunga-malang", images: " ", price: " " },{ label: "Toko Bunga Manado", category: "Collection", url: "/collections/toko-bunga-manado", images: " ", price: " " },{ label: "Toko Bunga Mangga Besar", category: "Collection", url: "/collections/toko-bunga-mangga-besar", images: " ", price: " " },{ label: "Toko Bunga Manokwari", category: "Collection", url: "/collections/toko-bunga-manokwari", images: " ", price: " " },{ label: "Toko Bunga Maros", category: "Collection", url: "/collections/toko-bunga-maros", images: " ", price: " " },{ label: "Toko Bunga Mataram", category: "Collection", url: "/collections/toko-bunga-mataram", images: " ", price: " " },{ label: "Toko Bunga Medan", category: "Collection", url: "/collections/toko-bunga-medan", images: " ", price: " " },{ label: "Toko Bunga Mojokerto", category: "Collection", url: "/collections/toko-bunga-mojokerto", images: " ", price: " " },{ label: "Toko Bunga Nganjuk", category: "Collection", url: "/collections/toko-bunga-nganjuk", images: " ", price: " " },{ label: "Toko Bunga Ngawi", category: "Collection", url: "/collections/toko-bunga-ngawi", images: " ", price: " " },{ label: "Toko Bunga Nias", category: "Collection", url: "/collections/toko-bunga-nias", images: " ", price: " " },{ label: "Toko Bunga Nusa Tenggara", category: "Collection", url: "/collections/toko-bunga-nusa-tenggara", images: " ", price: " " },{ label: "Toko Bunga Padang", category: "Collection", url: "/collections/toko-bunga-padang", images: " ", price: " " },{ label: "Toko Bunga Palembang", category: "Collection", url: "/collections/toko-bunga-palembang", images: " ", price: " " },{ label: "Toko Bunga Palu", category: "Collection", url: "/collections/toko-bunga-palu", images: " ", price: " " },{ label: "Toko Bunga Pangkal Pinang", category: "Collection", url: "/collections/toko-bunga-pangkal-pinang", images: " ", price: " " },{ label: "Toko Bunga Papua", category: "Collection", url: "/collections/toko-bunga-papua", images: " ", price: " " },{ label: "Toko Bunga Parepare", category: "Collection", url: "/collections/toko-bunga-parepare", images: " ", price: " " },{ label: "Toko Bunga Pasar Baru", category: "Collection", url: "/collections/toko-bunga-pasar-baru", images: " ", price: " " },{ label: "Toko Bunga Pasar Minggu", category: "Collection", url: "/collections/toko-bunga-pasar-minggu", images: " ", price: " " },{ label: "Toko Bunga Pasar Rebo", category: "Collection", url: "/collections/toko-bunga-pasar-rebo", images: " ", price: " " },{ label: "Toko Bunga Pasuruan", category: "Collection", url: "/collections/toko-bunga-pasuruan", images: " ", price: " " },{ label: "Toko Bunga Pati", category: "Collection", url: "/collections/toko-bunga-pati", images: " ", price: " " },{ label: "Toko Bunga Pekalongan", category: "Collection", url: "/collections/toko-bunga-pekalongan", images: " ", price: " " },{ label: "Toko Bunga Pekanbaru", category: "Collection", url: "/collections/toko-bunga-pekanbaru", images: " ", price: " " },{ label: "Toko Bunga Pemalang", category: "Collection", url: "/collections/toko-bunga-pemalang", images: " ", price: " " },
      { label: "grand salutation jabodetabek", category: "Produk", url: "/products/grand-salutation", images: "//outerbloom.com/cdn/shop/files/JKTCON1005_Grand-Salutation-Jabodetabek-WM_thumb.jpg?v=1703241523", price: "Rp 435.000" },{ label: "consolantibus jabodetabek", category: "Produk", url: "/products/consolantibus", images: "//outerbloom.com/cdn/shop/files/JKTDUK1011_Consolantibus-Jabodetabek-WM_thumb.jpg?v=1703239823", price: "Rp 435.000" },{ label: "classic midnight hand bouquet fiery red", category: "Produk", url: "/products/the-classic-midnight-hand-bouquet-fiery-red", images: "//outerbloom.com/cdn/shop/files/OBVBUN1422_Classic-Midnight-Hand-Bouquet---Fiery-Red-large_thumb.jpg?v=1757302521", price: "Rp 385.000" },{ label: "enchanted dome passionate red", category: "Produk", url: "/products/enchanted-dome-passionate-red", images: "//outerbloom.com/cdn/shop/files/Enchanted-dome-red-new-box_3_2_26c081bf-f2a5-42b4-9ce4-3c0304c498e5_thumb.jpg?v=1712639476", price: "Rp 1.435.000" },{ label: "endearing ruby", category: "Produk", url: "/products/endearing-ruby", images: "//outerbloom.com/cdn/shop/products/OUTSTF1003_Endearing-Ruby_thumb.jpg?v=1631296611", price: "Rp 585.000" },{ label: "gentle soul jabodetabek", category: "Produk", url: "/products/gentle-soul-jabodetabek", images: "//outerbloom.com/cdn/shop/files/JKTDUK1030_Gentle-Soul-Jabodetabek-WM_thumb.jpg?v=1703239894", price: "Rp 435.000" },{ label: "belleza jabodetabek", category: "Produk", url: "/products/belleza", images: "//outerbloom.com/cdn/shop/files/Belleza-Jabodetabek-LED_aecb756a-0737-45cc-8bfb-008515ca0a37_thumb.gif?v=1759229680", price: "Rp 435.000" },{ label: "majestic pink roses with baby breath bouquet", category: "Produk", url: "/products/majestic-pink-roses-with-baby-breath-bouquet", images: "//outerbloom.com/cdn/shop/products/ef4a3be9-c938-4c70-98ac-4873e7da82bf_90820a66-923a-463d-a464-81bcbe6e6644_thumb.jpg?v=1581413440", price: "Rp 485.000" },{ label: "sentiments jabodetabek", category: "Produk", url: "/products/sentiments", images: "//outerbloom.com/cdn/shop/files/Sentiments-Jabodetabek-WM_thumb.jpg?v=1759224099", price: "Rp 485.000" },{ label: "rose poetry bouquet", category: "Produk", url: "/products/rose-poetry-bouquet", images: "//outerbloom.com/cdn/shop/products/Rose-Poetry-Bouquet-20-tangkai_thumb.jpg?v=1675151039", price: "Rp 385.000" },{ label: "genuine feeling", category: "Produk", url: "/products/genuine-feeling", images: "//outerbloom.com/cdn/shop/products/OUTSTF1004Genuine-Feeling_981ade89-af27-433e-81aa-8d76175a0e4d_thumb.jpg?v=1612352389", price: "Rp 585.000" },{ label: "eternal fidelity jabodetabek", category: "Produk", url: "/products/eternal-fidelity-jabodetabek", images: "//outerbloom.com/cdn/shop/products/0b89df45-dcc1-4876-820e-61b2243a1945_964e211d-2972-46c9-8593-976210929089_thumb.jpg?v=1590491458", price: "Rp 435.000" },{ label: "rosabelle hand bouquet", category: "Produk", url: "/products/rosabelle-hand-bouquet", images: "//outerbloom.com/cdn/shop/files/OBVBUN1429_Rosabelle-Hand-Bouquet-Medium_thumb.jpg?v=1756971848", price: "Rp 385.000" },{ label: "dreaming in pink luxury in vase", category: "Produk", url: "/products/dreaming-in-pink-luxury-in-vase", images: "//outerbloom.com/cdn/shop/products/OBVBUN1051_Dreaming-In-Pink-Luxury-In-Vase_3_thumb.jpg?v=1614594504", price: "Rp 735.000" },{ label: "excito jabodetabek", category: "Produk", url: "/products/excito", images: "//outerbloom.com/cdn/shop/files/JKTCON1010_Excito-Jabodetabek-2023_thumb.gif?v=1717494677", price: "Rp 485.000" },{ label: "golden toast jabodetabek", category: "Produk", url: "/products/golden-toast", images: "//outerbloom.com/cdn/shop/products/LED-GoldenToast_thumb.gif?v=1579249585", price: "Rp 485.000" },{ label: "spirit of eminance jabodetabek", category: "Produk", url: "/products/spirit-of-eminance-jabodetabek", images: "//outerbloom.com/cdn/shop/files/JKTCON1026_Spirit-of-Eminance-Jabodetabek-newest-WM_thumb.jpg?v=1693297526", price: "Rp 485.000" },{ label: "white elysian bloom box", category: "Produk", url: "/products/white-elysian-bloom-box", images: "//outerbloom.com/cdn/shop/files/OBVBUN1704_White-Elysian-Bloom-Box_thumb.jpg?v=1757328247", price: "Rp 685.000" },{ label: "charming forevermore jabodetabek", category: "Produk", url: "/products/charming-forevermore-jabodetabek", images: "//outerbloom.com/cdn/shop/files/JKTWED1036_Charming-Forevermore-Jabodetabek-WM_thumb.jpg?v=1703239534", price: "Rp 485.000" },{ label: "moment of glory jabodetabek", category: "Produk", url: "/products/moment-of-glory-jabodetabek", images: "//outerbloom.com/cdn/shop/products/JKTCON1051_Moment-of-Glory-Jabodetabek_2_thumb.jpg?v=1596614663", price: "Rp 385.000" },{ label: "sweet romance jabodetabek", category: "Produk", url: "/products/sweet-romance", images: "//outerbloom.com/cdn/shop/products/JKTWED1005_Sweet-Romance-Jabodetabek_thumb.gif?v=1677134791", price: "Rp 635.000" },{ label: "with love bouquet", category: "Produk", url: "/products/with-love-bouquet", images: "//outerbloom.com/cdn/shop/products/c5d6fed6-8ada-4c38-ae0f-36d395aacb19_613f78f0-d52c-443b-9e13-63a151cd8ec5_thumb.jpg?v=1590748429", price: "Rp 535.000" },{ label: "sunflower yellow and with white daisies in vase", category: "Produk", url: "/products/sunflower-yellow-roses-with-white-and-yellow-daisies-in-a-glass-vase", images: "//outerbloom.com/cdn/shop/files/OBVBUN1132_Sunflower-Yellow-And-With-White-Daisies-in-Vase_thumb.jpg?v=1757930628", price: "Rp 435.000" },{ label: "everlasting peace jabodetabek", category: "Produk", url: "/products/everlasting-peace-jabodetabek", images: "//outerbloom.com/cdn/shop/products/JKTDUK1034_Everlasting-Peace-Jabodetabek_2_thumb.jpg?v=1596614613", price: "Rp 385.000" },{ label: "astoria passionate red", category: "Produk", url: "/products/astoria-passionate-red", images: "//outerbloom.com/cdn/shop/products/Astoria-passionate-red_b59b26f6-c39d-46d3-adcb-262c675bb16f_thumb.jpg?v=1633502742", price: "Rp 685.000" },{ label: "classic purple orchid majesty in vase", category: "Produk", url: "/products/classic-purple-orchid-majesty-in-vase", images: "//outerbloom.com/cdn/shop/products/Classic-Purple-Orchid-Majesty-in-Vase---White---4-Tangkai_40a5e337-283f-40f5-911c-5df9b506b9da_thumb.jpg?v=1639981404", price: "Rp 435.000" },{ label: "passion rouge bloom box", category: "Produk", url: "/products/passion-rouge-bloom-box", images: "//outerbloom.com/cdn/shop/files/OBVBUN1725_Passion-Rouge-Bloom-Box_thumb.jpg?v=1756972410", price: "Rp 385.000" },{ label: "classic white orchid majesty in vase", category: "Produk", url: "/products/classic-white-orchid-majesty-in-vase", images: "//outerbloom.com/cdn/shop/products/Classic-white-Orchid-Majesty-in-Vase---white---4-Tangkai_thumb.jpg?v=1644205542", price: "Rp 435.000" },{ label: "majestic blue romance bouquet", category: "Produk", url: "/products/majestic-blue-romance-bouquet", images: "//outerbloom.com/cdn/shop/files/OBVBUN1357_Majestic-Blue-Romance-Bouquet_99b8ba96-0e67-4eef-a00e-b2daedcddb6a_thumb.jpg?v=1757390540", price: "Rp 435.000" },{ label: "sincerely", category: "Produk", url: "/products/sincerely", images: "//outerbloom.com/cdn/shop/files/Sincerely-WM_thumb.jpg?v=1688354677", price: "Rp 585.000" },{ label: "happy days jabodetabek", category: "Produk", url: "/products/happy-days-jabodetabek", images: "//outerbloom.com/cdn/shop/files/Happy-Days-Jabodetabek_WM_thumb.jpg?v=1759224026", price: "Rp 485.000" },{ label: "solemn comfort jabodetabek", category: "Produk", url: "/products/solemn-comfort-jabodetabek", images: "//outerbloom.com/cdn/shop/products/7fe123d8-6bb2-4c0d-bd4c-f8c3032823f2_6b9c33b6-4a23-41cb-8709-fc9223fe096a_thumb.png?v=1590662086", price: "Rp 635.000" },{ label: "big dreams jabodetabek", category: "Produk", url: "/products/big-dreams", images: "//outerbloom.com/cdn/shop/files/JKTCON1002_Big-Dreams-Jabodetabek_thumb.gif?v=1717494603", price: "Rp 485.000" },{ label: "signature ramadan deluxe hampers", category: "Produk", url: "/products/outerbloom-signature-ramadhan-deluxe-hampers", images: "//outerbloom.com/cdn/shop/files/Signature-Deluxe-Hampers_thumb.jpg?v=1739242254", price: "Rp 985.000" },{ label: "amorous amos jabodetabek", category: "Produk", url: "/products/amorous-amos-jabodetabek", images: "//outerbloom.com/cdn/shop/files/Amorous-Amos-Jabodetabek-WM_thumb.jpg?v=1759224071", price: "Rp 485.000" },{ label: "pink darling bouquet", category: "Produk", url: "/products/pink-darling-bouquet", images: "//outerbloom.com/cdn/shop/products/Pink-Darling-Bouquet_thumb.jpg?v=1669969725", price: "Rp 485.000" },{ label: "black pink bouquet", category: "Produk", url: "/products/black-pink-bouquet", images: "//outerbloom.com/cdn/shop/files/Black-Pink-Bouquet_thumb.jpg?v=1756434063", price: "Rp 485.000" },{ label: "profound happiness jabodetabek", category: "Produk", url: "/products/profound-happiness-jabodetabek", images: "//outerbloom.com/cdn/shop/files/profound-happiness_thumb.gif?v=1689940309", price: "Rp 635.000" },{ label: "healing trove", category: "Produk", url: "/products/healing-trove", images: "//outerbloom.com/cdn/shop/products/2ef5379f-27a6-41ba-85c7-c65cf3ec3f08_thumb.jpg?v=1571471845", price: "Rp 485.000" },{ label: "sincerity solace", category: "Produk", url: "/products/sincerity-solace", images: "//outerbloom.com/cdn/shop/products/OUTSTF1038_sincerity-solace-WM_thumb.jpg?v=1612352477", price: "Rp 485.000" },{ label: "bellarosa bloom box", category: "Produk", url: "/products/bellarosa-bloom-box", images: "//outerbloom.com/cdn/shop/files/OBVBUN1783_Bellarosa-Bloom-Box_c0000424-411c-48ed-abf4-0de7d925ea53_thumb.jpg?v=1757316757", price: "Rp 785.000" }
  ];

             
        $( ".header-input-search" ).catcomplete({
         appendTo: ".searchResult",source: function(request, response) {
            var results = $.ui.autocomplete.filter(data, request.term);
            var predicate = function () {
                var counter = { Collection: 0, Produk: 0 };
            var fn = function(item) {counter[item.category] += 1;return (counter[item.category] <= 5);}
            return fn
            }();
            response(results.filter(predicate));
          },
          minLength:1,
           //results are clickable
          select: function( event, ui ) {window.location = ui.item.url;}
});
$( ".header-input-search2" ).catcomplete({
        appendTo: ".searchResult2",
                   source: function(request, response) {
                    var results = $.ui.autocomplete.filter(data, request.term);
                    var predicate = function () {
                        var counter = { Collection: 0, Produk: 0 };
              var fn = function(item) {
              counter[item.category] += 1;
  return (counter[item.category] <= 5);
}
               return fn
               }();
response(results.filter(predicate));
},
  minLength:1,
        //results are clickable
        select: function( event, ui ) {
          window.location = ui.item.url;
        }
});
});
</script>

    <script src="//outerbloom.com/cdn/shop/t/138/assets/vendors.js?v=6349622868601634021752652419" defer></script>
<script src="//outerbloom.com/cdn/shop/t/138/assets/app.js?v=136050180318808583701752652452" defer></script>

<script>
  ( function() {
    var youtube = document.querySelectorAll( ".youtube" );
    for (var i = 0; i < youtube.length; i++) {
      var source = "https://img.youtube.com/vi/"+ youtube[i].dataset.embed +"/sddefault_1x.jpg";
      var datasource = "https://img.youtube.com/vi/"+ youtube[i].dataset.embed +"/sddefault.jpg";
      var image = new Image();
      image.src = source;
      image.setAttribute("data-src", datasource);
      image.classList.add("swiper-lazy");
      image.addEventListener( "load", function() {
        youtube[ i ].appendChild( image );
      }( i ) );
      youtube[i].addEventListener( "click", function() {
        var iframe = document.createElement( "iframe" );
        iframe.setAttribute( "width", "480" );
        iframe.setAttribute( "height", "480" );
        iframe.setAttribute( "frameborder", "0" );
        iframe.setAttribute( "allowfullscreen", "" );
        iframe.setAttribute( "src", "https://www.youtube.com/embed/"+ this.dataset.embed +"?rel=0&showinfo=0&autoplay=1" );
        this.innerHTML = "";
        this.appendChild( iframe );
      } );
    };

  } )();

  /* Lazy Load */
  const mainLazyLoad = new LazyLoad({threshold:400});
  $(document).ready(function(){

    $("selectxxx").addClass("needsclick");
    FastClick.attach(document.body);
    
    var $customSelects = $('.select-search');
    $customSelects.select2({
      templateResult: function(result, container) {
        if (!result.id) {
          return result.text;
        }
        container.className += ' needsclick';
        return result.text;
      }
    });
    $customSelects.each(function(index, el){$(el).data('select2').$container.find('*').addClass('needsclick');});
    $(document).on('select2:open', () => {
      document.querySelector('.select2-search__field').focus();
    });
    

    $(".overlay").click(function(){
      $(".js-drawer-close").click();
    });
    $(".site-nav--mobile .js-drawer-open-left, #NavDrawer .icon-close, .overlay-nav").click(function(){
      $("html").toggleClass("nav_open");
    });
    
    $('.swatch-element label').on('click', function(){
      var srcImg = $(this).data('src');
      $('#thumb-image-product .product-single__thumbnail').each(function(){
        if ($(this).attr("href") == srcImg) {
          $(this).trigger('click');
        }
      });
    });
    var defaultValue = $(".swatch input:checked").val()
    
    $('#purchaseProduct .swatch [type=radio]').change(function() {
      var optionIndex = $(this).closest('.swatch').attr('data-option-index');
      var optionValue = $(this).val();
      console.log(optionIndex, optionValue)
      var value = parseInt(optionValue.split(' ')[0])
      $(this)
      .closest('#purchaseProduct')
      .find('.single-option-selector')
      .eq(optionIndex)
      .val(optionValue)
      .trigger('change');
      
    });
    
  });
  $(document).ready(function(){
    $(".nav-search a").click(function(e){
      e.preventDefault();
      $(".icon-navsearch").toggle();
      $(".icon-navclose").toggle();
      $(".site-nav__item > .site-nav__link").toggle();
      $(".open-search").toggle();
      $(".open-search input").focus();
    });
    $(".best-price-guarantee").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/logo-best-price-guarantee-grid_75x.png?v=72489032173169839651752652420' alt='Logo Best Price Guarantee'>");
    if ($(window).width() < 768) {
      $(".bg-products .label-tag.valentine").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/icon-valentine_75x.png?v=82732945490105366961752652419' alt='Icon Valentine'>");
      $(".bg-products .label-tag.cny").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/icon-cny_45x.png?v=101884295148001743851752652418' alt='Icon CNY'>");
      $(".bg-products .label-tag.free-valentine").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/free-valentine_150x.png?v=171641187769238175351752652421' alt='Icon Free Valentine'>");
    } else {
      $(".bg-products .label-tag.valentine").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/icon-valentine_60x.png?v=82732945490105366961752652419' alt='Icon Valentine'>");
      $(".bg-products .label-tag.cny").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/icon-cny_60x.png?v=101884295148001743851752652418' alt='Icon CNY'>");
      $(".bg-products .label-tag.free-valentine").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/free-valentine_200x.png?v=171641187769238175351752652421' alt='Icon Free Valentine'>");
    }
    $(".bg-products .label-tag.free-cookies").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/free-cookies_80x.png?51468' alt='Icon Free Cookies'>");
    $(".bg-products .label-tag.mothersday").html("<img src='//outerbloom.com/cdn/shop/t/138/assets/mothers-day_70x.png?v=171373711354766377891752652419' alt='Icon Mothers day'>");
  });
</script>


    
    
    
    

    <script type="text/javascript">
      var wishlistpage = 0;
       
       var quickShop_money_format="<span class='money'>"+"Rp {{amount_no_decimals}}"+"</span>";
    </script>
    
      <!-- Remove duplicate wishlist.js reference -->
      <style>
  .fade{opacity:0;-webkit-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.modal{position:fixed;top:0;right:0;bottom:0;left:0;z-index:999999;display:none;overflow:hidden;-webkit-overflow-scrolling:touch;outline:0}.fade.in{opacity:1}.modal-open .modal{overflow-x:hidden;overflow-y:auto;z-index:999999;background-color:rgba(0,0,0,.3)}.modal-dialog{position:relative;width:auto;margin:10px}.wishlist-model .modal-dialog{width:700px}.modal.fade .modal-dialog{-webkit-transition:-webkit-transform .3s ease-out;-o-transition:-o-transform .3s ease-out;transition:transform .3s ease-out;-webkit-transform:translate(0,-25%);-ms-transform:translate(0,-25%);-o-transform:translate(0,-25%);transform:translate(0,-25%)}.modal.in .modal-dialog{-webkit-transform:translate(0,0);-ms-transform:translate(0,0);-o-transform:translate(0,0);transform:translate(0,0)}.modal-content{position:relative;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #999;border:1px solid rgba(0,0,0,.2);outline:0;-webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);box-shadow:0 3px 9px rgba(0,0,0,.5)}.wishlist-model .modal-content{}.wishlist-model .modal-header{min-height:0;padding:0;border-bottom:0}.close{float:right;font-size:21px;font-weight:700;line-height:1;color:#000;text-shadow:0 1px 0 #121212;filter:alpha(opacity=20);opacity:.2}button.close{-webkit-appearance:none;padding:0;cursor:pointer;background:0 0;border:0}.modal-header .close{margin-top:-2px}.wishlist-model .close{position:absolute;top:-10px;right:-10px;background:#fff;opacity:1;width:30px;height:30px;font-size:15px;border-radius:50%;z-index:10;box-shadow:0 1px 4px 0 #121212}.wishlist-model .close .icon-close{width:25px;height:25px}.modal-body{position:relative;padding:15px}.wishlist-model .modal-body{padding:0 30px;display:flex}.wishlist-model .wishlist-left{width:66.67%;border-right:1px solid #ccc;padding:30px 0}.wishlist-model .wishlist-note{position:relative;display:inline-block;margin-bottom:20px;margin-left:35px;border-bottom:1px solid #121212;color:#121212}.wishlist-model .wishlist-note a{color: #ffffff;}.wishlist-model .wishlist-note .cirle{position:absolute;top:-4px;left:-35px;width:25px;height:25px;color:#fff;background:#121212;line-height:25px;border-radius:50%;text-align:center}.wishlist-model .wishlist-note svg{fill:#fff}.wishlist-model .wishlist-note .cirle .icon-check{vertical-align:middle}.wishlist-model .product-left{width:33.33%;float:left;margin-right:30px}.wishlist-model .wishlist-image{overflow:hidden}.wishlist-model .wishlist-image img{transition:all .3s linear}.wishlist-model .wishlist-name{padding:0;margin-bottom:10px}.wishlist-model .wishlist-name a{color: #ffffff;}.wishlist-model .wishlist-price{margin-bottom:10px}.wishlist-model .wishlist-price .price{font-weight:700;margin-right:10px;font-size:15px}.wishlist-model .wishlist-price .price_compare{color:#ccc}.wishlist-model .wishlist-right{width:33.33%;padding:30px 0;padding-left:30px}.wishlist-model .btn-quick-shop{width:100%;border-color:#121212;background:#fff;color:#121212;padding:0 30px;transition:all .2s linear;height:36px;margin-bottom:10px;text-transform:uppercase}.wishlist-model .btn-cta{width:100%;font-size:1em;border-color:#ffffff;background:#ffffff;color:#fff;padding:0;transition:all .2s linear;height:36px;line-height:36px;margin-bottom:10px}.wishlist-model .quantity-content{text-align:center}.wishlist-model .quantity-content input{outline:none;text-align:center;font-weight:600;border:1px solid #121212}.wishlist-model .quantity-content button{border-color:#121212}@media (min-width:768px){.modal-dialog{width:600px;margin:30px auto}.modal-content{-webkit-box-shadow:0 5px 15px rgba(0,0,0,.5);box-shadow:0 5px 15px rgba(0,0,0,.5)}}
</style>

<div class="modal fade" id="modalwishlist0" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">        
      <div class="modal-body">Your Wishlist is empty!</div>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>          
    </div>
  </div>
</div> 

<div class="wishlist-model">
  <div class="modal fade" id="modalwishlist1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog white-modal">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <svg class="icon icon-close" version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="32" height="32" viewBox="0 0 32 32">
<title>icon-close</title>
<path d="M16.943 16l8.862 8.862c0.26 0.26 0.26 0.682 0 0.943s-0.682 0.26-0.943 0l-8.862-8.862-8.862 8.862c-0.26 0.26-0.682 0.26-0.943 0s-0.26-0.682 0-0.943l8.862-8.862-8.862-8.862c-0.26-0.26-0.26-0.682 0-0.943s0.682-0.26 0.943 0l8.862 8.862 8.862-8.862c0.26-0.26 0.682-0.26 0.943 0s0.26 0.682 0 0.943l-8.862 8.862z"></path>
</svg>
          </button>
        </div>
        <div class="modal-body">
          <div class="wishlist-left">
            <div class="wishlist-note">
              <span class="cirle"><svg version="1.1" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="32" height="32" viewBox="0 0 32 32">
<title>icon-check</title>
<path d="M12 21.766l14.218-12.926c0.272-0.248 0.694-0.228 0.942 0.045s0.228 0.694-0.045 0.942l-14.667 13.333c-0.254 0.231-0.643 0.231-0.897 0l-6.667-6.061c-0.272-0.248-0.293-0.669-0.045-0.942s0.669-0.293 0.942-0.045l6.218 5.653z"></path>
</svg></span>
              Product added to <a href="/pages/wish-list">Wishlist</a>
            </div>
            <div class="wishlist-product">
              <div class="product-left">
                <div class="wishlist-image"></div>
              </div>
              <div class="product-right">
                <div class="wishlist-name"></div>
                <div class="wishlist-price"></div>
              </div>
            </div>
          </div>
          <div class="wishlist-right">
            <div class="wishlist-cart">
              <form action="/cart/add" method="post" class="variants-form variants" id="AddToCartForm" enctype="multipart/form-data">                  
                <div class="others-bottom">
                  <a class="btn btn-quick-shop" href="/pages/wish-list">View Wishlist</a>
                  <button type="submit" name="add" id="AddToCart" class="btn btn-cta">
                    <span id="AddToCartText" class="">Beli Sekarang</span>
                  </button>
                </div>
                <div id="wishlist-variants-container" class="variants-wrapper"></div> 
                <div class="quantity-content">
                  <label>QTY</label>
                  <input type="number" size="5" class="" name="quantity" value="1" />
                </div>
              </form> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

    
    <style>
       .stamped-badge[data-rating="0.0"]{display: none !Important;}
       
        div[data-load-type="continue"] ul.stamped-pagination li.next a, div[data-widget-load-type="continue"] ul.stamped-pagination li.next a {
          border-radius: 0px;
      }
          .stamped-review-body {
          padding-left: 0px !important;
      }
          #product-reviews .stamped-header:after {
            display:none !Important;
          }
      #stamped-main-widget .stamped-container, .stamped-badge-caption,#stamped-reviews-widget {
          font-family:inherit !important;
      }
    </style>

    

<div id='stamped-rewards-init' class='stamped-rewards-init'
  data-key-public=''

></div>

    <script src="//outerbloom.com/cdn/shop/t/138/assets/variant-sku-handler.js?v=91239063692820757781752652418" defer></script>
    <!-- Remove duplicate jQuery reference and load wishlist script properly -->
    <script src="//outerbloom.com/cdn/shop/t/138/assets/wishlist-fixed.js?v=35991423018869066281754360012" defer></script>

    <script>
      function myInit(){ StampedFn.init({ apiKey: 'pubkey-hCS8DHE9QbBHhHN89WXFkuJ0Y3422D', sId: '23462' }); }
    </script>
    <script async onload="myInit()" type="text/javascript" src="https://cdn1.stamped.io/files/widget.min.js"></script><style>
  .2 {
    background-color: rgba(0, 0, 0, 0.6);
  }
  .MuiBackdrop-root {
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    z-index: -1;
    position: fixed;
    align-items: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.5);
    -webkit-tap-highlight-color: transparent;
  }
  .MuiDialog-scrollPaper {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .MuiDialog-container {
    height: 100%;
    outline: 0;
  }
  .MuiPaper-elevation24 {
    box-shadow: 0px 11px 15px -7px rgba(0,0,0,0.2), 0px 24px 38px 3px rgba(0,0,0,0.14), 0px 9px 46px 8px rgba(0,0,0,0.12);
  }
  .MuiDialog-paper {
    margin: 32px;
    position: relative;
    overflow-y: auto;
  }

  .MuiDialog-paperScrollPaper {
    display: flex;
    max-height: calc(100% - 64px);
    flex-direction: column;
  }

  .MuiDialog-paperWidthSm {
    max-width: 600px;
  }

  #location-lock-dialog {
    top: 20%;
    left: 0;
    right: 0;
    width: 30%;
    margin: 0px auto;
    display: block;
    padding: 30px;
    z-index: 99999;
    position: fixed;
    font-size: 14px;
    background: rgb(0, 0, 0);
    box-shadow: rgba(11, 11, 12, 0.2) 2px 4px 5px 0px;
    text-align: center;
    font-family: Roboto, Arial, sans-serif;
    line-height: 1;
    border-radius: 8px;
    -webkit-font-smoothing: subpixel-antialiased;
  }
  .MuiButtonBase-root {
    color: inherit;
    border: 0;
    cursor: pointer;
    margin: 0;
    display: inline-flex;
    outline: 0;
    padding: 0;
    position: relative;
    align-items: center;
    user-select: none;
    border-radius: 0;
    vertical-align: middle;
    -moz-appearance: none;
    justify-content: center;
    text-decoration: none;
    background-color: transparent;
    -webkit-appearance: none;
    -webkit-tap-highlight-color: transparent;
  }
  .MuiIconButton-root {
    flex: 0 0 auto;
    color: rgba(0, 0, 0, 0.54);
    padding: 12px;
    overflow: visible;
    font-size: 1.5rem;
    text-align: center;
    transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
    border-radius: 50%;
  }
  .MuiIconButton-label {
    width: 100%;
    display: flex;
    align-items: inherit;
    justify-content: inherit;
  }
  .MuiSvgIcon-root {
    fill: currentColor;
    width: 1em;
    height: 1em;
    display: inline-block;
    font-size: 1.5rem;
    transition: fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
    flex-shrink: 0;
    user-select: none;
  }
  .MuiTouchRipple-root {
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 0;
    overflow: hidden;
    position: absolute;
    border-radius: inherit;
    pointer-events: none;
  }

  .q {
    color: #222222;
    font-size: 24px;
    font-family: Roboto, Arial, sans-serif;
    font-weight: 500;
  }
  .b {
    color: #555555;
    padding: 10px 0px 0px;
    font-size: 14px;
  }
  .MuiFormGroup-root {
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
  }
  .MuiFormGroup-row {
    flex-direction: row;
  }

  .l {
    width: 85%;
    margin: 15px auto;
    display: flex;
    padding: 11px 0px 0px;
    justify-content: space-evenly;
  }
  .MuiFormControlLabel-root {
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    margin-left: -11px;
    margin-right: 16px;
    vertical-align: middle;
    -webkit-tap-highlight-color: transparent;
  }
  .y {
    margin: 0;
  }
  .MuiButtonBase-root {
    color: inherit;
    border: 0;
    cursor: pointer;
    margin: 0;
    display: inline-flex;
    outline: 0;
    padding: 0;
    position: relative;
    align-items: center;
    user-select: none;
    border-radius: 0;
    vertical-align: middle;
    -moz-appearance: none;
    justify-content: center;
    text-decoration: none;
    background-color: transparent;
    -webkit-appearance: none;
    -webkit-tap-highlight-color: transparent;
  }
  .MuiIconButton-root {
    flex: 0 0 auto;
    color: rgba(0, 0, 0, 0.54);
    padding: 12px;
    overflow: visible;
    font-size: 1.5rem;
    text-align: center;
    transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
    border-radius: 50%;
  }
  .MuiIconButton-colorSecondary {
    color: #f50057;
  }
  .u {
    padding: 9px;
  }
  .MuiRadio-root {
    color: rgba(0, 0, 0, 0.54);
  }
  .9 {
    padding: 2px;
  }
  .MuiRadio-colorSecondary.Mui-checked {
    color: #f50057;
  }
  .MuiIconButton-label {
    width: 100%;
    display: flex;
    align-items: inherit;
    justify-content: inherit;
  }
  .MuiTypography-root {
    margin: 0;
  }
  .MuiTypography-body1 {
    font-size: 18px;
    font-family: Roboto,sans-serif;
    font-weight: 400;
    line-height: 1.5;
  }
  .location-popup_area-block__sp9Ws {
    display: -moz-box;
    display: flex;
    -moz-box-orient: vertical;
    -moz-box-direction: normal;
    flex-direction: column;
    -moz-box-pack: center;
    justify-content: center;
    position: relative;
    margin: 10px 10% 0;
  }
  .location-popup_pin-search-box__3l5mJ {
    width: 100%;
    display: -moz-box;
    display: flex;
    -moz-box-align: center;
    align-items: center;
  }
  .location-popup_place-icon-city__1XAX5, .location-popup_place-icon__jSG0Q {
    position: absolute;
    z-index: 999;
  }
  .location-popup_place-icon__jSG0Q {
    color: #ffffff;
    padding-left: 8px;
  }
  .location-popup_place-icon__jSG0Q svg {
    width: 18px;
    height: 18px;
  }
  .location-popup_cancel-icon__FHujU {
    color: #fff;
    right: 10px;
    width: 16px;
    cursor: pointer;
    height: 16px;
    display: none;
    padding: 5px;
    position: absolute;
    background: #999;
    text-align: center;
    border-radius: 50%;
  }
  .location-popup_pin-search-box__3l5mJ>div>select {
/*     -webkit-box-shadow: 0 0 10px #ffffff;
    box-shadow: 0 0 10px #ffffff; */
    text-transform: capitalize;
    border: 1px solid #ffffff;
    color: #ffffff;
    width: 100%;
    margin: 0;
    display: -moz-box;
    display: flex;
    padding: 0 30px;
    -webkit-animation: location-popup_focuses__1I8Gj 1.5s ease-in-out infinite;
    -moz-animation: location-popup_focuses__1I8Gj 1.5s ease-in-out infinite;
    animation: location-popup_focuses__1I8Gj 1.5s ease-in-out infinite;
    font-size: 16px;
    border-radius: 4px;
    height: 44px;
    moz-animation: location-popup_focuses__1I8Gj ease-in-out 1.5s infinite;
    webkit-animation: location-popup_focuses__1I8Gj ease-in-out 1.5s infinite;
  }
  .MuiButtonBase-root {
    color: inherit;
    border: 0;
    cursor: pointer;
    margin: 0;
    display: inline-flex;
    outline: 0;
    padding: 0;
    position: relative;
    align-items: center;
    user-select: none;
    border-radius: 0;
    vertical-align: middle;
    -moz-appearance: none;
    justify-content: center;
    text-decoration: none;
    background-color: transparent;
    -webkit-appearance: none;
    -webkit-tap-highlight-color: transparent;
  }
  .MuiButton-root {
    color: rgba(0, 0, 0, 0.87);
    padding: 6px 16px;
    font-size: 0.875rem;
    min-width: 64px;
    box-sizing: border-box;
    transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,border 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
    font-family: Roboto,sans-serif;
    font-weight: 500;
    line-height: 1.75;
    border-radius: 4px;
    text-transform: uppercase;
  }
  .MuiButton-contained {
    color: rgba(0, 0, 0, 0.87);
    box-shadow: 0px 3px 1px -2px rgba(0,0,0,0.2), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12);
    background-color: #e0e0e0;
  }
  .MuiButtonBase-root.Mui-disabled {
    cursor: default;
    pointer-events: none;
  }
  .MuiButton-label {
    width: 100%;
    display: inherit;
    align-items: inherit;
    justify-content: inherit;
  }
  .cartButton_login_content__2j1f7 {
    display: -moz-box;
    display: flex;
    text-align: center;
    z-index: 9;
    font-size: 18px;
    font-weight: 500;
    color: #fff;
  }
  
  .12 {
    top: 5px;
    right: 5px;
    padding: 4px;
    position: absolute;
    border-radius: 50%;
  }
  .s {
    cursor: pointer;
    font-size: 15px;
    line-height: 1.3;
    padding-left: 5px;
  }
  .t {
    color: #222222;
  }
  .d {
    color: #fff;
    width: 100%;
    height: 52px;
    padding: 11px 16px;
    font-size: 18px;
    min-width: 88px;
    min-height: 36px;
    transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
    font-weight: 500;
    line-weight: 1em;
    border-radius: 4px;
    text-transform: uppercase;
    background-color: #E87325;
  }
  @media (min-width: 991px){
    .cartButton_login_content__2j1f7 {
        font-weight: 500;
    }
  }

  @media (max-width: 992px) {
    #location-lock-dialog {
      width: 100%;
      top: auto;
      bottom: 0;
      padding-left: 0;
      padding-right: 0;
    }
    .MuiFormGroup-row {
      display: block
    }
    .MuiIconButton-label input {
      margin: 0;
    }
  } 

body {
    background-color: #37a539d4;
}

</style>
<div role="presentation" class="MuiDialog-root jss34" style="display: none;position: fixed; z-index: 9999; inset: 0px;">
  <div class="MuiBackdrop-root" aria-hidden="true" style="opacity: 1; transition: opacity 225ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;"></div>
  <div tabindex="0" data-test="sentinelStart"></div>
  <div class="MuiDialog-container MuiDialog-scrollPaper" role="none presentation" tabindex="-1" style="opacity: 1; transition: opacity 225ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;">
    <div class="MuiPaper-root MuiDialog-paper MuiDialog-paperScrollPaper MuiDialog-paperWidthSm MuiPaper-elevation24 MuiPaper-rounded" role="dialog">
      <div class="jss31 undefined" id="location-lock-dialog">
        <button id="close-popup-delivery" class="MuiButtonBase-root MuiIconButton-root 12" tabindex="0" type="button" aria-label="close">
          <span class="MuiIconButton-label">
            <svg class="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path>
            </svg>
          </span>
          <span class="MuiTouchRipple-root"></span>
        </button>
        <div>
          <div class="q">Select Delivery Location</div>
          <div class="b">Select a delivery location to see product availability</div>
        </div>
        <div class="MuiFormGroup-root l MuiFormGroup-row" role="radiogroup">
          <label for="jabodetabek" class="MuiFormControlLabel-root jss45">
            <span class="MuiButtonBase-root MuiIconButton-root jss46 MuiRadio-root MuiRadio-colorSecondary jss39 jss47 Mui-checked MuiIconButton-colorSecondary" aria-disabled="false">
              <span class="MuiIconButton-label">
                <input id="jabodetabek" class="jss49" type="radio" value="Jabodetabek" checked="" name="location">
                <span class="jss41"></span>
              </span>
              <span class="MuiTouchRipple-root"></span>
            </span>
            <span class="MuiTypography-root MuiFormControlLabel-label MuiTypography-body1">
              <span class="s t">Jabodetabek</span>
            </span>
          </label>
          <label for="non-jabodetabek" class="MuiFormControlLabel-root jss45">
            <span class="MuiButtonBase-root MuiIconButton-root jss46 MuiRadio-root MuiRadio-colorSecondary jss39 MuiIconButton-colorSecondary" aria-disabled="false">
              <span class="MuiIconButton-label">
                <input id="non-jabodetabek" class="jss49" type="radio" value="Outside Jabodetabek" name="location">
                <span class="jss40"></span>
              </span>
              <span class="MuiTouchRipple-root"></span>
            </span>
            <span class="MuiTypography-root MuiFormControlLabel-label MuiTypography-body1">
              <span class="s jss68">Outside Jabodetabek</span>
            </span>
          </label>
        </div>
        <div>
          <div class="MuiGrid-root location-popup_area-block__sp9Ws">
            <div class="MuiGrid-root location-popup_pin-search-box__3l5mJ false">
              <div class="MuiGrid-root location-popup_place-icon__jSG0Q">
                <svg class="MuiSvgIcon-root jss6" focusable="false" viewBox="0 0 24 24" aria-hidden="true" style="font-size:16px"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"></path></svg>
              </div>
              <div class="MuiGrid-root location-popup_cancel-icon__FHujU false">
                <i class="material-icons location-popup_clear-pin__s1dRc">close</i>
              </div>
              <div style="width: 100%;">
                <select id="choose-location" class="form-control">
                  <option value="">Choose Location</option>
                  <option value="jakarta">Jakarta</option>
                  <option value="bogor">Bogor</option>
                  <option value="depok">Depok</option>
                  <option value="tangerang">Tangerang</option>
                  <option value="bekasi">Bekasi</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <button class="MuiButtonBase-root MuiButton-root MuiButton-contained jss55" tabindex="-1" type="button" title="" id="location-lock-submit" data-idforcdp="actionBtn-cdp" data-testid="location-lock-submit" style="background-color: #ffffff; width: 80%; padding: 14px 0px 12px; margin: 20px 0px; font-size: 18px; font-weight: 500; box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px 0px; border-radius: 4px; color: rgb(0, 0, 0); height: 44px;" data-content="">
          <span class="MuiButton-label">
            <span class=""></span>
            <span id="location-lock-continue-btn" class="cartButton_login_content__2j1f7" style="font-weight: 500;" data-content="">Continue Shopping</span>
          </span>
        </button>
      </div>
    </div>
  </div>
  <div tabindex="0" data-test="sentinelEnd"></div>
</div>

<script>
  const jabodetabek = [
    {
      "code": "jakarta",
      "city": "jakarta",
      "zip": []
    },
    {
      "code": "bogor",
      "city": "bogor",
      "zip": []
    },
    {
      "code": "depok",
      "city": "depok",
      "zip": []
    },
    {
      "code": "tangerang",
      "city": "tangerang",
      "zip": []
    },
    {
      "code": "bekasi",
      "city": "bekasi",
      "zip": []
    }
  ]
  let cityNonJabodetabek = [
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    "pengiriman_aceh",
    
    
    
    
    
    "pengiriman_ambon",
    
    
    
    
    
    "pengiriman_atambua",
    
    
    
    
    
    "pengiriman_badung",
    
    
    
    
    
    "pengiriman_bali",
    
    
    
    
    
    "pengiriman_balikpapan",
    
    
    
    
    
    "pengiriman_bandar lampung",
    
    
    
    
    
    "pengiriman_bandung",
    
    
    
    
    
    "pengiriman_bandung barat",
    
    
    
    
    
    "pengiriman_banjarmasin",
    
    
    
    
    
    "pengiriman_banyumas",
    
    
    
    
    
    "pengiriman_banyuwangi",
    
    
    
    
    
    "pengiriman_batam",
    
    
    
    
    
    
    
    
    
    "pengiriman_biak",
    
    
    
    
    
    "pengiriman_binjai",
    
    
    
    
    
    "pengiriman_blitar",
    
    
    
    
    
    "pengiriman_blora",
    
    
    
    
    
    
    
    
    
    "pengiriman_bojonegoro",
    
    
    
    
    
    "pengiriman_boyolali",
    
    
    
    
    
    "pengiriman_bukittinggi",
    
    
    
    
    
    "pengiriman_buleleng",
    
    
    
    
    
    "pengiriman_ciamis",
    
    
    
    
    
    "pengiriman_cianjur",
    
    
    
    
    
    "pengiriman_cibinong",
    
    
    
    
    
    "pengiriman_cikarang",
    
    
    
    
    
    "pengiriman_cikupa",
    
    
    
    
    
    "pengiriman_cilacap",
    
    
    
    
    
    "pengiriman_cileunyi",
    
    
    
    
    
    "pengiriman_cimahi",
    
    
    
    
    
    "pengiriman_cirebon",
    
    
    
    
    
    "pengiriman_ciwidey",
    
    
    
    
    
    "pengiriman_deli serdang",
    
    
    
    
    
    "pengiriman_demak",
    
    
    
    
    
    "pengiriman_denpasar",
    
    
    
    
    
    
    
    
    
    "pengiriman_garut",
    
    
    
    
    
    "pengiriman_gianyar",
    
    
    
    
    
    "pengiriman_gresik",
    
    
    
    
    
    "pengiriman_gunung kidul",
    
    
    
    
    
    
    
    
    
    "pengiriman_jambi",
    
    
    
    
    
    "pengiriman_jayapura",
    
    
    
    
    
    "pengiriman_jember",
    
    
    
    
    
    "pengiriman_jepara",
    
    
    
    
    
    "pengiriman_jombang",
    
    
    
    
    
    "pengiriman_karanganyar",
    
    
    
    
    
    "pengiriman_karawang",
    
    
    
    
    
    "pengiriman_karo",
    
    
    
    
    
    "pengiriman_kebumen",
    
    
    
    
    
    "pengiriman_kediri",
    
    
    
    
    
    "pengiriman_keerom",
    
    
    
    
    
    "pengiriman_kendal",
    
    
    
    
    
    "pengiriman_klaten",
    
    
    
    
    
    
    
    
    
    "pengiriman_kudus",
    
    
    
    
    
    "pengiriman_kupang",
    
    
    
    
    
    "pengiriman_lainnya",
    
    
    
    
    
    "pengiriman_lamongan",
    
    
    
    
    
    "pengiriman_lampung",
    
    
    
    
    
    "pengiriman_lampung barat",
    
    
    
    
    
    "pengiriman_lembang",
    
    
    
    
    
    "pengiriman_lombok",
    
    
    
    
    
    "pengiriman_lumajang",
    
    
    
    
    
    "pengiriman_madiun",
    
    
    
    
    
    "pengiriman_magelang",
    
    
    
    
    
    "pengiriman_majalengka",
    
    
    
    
    
    "pengiriman_makassar",
    
    
    
    
    
    "pengiriman_malang",
    
    
    
    
    
    "pengiriman_manado",
    
    
    
    
    
    "pengiriman_medan",
    
    
    
    
    
    "pengiriman_mengwi",
    
    
    
    
    
    "pengiriman_mojokerto",
    
    
    
    
    
    "pengiriman_nganjuk",
    
    
    
    
    
    "pengiriman_ngawi",
    
    
    
    
    
    "pengiriman_padang",
    
    
    
    
    
    "pengiriman_palembang",
    
    
    
    
    
    "pengiriman_pasuruan",
    
    
    
    
    
    "pengiriman_pati",
    
    
    
    
    
    "pengiriman_pekalongan",
    
    
    
    
    
    "pengiriman_pekanbaru",
    
    
    
    
    
    "pengiriman_pemalang",
    
    
    
    
    
    "pengiriman_ponorogo",
    
    
    
    
    
    "pengiriman_pontianak",
    
    
    
    
    
    "pengiriman_probolinggo",
    
    
    
    
    
    "pengiriman_purbalingga",
    
    
    
    
    
    "pengiriman_purwakarta",
    
    
    
    
    
    "pengiriman_purwokerto",
    
    
    
    
    
    "pengiriman_rembang",
    
    
    
    
    
    "pengiriman_riau",
    
    
    
    
    
    "pengiriman_salatiga",
    
    
    
    
    
    "pengiriman_samarinda",
    
    
    
    
    
    "pengiriman_semarang",
    
    
    
    
    
    "pengiriman_sentani",
    
    
    
    
    
    "pengiriman_serang",
    
    
    
    
    
    "pengiriman_sidoarjo",
    
    
    
    
    
    "pengiriman_singkawang",
    
    
    
    
    
    "pengiriman_sragen",
    
    
    
    
    
    "pengiriman_subang",
    
    
    
    
    
    "pengiriman_sukabumi",
    
    
    
    
    
    "pengiriman_sumbawa",
    
    
    
    
    
    "pengiriman_surabaya",
    
    
    
    
    
    "pengiriman_surakarta solo",
    
    
    
    
    
    
    
    
    
    "pengiriman_tasikmalaya",
    
    
    
    
    
    "pengiriman_tegal",
    
    
    
    
    
    "pengiriman_timika",
    
    
    
    
    
    "pengiriman_wamena",
    
    
    
    
    
    "pengiriman_wiyung",
    
    
    
    
    
    "pengiriman_wonokromo",
    
    
    
    
    
    "pengiriman_yogyakarta",
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  ]
  console.log(cityNonJabodetabek)
  let non_jabodetabek = []
  for(var i=0;i<cityNonJabodetabek.length;i++) {
    const obj = {
      "code": cityNonJabodetabek[i].toLowerCase().replace('pengiriman_', '').replace(' ','-'),
      "city": cityNonJabodetabek[i].replace('pengiriman_', '').replace(' ','-'),
      "zip": []
    }
    non_jabodetabek.push(obj)
  }
  let current_location = getCookie("location_delivery")
  $("[name=location]").change(function(){
    let v = $(this).val()
    let option = []
    if(v == 'Jabodetabek') {
      for(var i=0;i<jabodetabek.length;i++) {
        const jabodetabekHtml = `<option value=${jabodetabek[i].city}>${jabodetabek[i].city}</option>`
        option.push(jabodetabekHtml)
      }
      $("#choose-location").html(`<option value="">Choose Location</option>${option}`)
    } else {
      for(var i=0;i<non_jabodetabek.length;i++) {
        const nonjabodetabekHtml = `<option value=${non_jabodetabek[i].city}>${non_jabodetabek[i].city}</option>`
        option.push(nonjabodetabekHtml)
      }
      $("#choose-location").html(`<option value="">Choose Location</option>${option}`)
    }
  })

  $("#location-lock-submit").click(function(e){
    let select = $("#choose-location")
    let value = select.val().toLowerCase()
    console.log(value)
    if(select.val() == "") {
      return alert("Choose Your Location")
      e.preventDefault()
    }
    setCookie("location_delivery",value,1000000);
    
    location.reload();
    
  })

  $("#close-popup-delivery").click(function(){
    $(".MuiDialog-root").hide()
    if(!current_location){
      setCookie("location_delivery","jakarta",1000000);
      $("#loc_delivery_city, #loc_delivery_city_mobile").text("Jakarta")
    }
  })
  $("#loc_delivery, #loc_delivery_mobile").click(function(){
    $(".MuiDialog-root").show()
  })

  
  if(!current_location){
    
  } else {
    $("#loc_delivery_city, #loc_delivery_city_mobile").text(current_location)
    console.log(current_location)
    $("#choose-location").each(function(){
      if(current_location == 'jakarta' || current_location == 'depok' || current_location == 'bogor' || current_location == 'tangerang' || current_location == 'bekasi'){
        $("#jabodetabek").trigger("click")
      } else {
        $("#non-jabodetabek").trigger("click")
      }
      $("#choose-location").find("option[value="+current_location+"]").attr("selected", "selected")
    })
  }

  // if(current_location == 'jakarta' || current_location == 'depok' || current_location == 'bogor' || current_location == 'tangerang' || current_location == 'bekasi' || current_location == 'bandung' || current_location == 'semarang' || current_location == 'yogyakarta' || current_location == 'surabaya'){
  //   $("#timeMalam").attr("disabled", false)
  // } else {
  //   $("#timeMalam").attr("disabled", true)
  // }

  if(current_location && current_location != 'jakarta') {
    $("#self-pickup").attr("disabled", true)
  }

  function setCookie(name,value,days) {
    var expires = "";
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days*24*60*60*1000));
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
  }
  function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
      var c = ca[i];
      while (c.charAt(0)==' ') c = c.substring(1,c.length);
      if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
  }
</script>
<!-- One Tap -->
    <script>
      console.log("Outerbloom...");
    </script>
  <div id="shopify-block-ANVEzSUcxTUxZOGpwZ__9703700522657871012" class="shopify-block shopify-app-block">














































<link rel="stylesheet" href="https://cdn1.bitbybit.studio/bitbybit/static/bitChat_widget/widget.css" />
<script src="https://cdn1.bitbybit.studio/bitbybit/static/bitChat_widget/widget.js" defer></script>
<script>
  const widgetConfig = {
    id: "clz7897za002cz7otleaz0d3d",
    showQuickResponse: false,
    quickResponsesData: [],
    themeColor: "#ffffff",
    widgetText: "",
    radiusType: "circle",
    widgetIconType: "whatsapp",
    position: "right",
    storeLogo: "",
    storeName: "Outerbloom",
    storeDescription: "",
    size: "small",
    showCard: false,
    widgetColorType: "solid",
    widgetColor1: "#008069",
    widgetColor2: "#008069",
    social: {
      socialOrders: ["instagram","tiktok","facebook","x","youtube","linkedin","email"],
      values: {
        instagram: {
          enabled: false,
          value: "",
        },
        facebook: {
          enabled: false,
          value: "",
        },
        email: {
          enabled: false,
          value: "",
        },
        x: {
          enabled: false,
          value: "",
        },
        tiktok: {
          enabled: false,
          value: "",
        },
        linkedin: {
          enabled: false,
          value: "",
        },
        youtube: {
          enabled: false,
          value: "",
        },
      },
    },
  };

  function initializeWidget() {
    if (typeof BBBWidget !== 'undefined') {
      BBBWidget.init(widgetConfig);
    } else {
      setTimeout(initializeWidget, 100);
    }
  }

  initializeWidget();</script>


</div><div id="shopify-block-ATzRpVTBPU3k1R2pnW__286197278318599166" class="shopify-block shopify-app-block">


<div style="position: fixed; bottom: 0; right: 0"></div>

<script>
console.info("bitlogin extension version: v2.5.7");

const googleScript = document.createElement("script");
googleScript.setAttribute("src", "https://accounts.google.com/gsi/client");
document.head.append(googleScript);

const bitLoginBaseUrl = "https://api.bitbybit.studio";
const apiUrl = `${bitLoginBaseUrl}/bitlogin/api`;

const appearance = {"style":"square","hasShadow":true,"domain":"outerbloom1.myshopify.com","colorScheme":"match","backgroundColor":"#ffffff","outlineColor":"#ffe100","textColor":"#700000","position":"top","hideDivider":false,"dividerText":"","size":"small","format":"contentFlex","language":"en","buttonText":"Continue With","redirectLink":"\/account","googleOneTap":true,"googleOneTapBanner":true,"captureAdditionalData":true,"customerTag":"bitLogin","redirectOneTapDesktop":"[{\"label\":\"Account\",\"label2\":\"Desktop: Account\",\"value\":\"account\",\"parentValue\":\"Desktop\"}]","redirectOneTapMobile":"[{\"label\":\"Thank you page\",\"label2\":\"Mobile: Thank you page\",\"value\":\"thank_you\",\"parentValue\":\"Mobile\"}]","watermark":true,"buttonList":{"google":"Continue with Google","facebook":"Continue with Facebook","apple":"Continue with Apple","whatsapp":"Continue with WhatsApp","microsoft":"Continue with Microsoft","twitter":"Continue with X","amazon":"Continue with Amazon","instagram":"Continue with Instagram","magic_link":"Continue with Magic Link","mobile_app":"Continue with Mobile App","linkedin":"Continue with LinkedIn"}};
const config = [{"domain":"outerbloom1.myshopify.com","provider":"FACEBOOK","enabledMobile":false,"enabledWeb":true,"clientId":"922184709213757","clientSecret":"e3c874c8bce6da4211538ebda706d1cb","appleTeamId":null,"applePrivateKey":null,"usePersonalOauth":false,"position":null},{"domain":"outerbloom1.myshopify.com","provider":"GOOGLE","enabledMobile":true,"enabledWeb":true,"clientId":"933600373534-vk6hiu9lqrtbblj0357q0gsoo7mqvsd0.apps.googleusercontent.com","clientSecret":"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","appleTeamId":null,"applePrivateKey":null,"usePersonalOauth":true,"position":null},{"domain":"outerbloom1.myshopify.com","provider":"APPLE","enabledMobile":true,"enabledWeb":true,"clientId":"com.bitlogin.outerbloom","clientSecret":"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","appleTeamId":"1A","applePrivateKey":"1A","usePersonalOauth":false,"position":null},{"domain":"outerbloom1.myshopify.com","provider":"WHATSAPP","enabledMobile":false,"enabledWeb":true,"clientId":null,"clientSecret":null,"appleTeamId":null,"applePrivateKey":null,"usePersonalOauth":false,"position":null},{"domain":"outerbloom1.myshopify.com","provider":"MICROSOFT","enabledMobile":false,"enabledWeb":false,"clientId":null,"clientSecret":null,"appleTeamId":null,"applePrivateKey":null,"usePersonalOauth":false,"position":null},{"domain":"outerbloom1.myshopify.com","provider":"TWITTER","enabledMobile":false,"enabledWeb":false,"clientId":null,"clientSecret":null,"appleTeamId":null,"applePrivateKey":null,"usePersonalOauth":false,"position":null},{"domain":"outerbloom1.myshopify.com","provider":"AMAZON","enabledMobile":false,"enabledWeb":false,"clientId":"amzn1.application-oa2-client.5b560a5e3e2943d6b25c50cd6dca5532","clientSecret":"amzn1.oa2-cs.v1.1cb5f9085a202341f60daf5a7be16c570ccc0b4bd5908b3afd080f34e9b8935d","appleTeamId":null,"applePrivateKey":null,"usePersonalOauth":false,"position":null}];
const redirectUrl = appearance.redirectLink;

let locationCacheSet = false;
let errorLocation = false;
let oneTapSet = false;

let bitloginCache = {
  appearance: appearance,
  config: config
};

let isInitializing = false;
const queue = [];

// Add CSS for the popup
const popupStyles = document.createElement('style');
popupStyles.textContent = `
  /* Styles for login popup */
  .bitlogin-popup-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.45);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
    z-index: 999999;
  }
  
  .bitlogin-popup-overlay.visible {
    opacity: 1;
  }
  
  .bitlogin-popup {
    background: #FFFFFF;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    border-radius: 16px;
    width: 100%;
    max-width: 560px;
    display: flex;
    overflow: hidden;
    position: relative;
    opacity: 0;
    transform: translateY(20px) scale(0.98);
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  }
  
  .bitlogin-popup.visible {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
  
  .bitlogin-popup-with-image {
    max-width: 640px;
  }
  
  .bitlogin-popup-right-image {
    flex-direction: row-reverse;
  }
  
  .bitlogin-popup-image {
    object-fit: cover;
    width: 50%;
    height: auto;
  }
  
  .bitlogin-popup-content {
    padding: 32px;
    position: relative;
    width: 50%;
  }
  
  .bitlogin-popup-close {
    position: absolute;
    top: 16px;
    right: 16px;
    background: white;
    border: none;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s;
    color: inherit;
    padding: 0;
  }
  
  .bitlogin-popup-close:hover {
    background-color: #e5e5e5;
  }
  
  .bitlogin-popup-buttons {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 24px;
  }
  
  /* Button styles within popup - override width for popup buttons */
  .bitlogin-popup-buttons #google-login,
  .bitlogin-popup-buttons #facebook-login,
  .bitlogin-popup-buttons #apple-login,
  .bitlogin-popup-buttons #whatsapp-login,
  .bitlogin-popup-buttons #microsoft-login,
  .bitlogin-popup-buttons #twitter-login,
  .bitlogin-popup-buttons #amazon-login,
  .bitlogin-popup-buttons #instagram-login,
  .bitlogin-popup-buttons #magic-link-login,
  .bitlogin-popup-buttons #mobile-app-login {
    width: 100% !important;
    font-family: inherit !important;
  }
  
  .bitlogin-popup-footer {
    margin-top: 32px;
    text-align: center;
    font-size: 14px;
    opacity: 0.6;
  }
  
  /* Modern Typography */
  .bitlogin-popup h2 {
    margin-top: 12px;
    font-size: 21px !important;
    line-height: 1.2 !important;
    font-weight: 700 !important;
    letter-spacing: -0.02em !important;
    margin-bottom: 16px !important;
  }
  
  .bitlogin-popup-header {
    position: relative;
    margin-bottom: 24px;
  }
  
  /* Modern gradient accent */
  .bitlogin-popup-content > div {
    font-size: 16px !important;
    line-height: 1.2 !important;
    opacity: 0.85 !important;
  }
  
  /* Enhanced button interactions */
  .bitlogin-popup-buttons button {
    position: relative;
    overflow: hidden;
  }
  
  @keyframes ripple {
    0% {
      transform: scale(0, 0);
      opacity: 0.5;
    }
    100% {
      transform: scale(100, 100);
      opacity: 0;
    }
  }
  
  /* Responsive adjustments */
  @media (max-width: 640px) {
    .bitlogin-popup {
      max-width: 90%;
      width: 90%;
      margin: 0 16px;
    }
    
    .bitlogin-popup-with-image {
      flex-direction: column !important;
    }
    
    .bitlogin-popup-image {
      width: 100%;
      height: 180px;
    }
    
    .bitlogin-popup-content {
      padding: 24px;
    }
    
    .bitlogin-popup h2 {
      font-size: 24px !important;
    }
  }
`;

document.head.appendChild(popupStyles);

// Add fonts link for different font options
const fontsLink = document.createElement('link');
fontsLink.rel = 'stylesheet';
fontsLink.href = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Roboto:wght@400;500&family=Open+Sans:wght@400;500;600&family=Noto+Sans:wght@400;500;600&family=Lato:wght@400;700&family=Poppins:wght@400;500;600&family=Quicksand:wght@400;500;600&family=Raleway:wght@400;500;600&family=PT+Sans:wght@400;700&family=Oswald:wght@400;500;600&display=swap';
document.head.appendChild(fontsLink);

(async () => {
  try {
    let host = window.location.host;
    if (host === "admin.shopify.com") {
      host = `${window.location.pathname.split("/")[2]}.myshopify.com`;
    }

    const urlSearchParams = new URLSearchParams(window.location.search);
    const checkoutUrl = urlSearchParams.get("checkout_url");

    async function init({ inputRef, index }) {
      if (isInitializing) {
        queue.push(() => init({ inputRef, index }));
        return;
      }

      isInitializing = true;

      try {
        let bitLoginSectionRoot = document.querySelector(
          `.bitlogin-root[data-index="${index}"]`
        );

        const formRef = inputRef?.closest(
          "form:not([action='/account/recover'])"
        );

        if (formRef && !bitLoginSectionRoot) {
          await getLocation();

          bitLoginSectionRoot = document.createElement(`div`);

          bitLoginSectionRoot.setAttribute("class", "bitlogin-root");
          bitLoginSectionRoot.setAttribute("data-index", `${index}`);

          updateAppearance({
            formRef,
            rootRef: bitLoginSectionRoot,
            host,
          });
        }
      } catch (err) {
        console.error(`error while initiating bitlogin extensions`, err);
      } finally {
        // Release the lock
        isInitializing = false;

        // Check if there are pending items in the queue
        if (queue.length > 0) {
          // Process the next function in the queue
          const nextFunction = queue.shift();
          nextFunction();
        }
      }
    }

    function initAll() {
      return new Promise((resolve, reject) => {
        setTimeout(async () => {
          const inputRefs = document.querySelectorAll(
            'input[name="customer[email]"]'
          );

          for (let i = 0; i < inputRefs.length; i++) {
            const currentInputRef = inputRefs[i];
            const isVisible = isElementVisible(currentInputRef);

            if (isVisible) {
              await init({ inputRef: currentInputRef, index: i });
            }
          }

          resolve("ok");
        }, 100);
      });
    }

    const observer = new MutationObserver((mutationsList) => {
      for (let mutation of mutationsList) {
        initAll();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
    });

    initAll();

    if (appearance.googleOneTap) {
      setupOneTap({ host, checkoutUrl });
    }

    // Initialize popup
    await initPopup(host);
  } catch (error) {
    console.error("Error initializing BitLogin:", error);
  }
})();

async function initPopup(host) {
  // Check if user is already logged in using Liquid checks properly
  const isLoggedIn = false || 
                    document.querySelector('.customer-logout-link') || 
                    document.querySelector('.account-link') || 
                    window.location.pathname.includes('/account');
  
  if (isLoggedIn) {
    return; // User is logged in, don't show popup
  }

  try {
    // Fetch the popup configuration
    const popupConfig = await fetch(`${apiUrl}/appearance/popup/domain/${host}`)
      .then(res => res.json())
      .catch(err => {
        console.error('Error fetching popup configuration:', err);
        return null;
      });

    if (!popupConfig || !popupConfig.enabled) {
      return; // Don't show popup if disabled or config not found
    }

    // Create popup after 10 seconds
    setTimeout(() => {
      // Check if user is still on the page and still not logged in
      if (document.visibilityState === 'visible') {
        // Additional check in case user logged in during the 10 second wait
        const currentlyLoggedIn = false || 
                              document.querySelector('.customer-logout-link') || 
                              document.querySelector('.account-link');
        
        if (!currentlyLoggedIn) {
          createLoginPopup(popupConfig, host);
        }
      }
    }, 10000);
  } catch (error) {
    console.error('Error initializing popup:', error);
  }
}

function createLoginPopup(popupConfig, host) {
  // Font mapping
  const fontFamilyMap = {
    system_fonts: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    montserrat: 'Montserrat, sans-serif',
    roboto: 'Roboto, sans-serif',
    open_sans: 'Open Sans, sans-serif',
    noto_sans: 'Noto Sans, sans-serif',
    lato: 'Lato, sans-serif',
    poppins: 'Poppins, sans-serif',
    quicksand: 'Quicksand, sans-serif',
    raleway: 'Raleway, sans-serif',
    pt_sans: 'PT Sans, sans-serif',
    oswald: 'Oswald, sans-serif',
  };

  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = 'bitlogin-popup-overlay';
  
  // Create popup container with appropriate styling
  const popup = document.createElement('div');
  popup.className = 'bitlogin-popup';

  if (popupConfig.layout === 'default') {
    popup.style.maxWidth = '400px';
  }
  
  // Function to close the popup
  const closePopup = () => {
    overlay.classList.remove('visible');
    popup.classList.remove('visible');
    setTimeout(() => {
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
    }, 300);
  };
  
  // Add click handler to the overlay to close when clicking outside
  overlay.addEventListener('click', (event) => {
    // Close only if clicking directly on the overlay, not its children
    if (event.target === overlay) {
      closePopup();
    }
  });
  
  // Add escape key handler to close popup
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && document.body.contains(overlay)) {
      closePopup();
    }
  });

  // Create layout with image if specified
  let contentWrapper;
  if (popupConfig.layout !== 'default' && popupConfig.popupImage) {
    popup.classList.add('bitlogin-popup-with-image');
    
    if (popupConfig.layout === 'right') {
      popup.classList.add('bitlogin-popup-right-image');
    }
    
    // Add image
    const image = document.createElement('img');
    image.className = 'bitlogin-popup-image';
    image.src = popupConfig.popupImage;
    image.alt = 'Login';
    image.loading = 'lazy';
    popup.appendChild(image);
    
    // Create content container
    contentWrapper = document.createElement('div');
    contentWrapper.className = 'bitlogin-popup-content';

    if (popupConfig.layout === 'right') {
      const closeButton = document.createElement('button');
      closeButton.className = 'bitlogin-popup-close';
      closeButton.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
        <path d="M13 1L1 13M1 1L13 13" stroke="${popupConfig.fontColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
      closeButton.setAttribute('aria-label', 'Close');
      closeButton.onclick = closePopup;
  
      popup.appendChild(closeButton);
    }
  } else {
    contentWrapper = document.createElement('div');
    contentWrapper.className = 'bitlogin-popup-content';
    contentWrapper.style.width = '100%';
  }

  // Set background style
  if (popupConfig.backgroundTheme === 'gradient') {
    contentWrapper.style.background = `linear-gradient(135deg, ${popupConfig.backgroundPopupColor}, ${popupConfig.gradientColor})`;
  } else {
    contentWrapper.style.backgroundColor = popupConfig.backgroundPopupColor;
  }

  // Apply font family
  contentWrapper.style.setProperty('font-family', fontFamilyMap[popupConfig.font] || fontFamilyMap.system_fonts, 'important');

  if (popupConfig.layout !== 'right') {
    const closeButton = document.createElement('button');
    closeButton.className = 'bitlogin-popup-close';
    closeButton.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
      <path d="M13 1L1 13M1 1L13 13" stroke="${popupConfig.fontColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.onclick = closePopup;
  
    contentWrapper.appendChild(closeButton);
  }

  // Add heading with subtle animation effect
  const header = document.createElement('div');
  header.className = 'bitlogin-popup-header';
  
  const heading = document.createElement('h2');
  heading.textContent = popupConfig.headingText || 'Sign in for exclusive benefits';
  heading.style.color = popupConfig.fontColor;
  header.appendChild(heading);

  // Add body text with improved formatting
  const bodyText = document.createElement('div');
  bodyText.innerHTML = popupConfig.bodyText || 'Join our community to access exclusive offers and a personalized shopping experience.';
  bodyText.style.color = popupConfig.fontColor;
  header.appendChild(bodyText);
  
  contentWrapper.appendChild(header);

  // Create buttons container with modern styling
  const buttonsContainer = document.createElement('div');
  buttonsContainer.className = 'bitlogin-popup-buttons';
  
  // Add social buttons
  const providerLabels = {
    'GOOGLE': 'Continue with Google',
    'FACEBOOK': 'Continue with Facebook',
    'APPLE': 'Continue with Apple',
    'WHATSAPP': 'Continue with WhatsApp',
    'MAGIC_LINK': 'Continue with Email',
  };

  // Add first login provider button
  if (popupConfig.loginProvider1 !== 'NONE') {
    const buttonConfig = {
      theme: popupConfig.colorScheme || 'match',
      customColor: popupConfig.textColor,
      format: 'contentFlex',
      buttonText: bitloginCache.appearance.buttonList[popupConfig.loginProvider1.toLowerCase()],
      hasShadow: popupConfig.hasShadow !== undefined ? popupConfig.hasShadow : true,
      style: popupConfig.style || 'rounded',
      size: popupConfig.size || 'medium',
      colorScheme: popupConfig.colorScheme || 'match',
      backgroundColor: popupConfig.backgroundColor || '#3B82F6',
      textColor: popupConfig.textColor || '#FFFFFF',
      outlineColor: popupConfig.outlineColor || '#3B82F6',
      host: host
    };
    
    const button1 = createSocialLoginButton(popupConfig.loginProvider1, buttonConfig);
    
    // Handle click event - this overrides the default click handler in createSocialLoginButton
    button1.onclick = () => {
      onClickSocialLogin({ provider: popupConfig.loginProvider1.toLowerCase(), host });
      closePopup();
    };
    
    buttonsContainer.appendChild(button1);
  }

  // Add second login provider button if enabled
  if (popupConfig.loginProvider2 !== 'NONE') {
    const buttonConfig = {
      theme: popupConfig.colorScheme || 'match',
      customColor: popupConfig.textColor,
      format: 'contentFlex',
      buttonText: bitloginCache.appearance.buttonList[popupConfig.loginProvider2.toLowerCase()],
      hasShadow: popupConfig.hasShadow !== undefined ? popupConfig.hasShadow : true,
      style: popupConfig.style || 'rounded',
      size: popupConfig.size || 'medium',
      colorScheme: popupConfig.colorScheme || 'match',
      backgroundColor: popupConfig.backgroundColor || '#3B82F6',
      textColor: popupConfig.textColor || '#FFFFFF',
      outlineColor: popupConfig.outlineColor || '#3B82F6',
      host: host
    };
    
    const button2 = createSocialLoginButton(popupConfig.loginProvider2, buttonConfig);
    
    // Handle click event - this overrides the default click handler in createSocialLoginButton
    button2.onclick = () => {
      onClickSocialLogin({ provider: popupConfig.loginProvider2.toLowerCase(), host });
      closePopup();
    };
    
    buttonsContainer.appendChild(button2);
  }

  contentWrapper.appendChild(buttonsContainer);

  // Append content to popup
  popup.appendChild(contentWrapper);
  
  // Append popup to overlay
  overlay.appendChild(popup);
  
  // Append overlay to body
  document.body.appendChild(overlay);
  
  // Trigger animation with slight delay for better perceived performance
  setTimeout(() => {
    overlay.classList.add('visible');
    setTimeout(() => {
      popup.classList.add('visible');
    }, 50);
  }, 10);
}

window.addEventListener("load", () => {
  window.addEventListener("message", (event) => {
    const receivedData = event.data;

    if (receivedData.type === "authorize") {
      post(
        JSON.parse(
          JSON.stringify({
            "customer[email]": receivedData.email,
            "customer[password]": receivedData.password,
            form_type: "customer_login",
            utf8: "✓",
            return_url: redirectUrl,
          })
        )
      );
    } else if (receivedData.type === "rejected") {
      if (receivedData.reason === "customer_account_disabled") {
        showAlert(
          "Your account needs to be activated. We've sent you an activation link - please check your email to complete this step."
        );
      } else if (receivedData.reason === "customer_entry_created_email_not_set") {
        showAlert(
          "A new account was created but requires an email address. Please update your account with a valid email address to continue."
        );
      } else if (receivedData.reason === "customer_exist_email_not_set") {
        showAlert(
          "Your existing account is missing an email address. Please contact support to update your account with a valid email address."
        );
      }
    }

    if (receivedData.type === "customer_authenticated") {
      // Dispatch a custom event that merchants can listen for to implement their custom logic
      const customerAuthEvent = new CustomEvent('bitlogin:customer_authenticated', {
        detail: {
          provider: receivedData.provider,
          customer: receivedData.customer,
          shopifyCustomerCreated: receivedData.shopifyCustomerCreated
        }
      });
      
      // Dispatch the event on the window object so merchants can listen for it
      window.dispatchEvent(customerAuthEvent);
      
    }
  });
});

// Reusable functions for social login buttons
function createSocialLoginButton(provider, config = {}) {
  const {
    theme = 'match',
    customColor = null,
    format = 'contentFlex',
    buttonText = null,
    hasShadow = true,
    style = 'rounded',
    size = 'medium',
    colorScheme = 'match',
    backgroundColor = '#3B82F6',
    textColor = '#FFFFFF',
    outlineColor = '#3B82F6',
    rootRef = null,
    host = null
  } = config;
  
  // Create button element with appropriate ID and attributes
  const button = document.createElement('button');
  button.id = `${provider.toLowerCase()}-login`;
  button.type = 'button';
  
  // Set the inner SVG based on provider
  switch (provider.toUpperCase()) {
    case 'GOOGLE':
      button.innerHTML = googleLoginIcon(theme, customColor);
      break;
    case 'FACEBOOK':
      button.innerHTML = facebookLoginIcon(theme, customColor);
      break;
    case 'APPLE':
      button.innerHTML = appleLoginIcon(theme, customColor);
      break;
    case 'WHATSAPP':
      button.innerHTML = whatsappLoginIcon(theme, customColor);
      break;
    case 'MICROSOFT':
      button.innerHTML = microsoftLoginIcon(theme, customColor);
      break;
    case 'TWITTER':
      button.innerHTML = twitterLoginIcon(theme, customColor);
      break;
    case 'AMAZON':
      button.innerHTML = amazonLoginIcon(theme, customColor);
      break;
    case 'INSTAGRAM':
      button.innerHTML = instagramLoginIcon(theme, customColor);
      break;
    case 'MAGIC_LINK':
      button.innerHTML = magicLinkLoginIcon(theme, customColor);
      break;
    case 'MOBILE_APP':
      button.innerHTML = mobileAppLoginIcon(theme, customColor);
      break;
    case 'LINKEDIN':
      button.innerHTML = linkedinLoginIcon(theme, customColor);
      break;
  }
  
  // Add text if format isn't icon-only and buttonText is provided
  if (format !== "wrapperFlexContainerOnlyLogo" && buttonText) {
    button.innerHTML += `<p>${buttonText}</p>`;
  }
  
  // Apply styling
  // Shadow
  if (hasShadow) {
    const shadowProperties = `0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)`;
    button.style["box-shadow"] = shadowProperties;
  }
  
  // Border radius
  const radiusProperties =
    style === "rounded"
      ? "8px"
      : style === "square"
      ? "0px"
      : style === "fullRounded"
      ? format === "wrapperFlexContainerOnlyLogo"
        ? "50%"
        : "50px"
      : undefined;
  button.style["border-radius"] = radiusProperties;
  
  // Size
  const sizeProperties =
    size === "medium"
      ? "12px"
      : size === "small"
      ? "8px"
      : size === "large"
      ? "16px"
      : "8px";

  button.style["padding-block"] = sizeProperties;

  // Format styling
  if (format) {
    if (
      format === "contentFlexReverse" ||
      format === "contentFlexCenterReverse"
    ) {
      const flexDir = `row-reverse`;
      button.style["flex-direction"] = flexDir;
    }
    
    if (
      format === "contentFlexCenter" ||
      format === "contentFlexCenterReverse"
    ) {
      const justifyContent = `center`;
      button.style["justify-content"] = justifyContent;
    } else if (
      format === "contentFlex" ||
      format === "contentFlexReverse"
    ) {
      const buttonTextElement = button.querySelector("p");
      if (buttonTextElement) {
        buttonTextElement.style["flex-grow"] = 1;
        buttonTextElement.style["text-align"] = "center";
      }
    }

    if (format === "wrapperFlexContainerOnlyLogo" && rootRef) {
      rootRef.style["flex-direction"] = "row";
      rootRef.style["gap"] = "8px";
      rootRef.style["display"] = "flex";
      rootRef.style["flex-wrap"] = "wrap";

      const sizeMapping = {
        small: "52px",
        medium: "62px",
        large: "72px",
      };
      const buttonSize = sizeMapping[size] || "52px";

      button.style["margin"] = 0;
      button.style["width"] = buttonSize;
      button.style["height"] = buttonSize;
      button.style["display"] = "flex";
      button.style["align-items"] = "center";
      button.style["justify-content"] = "center";

      const svgElement = button.querySelector("svg");
      if (svgElement) {
        svgElement.style["flex"] = "none";
      }
    }
  }

  // Color scheme styling
  if (colorScheme === "black") {
    button.classList.add("scheme-black");
  } else if (colorScheme === "white") {
    button.classList.add("scheme-white");
  } else if (colorScheme === "custom") {
    button.style["background-color"] = backgroundColor;
    button.style["color"] = textColor;
    button.style["border-color"] = outlineColor;

    const darkenColor = (color, percentage) => {
      const value = parseInt(color.slice(1), 16);
      const r = Math.max(0, ((value >> 16) & 0xff) - (0xff * percentage));
      const g = Math.max(0, ((value >> 8) & 0xff) - (0xff * percentage));
      const b = Math.max(0, (value & 0xff) - (0xff * percentage));
      return `rgb(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)})`;
    };

    button.addEventListener("mouseover", () => {
      button.style["background-color"] = darkenColor(backgroundColor, 0.2);
    });
    button.addEventListener("mouseout", () => {
      button.style["background-color"] = backgroundColor;
    });
  } else if (colorScheme === "match") {
    button.classList.add("scheme-match");
  } else if (colorScheme === "matchOutline") {
    button.classList.add("scheme-match-outline");
  }
  
  // Add click event listener if host is provided
  if (host) {
    button.addEventListener("click", () => 
      onClickSocialLogin({ provider: provider.toLowerCase(), host })
    );
  }
  
  return button;
}

function setupSocialLoginButtons(config, rootRef, data, host) {
  // Clear any existing content
  rootRef.innerHTML = '';

  const sortedEnabledProviders = config
    .filter(c => c.enabledWeb)
    .sort((a, b) => a.position - b.position);

  sortedEnabledProviders.forEach(provider => {
    const key = provider.provider;
    const lowerKey = key.toLowerCase();

    const buttonText = data.format !== "wrapperFlexContainerOnlyLogo"
      ? (lowerKey === 'twitter'
          ? data.buttonList.twitter.replace('Twitter', 'X')
          : data.buttonList[lowerKey])
      : null;

    const button = createSocialLoginButton(key, {
      theme: data.colorScheme || 'match',
      customColor: data.textColor,
      format: data.format,
      buttonText: buttonText,
      hasShadow: data.hasShadow !== undefined ? data.hasShadow : true,
      style: data.style,
      size: data.size,
      colorScheme: data.colorScheme,
      backgroundColor: data.backgroundColor,
      textColor: data.textColor,
      outlineColor: data.outlineColor,
      rootRef: rootRef,
      host: host
    });

    rootRef.appendChild(button);
  });

  return rootRef;
}

function updateAppearance({ formRef, rootRef, host }) {
  if (!formRef) return;

  const data = bitloginCache.appearance || {
    style: "square",
    hasShadow: false,
    colorScheme: "match",
    backgroundColor: "#FFFFFF",
    outlineColor: "#47af63c4",
    textColor: "#47af63c4",
    position: "bottom",
    hideDivider: "false",
    dividerText: "OR",
    size: "small",
    format: "contentFlex",
    language: "en",
    buttonText: "Continue with",
    redirectLink: "/account",
    googleOneTap: true,
    googleOneTapBanner: true,
    customerTag: "bitLogin",
    redirectOneTapDesktop: null,
    redirectOneTapMobile: null,
    buttonList: {
      google: "Continue with Google",
      facebook: "Continue with Facebook",
      apple: "Continue with Apple",
      whatsapp: "Continue with WhatsApp",
      microsoft: "Continue with Microsoft",
      twitter: "Continue with X",
      amazon: "Continue with Amazon",
      instagram: "Continue with Instagram",
      magic_link: "Continue with Magic Link",
      mobile_app: "Continue with Mobile App",
      linkedin: "Continue with LinkedIn",
    },
  };

  // Use the new setupSocialLoginButtons function to create and configure all buttons
  setupSocialLoginButtons(bitloginCache.config, rootRef, data, host);

  let divider;

  if (!data.hideDivider) {
    divider = document.createElement("div");
    const dividerStyle = "text-align:center;margin-block:16px";
    divider.setAttribute("style", dividerStyle);
    divider.innerHTML = data.dividerText;
  }

  if (data.position === "bottom") {
    if (divider) {
      formRef.appendChild(divider);
    }
    formRef.appendChild(rootRef);
  } else if (data.position === "top") {
    if (divider) {
      formRef.prepend(divider);
    }
    formRef.prepend(rootRef);
  }
}


async function onClickSocialLogin({ provider, host }) {
  const rand = Math.random().toString();

  const locationQueryString = bitloginCache.location
    ? `&${objectToQueryString(bitloginCache.location)}`
    : "";

  const width = 800;
  const height = 600;
  const left = (window.screen.width / 2) - (width / 2);
  const top = (window.screen.height / 2) - (height / 2) - 50;

  if(provider === 'whatsapp') {
    window.open(
      `/apps/bitlogin/whatsapp${locationQueryString ? `?${locationQueryString}` : ''}`,
      "mywindow",
      `menubar=1,resizable=1,width=${width},height=${height},top=${top},left=${left}`
    );
  } else {
    window.open(
      `${apiUrl}/login/${provider}?referrerId=${rand}&shop=${host}${locationQueryString}`,
      "mywindow",
      `menubar=1,resizable=1,width=${width},height=${height},top=${top},left=${left}`
    );
  }
}

function objectToQueryString(obj) {
  return Object.keys(obj)
    .map((key) => {
      return encodeURIComponent(key) + "=" + encodeURIComponent(obj[key]);
    })
    .join("&");
}

async function getLocation() {
  if (locationCacheSet) return;

  try {
    const response = await fetch("https://ipapi.co/json/");

    if (!response.ok) {
      console.error(`error retrieving location...`, response.status);
      errorLocation = true;
    } else {
      const data = await response.json();

      const { city, region, country_name, country_code } = data;

      const formattedLocationData = {
        city,
        region,
        country_name,
        country_code,
      };

      bitloginCache.location = formattedLocationData;
      locationCacheSet = true;
      errorLocation = false;
    }
  } catch (err) {
    console.error(`error fetching location`, err);
    errorLocation = true;
  }
}

function post(params) {
  // The rest of this code assumes you are not using a library.
  // It can be made less verbose if you use one.
  const form = document.createElement("form");
  form.method = "post";
  form.action = `/account/login`;
  form.acceptCharset = "UTF-8";
  form.setAttribute("data-login-with-shop-sign-in", "true");
  form.setAttribute("novalidate", "novalidate");

  for (const key in params) {
    if (params.hasOwnProperty(key)) {
      const hiddenField = document.createElement("input");
      hiddenField.type = "hidden";
      hiddenField.name = key;
      hiddenField.value = params[key];

      form.appendChild(hiddenField);
    }
  }

  document.body.appendChild(form);
  form.submit();
}

async function setupOneTap({ host, checkoutUrl }) {
  if (oneTapSet) return;

  const redirectOneTapDesktop = JSON.parse(JSON.stringify(bitloginCache.appearance.redirectOneTapDesktop || '[]'));
  const redirectOneTapMobile = JSON.parse(JSON.stringify(bitloginCache.appearance.redirectOneTapMobile || '[]'));

  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  const redirectList = JSON.parse(isMobile ? redirectOneTapMobile : redirectOneTapDesktop);

  const currentPath = window.location.pathname.toLowerCase();
  const currentUrl = window.location.href.toLowerCase();

  const shouldHideGoogleOneTap = redirectList.some(({ value }) => {
    switch (value) {
      case 'home':
        return currentPath === '/';
      case 'product':
        return currentPath.startsWith('/products/');
      case 'collections':
        return currentPath.startsWith('/collections');
      case 'cart':
        return currentPath === '/cart';
      case 'checkout':
        return currentPath.startsWith('/checkouts') && !currentPath.includes('thank_you');
      case 'thank_you':
        return currentPath.includes('/thank_you');
      case 'account':
        return currentPath.startsWith('/account');
      case 'pages':
        return currentPath.startsWith('/pages');
      case 'blogs':
        return currentPath === '/blogs' || currentPath === '/blogs/news';
      case 'blog_post':
        return currentPath.startsWith('/blogs/') && currentPath.split('/').length > 3;
      default:
        return false;
    }
  });

  if (shouldHideGoogleOneTap) return;

  const oneTapClientId = bitloginCache.config.find(
    (config) => config.provider === "GOOGLE"
  )?.clientId;

  const isLoggedIn = false;

  if (bitloginCache.appearance.googleOneTap && oneTapClientId && !isLoggedIn) {
    const googleOneTapButton = document.createElement("div");
    googleOneTapButton.setAttribute("id", "g_id_onload");
    googleOneTapButton.setAttribute("data-client_id", oneTapClientId);
    googleOneTapButton.setAttribute("data-context", "signin");
    googleOneTapButton.setAttribute(
      "data-callback",
      "handleGoogleOneTapResponse"
    );
    googleOneTapButton.setAttribute("data-itp_support", "true");

    const googleOneTapScript = document.createElement("script");

    googleOneTapScript.innerHTML += `
          function handleGoogleOneTapResponse(response) {
              if (response.credential) {
                  const idToken = response.credential;
                  fetch('${bitLoginBaseUrl}/bitlogin/api/login/google-one-tap', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ idToken, shop: "${host}", ...bitloginCache.location })
                  }).then(response => {
                      response.json().then((data) => {
                        post(
                          JSON.parse(
                            JSON.stringify({
                              "customer[email]": data.email,
                              "customer[password]": data.password,
                              form_type: "customer_login",
                              utf8: "✓",
                              return_url: redirectUrl,
                            })
                          )
                        );
                      });  
                  }).catch(error => {
                      console.error('Error occurred:', error);
                  });
              } else {
                  console.error('No credential available');
              }
          }
       `;

    document.body.append(googleOneTapButton);
    document.body.append(googleOneTapScript);
  }

  oneTapSet = true;
}

const googleLoginIcon = (
  theme,
  customColor
) => `
${
  theme === "match" || theme === "matchOutline" || theme === "custom"
    ? `<svg
    xmlns='https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif'
    xmlns:v='https://vecta.io/nano'
    width='24'
    height='24'
    viewBox='0 0 186.69 190.5'
  >
    <g transform="translate(1184.583 765.171)"><path clip-path="none" mask="none" d="M-1089.333-687.239v36.888h51.262c-2.251 11.863-9.006 21.908-19.137 28.662l30.913 23.986c18.011-16.625 28.402-41.044 28.402-70.052 0-6.754-.606-13.249-1.732-19.483z" fill="${
      theme === "custom" ? customColor : "#4285f4"
    }"/><path clip-path="none" mask="none" d="M-1142.714-651.791l-6.972 5.337-24.679 19.223h0c15.673 31.086 47.796 52.561 85.03 52.561 25.717 0 47.278-8.486 63.038-23.033l-30.913-23.986c-8.486 5.715-19.31 9.179-32.125 9.179-24.765 0-45.806-16.712-53.34-39.226z" fill="${
        theme === "custom" ? customColor : "#34a853"
      }"/><path clip-path="none" mask="none" d="M-1174.365-712.61c-6.494 12.815-10.217 27.276-10.217 42.689s3.723 29.874 10.217 42.689c0 .086 31.693-24.592 31.693-24.592-1.905-5.715-3.031-11.776-3.031-18.098s1.126-12.383 3.031-18.098z" fill="${
        theme === "custom" ? customColor : "#fbbc05"
      }"/><path d="M-1089.333-727.244c14.028 0 26.497 4.849 36.455 14.201l27.276-27.276c-16.539-15.413-38.013-24.852-63.731-24.852-37.234 0-69.359 21.388-85.032 52.561l31.692 24.592c7.533-22.514 28.575-39.226 53.34-39.226z" fill="${
        theme === "custom" ? customColor : "#ea4335"
      }" clip-path="none" mask="none"/></g>
  </svg>`
    : `<svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="25" height="25" viewBox="0 0 25 25" fill="none">
<path d="M24.1906 12.7758C24.1906 11.96 24.1244 11.1399 23.9833 10.3374H12.6646V14.9584H19.1463C18.8773 16.4488 18.0131 17.7672 16.7476 18.6049V21.6032H20.6146C22.8854 19.5132 24.1906 16.4267 24.1906 12.7758Z" fill="${
        theme !== "black" ? "black" : "white"
      }"/>
<path d="M12.6647 24.5001C15.9011 24.5001 18.6305 23.4374 20.619 21.6031L16.7521 18.6048C15.6762 19.3368 14.2873 19.7513 12.6691 19.7513C9.53845 19.7513 6.88403 17.6391 5.93161 14.7996H1.94116V17.8904C3.97828 21.9428 8.12746 24.5001 12.6647 24.5001Z" fill="${
        theme !== "black" ? "black" : "white"
      }"/>
<path d="M5.92709 14.7995C5.42442 13.3091 5.42442 11.6953 5.92709 10.205V7.11401H1.94105C0.23905 10.5048 0.23905 14.4996 1.94105 17.8903L5.92709 14.7995Z" fill="${
        theme !== "black" ? "black" : "white"
      }"/>
<path d="M12.6647 5.24893C14.3755 5.22248 16.029 5.86623 17.268 7.04794L20.694 3.62188C18.5247 1.58477 15.6454 0.464802 12.6647 0.500076C8.12745 0.500076 3.97828 3.05749 1.94116 7.11408L5.9272 10.205C6.8752 7.36099 9.53403 5.24893 12.6647 5.24893Z" fill="${
        theme !== "black" ? "black" : "white"
      }"/>
</svg>`
}`;

const appleLoginIcon = (
  theme,
  customColor
) => `<svg width="24" height="24" viewBox="0 0 19 24" fill="none" xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
<path d="M15.4146 22.08C14.263 23.2897 12.9925 23.1013 11.7815 22.5307C10.494 21.9489 9.31698 21.9121 7.95724 22.5307C6.26395 23.322 5.36524 23.092 4.34544 22.08C-1.4122 15.663 -0.562362 5.88801 5.98138 5.52001C7.56844 5.61201 8.6796 6.46991 9.61442 6.54121C11.0039 6.23531 12.3339 5.35901 13.8211 5.47401C15.6078 5.63041 16.9443 6.39401 17.8366 7.76711C14.161 10.1591 15.0321 15.4031 18.4082 16.8751C17.7324 18.7956 16.8656 20.6931 15.4125 22.0961L15.4146 22.08ZM9.48695 5.45101C9.31486 2.59901 11.4501 0.25301 13.9061 0.0230103C14.2439 3.31201 11.1441 5.77301 9.48695 5.45101Z" fill="${
  theme === "custom"
    ? customColor
    : theme === "match" || theme === "black"
    ? "white"
    : "black"
}"/>
</svg>`;

const facebookLoginIcon = (
  theme,
  customColor
) => `
${
  theme === "match" || theme === "matchOutline" || theme === "custom"
    ? `<svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="25" viewBox="0 0 24 25" fill="none">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M24 12.5C24 5.8731 18.6268 0.5 12 0.5C5.3731 0.5 0 5.8731 0 12.5C0 18.489 4.38762 23.4537 10.1252 24.355V15.9696H7.07748V12.5H10.1252V9.85562C10.1252 6.84842 11.9173 5.18622 14.6579 5.18622C15.9707 5.18622 17.3443 5.42077 17.3443 5.42077V8.37398H15.8307C14.3406 8.37398 13.8748 9.29875 13.8748 10.2488V12.4999H17.2025L16.671 15.9695H13.8747V24.3548C19.6123 23.4553 23.9998 18.4907 23.9998 12.4999L24 12.5Z" fill="${
      theme === "custom" ? customColor : theme === "match" ? "white" : "#1977F3"
    }"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5934 16.2833L17.1251 12.8137H13.7973V10.5626C13.7973 9.61422 14.2614 8.68778 15.7532 8.68778H17.2669V5.73457C17.2669 5.73457 15.8933 5.5 14.5804 5.5C11.8399 5.5 10.0477 7.16057 10.0477 10.1694V12.8138H7V16.2834H10.0477V24.6688C10.6586 24.7648 11.2846 24.8138 11.9225 24.8138C12.5604 24.8138 13.1865 24.7631 13.7973 24.6688V16.2834H16.5936L16.5934 16.2833Z" fill="${
      theme === "match" ? "#1778f2" : "transparent"
    }"/>
    </svg>`
    : `<svg xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif" width="24" height="25" viewBox="0 0 24 25" fill="none">
<path fill-rule="evenodd" clip-rule="evenodd" d="M24 12.5C24 5.8731 18.6268 0.5 12 0.5C5.3731 0.5 0 5.8731 0 12.5C0 18.489 4.38762 23.4537 10.1252 24.355V15.9696H7.07748V12.5H10.1252V9.85562C10.1252 6.84842 11.9173 5.18622 14.6579 5.18622C15.9707 5.18622 17.3443 5.42077 17.3443 5.42077V8.37398H15.8307C14.3406 8.37398 13.8748 9.29875 13.8748 10.2488V12.4999H17.2025L16.671 15.9695H13.8747V24.3548C19.6123 23.4553 23.9998 18.4907 23.9998 12.4999L24 12.5Z" fill="${
        theme === "black" ? "white" : "black"
      }"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M16.5934 16.2833L17.1251 12.8137H13.7973V10.5626C13.7973 9.61422 14.2614 8.68778 15.7532 8.68778H17.2669V5.73457C17.2669 5.73457 15.8933 5.5 14.5804 5.5C11.8399 5.5 10.0477 7.16057 10.0477 10.1694V12.8138H7V16.2834H10.0477V24.6688C10.6586 24.7648 11.2846 24.8138 11.9225 24.8138C12.5604 24.8138 13.1865 24.7631 13.7973 24.6688V16.2834H16.5936L16.5934 16.2833Z" fill="${
        theme === "black" ? "black" : "white"
      }"/>
</svg>`
}`;

const whatsappLoginIcon = (
  theme,
  customColor
) => `<svg
  viewBox="0 0 24 24"
  fill="none"
  width="24"
  height="25"
  xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
>
  <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
  <g
    id="SVGRepo_tracerCarrier"
    stroke-linecap="round"
    stroke-linejoin="round"
  ></g>
  <g id="SVGRepo_iconCarrier">
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M3.50002 12C3.50002 7.30558 7.3056 3.5 12 3.5C16.6944 3.5 20.5 7.30558 20.5 12C20.5 16.6944 16.6944 20.5 12 20.5C10.3278 20.5 8.77127 20.0182 7.45798 19.1861C7.21357 19.0313 6.91408 18.9899 6.63684 19.0726L3.75769 19.9319L4.84173 17.3953C4.96986 17.0955 4.94379 16.7521 4.77187 16.4751C3.9657 15.176 3.50002 13.6439 3.50002 12ZM12 1.5C6.20103 1.5 1.50002 6.20101 1.50002 12C1.50002 13.8381 1.97316 15.5683 2.80465 17.0727L1.08047 21.107C0.928048 21.4637 0.99561 21.8763 1.25382 22.1657C1.51203 22.4552 1.91432 22.5692 2.28599 22.4582L6.78541 21.1155C8.32245 21.9965 10.1037 22.5 12 22.5C17.799 22.5 22.5 17.799 22.5 12C22.5 6.20101 17.799 1.5 12 1.5ZM14.2925 14.1824L12.9783 15.1081C12.3628 14.7575 11.6823 14.2681 10.9997 13.5855C10.2901 12.8759 9.76402 12.1433 9.37612 11.4713L10.2113 10.7624C10.5697 10.4582 10.6678 9.94533 10.447 9.53028L9.38284 7.53028C9.23954 7.26097 8.98116 7.0718 8.68115 7.01654C8.38113 6.96129 8.07231 7.046 7.84247 7.24659L7.52696 7.52195C6.76823 8.18414 6.3195 9.2723 6.69141 10.3741C7.07698 11.5163 7.89983 13.314 9.58552 14.9997C11.3991 16.8133 13.2413 17.5275 14.3186 17.8049C15.1866 18.0283 16.008 17.7288 16.5868 17.2572L17.1783 16.7752C17.4313 16.5691 17.5678 16.2524 17.544 15.9269C17.5201 15.6014 17.3389 15.308 17.0585 15.1409L15.3802 14.1409C15.0412 13.939 14.6152 13.9552 14.2925 14.1824Z"
      fill="${
        theme === "match" || theme === "black"
          ? "#ffffff"
          : theme === "white"
          ? "#47af63c4"
          : theme === "matchOutline"
          ? "#25d366"
          : customColor
      }"
    ></path>
  </g>
</svg>`;

const microsoftLoginIcon = (
  theme,
  customColor
) => `<svg
xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
width="25"
height="25"
viewBox="0 0 48 48">
<path fill="${
  theme === "match" || theme == "matchOutline"
    ? "#ff5722"
    : theme === "black"
    ? "#ffffff"
    : theme === "white"
    ? "#47af63c4"
    : customColor
}" d="M6 6H22V22H6z" transform="rotate(-180 14 14)"></path>
<path
  fill="${
    theme === "match" || theme == "matchOutline"
      ? "#4caf50"
      : theme === "black"
      ? "#ffffff"
      : theme === "white"
      ? "#47af63c4"
      : customColor
  }"
  d="M26 6H42V22H26z"
  transform="rotate(-180 34 14)"></path>
<path
  fill="${
    theme === "match" || theme == "matchOutline"
      ? "#ffc107"
      : theme === "black"
      ? "#ffffff"
      : theme === "white"
      ? "#47af63c4"
      : customColor
  }"
  d="M26 26H42V42H26z"
  transform="rotate(-180 34 34)"></path>
<path fill="${
  theme === "match" || theme == "matchOutline"
    ? "#03a9f4"
    : theme === "black"
    ? "#ffffff"
    : theme === "white"
    ? "#47af63c4"
    : customColor
}" d="M6 26H22V42H6z" transform="rotate(-180 14 34)"></path>
</svg>`;

const twitterLoginIcon = (
  theme,
  customColor
) => `<svg
xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
width="25"
height="25"
viewBox="0 0 48 48">
<polygon fill="${
  theme === "match" || theme === "black"
    ? "#ffffff"
    : theme === "matchOutline" || theme === "white"
    ? "#47af63c4"
    : customColor
}" points="41,6 9.929,42 6.215,42 37.287,6"></polygon>
<polygon
  fill="${
    theme === "match" || theme === "black"
      ? "#47af63c4"
      : theme === "matchOutline" || theme === "white"
      ? "#ffffff"
      : customColor
  }"
  fill-rule="evenodd"
  points="31.143,41 7.82,7 16.777,7 40.1,41"
  clip-rule="evenodd"></polygon>
<path
  fill="${
    theme === "match" || theme === "black"
      ? "#ffffff"
      : theme === "matchOutline" || theme === "white"
      ? "#47af63c4"
      : customColor
  }"
  d="M15.724,9l20.578,30h-4.106L11.618,9H15.724 M17.304,6H5.922l24.694,36h11.382L17.304,6L17.304,6z"></path>
</svg>`;

const amazonLoginIcon = (theme, customColor) => `
 <svg
      xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
      x="0px"
      y="0px"
      width="25"
      height="25"
      viewBox="0 0 50 50"
    >
      <path
        fill="${
          theme === "black"
            ? "#ffffff"
            : theme === "matchOutline"
            ? "#FF9900"
            : theme === "white" || theme === "match"
            ? "#47af63c4"
            : customColor
        }"
        d="M 25.3125 3 C 19.210938 3 12.492188 5.3125 11.09375 12.8125 C 10.894531 13.613281 11.5 13.992188 12 14.09375 L 18.1875 14.6875 C 18.789063 14.6875 19.207031 14.101563 19.40625 13.5 C 19.90625 10.898438 22.101563 9.59375 24.5 9.59375 C 25.800781 9.59375 27.292969 10.113281 28.09375 11.3125 C 28.992188 12.613281 28.8125 14.40625 28.8125 15.90625 L 28.8125 16.8125 C 25.113281 17.210938 20.3125 17.5 16.8125 19 C 12.8125 20.699219 10 24.207031 10 29.40625 C 10 36.007813 14.199219 39.3125 19.5 39.3125 C 24 39.3125 26.5 38.195313 30 34.59375 C 31.199219 36.292969 31.585938 37.105469 33.6875 38.90625 C 34.1875 39.207031 34.789063 39.085938 35.1875 38.6875 L 35.1875 38.8125 C 36.488281 37.710938 38.792969 35.601563 40.09375 34.5 C 40.59375 34.199219 40.492188 33.5 40.09375 33 C 38.894531 31.398438 37.6875 30.09375 37.6875 27.09375 L 37.6875 17.1875 C 37.6875 12.988281 38.007813 9.085938 34.90625 6.1875 C 32.40625 3.789063 28.414063 3 25.3125 3 Z M 27 22 L 28.6875 22 L 28.6875 23.40625 C 28.6875 25.804688 28.792969 27.894531 27.59375 30.09375 C 26.59375 31.894531 24.988281 33 23.1875 33 C 20.789063 33 19.3125 31.207031 19.3125 28.40625 C 19.3125 23.707031 23 22.300781 27 22 Z M 44.59375 36.59375 C 42.992188 36.59375 41.085938 37 39.6875 38 C 39.289063 38.300781 39.3125 38.6875 39.8125 38.6875 C 41.414063 38.488281 44.988281 38.007813 45.6875 38.90625 C 46.289063 39.707031 45.007813 43.085938 44.40625 44.6875 C 44.207031 45.1875 44.601563 45.300781 45 45 C 47.699219 42.699219 48.40625 38.007813 47.90625 37.40625 C 47.605469 36.90625 46.195313 36.59375 44.59375 36.59375 Z M 2.1875 37.5 C 1.886719 37.5 1.695313 38.011719 2.09375 38.3125 C 8.09375 43.710938 16.007813 47 24.90625 47 C 31.207031 47 38.492188 45.011719 43.59375 41.3125 C 44.394531 40.710938 43.707031 39.695313 42.90625 40.09375 C 37.207031 42.492188 31.101563 43.6875 25.5 43.6875 C 17.199219 43.6875 9.1875 41.386719 2.6875 37.6875 C 2.488281 37.488281 2.289063 37.5 2.1875 37.5 Z"
      ></path>
    </svg>`;

const instagramLoginIcon= (theme, customColor) => `
    <svg
      width="25"
      height="25"
      viewBox="0 0 25 24"
      fill="none"
      xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M10.5 0C7.784 0 7.444 0.0119999 6.377 0.0599999C5.313 0.109 4.586 0.278 3.95 0.525C3.28247 0.775816 2.67773 1.16931 2.178 1.678C1.66931 2.17773 1.27582 2.78247 1.025 3.45C0.778 4.086 0.609 4.813 0.56 5.877C0.511 6.944 0.5 7.284 0.5 10C0.5 12.716 0.511 13.056 0.56 14.123C0.609 15.187 0.778 15.914 1.025 16.55C1.27582 17.2175 1.66931 17.8223 2.178 18.322C2.67773 18.8307 3.28247 19.2242 3.95 19.475C4.586 19.722 5.313 19.891 6.377 19.94C7.444 19.988 7.784 20 10.5 20C13.216 20 13.556 19.988 14.623 19.94C15.687 19.891 16.414 19.722 17.05 19.475C17.7175 19.2242 18.3223 18.8307 18.822 18.322C19.3307 17.8223 19.7242 17.2175 19.975 16.55C20.222 15.914 20.391 15.187 20.44 14.123C20.488 13.056 20.5 12.716 20.5 10C20.5 7.284 20.488 6.944 20.44 5.877C20.391 4.813 20.222 4.086 19.975 3.45C19.7242 2.78247 19.3307 2.17773 18.822 1.678C18.3223 1.16931 17.7175 0.775816 17.05 0.525C16.414 0.278 15.687 0.109 14.623 0.0599999C13.556 0.0119999 13.216 0 10.5 0ZM10.5 1.802C13.17 1.802 13.486 1.812 14.54 1.86C15.516 1.905 16.045 2.067 16.398 2.204C16.864 2.386 17.198 2.603 17.548 2.952C17.898 3.302 18.114 3.636 18.296 4.102C18.432 4.455 18.596 4.984 18.64 5.959C18.688 7.014 18.698 7.329 18.698 10C18.698 12.67 18.688 12.986 18.64 14.04C18.595 15.016 18.432 15.545 18.296 15.898C18.1357 16.3324 17.8801 16.7253 17.548 17.048C17.198 17.398 16.864 17.614 16.398 17.796C16.045 17.932 15.516 18.096 14.541 18.14C13.487 18.188 13.171 18.198 10.5 18.198C7.83 18.198 7.513 18.188 6.46 18.14C5.484 18.095 4.955 17.932 4.602 17.796C4.16762 17.6357 3.77466 17.3801 3.452 17.048C3.11991 16.7253 2.86432 16.3324 2.704 15.898C2.567 15.545 2.404 15.016 2.36 14.041C2.312 12.986 2.302 12.671 2.302 10C2.302 7.33 2.312 7.014 2.36 5.96C2.405 4.984 2.567 4.455 2.704 4.102C2.886 3.636 3.103 3.302 3.452 2.952C3.802 2.602 4.136 2.386 4.602 2.204C4.955 2.067 5.484 1.904 6.459 1.86C7.514 1.812 7.829 1.802 10.5 1.802ZM10.5 13.333C9.61603 13.333 8.76827 12.9818 8.14321 12.3568C7.51815 11.7317 7.167 10.884 7.167 10C7.167 9.11603 7.51815 8.26827 8.14321 7.64321C8.76827 7.01815 9.61603 6.667 10.5 6.667C11.384 6.667 12.2317 7.01815 12.8568 7.64321C13.4818 8.26827 13.833 9.11603 13.833 10C13.833 10.884 13.4818 11.7317 12.8568 12.3568C12.2317 12.9818 11.384 13.333 10.5 13.333ZM10.5 4.865C9.82566 4.865 9.15793 4.99782 8.53492 5.25588C7.91191 5.51394 7.34584 5.89218 6.86901 6.36901C6.39218 6.84584 6.01394 7.41191 5.75588 8.03492C5.49782 8.65793 5.365 9.32566 5.365 10C5.365 10.6743 5.49782 11.3421 5.75588 11.9651C6.01394 12.5881 6.39218 13.1542 6.86901 13.631C7.34584 14.1078 7.91191 14.4861 8.53492 14.7441C9.15793 15.0022 9.82566 15.135 10.5 15.135C11.8619 15.135 13.168 14.594 14.131 13.631C15.094 12.668 15.635 11.3619 15.635 10C15.635 8.63811 15.094 7.33201 14.131 6.36901C13.168 5.40601 11.8619 4.865 10.5 4.865ZM17.038 4.662C17.038 4.81959 17.007 4.97563 16.9467 5.12122C16.8863 5.26681 16.798 5.3991 16.6865 5.51053C16.5751 5.62196 16.4428 5.71035 16.2972 5.77066C16.1516 5.83096 15.9956 5.862 15.838 5.862C15.6804 5.862 15.5244 5.83096 15.3788 5.77066C15.2332 5.71035 15.1009 5.62196 14.9895 5.51053C14.878 5.3991 14.7897 5.26681 14.7293 5.12122C14.669 4.97563 14.638 4.81959 14.638 4.662C14.638 4.34374 14.7644 4.03852 14.9895 3.81347C15.2145 3.58843 15.5197 3.462 15.838 3.462C16.1563 3.462 16.4615 3.58843 16.6865 3.81347C16.9116 4.03852 17.038 4.34374 17.038 4.662Z"
        fill="url(#paint0_radial_378_3535)" />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M10.5 0C7.784 0 7.444 0.0119999 6.377 0.0599999C5.313 0.109 4.586 0.278 3.95 0.525C3.28247 0.775816 2.67773 1.16931 2.178 1.678C1.66931 2.17773 1.27582 2.78247 1.025 3.45C0.778 4.086 0.609 4.813 0.56 5.877C0.511 6.944 0.5 7.284 0.5 10C0.5 12.716 0.511 13.056 0.56 14.123C0.609 15.187 0.778 15.914 1.025 16.55C1.27582 17.2175 1.66931 17.8223 2.178 18.322C2.67773 18.8307 3.28247 19.2242 3.95 19.475C4.586 19.722 5.313 19.891 6.377 19.94C7.444 19.988 7.784 20 10.5 20C13.216 20 13.556 19.988 14.623 19.94C15.687 19.891 16.414 19.722 17.05 19.475C17.7175 19.2242 18.3223 18.8307 18.822 18.322C19.3307 17.8223 19.7242 17.2175 19.975 16.55C20.222 15.914 20.391 15.187 20.44 14.123C20.488 13.056 20.5 12.716 20.5 10C20.5 7.284 20.488 6.944 20.44 5.877C20.391 4.813 20.222 4.086 19.975 3.45C19.7242 2.78247 19.3307 2.17773 18.822 1.678C18.3223 1.16931 17.7175 0.775816 17.05 0.525C16.414 0.278 15.687 0.109 14.623 0.0599999C13.556 0.0119999 13.216 0 10.5 0ZM10.5 1.802C13.17 1.802 13.486 1.812 14.54 1.86C15.516 1.905 16.045 2.067 16.398 2.204C16.864 2.386 17.198 2.603 17.548 2.952C17.898 3.302 18.114 3.636 18.296 4.102C18.432 4.455 18.596 4.984 18.64 5.959C18.688 7.014 18.698 7.329 18.698 10C18.698 12.67 18.688 12.986 18.64 14.04C18.595 15.016 18.432 15.545 18.296 15.898C18.1357 16.3324 17.8801 16.7253 17.548 17.048C17.198 17.398 16.864 17.614 16.398 17.796C16.045 17.932 15.516 18.096 14.541 18.14C13.487 18.188 13.171 18.198 10.5 18.198C7.83 18.198 7.513 18.188 6.46 18.14C5.484 18.095 4.955 17.932 4.602 17.796C4.16762 17.6357 3.77466 17.3801 3.452 17.048C3.11991 16.7253 2.86432 16.3324 2.704 15.898C2.567 15.545 2.404 15.016 2.36 14.041C2.312 12.986 2.302 12.671 2.302 10C2.302 7.33 2.312 7.014 2.36 5.96C2.405 4.984 2.567 4.455 2.704 4.102C2.886 3.636 3.103 3.302 3.452 2.952C3.802 2.602 4.136 2.386 4.602 2.204C4.955 2.067 5.484 1.904 6.459 1.86C7.514 1.812 7.829 1.802 10.5 1.802ZM10.5 13.333C9.61603 13.333 8.76827 12.9818 8.14321 12.3568C7.51815 11.7317 7.167 10.884 7.167 10C7.167 9.11603 7.51815 8.26827 8.14321 7.64321C8.76827 7.01815 9.61603 6.667 10.5 6.667C11.384 6.667 12.2317 7.01815 12.8568 7.64321C13.4818 8.26827 13.833 9.11603 13.833 10C13.833 10.884 13.4818 11.7317 12.8568 12.3568C12.2317 12.9818 11.384 13.333 10.5 13.333ZM10.5 4.865C9.82566 4.865 9.15793 4.99782 8.53492 5.25588C7.91191 5.51394 7.34584 5.89218 6.86901 6.36901C6.39218 6.84584 6.01394 7.41191 5.75588 8.03492C5.49782 8.65793 5.365 9.32566 5.365 10C5.365 10.6743 5.49782 11.3421 5.75588 11.9651C6.01394 12.5881 6.39218 13.1542 6.86901 13.631C7.34584 14.1078 7.91191 14.4861 8.53492 14.7441C9.15793 15.0022 9.82566 15.135 10.5 15.135C11.8619 15.135 13.168 14.594 14.131 13.631C15.094 12.668 15.635 11.3619 15.635 10C15.635 8.63811 15.094 7.33201 14.131 6.36901C13.168 5.40601 11.8619 4.865 10.5 4.865ZM17.038 4.662C17.038 4.81959 17.007 4.97563 16.9467 5.12122C16.8863 5.26681 16.798 5.3991 16.6865 5.51053C16.5751 5.62196 16.4428 5.71035 16.2972 5.77066C16.1516 5.83096 15.9956 5.862 15.838 5.862C15.6804 5.862 15.5244 5.83096 15.3788 5.77066C15.2332 5.71035 15.1009 5.62196 14.9895 5.51053C14.878 5.3991 14.7897 5.26681 14.7293 5.12122C14.669 4.97563 14.638 4.81959 14.638 4.662C14.638 4.34374 14.7644 4.03852 14.9895 3.81347C15.2145 3.58843 15.5197 3.462 15.838 3.462C16.1563 3.462 16.4615 3.58843 16.6865 3.81347C16.9116 4.03852 17.038 4.34374 17.038 4.662Z"
        fill="url(#paint0_radial_378_3535)" />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M10.5 0C7.784 0 7.444 0.0119999 6.377 0.0599999C5.313 0.109 4.586 0.278 3.95 0.525C3.28247 0.775816 2.67773 1.16931 2.178 1.678C1.66931 2.17773 1.27582 2.78247 1.025 3.45C0.778 4.086 0.609 4.813 0.56 5.877C0.511 6.944 0.5 7.284 0.5 10C0.5 12.716 0.511 13.056 0.56 14.123C0.609 15.187 0.778 15.914 1.025 16.55C1.27582 17.2175 1.66931 17.8223 2.178 18.322C2.67773 18.8307 3.28247 19.2242 3.95 19.475C4.586 19.722 5.313 19.891 6.377 19.94C7.444 19.988 7.784 20 10.5 20C13.216 20 13.556 19.988 14.623 19.94C15.687 19.891 16.414 19.722 17.05 19.475C17.7175 19.2242 18.3223 18.8307 18.822 18.322C19.3307 17.8223 19.7242 17.2175 19.975 16.55C20.222 15.914 20.391 15.187 20.44 14.123C20.488 13.056 20.5 12.716 20.5 10C20.5 7.284 20.488 6.944 20.44 5.877C20.391 4.813 20.222 4.086 19.975 3.45C19.7242 2.78247 19.3307 2.17773 18.822 1.678C18.3223 1.16931 17.7175 0.775816 17.05 0.525C16.414 0.278 15.687 0.109 14.623 0.0599999C13.556 0.0119999 13.216 0 10.5 0ZM10.5 1.802C13.17 1.802 13.486 1.812 14.54 1.86C15.516 1.905 16.045 2.067 16.398 2.204C16.864 2.386 17.198 2.603 17.548 2.952C17.898 3.302 18.114 3.636 18.296 4.102C18.432 4.455 18.596 4.984 18.64 5.959C18.688 7.014 18.698 7.329 18.698 10C18.698 12.67 18.688 12.986 18.64 14.04C18.595 15.016 18.432 15.545 18.296 15.898C18.1357 16.3324 17.8801 16.7253 17.548 17.048C17.198 17.398 16.864 17.614 16.398 17.796C16.045 17.932 15.516 18.096 14.541 18.14C13.487 18.188 13.171 18.198 10.5 18.198C7.83 18.198 7.513 18.188 6.46 18.14C5.484 18.095 4.955 17.932 4.602 17.796C4.16762 17.6357 3.77466 17.3801 3.452 17.048C3.11991 16.7253 2.86432 16.3324 2.704 15.898C2.567 15.545 2.404 15.016 2.36 14.041C2.312 12.986 2.302 12.671 2.302 10C2.302 7.33 2.312 7.014 2.36 5.96C2.405 4.984 2.567 4.455 2.704 4.102C2.886 3.636 3.103 3.302 3.452 2.952C3.802 2.602 4.136 2.386 4.602 2.204C4.955 2.067 5.484 1.904 6.459 1.86C7.514 1.812 7.829 1.802 10.5 1.802ZM10.5 13.333C9.61603 13.333 8.76827 12.9818 8.14321 12.3568C7.51815 11.7317 7.167 10.884 7.167 10C7.167 9.11603 7.51815 8.26827 8.14321 7.64321C8.76827 7.01815 9.61603 6.667 10.5 6.667C11.384 6.667 12.2317 7.01815 12.8568 7.64321C13.4818 8.26827 13.833 9.11603 13.833 10C13.833 10.884 13.4818 11.7317 12.8568 12.3568C12.2317 12.9818 11.384 13.333 10.5 13.333ZM10.5 4.865C9.82566 4.865 9.15793 4.99782 8.53492 5.25588C7.91191 5.51394 7.34584 5.89218 6.86901 6.36901C6.39218 6.84584 6.01394 7.41191 5.75588 8.03492C5.49782 8.65793 5.365 9.32566 5.365 10C5.365 10.6743 5.49782 11.3421 5.75588 11.9651C6.01394 12.5881 6.39218 13.1542 6.86901 13.631C7.34584 14.1078 7.91191 14.4861 8.53492 14.7441C9.15793 15.0022 9.82566 15.135 10.5 15.135C11.8619 15.135 13.168 14.594 14.131 13.631C15.094 12.668 15.635 11.3619 15.635 10C15.635 8.63811 15.094 7.33201 14.131 6.36901C13.168 5.40601 11.8619 4.865 10.5 4.865ZM17.038 4.662C17.038 4.81959 17.007 4.97563 16.9467 5.12122C16.8863 5.26681 16.798 5.3991 16.6865 5.51053C16.5751 5.62196 16.4428 5.71035 16.2972 5.77066C16.1516 5.83096 15.9956 5.862 15.838 5.862C15.6804 5.862 15.5244 5.83096 15.3788 5.77066C15.2332 5.71035 15.1009 5.62196 14.9895 5.51053C14.878 5.3991 14.7897 5.26681 14.7293 5.12122C14.669 4.97563 14.638 4.81959 14.638 4.662C14.638 4.34374 14.7644 4.03852 14.9895 3.81347C15.2145 3.58843 15.5197 3.462 15.838 3.462C16.1563 3.462 16.4615 3.58843 16.6865 3.81347C16.9116 4.03852 17.038 4.34374 17.038 4.662Z"
        fill="url(#paint0_radial_378_3535)" />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M10.5 0C7.784 0 7.444 0.0119999 6.377 0.0599999C5.313 0.109 4.586 0.278 3.95 0.525C3.28247 0.775816 2.67773 1.16931 2.178 1.678C1.66931 2.17773 1.27582 2.78247 1.025 3.45C0.778 4.086 0.609 4.813 0.56 5.877C0.511 6.944 0.5 7.284 0.5 10C0.5 12.716 0.511 13.056 0.56 14.123C0.609 15.187 0.778 15.914 1.025 16.55C1.27582 17.2175 1.66931 17.8223 2.178 18.322C2.67773 18.8307 3.28247 19.2242 3.95 19.475C4.586 19.722 5.313 19.891 6.377 19.94C7.444 19.988 7.784 20 10.5 20C13.216 20 13.556 19.988 14.623 19.94C15.687 19.891 16.414 19.722 17.05 19.475C17.7175 19.2242 18.3223 18.8307 18.822 18.322C19.3307 17.8223 19.7242 17.2175 19.975 16.55C20.222 15.914 20.391 15.187 20.44 14.123C20.488 13.056 20.5 12.716 20.5 10C20.5 7.284 20.488 6.944 20.44 5.877C20.391 4.813 20.222 4.086 19.975 3.45C19.7242 2.78247 19.3307 2.17773 18.822 1.678C18.3223 1.16931 17.7175 0.775816 17.05 0.525C16.414 0.278 15.687 0.109 14.623 0.0599999C13.556 0.0119999 13.216 0 10.5 0ZM10.5 1.802C13.17 1.802 13.486 1.812 14.54 1.86C15.516 1.905 16.045 2.067 16.398 2.204C16.864 2.386 17.198 2.603 17.548 2.952C17.898 3.302 18.114 3.636 18.296 4.102C18.432 4.455 18.596 4.984 18.64 5.959C18.688 7.014 18.698 7.329 18.698 10C18.698 12.67 18.688 12.986 18.64 14.04C18.595 15.016 18.432 15.545 18.296 15.898C18.1357 16.3324 17.8801 16.7253 17.548 17.048C17.198 17.398 16.864 17.614 16.398 17.796C16.045 17.932 15.516 18.096 14.541 18.14C13.487 18.188 13.171 18.198 10.5 18.198C7.83 18.198 7.513 18.188 6.46 18.14C5.484 18.095 4.955 17.932 4.602 17.796C4.16762 17.6357 3.77466 17.3801 3.452 17.048C3.11991 16.7253 2.86432 16.3324 2.704 15.898C2.567 15.545 2.404 15.016 2.36 14.041C2.312 12.986 2.302 12.671 2.302 10C2.302 7.33 2.312 7.014 2.36 5.96C2.405 4.984 2.567 4.455 2.704 4.102C2.886 3.636 3.103 3.302 3.452 2.952C3.802 2.602 4.136 2.386 4.602 2.204C4.955 2.067 5.484 1.904 6.459 1.86C7.514 1.812 7.829 1.802 10.5 1.802ZM10.5 13.333C9.61603 13.333 8.76827 12.9818 8.14321 12.3568C7.51815 11.7317 7.167 10.884 7.167 10C7.167 9.11603 7.51815 8.26827 8.14321 7.64321C8.76827 7.01815 9.61603 6.667 10.5 6.667C11.384 6.667 12.2317 7.01815 12.8568 7.64321C13.4818 8.26827 13.833 9.11603 13.833 10C13.833 10.884 13.4818 11.7317 12.8568 12.3568C12.2317 12.9818 11.384 13.333 10.5 13.333ZM10.5 4.865C9.82566 4.865 9.15793 4.99782 8.53492 5.25588C7.91191 5.51394 7.34584 5.89218 6.86901 6.36901C6.39218 6.84584 6.01394 7.41191 5.75588 8.03492C5.49782 8.65793 5.365 9.32566 5.365 10C5.365 10.6743 5.49782 11.3421 5.75588 11.9651C6.01394 12.5881 6.39218 13.1542 6.86901 13.631C7.34584 14.1078 7.91191 14.4861 8.53492 14.7441C9.15793 15.0022 9.82566 15.135 10.5 15.135C11.8619 15.135 13.168 14.594 14.131 13.631C15.094 12.668 15.635 11.3619 15.635 10C15.635 8.63811 15.094 7.33201 14.131 6.36901C13.168 5.40601 11.8619 4.865 10.5 4.865ZM17.038 4.662C17.038 4.81959 17.007 4.97563 16.9467 5.12122C16.8863 5.26681 16.798 5.3991 16.6865 5.51053C16.5751 5.62196 16.4428 5.71035 16.2972 5.77066C16.1516 5.83096 15.9956 5.862 15.838 5.862C15.6804 5.862 15.5244 5.83096 15.3788 5.77066C15.2332 5.71035 15.1009 5.62196 14.9895 5.51053C14.878 5.3991 14.7897 5.26681 14.7293 5.12122C14.669 4.97563 14.638 4.81959 14.638 4.662C14.638 4.34374 14.7644 4.03852 14.9895 3.81347C15.2145 3.58843 15.5197 3.462 15.838 3.462C16.1563 3.462 16.4615 3.58843 16.6865 3.81347C16.9116 4.03852 17.038 4.34374 17.038 4.662Z"
        fill="url(#paint1_radial_378_3535)" />
      <defs>
        <radialGradient
          id="paint0_radial_378_3535"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(17.4 22.7) rotate(-115.776) scale(27.2737 40.5665)">
          <stop offset="0.24392" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#FF1B90' : customColor}" />
          <stop offset="0.436673" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#F80261' : customColor}" />
          <stop offset="0.688476" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#ED00C0' : customColor}" />
          <stop offset="0.776787" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#C500E9' : customColor}" />
          <stop offset="0.893155" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#7017FF' : customColor}" />
        </radialGradient>
        <radialGradient
          id="paint1_radial_378_3535"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(7.75 19.31) rotate(-57.4396) scale(11.8174 12.2918)">
          <stop stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#FFD600' : customColor}" />
          <stop offset="0.484375" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#FF6930' : customColor}" />
          <stop offset="0.734375" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#FE3B36' : customColor}" />
          <stop offset="1" stop-color="${theme === 'black' ? '#ffffff' : theme === 'white' ? '#47af63c4' : theme === 'match' || theme === 'matchOutline' ? '#FE3B36' : customColor}" stop-opacity="0" />
        </radialGradient>
      </defs>
    </svg>`;

const magicLinkLoginIcon = (theme, customColor) => `
  <svg
    xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
    width="25"
    height="25"
    fill="none"
    viewBox="0 0 25 25"
  >
    <path
      fill="${
        theme === 'match' || theme === 'black' ? '#ffffff' : theme === 'matchOutline' || theme === 'white' ? '#47af63c4' : customColor
      }"
      fillRule="evenodd"
      d="M10.975 14.51a1.05 1.05 0 000-1.485 2.95 2.95 0 010-4.172l3.536-3.535a2.95 2.95 0 114.172 4.172l-1.093 1.092a1.05 1.05 0 001.485 1.485l1.093-1.092a5.05 5.05 0 00-7.142-7.142L9.49 7.368a5.05 5.05 0 000 7.142c.41.41 1.075.41 1.485 0zm2.05-5.02a1.05 1.05 0 000 1.485 2.95 2.95 0 010 4.172l-3.5 3.5a2.95 2.95 0 11-4.171-4.172l1.025-1.025a1.05 1.05 0 00-1.485-1.485L3.87 12.99a5.05 5.05 0 007.142 7.142l3.5-3.5a5.05 5.05 0 000-7.142 1.05 1.05 0 00-1.485 0z"
      clipRule="evenodd"
    ></path>
  </svg>`;

const mobileAppLoginIcon = (theme, customColor) => `
  <svg
    width="20"
    height="24"
    viewBox="0 0 12 16"
    fill="none"
    xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
  >
    <path
      d="M9.75 0.5H2.25C1.42275 0.5 0.75 1.17275 0.75 2V14C0.75 14.8273 1.42275 15.5 2.25 15.5H9.75C10.5773 15.5 11.25 14.8273 11.25 14V2C11.25 1.17275 10.5773 0.5 9.75 0.5ZM2.25 11.7493V2.75H9.75L9.7515 11.7493H2.25Z"
      fill=${
        theme === 'match' || theme === 'black' ? '#ffffff' : theme === 'matchOutline' ? '#FD823E' : theme === 'white' ? '#47af63c4' : customColor
      }
    />
  </svg>
`;

const linkedinLoginIcon = (theme, customColor) => `
  <svg
    xmlns="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@ea77910ec6ea5bdaf8fd81c89e25aa59461c176c/uploads/2026-02-14T11-55-55-674Z-hri54syel.gif"
    width="25"
    height="24"
    viewBox="0 0 25 24"
    fill="none"
  >
    <path
      d="M19.0714 0C19.8304 0 20.5 0.669643 20.5 1.47321V18.5714C20.5 19.375 19.8304 20 19.0714 20H1.88393C1.125 20 0.5 19.375 0.5 18.5714V1.47321C0.5 0.669643 1.125 0 1.88393 0H19.0714ZM6.52679 17.1429V7.63393H3.58036V17.1429H6.52679ZM5.05357 6.29464C5.99107 6.29464 6.75 5.53571 6.75 4.59821C6.75 3.66071 5.99107 2.85714 5.05357 2.85714C4.07143 2.85714 3.3125 3.66071 3.3125 4.59821C3.3125 5.53571 4.07143 6.29464 5.05357 6.29464ZM17.6429 17.1429V11.9196C17.6429 9.375 17.0625 7.36607 14.0714 7.36607C12.6429 7.36607 11.6607 8.16964 11.2589 8.92857H11.2143V7.63393H8.40179V17.1429H11.3482V12.4554C11.3482 11.2054 11.5714 10 13.1339 10C14.6518 10 14.6518 11.4286 14.6518 12.5V17.1429H17.6429Z"
      fill=${
        theme === 'match' || theme === 'black' ? '#ffffff' : theme === 'matchOutline' ? '#0A66C2' : theme === 'white' ? '#47af63c4' : customColor
      }
    />
  </svg>
`;

function isElementVisible(element) {
  return (
    document.body.contains(element) &&
    getComputedStyle(element).display !== "none" &&
    getComputedStyle(element).visibility !== "hidden" &&
    getComputedStyle(element).opacity !== "0" &&
    !element.hasAttribute("hidden") &&
    !isAncestorHidden(element)
  );
}

function isAncestorHidden(element) {
  let parent = element.parentElement;
  while (parent) {
    if (
      getComputedStyle(parent).display === "none" ||
      getComputedStyle(parent).visibility === "hidden" ||
      getComputedStyle(parent).opacity === "0" ||
      parent.hasAttribute("hidden")
    ) {
      return true;
    }
    parent = parent.parentElement;
  }
  return false;
}

function showAlert(message) {
  const alertBox = document.createElement("div");
  alertBox.textContent = message;
  alertBox.style.position = "fixed";
  alertBox.style.top = "20px";
  alertBox.style.right = "-300px"; // Start off-screen
  alertBox.style.backgroundColor = "#47af63c4"; // Black background
  alertBox.style.color = "#ffffff"; // White text
  alertBox.style.padding = "15px";
  alertBox.style.borderRadius = "8px";
  alertBox.style.zIndex = "1000";
  alertBox.style.transition =
    "right 0.5s ease-in-out, opacity 0.5s ease-in-out"; // Transition for sliding and fading
  alertBox.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.2)"; // Optional shadow for depth

  document.body.appendChild(alertBox);

  // Slide in
  requestAnimationFrame(() => {
    alertBox.style.right = "20px"; // Move into view
    alertBox.style.opacity = "1"; // Ensure opacity is set to 1
  });

  // Slide out and remove the alert after a few seconds
  setTimeout(() => {
    alertBox.style.opacity = "0"; // Fade out
    alertBox.style.right = "-300px"; // Move out of view

    // Wait for the transition to finish before removing the element
    setTimeout(() => {
      document.body.removeChild(alertBox);
    }, 500); // Match this duration with the exit transition duration
  }, 3000);
}
</script>

<style>
    .v {
            display: flex;
            justify-content: space-around;
            position: fixed;
            background: linear-gradient(to bottom, #47af63c4 0%, #3d3d3d, #47af63c4 100%);
            box-shadow: 0 0 12px #ffd700;
            outline: none;
            padding: 5px 0;
            box-shadow: 0 0 0 0 2px 2px #198f01;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 99;
            border-radius: 40px 40px 0px 0px;
            border-style:dashed;
            
        }

        .v a {
            flex-basis: calc((100% - 15px*6)/ 5);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #fff;
            max-width: 75px;
            font-size: 12px;
            font-family: Ubuntu, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
        }

        .v a:hover {
            font-weight: bold;
        }

        .v .center {
            transform: scale(1.5) translateY(-5px);
            background: center no-repeat;
            background-size: contain;
            background-color: inherit;
            border-radius: 50%;
        }

        .v img {
            max-width: 20px;
            margin-bottom: 0;
            max-height: 20px;
        }
</style>
    
    <div class="v">
    <a href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noopener" target="_blank">
        <img layout="intrinsic" height="20px" width="20px" src="img/promo.png" alt="PROMOSI">
        PROMO
    </a>
    <a href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noopener" target="_blank">
        <img layout="intrinsic" height="20px" width="20px" src="img/login.png" alt="LOGIN">
        LOGIN
    </a>
    <a href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noopener" target="_blank" class="tada">
        <img layout="intrinsic" height="20px" width="20px" src="img/daftar.png" alt="DAFTAR">
        DAFTAR
    </a>
    <a href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noopener" target="_blank">
        <img layout="intrinsic" height="20px" width="20px" src="https://cdn.emailacademy.com/user/81886793bb2d95b12374d87efe201f6574829a0186ffd4a349193ed44322ec2d/wa2026_02_14_12_00_33.gif" alt="WHATSAPP">
        WHATSAPP
    </a>
    <a href="https://stres.b-cdn.net/bandar-togel.html" rel="nofollow noopener" target="_blank"
        class="js_live_chat_link live-chat-link">
        <img class="live-chat-icon" layout="intrinsic" height="20px" width="20px" src="img/lc.png" alt="Live Chat">
        Live Chat
    </a>
</div>
</div>
</body>
</html>