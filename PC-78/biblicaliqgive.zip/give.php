
<!DOCTYPE html>
<html class="html" lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>Give to Invest &#8211; Biblical I.Q.</title>
<meta name='robots' content='max-image-preview:large' />
<meta name="viewport" content="width=device-width, initial-scale=1"><link rel="alternate" type="application/rss+xml" title="Biblical I.Q. &raquo; Feed" href="https://biblicaliq.org/feed/" />
<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://biblicaliq.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fbiblicaliq.org%2Fgive%2F" />
<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://biblicaliq.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fbiblicaliq.org%2Fgive%2F&#038;format=xml" />
<style id='wp-img-auto-sizes-contain-inline-css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
/*# sourceURL=global-styles-inline-css */
</style>
<link rel='stylesheet' id='font-awesome-css' href='https://biblicaliq.org/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='simple-line-icons-css' href='https://biblicaliq.org/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' media='all' />
<link rel='stylesheet' id='oceanwp-style-css' href='https://biblicaliq.org/wp-content/themes/oceanwp/assets/css/style.min.css?ver=4.1.4' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.46.0' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='elementor-post-37-css' href='https://biblicaliq.org/wp-content/uploads/elementor/css/post-37.css?ver=1770310118' media='all' />
<link rel='stylesheet' id='e-animation-fadeIn-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/lib/animations/styles/fadeIn.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='widget-heading-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='widget-image-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='widget-accordion-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/widget-accordion.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='widget-divider-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/widget-divider.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='widget-spacer-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/widget-spacer.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='widget-icon-list-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.34.2' media='all' />
<link rel='stylesheet' id='elementor-post-123-css' href='https://biblicaliq.org/wp-content/uploads/elementor/css/post-123.css?ver=1770316641' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css' href='https://biblicaliq.org/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=6.9' media='all' />
<link rel='stylesheet' id='elementor-gf-local-roboto-css' href='https://biblicaliq.org/wp-content/uploads/elementor/google-fonts/css/roboto.css?ver=1745876759' media='all' />
<link rel='stylesheet' id='elementor-gf-local-robotoslab-css' href='https://biblicaliq.org/wp-content/uploads/elementor/google-fonts/css/robotoslab.css?ver=1745876767' media='all' />
<link rel='stylesheet' id='elementor-gf-local-merriweather-css' href='https://biblicaliq.org/wp-content/uploads/elementor/google-fonts/css/merriweather.css?ver=1745876776' media='all' />
<link rel='stylesheet' id='elementor-gf-local-karla-css' href='https://biblicaliq.org/wp-content/uploads/elementor/google-fonts/css/karla.css?ver=1745876778' media='all' />
<link rel='stylesheet' id='elementor-gf-local-opensans-css' href='https://biblicaliq.org/wp-content/uploads/elementor/google-fonts/css/opensans.css?ver=1745876791' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-regular-css' href='https://biblicaliq.org/wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min.css?ver=5.15.3' media='all' />
<script src="https://biblicaliq.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://biblicaliq.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://biblicaliq.org/wp-json/" /><link rel="alternate" title="JSON" type="application/json" href="https://biblicaliq.org/wp-json/wp/v2/pages/123" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://biblicaliq.org/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9" />
<link rel="canonical" href="https://biblicaliq.org/give/" />
<link rel='shortlink' href='https://biblicaliq.org/?p=123' />
<meta name="generator" content="Elementor 3.34.2; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://biblicaliq.org/wp-content/uploads/2023/10/cropped-flavicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://biblicaliq.org/wp-content/uploads/2023/10/cropped-flavicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://biblicaliq.org/wp-content/uploads/2023/10/cropped-flavicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://biblicaliq.org/wp-content/uploads/2023/10/cropped-flavicon-270x270.png" />
		<style id="wp-custom-css">
			/** Start Template Kit CSS:Wildlife Conservation (css/customizer.css) **//*-------------------------------------------------------------- # Accessibility --------------------------------------------------------------*//* Text meant only for screen readers. */.screen-reader-text{clip:rect(1px,1px,1px,1px);position:absolute !important;height:1px;width:1px;overflow:hidden}.screen-reader-text:focus{background-color:#f1f1f1;border-radius:3px;box-shadow:0 0 2px 2px rgba(0,0,0,0.6);clip:auto !important;color:#21759b;display:block;font-size:14px;font-size:0.875rem;font-weight:bold;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;word-wrap:normal !important;z-index:100000;/* Above WP toolbar. */}:focus{outline:none}input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="search"]:focus,input[type="number"]:focus,input[type="tel"]:focus,input[type="range"]:focus,input[type="date"]:focus,input[type="month"]:focus,input[type="week"]:focus,input[type="time"]:focus,input[type="datetime"]:focus,input[type="datetime-local"]:focus,input[type="color"]:focus,textarea:focus{color:#111;border-color:#1b1f22}button:focus,input[type="button"]:focus,input[type="reset"]:focus,input[type="submit"]:focus{background:#1b1f22;cursor:pointer}a:focus,a:active{color:#1b1f22}a:focus{outline:thin dotted}.entry-content a:focus,.entry-summary a:focus,.edit-link a:focus,.widget a:focus,.entry-meta a:focus,.entry-footer a:focus,.site-footer a:focus,.entry-title a:focus,.post-navigation a:focus,.posts-navigation a:focus,.comment-navigation a:focus,.widget_authors a:focus strong,.project-terms a:focus,.author-bio a:focus,.entry-content a.button:focus,.button:focus,.widget ul li a:focus,#comments a:focus{border-bottom-color:currentColor}.elementor-progress-text,.elementor-progress-percentage{font-size:14px;font-family:Sans-serif}/* Rounded image box */.envato-kit-19-rounded .elementor-image-box-img img{border-radius:100%}/** End Template Kit CSS:Wildlife Conservation (css/customizer.css) **//** Start Block Kit CSS:135-3-c665d4805631b9a8bf464e65129b2f58 **/.envato-block__preview{overflow:visible}/** End Block Kit CSS:135-3-c665d4805631b9a8bf464e65129b2f58 **//** Start Block Kit CSS:144-3-3a7d335f39a8579c20cdf02f8d462582 **/.envato-block__preview{overflow:visible}/* Envato Kit 141 Custom Styles - Applied to the element under Advanced */.elementor-headline-animation-type-drop-in .elementor-headline-dynamic-wrapper{text-align:center}.envato-kit-141-top-0 h1,.envato-kit-141-top-0 h2,.envato-kit-141-top-0 h3,.envato-kit-141-top-0 h4,.envato-kit-141-top-0 h5,.envato-kit-141-top-0 h6,.envato-kit-141-top-0 p{margin-top:0}.envato-kit-141-newsletter-inline .elementor-field-textual.elementor-size-md{padding-left:1.5rem;padding-right:1.5rem}.envato-kit-141-bottom-0 p{margin-bottom:0}.envato-kit-141-bottom-8 .elementor-price-list .elementor-price-list-item .elementor-price-list-header{margin-bottom:.5rem}.envato-kit-141.elementor-widget-testimonial-carousel.elementor-pagination-type-bullets .swiper-container{padding-bottom:52px}.envato-kit-141-display-inline{display:inline-block}.envato-kit-141 .elementor-slick-slider ul.slick-dots{bottom:-40px}/** End Block Kit CSS:144-3-3a7d335f39a8579c20cdf02f8d462582 **/		</style>
		<!-- OceanWP CSS -->
<style type="text/css">
/* Colors */body .theme-button,body input[type="submit"],body button[type="submit"],body button,body .button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button,.woocommerce-cart .wp-element-button,.woocommerce-checkout .wp-element-button,.wp-block-button__link{border-color:#ffffff}body .theme-button:hover,body input[type="submit"]:hover,body button[type="submit"]:hover,body button:hover,body .button:hover,body div.wpforms-container-full .wpforms-form input[type=submit]:hover,body div.wpforms-container-full .wpforms-form input[type=submit]:active,body div.wpforms-container-full .wpforms-form button[type=submit]:hover,body div.wpforms-container-full .wpforms-form button[type=submit]:active,body div.wpforms-container-full .wpforms-form .wpforms-page-button:hover,body div.wpforms-container-full .wpforms-form .wpforms-page-button:active,.woocommerce-cart .wp-element-button:hover,.woocommerce-checkout .wp-element-button:hover,.wp-block-button__link:hover{border-color:#ffffff}/* OceanWP Style Settings CSS */.theme-button,input[type="submit"],button[type="submit"],button,.button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{border-style:solid}.theme-button,input[type="submit"],button[type="submit"],button,.button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{border-width:1px}form input[type="text"],form input[type="password"],form input[type="email"],form input[type="url"],form input[type="date"],form input[type="month"],form input[type="time"],form input[type="datetime"],form input[type="datetime-local"],form input[type="week"],form input[type="number"],form input[type="search"],form input[type="tel"],form input[type="color"],form select,form textarea,.woocommerce .woocommerce-checkout .select2-container--default .select2-selection--single{border-style:solid}body div.wpforms-container-full .wpforms-form input[type=date],body div.wpforms-container-full .wpforms-form input[type=datetime],body div.wpforms-container-full .wpforms-form input[type=datetime-local],body div.wpforms-container-full .wpforms-form input[type=email],body div.wpforms-container-full .wpforms-form input[type=month],body div.wpforms-container-full .wpforms-form input[type=number],body div.wpforms-container-full .wpforms-form input[type=password],body div.wpforms-container-full .wpforms-form input[type=range],body div.wpforms-container-full .wpforms-form input[type=search],body div.wpforms-container-full .wpforms-form input[type=tel],body div.wpforms-container-full .wpforms-form input[type=text],body div.wpforms-container-full .wpforms-form input[type=time],body div.wpforms-container-full .wpforms-form input[type=url],body div.wpforms-container-full .wpforms-form input[type=week],body div.wpforms-container-full .wpforms-form select,body div.wpforms-container-full .wpforms-form textarea{border-style:solid}form input[type="text"],form input[type="password"],form input[type="email"],form input[type="url"],form input[type="date"],form input[type="month"],form input[type="time"],form input[type="datetime"],form input[type="datetime-local"],form input[type="week"],form input[type="number"],form input[type="search"],form input[type="tel"],form input[type="color"],form select,form textarea{border-radius:3px}body div.wpforms-container-full .wpforms-form input[type=date],body div.wpforms-container-full .wpforms-form input[type=datetime],body div.wpforms-container-full .wpforms-form input[type=datetime-local],body div.wpforms-container-full .wpforms-form input[type=email],body div.wpforms-container-full .wpforms-form input[type=month],body div.wpforms-container-full .wpforms-form input[type=number],body div.wpforms-container-full .wpforms-form input[type=password],body div.wpforms-container-full .wpforms-form input[type=range],body div.wpforms-container-full .wpforms-form input[type=search],body div.wpforms-container-full .wpforms-form input[type=tel],body div.wpforms-container-full .wpforms-form input[type=text],body div.wpforms-container-full .wpforms-form input[type=time],body div.wpforms-container-full .wpforms-form input[type=url],body div.wpforms-container-full .wpforms-form input[type=week],body div.wpforms-container-full .wpforms-form select,body div.wpforms-container-full .wpforms-form textarea{border-radius:3px}/* Header */#site-logo #site-logo-inner,.oceanwp-social-menu .social-menu-inner,#site-header.full_screen-header .menu-bar-inner,.after-header-content .after-header-content-inner{height:80px}#site-navigation-wrap .dropdown-menu >li >a,#site-navigation-wrap .dropdown-menu >li >span.opl-logout-link,.oceanwp-mobile-menu-icon a,.mobile-menu-close,.after-header-content-inner >a{line-height:80px}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-logo #site-logo-inner a img,#site-header.center-header #site-navigation-wrap .middle-site-logo a img{max-width:180px}#site-header #site-logo #site-logo-inner a img,#site-header.center-header #site-navigation-wrap .middle-site-logo a img{max-height:150px}.effect-one #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:after,.effect-three #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:after,.effect-five #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:before,.effect-five #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:after,.effect-nine #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:before,.effect-nine #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:after{background-color:#f2a150}.effect-four #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:before,.effect-four #site-navigation-wrap .dropdown-menu >li >a.menu-link >span:after,.effect-seven #site-navigation-wrap .dropdown-menu >li >a.menu-link:hover >span:after,.effect-seven #site-navigation-wrap .dropdown-menu >li.sfHover >a.menu-link >span:after{color:#f2a150}.effect-seven #site-navigation-wrap .dropdown-menu >li >a.menu-link:hover >span:after,.effect-seven #site-navigation-wrap .dropdown-menu >li.sfHover >a.menu-link >span:after{text-shadow:10px 0 #f2a150,-10px 0 #f2a150}#site-navigation-wrap .dropdown-menu >li >a:hover,.oceanwp-mobile-menu-icon a:hover,#searchform-header-replace-close:hover{color:#f2a150}#site-navigation-wrap .dropdown-menu >li >a:hover .owp-icon use,.oceanwp-mobile-menu-icon a:hover .owp-icon use,#searchform-header-replace-close:hover .owp-icon use{stroke:#f2a150}.dropdown-menu .sub-menu,#searchform-dropdown,.current-shop-items-dropdown{border-color:#f2a150}/* Blog CSS */.ocean-single-post-header ul.meta-item li a:hover{color:#333333}/* Typography */body{font-size:14px;line-height:1.8}h1,h2,h3,h4,h5,h6,.theme-heading,.widget-title,.oceanwp-widget-recent-posts-title,.comment-reply-title,.entry-title,.sidebar-box .widget-title{line-height:1.4}h1{font-size:23px;line-height:1.4}h2{font-size:20px;line-height:1.4}h3{font-size:18px;line-height:1.4}h4{font-size:17px;line-height:1.4}h5{font-size:14px;line-height:1.4}h6{font-size:15px;line-height:1.4}.page-header .page-header-title,.page-header.background-image-page-header .page-header-title{font-size:32px;line-height:1.4}.page-header .page-subheading{font-size:15px;line-height:1.8}.site-breadcrumbs,.site-breadcrumbs a{font-size:13px;line-height:1.4}#top-bar-content,#top-bar-social-alt{font-size:12px;line-height:1.8}#site-logo a.site-logo-text{font-size:24px;line-height:1.8}#site-navigation-wrap .dropdown-menu >li >a,#site-header.full_screen-header .fs-dropdown-menu >li >a,#site-header.top-header #site-navigation-wrap .dropdown-menu >li >a,#site-header.center-header #site-navigation-wrap .dropdown-menu >li >a,#site-header.medium-header #site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a{font-size:17px}.dropdown-menu ul li a.menu-link,#site-header.full_screen-header .fs-dropdown-menu ul.sub-menu li a{font-size:16px;line-height:1.2;letter-spacing:.6px}.sidr-class-dropdown-menu li a,a.sidr-class-toggle-sidr-close,#mobile-dropdown ul li a,body #mobile-fullscreen ul li a{font-size:15px;line-height:1.8}.blog-entry.post .blog-entry-header .entry-title a{font-size:24px;line-height:1.4}.ocean-single-post-header .single-post-title{font-size:34px;line-height:1.4;letter-spacing:.6px}.ocean-single-post-header ul.meta-item li,.ocean-single-post-header ul.meta-item li a{font-size:13px;line-height:1.4;letter-spacing:.6px}.ocean-single-post-header .post-author-name,.ocean-single-post-header .post-author-name a{font-size:14px;line-height:1.4;letter-spacing:.6px}.ocean-single-post-header .post-author-description{font-size:12px;line-height:1.4;letter-spacing:.6px}.single-post .entry-title{line-height:1.4;letter-spacing:.6px}.single-post ul.meta li,.single-post ul.meta li a{font-size:14px;line-height:1.4;letter-spacing:.6px}.sidebar-box .widget-title,.sidebar-box.widget_block .wp-block-heading{font-size:13px;line-height:1;letter-spacing:1px}#footer-widgets .footer-box .widget-title{font-size:13px;line-height:1;letter-spacing:1px}#footer-bottom #copyright{font-size:12px;line-height:1}#footer-bottom #footer-bottom-menu{font-size:12px;line-height:1}.woocommerce-store-notice.demo_store{line-height:2;letter-spacing:1.5px}.demo_store .woocommerce-store-notice__dismiss-link{line-height:2;letter-spacing:1.5px}.woocommerce ul.products li.product li.title h2,.woocommerce ul.products li.product li.title a{font-size:14px;line-height:1.5}.woocommerce ul.products li.product li.category,.woocommerce ul.products li.product li.category a{font-size:12px;line-height:1}.woocommerce ul.products li.product .price{font-size:18px;line-height:1}.woocommerce ul.products li.product .button,.woocommerce ul.products li.product .product-inner .added_to_cart{font-size:12px;line-height:1.5;letter-spacing:1px}.woocommerce ul.products li.owp-woo-cond-notice span,.woocommerce ul.products li.owp-woo-cond-notice a{font-size:16px;line-height:1;letter-spacing:1px;font-weight:600;text-transform:capitalize}.woocommerce div.product .product_title{font-size:24px;line-height:1.4;letter-spacing:.6px}.woocommerce div.product p.price{font-size:36px;line-height:1}.woocommerce .owp-btn-normal .summary form button.button,.woocommerce .owp-btn-big .summary form button.button,.woocommerce .owp-btn-very-big .summary form button.button{font-size:12px;line-height:1.5;letter-spacing:1px;text-transform:uppercase}.woocommerce div.owp-woo-single-cond-notice span,.woocommerce div.owp-woo-single-cond-notice a{font-size:18px;line-height:2;letter-spacing:1.5px;font-weight:600;text-transform:capitalize}.ocean-preloader--active .preloader-after-content{font-size:20px;line-height:1.8;letter-spacing:.6px}
</style></head>

<body class="wp-singular page-template-default page page-id-123 wp-custom-logo wp-embed-responsive wp-theme-oceanwp oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled has-breadcrumbs elementor-default elementor-kit-37 elementor-page elementor-page-123" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
<header id="site-header" class="minimal-header effect-three clr" data-height="80" itemscope="itemscope" itemtype="https://schema.org/WPHeader" role="banner">

	
					
			<div id="site-header-inner" class="clr container">

				
				

<div id="site-logo" class="clr" itemscope itemtype="https://schema.org/Brand" >

	
	<div id="site-logo-inner" class="clr">

		<a href="https://biblicaliq.org/" class="custom-logo-link" rel="home"><img fetchpriority="high" width="1616" height="411" src="https://biblicaliq.org/wp-content/uploads/2021/11/cropped-Biblicaliq_logo2.png" class="custom-logo" alt="Biblical I.Q." decoding="async" srcset="https://biblicaliq.org/wp-content/uploads/2021/11/cropped-Biblicaliq_logo2.png 1616w, https://biblicaliq.org/wp-content/uploads/2021/11/cropped-Biblicaliq_logo2-300x76.png 300w, https://biblicaliq.org/wp-content/uploads/2021/11/cropped-Biblicaliq_logo2-1024x260.png 1024w, https://biblicaliq.org/wp-content/uploads/2021/11/cropped-Biblicaliq_logo2-768x195.png 768w, https://biblicaliq.org/wp-content/uploads/2021/11/cropped-Biblicaliq_logo2-1536x391.png 1536w" sizes="(max-width: 1616px) 100vw, 1616px" /></a>
	</div><!-- #site-logo-inner -->

	
	
</div><!-- #site-logo -->

			<div id="site-navigation-wrap" class="clr">
			
			
			
			<nav id="site-navigation" class="navigation main-navigation clr" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement" role="navigation" >

				<ul id="menu-main" class="main-menu dropdown-menu sf-menu"><li id="menu-item-104" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children dropdown menu-item-104"><a href="https://biblicaliq.org/" class="menu-link"><span class="text-wrap">Home<i class="nav-arrow fa fa-angle-down" aria-hidden="true" role="img"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-112" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-112"><a href="https://biblicaliq.org/contact-us/" class="menu-link"><span class="text-wrap">Contact Us</span></a></li>	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113"><a href="https://biblicaliq.org/getting-started/" class="menu-link"><span class="text-wrap">Getting Started</span></a></li></ul>
</li><li id="menu-item-1349" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown menu-item-1349"><a href="https://biblicaliq.org/our-goal/" class="menu-link"><span class="text-wrap">What We Believe<i class="nav-arrow fa fa-angle-down" aria-hidden="true" role="img"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-129" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-129"><a href="https://biblicaliq.org/our-goal/" class="menu-link"><span class="text-wrap">Our Goal</span></a></li>	<li id="menu-item-131" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-131"><a href="https://biblicaliq.org/doctrine-and-philosophy/" class="menu-link"><span class="text-wrap">Doctrine and Philosophy</span></a></li>	<li id="menu-item-130" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a href="https://biblicaliq.org/statement-of-faith/" class="menu-link"><span class="text-wrap">Statement of Faith</span></a></li></ul>
</li><li id="menu-item-128" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-123 current_page_item menu-item-128"><a href="https://biblicaliq.org/give/" class="menu-link"><span class="text-wrap">Give to Invest</span></a></li><li id="menu-item-127" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-127"><a href="https://biblicaliq.org/our-partners/" class="menu-link"><span class="text-wrap">Our Partners</span></a></li><li class="search-toggle-li" ><a href="https://biblicaliq.org/#" class="site-search-toggle search-dropdown-toggle"><span class="screen-reader-text">Toggle website search</span><i class=" icon-magnifier" aria-hidden="true" role="img"></i></a></li></ul>
<div id="searchform-dropdown" class="header-searchform-wrap clr" >
	
<form aria-label="Search this website" role="search" method="get" class="searchform" action="https://biblicaliq.org/">	
	<input aria-label="Insert search query" type="search" id="ocean-search-form-1" class="field" autocomplete="off" placeholder="Search" name="s">
		</form>
</div><!-- #searchform-dropdown -->

			</nav><!-- #site-navigation -->

			
			
					</div><!-- #site-navigation-wrap -->
			
		
	
				
	
	<div class="oceanwp-mobile-menu-icon clr mobile-right">

		
		
		
		<a href="https://biblicaliq.org/#mobile-menu-toggle" class="mobile-menu"  aria-label="Mobile Menu">
							<i class="fa fa-bars" aria-hidden="true"></i>
								<span class="oceanwp-text">Menu</span>
				<span class="oceanwp-close-text">Close</span>
						</a>

		
		
		
	</div><!-- #oceanwp-mobile-menu-navbar -->

	

			</div><!-- #site-header-inner -->

			
<div id="mobile-dropdown" class="clr" >

	<nav class="clr" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">

		<ul id="menu-main-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children menu-item-104"><a href="https://biblicaliq.org/">Home</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-112"><a href="https://biblicaliq.org/contact-us/">Contact Us</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113"><a href="https://biblicaliq.org/getting-started/">Getting Started</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1349"><a href="https://biblicaliq.org/our-goal/">What We Believe</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-129"><a href="https://biblicaliq.org/our-goal/">Our Goal</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-131"><a href="https://biblicaliq.org/doctrine-and-philosophy/">Doctrine and Philosophy</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a href="https://biblicaliq.org/statement-of-faith/">Statement of Faith</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-123 current_page_item menu-item-128"><a href="https://biblicaliq.org/give/" aria-current="page">Give to Invest</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-127"><a href="https://biblicaliq.org/our-partners/">Our Partners</a></li>
<li class="search-toggle-li" ><a href="https://biblicaliq.org/#" class="site-search-toggle search-dropdown-toggle"><span class="screen-reader-text">Toggle website search</span><i class=" icon-magnifier" aria-hidden="true" role="img"></i></a></li></ul>
<div id="mobile-menu-search" class="clr">
	<form aria-label="Search this website" method="get" action="https://biblicaliq.org/" class="mobile-searchform">
		<input aria-label="Insert search query" value="" class="field" id="ocean-mobile-search-2" type="search" name="s" autocomplete="off" placeholder="Search" />
		<button aria-label="Submit search" type="submit" class="searchform-submit">
			<i class=" icon-magnifier" aria-hidden="true" role="img"></i>		</button>
					</form>
</div><!-- .mobile-menu-search -->

	</nav>

</div>

			
			
		
		
</header><!-- #site-header -->


			
			<main id="main" class="site-main clr"  role="main">

				
	
	<div id="content-wrap" class="container clr">

		
		<div id="primary" class="content-area clr">

			
			<div id="content" class="site-content clr">

				
				
<article class="single-page-article clr">

	
<div class="entry clr" itemprop="text">

	
			<div data-elementor-type="wp-page" data-elementor-id="123" class="elementor elementor-123">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-5fd84365 elementor-section-stretched elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="5fd84365" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1e931a9" data-id="1e931a9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-208fb2d elementor-invisible elementor-widget elementor-widget-heading" data-id="208fb2d" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h1 class="elementor-heading-title elementor-size-default">Give to Invest</h1>				</div>
				</div>
				<div class="elementor-element elementor-element-bdacd42 elementor-align-center elementor-widget elementor-widget-button" data-id="bdacd42" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
					<a class="elementor-button elementor-button-link elementor-size-md" href="https://give.egive-usa.com/app/giving/DCMI9999834" target="_blank">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">Give Now to Invest</span>
					</span>
					</a>
				</div>
								</div>
				</div>
				<div class="elementor-element elementor-element-134120a1 elementor-invisible elementor-widget elementor-widget-text-editor" data-id="134120a1" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>Become A Financial Partner</p>								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2d551e8d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2d551e8d" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-56d96f99" data-id="56d96f99" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-234ecb5a elementor-invisible elementor-widget elementor-widget-image" data-id="234ecb5a" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="447" height="383" src="https://biblicaliq.org/wp-content/uploads/2022/01/quote_icon@2x.png" class="attachment-full size-full wp-image-396" alt="" srcset="https://biblicaliq.org/wp-content/uploads/2022/01/quote_icon@2x.png 447w, https://biblicaliq.org/wp-content/uploads/2022/01/quote_icon@2x-300x257.png 300w" sizes="(max-width: 447px) 100vw, 447px" />															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-738c5154 elementor-invisible" data-id="738c5154" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
					<div class="elementor-background-overlay"></div>
						<div class="elementor-element elementor-element-5ae39779 elementor-invisible elementor-widget elementor-widget-heading" data-id="5ae39779" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver.</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-70e47c4c elementor-invisible elementor-widget elementor-widget-text-editor" data-id="70e47c4c" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>2 Corinthians 9:7</p>								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-b2f34df elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b2f34df" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-58afe96f" data-id="58afe96f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-8f8aa20 elementor-invisible elementor-widget elementor-widget-image" data-id="8f8aa20" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="1024" height="683" src="https://biblicaliq.org/wp-content/uploads/2021/12/nicole-honeywill-703542-unsplash-1024x683.jpg" class="attachment-large size-large wp-image-246" alt="" srcset="https://biblicaliq.org/wp-content/uploads/2021/12/nicole-honeywill-703542-unsplash-1024x683.jpg 1024w, https://biblicaliq.org/wp-content/uploads/2021/12/nicole-honeywill-703542-unsplash-300x200.jpg 300w, https://biblicaliq.org/wp-content/uploads/2021/12/nicole-honeywill-703542-unsplash-768x512.jpg 768w, https://biblicaliq.org/wp-content/uploads/2021/12/nicole-honeywill-703542-unsplash-1536x1024.jpg 1536w, https://biblicaliq.org/wp-content/uploads/2021/12/nicole-honeywill-703542-unsplash.jpg 1900w" sizes="(max-width: 1024px) 100vw, 1024px" />															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-1272f6d4" data-id="1272f6d4" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-54c36da8 elementor-invisible elementor-widget elementor-widget-accordion" data-id="54c36da8" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="accordion.default">
				<div class="elementor-widget-container">
							<div class="elementor-accordion">
							<div class="elementor-accordion-item">
					<div id="elementor-tab-title-1421" class="elementor-tab-title" data-tab="1" role="button" aria-controls="elementor-tab-content-1421" aria-expanded="false">
													<span class="elementor-accordion-icon elementor-accordion-icon-right" aria-hidden="true">
															<span class="elementor-accordion-icon-closed"><i class="fas fa-plus"></i></span>
								<span class="elementor-accordion-icon-opened"><i class="fas fa-minus"></i></span>
														</span>
												<a class="elementor-accordion-title" tabindex="0">Why Give?</a>
					</div>
					<div id="elementor-tab-content-1421" class="elementor-tab-content elementor-clearfix" data-tab="1" role="region" aria-labelledby="elementor-tab-title-1421"><p>2.2 million evangelical churches, and <b>85%</b> are led by pastors with no formal theological training.</p></div>
				</div>
							<div class="elementor-accordion-item">
					<div id="elementor-tab-title-1422" class="elementor-tab-title" data-tab="2" role="button" aria-controls="elementor-tab-content-1422" aria-expanded="false">
													<span class="elementor-accordion-icon elementor-accordion-icon-right" aria-hidden="true">
															<span class="elementor-accordion-icon-closed"><i class="fas fa-plus"></i></span>
								<span class="elementor-accordion-icon-opened"><i class="fas fa-minus"></i></span>
														</span>
												<a class="elementor-accordion-title" tabindex="0">How do I send my contribution to Biblical iQ?</a>
					</div>
					<div id="elementor-tab-content-1422" class="elementor-tab-content elementor-clearfix" data-tab="2" role="region" aria-labelledby="elementor-tab-title-1422"><p>mail or Biblical iQ egive (credit card, debit card, or direct deposit), please check the information below.</p></div>
				</div>
							<div class="elementor-accordion-item">
					<div id="elementor-tab-title-1423" class="elementor-tab-title" data-tab="3" role="button" aria-controls="elementor-tab-content-1423" aria-expanded="false">
													<span class="elementor-accordion-icon elementor-accordion-icon-right" aria-hidden="true">
															<span class="elementor-accordion-icon-closed"><i class="fas fa-plus"></i></span>
								<span class="elementor-accordion-icon-opened"><i class="fas fa-minus"></i></span>
														</span>
												<a class="elementor-accordion-title" tabindex="0">How do I know that my giving was received by the Biblical iQ?</a>
					</div>
					<div id="elementor-tab-content-1423" class="elementor-tab-content elementor-clearfix" data-tab="3" role="region" aria-labelledby="elementor-tab-title-1423"><p>We will send you a <b>receipt</b>. If you have not gotten your receipt, please contact us.&nbsp;</p></div>
				</div>
								</div>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-77a92905 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="77a92905" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-47a5948f" data-id="47a5948f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d50d21f elementor-widget elementor-widget-text-editor" data-id="d50d21f" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p><strong>Biblical iQ’s goal</strong> is to give more Bible training to <strong>Pastors and Church Leaders</strong> because <strong>85%</strong> of the Pastors around the world have had very little Bible training. There are many costs associated with the training we provide.</p><p><strong>Our ministry</strong> is dependent on God to provide us with financial partners. <strong>100%</strong> of all funds given are tax-deductible and used within budgetary constraints.</p><p>Consider supporting our ministry by joining our financial support team.</p><p>Together, God will use us to advocate for ministry leaders!</p>								</div>
				</div>
				<div class="elementor-element elementor-element-9103d56 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="9103d56" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
							<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-73303e94 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="73303e94" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-6a5b34a9" data-id="6a5b34a9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-690b6612 elementor-invisible elementor-widget elementor-widget-image" data-id="690b6612" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img loading="lazy" decoding="async" width="768" height="1160" src="https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-768x1160.jpg" class="attachment-medium_large size-medium_large wp-image-563" alt="" srcset="https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-768x1160.jpg 768w, https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-199x300.jpg 199w, https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-678x1024.jpg 678w, https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-1017x1536.jpg 1017w, https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-1356x2048.jpg 1356w, https://biblicaliq.org/wp-content/uploads/2022/02/shane-rounce-DNkoNXQti3c-unsplash-scaled.jpg 1696w" sizes="(max-width: 768px) 100vw, 768px" />															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-41d2863f" data-id="41d2863f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-673a4e6 elementor-invisible elementor-widget elementor-widget-heading" data-id="673a4e6" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Mail</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-6b1efac5 elementor-invisible elementor-widget elementor-widget-text-editor" data-id="6b1efac5" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p><strong>Organization Name :</strong> DCMI/Biblical iQ</p><p><strong>Organization Address :</strong> 5223 80<sup>th</sup> Ave. NW, Gig Harbor, WA 98335</p>								</div>
				</div>
				<div class="elementor-element elementor-element-276f8436 elementor-invisible elementor-widget elementor-widget-heading" data-id="276f8436" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Biblical iQ Egive <h3 style="font-family:merriweather">Credit, Debit, or Direct Deposit</h3></h2>				</div>
				</div>
				<div class="elementor-element elementor-element-7c0eaff9 elementor-invisible elementor-widget elementor-widget-text-editor" data-id="7c0eaff9" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>Become a financial partner with us. Please follow the instruction below.</p><ol><li>Click<strong> &#8220;GIVE NOW&#8221;</strong> button on your device or visit <a href="https://give.egive-usa.com/app/giving/DCMI9999834">https://give.egive-usa.com/app/giving/DCMI9999834</a></li><li> Click your donation options (One-time or Recurring)</li><li>Type amount you want to donate</li><li>Select Give Method (Credit, Debit, Google Pay, or Bank Account)</li><li>Please fill in the information</li><li>Click Submit!</li></ol>								</div>
				</div>
				<div class="elementor-element elementor-element-e7a492a elementor-align-center elementor-button-info elementor-widget elementor-widget-button" data-id="e7a492a" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
					<a class="elementor-button elementor-button-link elementor-size-md" href="https://give.egive-usa.com/app/giving/DCMI9999834" target="_blank">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon">
				<i aria-hidden="true" class="fas fa-hand-holding-heart"></i>			</span>
									<span class="elementor-button-text">Give Now to Invest</span>
					</span>
					</a>
				</div>
								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-5e20568 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5e20568" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ad5830a" data-id="ad5830a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-32ef698 elementor-widget elementor-widget-spacer" data-id="32ef698" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-286fe29 elementor-invisible elementor-widget elementor-widget-image" data-id="286fe29" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img loading="lazy" decoding="async" width="1024" height="981" src="https://biblicaliq.org/wp-content/uploads/2021/11/rawpixel-769319-unsplash-1024x981.jpg" class="attachment-large size-large wp-image-162" alt="" srcset="https://biblicaliq.org/wp-content/uploads/2021/11/rawpixel-769319-unsplash-1024x981.jpg 1024w, https://biblicaliq.org/wp-content/uploads/2021/11/rawpixel-769319-unsplash-300x287.jpg 300w, https://biblicaliq.org/wp-content/uploads/2021/11/rawpixel-769319-unsplash-768x736.jpg 768w, https://biblicaliq.org/wp-content/uploads/2021/11/rawpixel-769319-unsplash-1536x1471.jpg 1536w, https://biblicaliq.org/wp-content/uploads/2021/11/rawpixel-769319-unsplash.jpg 1900w" sizes="(max-width: 1024px) 100vw, 1024px" />															</div>
				</div>
				<div class="elementor-element elementor-element-c9dcf74 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="c9dcf74" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
							<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-4c63f14 elementor-widget elementor-widget-heading" data-id="4c63f14" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h1 class="elementor-heading-title elementor-size-default">Pray</h1>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7622def" data-id="7622def" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-7d0fa99 elementor-widget elementor-widget-spacer" data-id="7d0fa99" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-a432f12 elementor-widget elementor-widget-text-editor" data-id="a432f12" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>Pray is the best resource</p>								</div>
				</div>
				<div class="elementor-element elementor-element-831759f elementor-widget elementor-widget-text-editor" data-id="831759f" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p><span data-preserver-spaces="true">Prayer is one of the most important components of the Christian life. </span></p><p><span data-preserver-spaces="true"> </span><span data-preserver-spaces="true">It is how we communicate with our Heavenly Father and build our relationship with Him. To ignore the act of prayer is to ignore God&#8217;s insight, wisdom, discernment, power, and sovereignty in our lives. </span></p><p><span data-preserver-spaces="true">We invite you to pray for our ministry as we come alongside missionaries, pastors, para-church leaders, and other ministry leaders. </span><span data-preserver-spaces="true">To learn more go to: </span><a class="editor-rtfLink" href="http://www.paraclete.net%20/" target="_blank" rel="noopener"><span data-preserver-spaces="true">www.paraclete.net </span></a></p><p><span data-preserver-spaces="true"> </span><span data-preserver-spaces="true">If you have a prayer request, feel free to let us know and we will add you to our prayer list. </span></p>								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-695781e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="695781e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-74f584e" data-id="74f584e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-b299fd9 elementor-widget elementor-widget-text-editor" data-id="b299fd9" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>Grow in Your Understanding &amp; Wisdom</p>								</div>
				</div>
				<div class="elementor-element elementor-element-580ad6c elementor-widget elementor-widget-text-editor" data-id="580ad6c" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p><span data-preserver-spaces="true">Be a learner of ministry and get involved in caring for the needs of the people who are serving others in response to Matthew 28:18-20.</span></p><p><strong><em><span data-preserver-spaces="true">18 </span></em></strong><em><span data-preserver-spaces="true">Then Jesus came to them and said, “All authority in heaven and on earth has been given to me. </span></em><strong><em><span data-preserver-spaces="true">19 </span></em></strong><em><span data-preserver-spaces="true">Therefore go and make disciples of all nations, baptizing them in the name of the Father and of the Son and of the Holy Spirit, </span></em><strong><em><span data-preserver-spaces="true">20 </span></em></strong><em><span data-preserver-spaces="true">and teaching them to obey everything I have commanded you. And surely I am with you always, to the very end of the age.” &#8211; NIV</span></em></p>								</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-838c1f3" data-id="838c1f3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-833cae7 elementor-invisible elementor-widget elementor-widget-image" data-id="833cae7" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img loading="lazy" decoding="async" width="1024" height="683" src="https://biblicaliq.org/wp-content/uploads/2022/02/priscilla-du-preez-SSh9O_-sTzg-unsplash-1024x683.jpg" class="attachment-large size-large wp-image-564" alt="" srcset="https://biblicaliq.org/wp-content/uploads/2022/02/priscilla-du-preez-SSh9O_-sTzg-unsplash-1024x683.jpg 1024w, https://biblicaliq.org/wp-content/uploads/2022/02/priscilla-du-preez-SSh9O_-sTzg-unsplash-300x200.jpg 300w, https://biblicaliq.org/wp-content/uploads/2022/02/priscilla-du-preez-SSh9O_-sTzg-unsplash-768x512.jpg 768w, https://biblicaliq.org/wp-content/uploads/2022/02/priscilla-du-preez-SSh9O_-sTzg-unsplash-1536x1024.jpg 1536w, https://biblicaliq.org/wp-content/uploads/2022/02/priscilla-du-preez-SSh9O_-sTzg-unsplash-2048x1365.jpg 2048w" sizes="(max-width: 1024px) 100vw, 1024px" />															</div>
				</div>
				<div class="elementor-element elementor-element-ed083aa elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="ed083aa" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
							<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-3411e9b elementor-widget elementor-widget-heading" data-id="3411e9b" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h1 class="elementor-heading-title elementor-size-default">Discern</h1>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c0f132b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c0f132b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-3e1062e" data-id="3e1062e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-293c90c elementor-widget elementor-widget-spacer" data-id="293c90c" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-821fb31 elementor-widget elementor-widget-heading" data-id="821fb31" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Our Monthly Newsletter</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-bb6e5d2 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="bb6e5d2" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
							<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-af03afa elementor-align-center elementor-widget elementor-widget-button" data-id="af03afa" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
					<a class="elementor-button elementor-button-link elementor-size-lg" href="mailto:larrybiblicaliq@gmail.com">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon">
				<i aria-hidden="true" class="far fa-paper-plane"></i>			</span>
									<span class="elementor-button-text">Subscribe </span>
					</span>
					</a>
				</div>
								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-74a72689 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="74a72689" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-3e83bad8" data-id="3e83bad8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-6b00181d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6b00181d" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3f719147" data-id="3f719147" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-c02f651 elementor-widget elementor-widget-heading" data-id="c02f651" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Biblical iQ</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-feec152 elementor-tablet-align-start elementor-align-start elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="feec152" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-map-marker-alt"></i>						</span>
										<span class="elementor-icon-list-text">5223 80th Ave. NW, <br>Gig Harbor, WA 98335</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-phone"></i>						</span>
										<span class="elementor-icon-list-text">+1 360 509 1237</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-envelope-open"></i>						</span>
										<span class="elementor-icon-list-text">larrybiblicaliq@gmail.com</span>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-74f45776" data-id="74f45776" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-7c29ac3e elementor-widget elementor-widget-heading" data-id="7c29ac3e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">I'm New</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-770b0b5f elementor-tablet-align-start elementor-mobile-align-start elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="770b0b5f" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://biblicaliq.org/contact-us/">

												<span class="elementor-icon-list-icon">
													</span>
										<span class="elementor-icon-list-text">Contact Us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://biblicaliq.org/getting-started/">

												<span class="elementor-icon-list-icon">
													</span>
										<span class="elementor-icon-list-text">Getting Started With Us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://biblicaliq.org/doctrine-and-philosophy/">

												<span class="elementor-icon-list-icon">
													</span>
										<span class="elementor-icon-list-text">Doctrine And Philosophy</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://biblicaliq.org/our-goal/">

											<span class="elementor-icon-list-text">Our Goal</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-139409d9" data-id="139409d9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-8c0bc78 elementor-widget elementor-widget-heading" data-id="8c0bc78" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Our Monthly Newsletter</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-15a6fee6 elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="15a6fee6" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
					<a class="elementor-button elementor-button-link elementor-size-md" href="mailto:larrybiblicaliq@gmail.com">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon">
				<i aria-hidden="true" class="far fa-paper-plane"></i>			</span>
									<span class="elementor-button-text">Subscribe </span>
					</span>
					</a>
				</div>
								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		
	
</div>

</article>

				
			</div><!-- #content -->

			
		</div><!-- #primary -->

		
	</div><!-- #content-wrap -->

	

	</main><!-- #main -->

	
	
	
		
	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a aria-label="Scroll to the top of the page" href="#" id="scroll-top" class="scroll-top-right"><i class=" fa fa-angle-up" aria-hidden="true" role="img"></i></a>




<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/oceanwp/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script src="https://biblicaliq.org/wp-includes/js/imagesloaded.min.js?ver=5.0.0" id="imagesloaded-js"></script>
<script id="oceanwp-main-js-extra">
var oceanwpLocalize = {"nonce":"7653157797","isRTL":"","menuSearchStyle":"drop_down","mobileMenuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customScrollOffset":"0","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","loadMoreLoadingText":"Loading...","ajax_url":"https://biblicaliq.org/wp-admin/admin-ajax.php","oe_mc_wpnonce":"44f126d2d6"};
//# sourceURL=oceanwp-main-js-extra
</script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/theme.min.js?ver=4.1.4" id="oceanwp-main-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/drop-down-mobile-menu.min.js?ver=4.1.4" id="oceanwp-drop-down-mobile-menu-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/drop-down-search.min.js?ver=4.1.4" id="oceanwp-drop-down-search-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/vendors/magnific-popup.min.js?ver=4.1.4" id="ow-magnific-popup-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/ow-lightbox.min.js?ver=4.1.4" id="oceanwp-lightbox-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/vendors/flickity.pkgd.min.js?ver=4.1.4" id="ow-flickity-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/ow-slider.min.js?ver=4.1.4" id="oceanwp-slider-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/scroll-effect.min.js?ver=4.1.4" id="oceanwp-scroll-effect-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/scroll-top.min.js?ver=4.1.4" id="oceanwp-scroll-top-js"></script>
<script src="https://biblicaliq.org/wp-content/themes/oceanwp/assets/js/select.min.js?ver=4.1.4" id="oceanwp-select-js"></script>
<script id="flickr-widget-script-js-extra">
var flickrWidgetParams = {"widgets":[]};
//# sourceURL=flickr-widget-script-js-extra
</script>
<script src="https://biblicaliq.org/wp-content/plugins/ocean-extra/includes/widgets/js/flickr.min.js?ver=6.9" id="flickr-widget-script-js"></script>
<script id="wp_slimstat-js-extra">
var SlimStatParams = {"transport":"ajax","ajaxurl_rest":"https://biblicaliq.org/wp-json/slimstat/v1/hit","ajaxurl_ajax":"https://biblicaliq.org/wp-admin/admin-ajax.php","ajaxurl_adblock":"https://biblicaliq.org/request/9f12b4d1b64e6ae71f794417fdc8dd69/","ajaxurl":"https://biblicaliq.org/wp-admin/admin-ajax.php","baseurl":"/","dnt":"noslimstat,ab-item","ci":"YTozOntzOjEyOiJjb250ZW50X3R5cGUiO3M6NDoicGFnZSI7czoxMDoiY29udGVudF9pZCI7aToxMjM7czo2OiJhdXRob3IiO3M6MTg6ImFuaWUwNTIxQGdtYWlsLmNvbSI7fQ--.0ecbd989bc5e6dcfbb2ea0f47bf1d9a4","wp_rest_nonce":"bd5f217ec2"};
//# sourceURL=wp_slimstat-js-extra
</script>
<script defer src="https://biblicaliq.org/wp-content/plugins/wp-slimstat/wp-slimstat.min.js?ver=5.3.5" id="wp_slimstat-js"></script>
<script src="https://biblicaliq.org/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.34.2" id="elementor-webpack-runtime-js"></script>
<script src="https://biblicaliq.org/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.34.2" id="elementor-frontend-modules-js"></script>
<script src="https://biblicaliq.org/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"3.34.2","is_static":false,"experimentalFeatures":{"additional_custom_breakpoints":true,"home_screen":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"cloud-library":true,"e_opt_in_v4_page":true,"e_interactions":true,"e_editor_one":true,"import-export-customization":true},"urls":{"assets":"https:\/\/biblicaliq.org\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/biblicaliq.org\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/biblicaliq.org\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"02218d8f88"},"swiperClass":"swiper","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":123,"title":"Give%20to%20Invest%20%E2%80%93%20Biblical%20I.Q.","excerpt":"","featuredImage":false}};
//# sourceURL=elementor-frontend-js-before
</script>
<script src="https://biblicaliq.org/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.34.2" id="elementor-frontend-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://biblicaliq.org/wp-includes/js/wp-emoji-release.min.js?ver=6.9"}}
</script>
<script type="module">
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://biblicaliq.org/wp-includes/js/wp-emoji-loader.min.js
</script>
</body>
</html>