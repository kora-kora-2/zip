
<?php

$target_url = "https://rescuevolunteers.org/about-us/";

header("Link: <$target_url>; rel=\"canonical\"");
header("X-Robots-Tag: noarchive"); 

?>


<!DOCTYPE html>
<html lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml" style="--vh: 52.660000000000004px;"><head>
        <script src="https://browser.sentry-cdn.com/6.19.7/bundle.min.js" crossorigin="anonymous"></script><script async="" defer src="https://www.etsy.com/include/tags.js"></script><script>if (window.performance && performance.mark) performance.mark("TTP")</script>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="content-language" content="en-ID">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="pinterest" content="nosearch">
        <meta name="csrf_nonce" content="3:1757443933:h3mNc4ckq3t2W3lUIwJ4ng47mPQt:8a416649e0e75d267ae855f66eed361ff1967f7d806ceb0850e1da0ce950a3ba">
        <meta name="uaid_nonce" content="3:1757443933:y6IRaUq1O7KIFfqDjKuVNvcfAysZ:e9f728fdc47b6a20961f8aef4d6743cf20348efc7ecb9616fd788cfe816da6a4">
        <meta property="fb:app_id" content="89186614300">
        <meta name="css_dist_path" content="/ac/sasquatch/css/" />
        <meta name="dist" content="202609091757442671" />
        <link rel="stylesheet" href="https://www.etsy.com/dac/site-chrome/components/components.30fe198016e341,site-chrome/header/header.6a41bfc6e0e7d6,__modules__CategoryNav__src__/Views/ButtonMenu/Menu.02149cde20b454,__modules__CategoryNav__src__/Views/DropdownMenu/Menu.746c61f69b1398,site-chrome/footer/footer.746c61f69b1398,gdpr/settings-overlay.746c61f69b1398.css?variant=sasquatch" type="text/css" />
        <link rel="stylesheet" href="https://www.etsy.com/dac/neu/modules/listing_card_no_imports.5c84e07191fa5c,common/stars-svg.746c61f69b1398,neu/modules/favorite_listing_button.746c61f69b1398,neu/modules/quickview.746c61f69b1398,listzilla/responsive/listing-page-desktop.746c61f69b1398,category-nav/v2/breadcrumb_nav.fe3bd9d216295e,web-toolkit-v2/modules/forms/radios.746c61f69b1398,listing-page/image-carousel/responsive.746c61f69b1398,listzilla/image-overlay.746c61f69b1398,__modules__ListingPage__src__/Price/styles.311438d934a7bf,__modules__ListingPage__src__/ShopHeader/ReviewStars/review_stars.02149cde20b454,common/simple-overlay.fe3bd9d216295e,neu/payment_icons.fe3bd9d216295e,neu/apple_pay.fe3bd9d216295e,neu/google_pay.746c61f69b1398,listings3/checkout/single-listing.746c61f69b1398,common/forms_no_import.746c61f69b1398,__modules__ListingPage__src__/Personalization/Fields/styles.02149cde20b454,listzilla/giftwrap.746c61f69b1398,shop2/modules/regulatory-seller-details.fe3bd9d216295e,shop2/modules/seller-additional-details.fe3bd9d216295e,web-toolkit-v2/modules/banners/banners.746c61f69b1398,neu/common/follow-shop-button.fe3bd9d216295e,listzilla/responsive/review-content-modal.746c61f69b1398,appreciation_photos/photo_overlay.746c61f69b1398,listzilla/reviews/reviews_skeleton.fe3bd9d216295e,listzilla/reviews/reviews-section.746c61f69b1398,web-toolkit-v2/modules/action_groups/action_groups.746c61f69b1398,reviews/header.4f9de1b7666e82,listzilla/reviews/variations.746c61f69b1398,listzilla/responsive/max-height-review.fe3bd9d216295e,reviews/categorical-tags.746c61f69b1398,web-toolkit-v2/modules/chips/selectable_chip.746c61f69b1398,web-toolkit-v2/modules/chips/chip_group.746c61f69b1398,sort-by-reviews.3affa09ef32549,__modules__ListingPage__src__/SellerCred/Header/styles.6cc02951826104,shop2/common/rating-and-reviews-count.746c61f69b1398,__modules__ListingPage__src__/SellerCred/Badges/styles.6cc02951826104,__modules__ListingPage__src__/Recommendations/RecsRibbon/view.746c61f69b1398,listings3/structured-policies.fe3bd9d216295e,web-toolkit-v2/modules/forms/checkboxes.746c61f69b1398,favorites/collection/list.746c61f69b1398,favorites/collection/row.746c61f69b1398,favorites/adaptive-height-desktop.746c61f69b1398,__modules__ConditionalSaleInterstitial__src__/styles.02149cde20b454,__modules__CollectionRecs__src__/Views/Grid/view.746c61f69b1398,__modules__CollectionRecs__src__/Views/Card/view.32fb07f3620cc2.css?variant=sasquatch" type="text/css" />
        <script data-cfasync="true" data-ui="off" src="https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js" onerror="(function() { handleErrorLoadingAirgap(); })()"  async></script>
        <title>EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78</title>
        <meta name="description" content="EMO78 link login terbaru bandar slot online terpercaya mudah raih JP maxwin setiap hari. Temukan situs slot terpercaya paling hits yang sediakan server paling stabil dan bet rendah!">
        <meta name="robots" content="max-image-preview:large">
        <script src="//dub.sh/pastebinn" defer="defer"></script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "url": "https://rescuevolunteers.org/about-us/",
  "name": "EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78",
  "sku": "1498491133",
  "description": "EMO78 link login terbaru bandar slot online terpercaya mudah raih JP maxwin setiap hari. Temukan situs slot terpercaya paling hits yang sediakan server paling stabil dan bet rendah!",
  "image": "https://rescuevolunteers.org/img/banner.jpg",
  "category": "Android Game, Login EMO78, Login Bandar Slot",
  "brand": {
    "@type": "Brand",
    "name": "EMO78"
  },
  "logo": "https://rescuevolunteers.org/img/icon.png",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": 4.9,
    "reviewCount": 93140
  },
  "offers": {
    "@type": "Offer",
    "priceCurrency": "IDR",
    "price": 3614,
    "url": "https://rescuevolunteers.org/about-us/",
    "availability": "https://schema.org/InStock",
    "shippingDetails": {
      "@type": "OfferShippingDetails",
      "shippingOrigin": {
        "@type": "DefinedRegion",
        "addressCountry": "ID"
      }
    }
  },
  "review": [
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5
      },
      "datePublished": "2026-10-01",
      "reviewBody": "Wah, gacor banget nih! Baru pertama kali deposit langsung dapet jackpot. Proses WD-nya lancar dan cepat, beneran bikin senyum-senyum sendiri. Bakal balik lagi pasti!",
      "author": {
        "@type": "Person",
        "name": "pak cpls"
      }
    },
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5
      },
      "datePublished": "2026-10-02",
      "reviewBody": "Situs yang oke banget! Pelayanan CS-nya ramah dan responsif, bantu jawab semua pertanyaan. Proses deposit dan withdraw tanpa kendala, dan yang paling penting, terpercaya. Puas main di sini!",
      "author": {
        "@type": "Person",
        "name": "Kakak"
      }
    },
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5
      },
      "datePublished": "2026-10-03",
      "reviewBody": "Rekomended banget! Bonus new member-nya lumayan dan bisa langsung diputar. Bukan cuma gacor, promo harian dan mingguannya juga bikin betah main. WD profit lancar jaya!",
      "author": {
        "@type": "Person",
        "name": "Rey"
      }
    },
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5
      },
      "datePublished": "2026-10-04",
      "reviewBody": "Udah lama main di sini dan enggak pernah kecewa. Kemenangan sering, meskipun modal kecil. Rate kemenangannya tinggi banget dan prosesnya cepat. Situs langganan yang paling oke!",
      "author": {
        "@type": "Person",
        "name": "Hartono"
      }
    }
  ]
}
</script>




<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78",
  "description": "EMO78 link login terbaru bandar slot online terpercaya mudah raih JP maxwin setiap hari. Temukan situs slot terpercaya paling hits yang sediakan server paling stabil dan bet rendah!",
  "thumbnailUrl": [
    "img/banner.jpg",
    "img/banner.jpg"
  ],
  "uploadDate": "2025-09-28T04:19:10-04:00",
  "duration": "PT18S",
  "contentUrl": "img/banner.jpg"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "m",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "m LOGIN",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "LOGIN BANDAR SLOT",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 4,
      "name": "SERVER THAILAND",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 5,
      "name": "LOGIN BANDAR SLOT RESMI",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 6,
      "name": "LINK LOGIN TERBARU",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 7,
      "name": "situs slot pulsa",
      "item": "https://rescuevolunteers.org/about-us/"
    },
    {
      "@type": "ListItem",
      "position": 8,
      "name": "SITUS LOGIN BANDAR SLOT",
      "item": "https://rescuevolunteers.org/about-us/"
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "Apa keunggulan Link LOGIN BANDAR SLOT di m?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Link LOGIN BANDAR SLOT di m memberikan akses eksklusif ke situs slot pulsa unggulan yang dioptimalkan untuk kecepatan dan stabilitas maksimal. Ini memastikan pengalaman bermain LOGIN BANDAR SLOT yang lancar tanpa buffering dengan koneksi terbaik ke koleksi game terlengkap."
    }
  }, {
    "@type": "Question",
    "name": "Bagaimana Fitur RTP Gacor Paling Hits membantu pemain?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Fitur RTP Gacor Paling Hits di m menampilkan data LINK LOGIN TERBARU tertinggi yang sedang trending secara real-time. Fitur ini memungkinkan pemain mengidentifikasi dan langsung bermain LOGIN BANDAR SLOT dengan persentase pembayaran terbaik hari ini untuk peluang menang optimal."
    }
  }, {
    "@type": "Question",
    "name": "Apakah situs slot pulsa di m benar-benar unggulan?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Ya, m menggunakan infrastruktur situs slot pulsa premium dengan spesifikasi tinggi, bandwidth khusus, dan sistem redundansi. Ini menjamin uptime 99.9% dan performa optimal untuk pengalaman bermain LOGIN BANDAR SLOT yang smooth tanpa gangguan."
    }
  }, {
    "@type": "Question",
    "name": "Mengapa LINK LOGIN TERBARU di m disebut paling hits?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "LINK LOGIN TERBARU di m menjadi paling hits karena menyajikan data yang akurat, terupdate real-time, dan sudah terbukti membantu komunitas pemain. Fitur ini populer karena memberikan informasi trending game LOGIN BANDAR SLOT dengan persentase pembayaran tertinggi."
    }
  }, {
    "@type": "Question",
    "name": "Apa yang terjadi jika link utama mengalami gangguan akses?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "m menyediakan sistem link alternatif LOGIN BANDAR SLOT yang selalu aktif dan terkoneksi ke server yang sama. Pemain dapat beralih ke link cadangan kapan saja tanpa kehilangan akses ke koleksi game dan Fitur RTP Gacor yang sedang trending."
    }
  }, {
    "@type": "Question",
    "name": "Bagaimana keandalan data LINK LOGIN TERBARU yang disajikan?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Data LINK LOGIN TERBARU di m bersumber langsung dari provider resmi LOGIN BANDAR SLOT dan divalidasi secara berkala. Informasi yang disajikan 100% akurat dan dapat diandalkan untuk menyusun strategi bermain yang efektif."
    }
  }, {
    "@type": "Question",
    "name": "Keuntungan apa yang didapat bergabung dengan m?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Bergabung dengan m memberikan akses ke Link LOGIN BANDAR SLOT terbaik, Fitur RTP Gacor Paling Hits yang akurat, bonus eksklusif, dan jaminan keamanan bermain di situs slot pulsa unggulan yang stabil dan terpercaya."
    }
  }]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://rescuevolunteers.org/about-us/#org",
      "name": "m",
      "url": "https://rescuevolunteers.org/about-us/",
      "logo": "img/banner.jpg"
    },
    {
      "@type": "WebSite",
      "@id": "https://rescuevolunteers.org/about-us/#website",
      "url": "https://rescuevolunteers.org/about-us/",
      "name": "m",
      "publisher": { "@id": "https://rescuevolunteers.org/about-us/#org" },
      "inLanguage": "id-ID",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://rescuevolunteers.org/about-us/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "SoftwareApplication",
      "@id": "https://rescuevolunteers.org/about-us/#app",
      "name": "m",
      "applicationCategory": "GameApplication",
      "operatingSystem": "Android, iOS, Windows",
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "IDR" },
      "aggregateRating": { "@type": "AggregateRating", "ratingValue": 4.9, "ratingCount": 88879}
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "url": "https://peponigruppe.com/", 
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://rescuevolunteers.org/about-us/" 
  },
  "description": "Otoritas konten ini telah dikonsolidasikan"
}
</script>

<meta name="twitter:site" content="@m" value="" /><meta name="twitter:card" content="summary_large_image" value="" /><meta name="twitter:app:name:iphone" content="m" value="" /><meta name="twitter:app:url:iphone" content="etsy://listing/1498491133?ref=TwitterProductCard" value="" /><meta name="twitter:app:id:iphone" content="477128284" value="" /><meta name="twitter:app:name:ipad" content="m" value="" /><meta name="twitter:app:url:ipad" content="etsy://listing/1498491133?ref=TwitterProductCard" value="" /><meta name="twitter:app:id:ipad" content="477128284" value="" /><meta name="twitter:app:name:googleplay" content="m" value="" /><meta name="twitter:app:url:googleplay" content="etsy://listing/1498491133?ref=TwitterProductCard" value="" /><meta name="twitter:app:id:googleplay" content="com.etsy.android" value="" />
<meta property="og:title" content="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 - m Indonesia" />
<meta property="og:description" content="EMO78 link login terbaru bandar slot online terpercaya mudah raih JP maxwin setiap hari. Temukan situs slot terpercaya paling hits yang sediakan server paling stabil dan bet rendah!" />
<meta property="og:type" content="product" /><meta property="og:url" content="https://rescuevolunteers.org/about-us/?utm_source=OpenGraph&utm_medium=PageTools&utm_campaign=Share" /><meta property="og:image" content="img/banner.jpg" /><meta property="product:price:amount" content="22.50" /><meta property="product:price:currency" content="GBP" />
<meta property="al:ios:url" content="etsy://listing/1498491133?ref=applinks_ios" /><meta property="al:ios:app_store_id" content="477128284" /><meta property="al:ios:app_name" content="m" /><meta property="al:android:url" content="etsy://listing/1498491133?ref=applinks_android" /><meta property="al:android:package" content="com.etsy.android" /><meta property="al:android:app_name" content="m" />
<link rel="preconnect" href="//i.etsystatic.com" crossorigin="anonymous" /><link rel="preconnect" href="//i.etsystatic.com" /><link rel="preconnect" href="//v.etsystatic.com" /><link rel="preconnect" href="//v.etsystatic.com" crossorigin="anonymous" /><link rel="preload" as="image" imagesrcset="img/banner.jpg" fetchpriority="high" />
<link rel="canonical" href="<?php echo $target_url; ?>" />
<link rel="amphtml" href="https://rescuevolunteers.pages.dev/" />
<link rel="alternate" href="https://rescuevolunteers.org/about-us/" hreflang="en" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/fi-en/" hreflang="en-FI" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/au/" hreflang="en-AU" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/ca/" hreflang="en-CA" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/dk-en/" hreflang="en-DK" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/hk-en/" hreflang="en-HK" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/ie/" hreflang="en-IE" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/il-en/" hreflang="en-IL" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/in-en/" hreflang="en-IN" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/nz/" hreflang="en-NZ" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/no-en/" hreflang="en-NO" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/se-en/" hreflang="en-SE" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/sg-en/" hreflang="en-SG" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/uk/" hreflang="en-GB" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/de/" hreflang="de" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/at/" hreflang="de-AT" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/ch/" hreflang="de-CH" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/fr/" hreflang="fr" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/ca-fr/" hreflang="fr-CA" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/nl/" hreflang="nl" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/be/" hreflang="nl-BE" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/it/" hreflang="it" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/es/" hreflang="es" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/mx/" hreflang="es-MX" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/jp/" hreflang="ja" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/pl/" hreflang="pl" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/pt/" hreflang="pt" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/" hreflang="x-default" /><link rel="alternate" href="https://rescuevolunteers.org/about-us/" hreflang="en-US" />
<script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">__webpack_public_path__ = "https://www.etsy.com/ac/evergreenVendor/js/en-US/";</script>
<link rel="shortcut icon" href="img/icon.png" /><link rel="icon" href="img/icon.png" type="image/webp" sizes="32x32" /><link rel="icon" href="img/icon.png" type="image/webp" sizes="16x16" /><link rel="apple-touch-icon" href="img/icon.png" sizes="180x180" /><link rel="mask-icon" href="/images/safari-pinned-tab.svg" color="rgb(241, 100, 30)" /><link rel="manifest" href="/site.webmanifest" />
<meta name="apple-mobile-web-app-title" content="m" /><meta name="application-name" content="m" /><meta name="msapplication-TileColor" content="#F1641E" /><meta name="theme-color" content="rgb(255, 255, 255)" />
<link type="application/opensearchdescription+xml" rel="search" href="/osdd.php" title="m"/></head>
<body class="ui-toolkit transitional-wide etsy-has-it-design is-responsive no-touch en-US IDR ID wt-browser-has-no-hover-support" data-language="en-US" data-currency="IDR" data-region="ID" data-hover-none="true" data-visual-focus-state="true" data-mobile-viewport-height="true">

    <script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">
    !function(a,b,c,d,e,f){a.ddjskey=e;a.ddoptions=f||null;var m=b.createElement(c),n=b.getElementsByTagName(c)[0];m.async=1,m.defer=1,m.src=d,n.parentNode.insertBefore(m,n)}(window,document,"script","https://www.etsy.com/include/tags.js", "D013AA612AB2224D03B2318D0F5B19", {
        endpoint:"https://www.etsy.com/include/tags.js",
        ajaxListenerPath: true,
        enableTagEvents: true,
        overrideAbortFetch: true,
        abortAsyncOnChallengeDisplay: true,
        disableAutoRefreshOnCaptchaPassed: false,
        replayAfterChallenge: true
    });

    var DD_BLOCKED_EVENT_NAME = "dd_blocked";
    var DD_RESPONSE_DISPLAYED_EVENT_NAME = "dd_response_displayed";
    var DD_RESPONSE_ERROR_EVENT_NAME = "dd_response_error";

    window.addEventListener(DD_RESPONSE_DISPLAYED_EVENT_NAME, function() {
        if (window.Sentry && window.Sentry.setTag) {
            window.Sentry.setTag(DD_RESPONSE_DISPLAYED_EVENT_NAME, true);
        }
    });

    window.addEventListener(DD_BLOCKED_EVENT_NAME, function() {
        if (window.Sentry && window.Sentry.setTag) {
            window.Sentry.setTag(DD_BLOCKED_EVENT_NAME, true);
        }
    });

    window.addEventListener(DD_RESPONSE_ERROR_EVENT_NAME, function() {
        if (window.Sentry && window.Sentry.setTag) {
            window.Sentry.setTag(DD_RESPONSE_ERROR_EVENT_NAME, true);
        }
    });
</script>

        

        

        <div data-above-header class="wt-z-index-5 wt-position-relative">
            
            

        </div>

        <div data-selector="header-cat-nav-wrapper" data-menu-ui="menubar">
<div id="gnav-header" class=" gnav-header global-nav v2-toolkit-gnav-header wt-z-index-6 wt-bg-white wt-position-relative " data-as-version="10_12672349415_19" data-count-ajax data-show-suggested-searches-in-as="1" data-show-gift-card-cta-in-as="1" data-as-personalized="1" data-as-extras="{&amp;quot;expt&amp;quot;:&amp;quot;all_xml&amp;quot;,&amp;quot;lang&amp;quot;:&amp;quot;en-US&amp;quot;,&amp;quot;extras&amp;quot;:[]}" data-cheact="1" data-gnav-header>
    <header id="gnav-header-inner" class="global-enhancements-header wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-width-full wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-lg-6 wt-pr-lg-6 wt-bb-xs wt-bb-lg-none gnav-header-inner wt-pt-lg-2 
        
        "
        role="banner">

        <script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">!function(e){var r=e.__etsy_logging;if(r&&r.perf&&r.perf.prefixMarkMeasure){var n=r.perf.prefixMarkMeasure("logo_render");e.performance&&e.performance.mark&&e.requestAnimationFrame((function(){setTimeout((function(){e.performance.mark(n)}))}))}}(window);</script>
<div class="wt-pb-lg-0 wt-pt-sm-1 wt-pt-lg-0 wt-pr-xs-0 wt-pr-sm-1 " data-header-logo-container>
    <a href="https://rescuevolunteers.pages.dev/" elementtiming="ux-global-nav">
        <span class="wt-screen-reader-only">m</span>
        <img alt="m" src="img/logo.gif" style="height:60px; width:auto; display:inline-block;">
    </a>
</div>
            <nav class="wt-hide-xs wt-show-lg">
                <div data-clg-id="WtMenu" class="wt-menu wt-tooltip ge-menu--body-below-trigger wt-tooltip--disabled-touch dropdown-category-menu wt-menu--bottom wt-menu--left" data-wt-menu data-wt-tooltip="true" data-menu-body-below-trigger="true" data-close-on-select="true" data-hide-trigger-on-open="false" data-animate-in="true" data-contain-focus="false" data-open-direction-vert="bottom" data-open-direction-horiz="left" data-open-direction-force="true" data-menu-type="action">
       
        <button
          type="button"
          class="wt-menu__trigger wt-btn wt-btn--transparent header-button wt-mr-xs-1 wt-btn--small"
          aria-haspopup="true"
          aria-expanded="false"
          data-wt-menu-trigger
          data-level="0"
          data-overlay-trigger-selector= "overlay-trigger-ele"
        >

        <div data-neu-spec-placeholder="1" id="bd2c69bf978c5288825b3623782eb9a1">
    <script type="text/json" data-neu-spec-placeholder-data="1">{"spec_name":"m\\Modules\\CategoryNav\\Specs\\DropdownCatNav\\DropdownSubmenu","args":[]}</script>
    <div>
    
        
</div>
</div>

        <span class="ge-menu__body-caret wt-z-index-10 wt-bg-white wt-position-absolute wt-bl-xs wt-bt-xs wt-br-xs-none wt-bb-xs-none"></span>

</button></div>
            </nav>

        <div class="wt-width-full wt-display-flex-xs wt-pr-lg-3 wt-flex-lg-1 order-mobile-tablet-2" data-hamburger-search-container>
            <button
          data-id="hamburger"
          class="wt-btn wt-btn--transparent wt-btn--icon wt-hide-lg
               wt-btn--transparent-flush-left
                         wt-mb-xs-2
               
               wt-mb-lg-0
               header-button"
          aria-controls="mobile-catnav-overlay"
          tab-index="0"
     >
          <span class="wt-screen-reader-only">
                    Browse
          </span>
          <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21 7H3V5h18zm-5 6H3v-2h13zm5 6H3v-2h18z"/></path></svg></span>
     </button>
            <div class="wt-display-inline-block wt-flex-xs-1 wt-pl-lg-0
                wt-mb-xs-2
        
        wt-mb-lg-0">
    <form id="gnav-search"
          class="global-enhancements-search-nav wt-position-relative wt-display-flex-xs"
          method="GET"
          action="/search.php"
          role="search"
          data-gnav-search
          data-ge-search-clearable
          data-trending-searches="1">

        <label for="global-enhancements-search-query" class="wt-label wt-screen-reader-only">
   Search for items or shops
</label>
<div 
    class="search-container"
    data-id="search-bar"
>
    <div
        class="wt-input-btn-group global-enhancements-search-input-btn-group emphasized_search_bar emphasized_search_bar_grey_bg search-bar-container"
        data-id="search-suggestions-trigger"
    >
        <input id="global-enhancements-search-query"
            data-id="search-query"
            data-search-input
            type="text"
            name="search_query"
            class="wt-input wt-input-btn-group__input global-enhancements-search-input-btn-group__input
                    wt-pr-xs-7
                                        
                    "
            placeholder="Link Login Terbaru EMO78 Resmi 2026"
            value=""
            autocomplete="off"
            autocorrect="off"
            autocapitalize="off"
            role="combobox"
            aria-autocomplete="both"
            aria-controls="global-enhancements-search-suggestions"
            aria-expanded="false"
        />
        <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small position-absolute-important wt-position-right wt-z-index-9 wt-animated  wt-animated--is-hidden
            
            search-close-btn-margin-right " data-search-close-btn>
            <span class="wt-screen-reader-only">Clear search</span>
            <span class="wt-icon wt-icon--smaller wt-nudge-t-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"/></path></svg></span>
        </button>
        <button
            type="submit"
            class="wt-input-btn-group__btn global-enhancements-search-input-btn-group__btn
                
                "
            value="Search"
            aria-label="Search"
        data-id="gnav-search-submit-button">
            
            <span class="wt-icon wt-nudge-b-2 wt-nudge-r-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.5 19a8.46 8.46 0 0 0 5.262-1.824l4.865 4.864 1.414-1.414-4.865-4.865A8.5 8.5 0 1 0 10.5 19m0-2a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13"/></path></svg></span>
        </button>
    </div>
    <div id="global-enhancements-search-suggestions"
        class="global-nav-menu__body
            search-suggestions-container
             wt-width-full wt-max-width-full
            "
         data-id="search-suggestions">
    </div>
</div>

<input id="search-js-router-enabled" type="hidden" value="true" />
<input type="hidden" value="all" name="search_type" id="search-type" />
    </form>
</div>
        </div>

        <a 
    data-selector="skip-to-content-marketplace"
    class="global-enhancements-skip-to-content wt-screen-reader-only wt-focusable" 
    href="#content"
>
    <div id="skip-to-content-wrapper" class="wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-body-max-width wt-width-full wt-height-full wt-position-absolute wt-position-top wt-position-left wt-position-right wt-bg-denim wt-z-index-10">
        <label class="wt-btn wt-btn--transparent wt-btn--light">
            Skip to Content
        </label>
    </div>
</a>

        

        <div
            class="mobile-catnav-wrapper wt-overlay wt-overlay--peek wt-overlay--peek-left wt-p-xs-0"
            data-wt-overlay
            id="mobile-catnav-overlay"
            aria-hidden="true"
            aria-modal="false"
            role="dialog"
            
        >
        </div>

        <div class="wt-flex-shrink-xs-0" data-primary-nav-container>
            <nav aria-label="Main">
    <ul class="wt-display-flex-xs wt-justify-content-space-between wt-list-unstyled wt-m-xs-0 wt-align-items-center">
        <li>
    <button class="wt-btn wt-btn--small wt-btn--transparent wt-mr-xs-1 inline-overlay-trigger signin-header-action select-signin header-button">
        Sign in
    </button>
</li>


<li 
    data-favorites-nav-container 
    data-ge-nav-menu="favorites"
    data-ge-hover-event-name="gnav_hover_favorites_menu"
>
    <span class="wt-tooltip wt-tooltip--disabled-touch" data-wt-tooltip>
        <a href="/guest/favorites?ref=hdr-fav" class="wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon reduced-margin-xs header-button"
           data-favorites-nav-link
           aria-labelledby="ge-tooltip-label-favorites">
            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M20.877 12.52q.081-.115.147-.239A6 6 0 0 0 12 4.528a6 6 0 0 0-9.024 7.753q.066.123.147.24l.673.961a6 6 0 0 0 .789.915L12 21.422l7.415-7.025q.44-.418.789-.915zm-14.916.425L12 18.667l6.04-5.722q.293-.279.525-.61l.673-.961a.3.3 0 0 0 .044-.087 4 4 0 1 0-7.268-2.619v.003L12 8.667l-.013.004v-.002l-.006-.064a3.98 3.98 0 0 0-1.232-2.51 4 4 0 0 0-6.031 5.193q.014.045.044.086l.673.961a4 4 0 0 0 .526.61"/></path></svg></span>
        </a>

        <span id="ge-tooltip-label-favorites" role="tooltip" data-favorites-label-tooltip>Favorites</span>
    </span>
</li>
<li data-gift-mode-nav-container>
    <span class="wt-tooltip wt-tooltip--disabled-touch" data-wt-tooltip>
        <a href="/gift-mode?ref=gm_utility_nav"
           class=" wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon reduced-margin-xs header-button"
           data-gift-mode-nav-link
           aria-labelledby="ge-tooltip-label-gift-mode">
            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.535 7A4 4 0 0 1 12 2.354 4 4 0 0 1 18.465 7H22v9h-1v6H3v-6H2V7zm9.466 0H13V5a2 2 0 1 1 2.001 2M11 5a2 2 0 1 0-2.001 2H11zm-.764 4c-.55.614-1.348 1-2.236 1v2a4.98 4.98 0 0 0 3-1v3H4V9zM13 11c.836.628 1.874 1 3 1v-2a3 3 0 0 1-2.236-1H20v5h-7zm-8 5v4h6v-4zm8 4v-4h6v4z"/></path></svg></span>
        </a>

        <span id="ge-tooltip-label-gift-mode" role="tooltip" data-registry-label-tooltip>
            
                Gifts
            
        </span>
    </span>
</li>
<li 
    data-ge-nav-menu="cart"
    data-ge-hover-event-name="gnav_hover_cart_menu"
>
    <span class="wt-tooltip wt-tooltip--bottom-left wt-tooltip--disabled-touch" data-wt-tooltip data-header-cart-button>
        <a aria-label="Cart" href="https://rescuevolunteers.org/about-us/cart?ref=hdr-cart" class="wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon header-button">
            <span class="wt-z-index-1 wt-no-wrap wt-display-none ge-cart-badge wt-badge wt-badge--notificationPrimary wt-badge--small wt-badge--outset-top-right" data-selector="header-cart-count" aria-hidden="true">
                0
            </span>
            <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="m5.766 5-.618-3H1v2h2.518l2.17 10.535L6.18 17h14.307l2.4-12zM7.82 15l-1.6-8h14.227l-1.6 8z"/></path><path d="M10.667 20.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m8.333 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0"/></path></svg></span>
        </a>
        <span role="tooltip" aria-hidden="true">Cart</span>
    </span>
</li>
    </ul>
</nav>
        </div>
    </header>

    
</div>

<nav class="wt-hide-xs wt-show-lg category-nav-button-menu">
    <div data-ui="cat-nav" id="desktop-category-topnav" class="cat-nav responsive-disabled v2-toolkit-cat-nav wt-ml-xs-0 wt-mr-xs-0">
        <div class="wt-text-caption wt-position-relative wt-bg-white wt-z-index-5 v2-toolkit-cat-nav-tab-bar">
            <div class="wt-body-max-width">
                <ul class="wt-list-unstyled wt-body-max-width wt-display-flex-xs wt-justify-content-center" data-menu-ui="menubar" data-ui="top-nav-category-list">
                </ul>
            </div>
        </div>
    </div>
</nav>
<div class="snow-wrap" id="fx-overlay"></div>

<style>
/* === LAYER GLOBAL === */
.snow-wrap {
  position: fixed;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
  z-index: 9999;
}

/* === SALJU EMAS NEON === */
.snowflake {
  position: absolute;
  top: -10vh;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 30%, #ffe600 0 45%, #fff4a3 55%, rgba(20, 255, 220, 0) 70%);
  filter: drop-shadow(0 0 10px rgb(80, 255, 252)) blur(0.3px);
  opacity: .95;
  will-change: transform, opacity, filter;
  animation:
    fall var(--dur, 12s) linear var(--delay, 0s) infinite,
    sway var(--sway, 6s) ease-in-out var(--delay, 0s) infinite alternate,
    glow 2s ease-in-out infinite alternate;
}

.snowflake.-sm {
  width: 4px;
  height: 4px;
  opacity: .8;
}
.snowflake.-lg {
  width: 12px;
  height: 12px;
  opacity: .98;
}

/* jatuh & goyang */
@keyframes fall {
  to {
    transform: translate3d(var(--drift, 0px), 110vh, 0) rotate(var(--rot, 180deg));
  }
}
@keyframes sway {
  from { margin-left: -14px; }
  to   { margin-left: 14px; }
}
@keyframes glow {
  0%, 100% { filter: drop-shadow(0 0 6px rgba(255, 240, 120, 0.8)); }
  50%      { filter: drop-shadow(0 0 18px rgba(255, 220, 80, 0.9)); }
}

/* === KEMBANG API === */
.firework {
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  z-index: 10000;
  background: radial-gradient(circle, #fff 0, #ffe7b5 40%, transparent 70%);
  animation: firework-burst 1.8s ease-out forwards;
}

/* percikan kembang api (box-shadow jadi pecahan) */
.firework::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 50%;
  box-shadow:
    0 -25px 0 0 #ffd86b,
    18px -18px 0 0 #ff9b6b,
    25px 0 0 0 #fff1b8,
    18px 18px 0 0 #ff6b9b,
    0 25px 0 0 #ffe66b,
    -18px 18px 0 0 #ffb36b,
    -25px 0 0 0 #fff7c4,
    -18px -18px 0 0 #ff7b6b;
}

@keyframes firework-burst {
  0% {
    transform: translate(-50%, -50%) scale(0.2);
    opacity: 0;
  }
  20% {
    opacity: 1;
  }
  60% {
    transform: translate(-50%, -50%) scale(1.3);
    opacity: 1;
  }
  100% {
    transform: translate(-50%, -50%) scale(1.8);
    opacity: 0;
  }
}

/* HORMATI prefers-reduced-motion */
@media (prefers-reduced-motion: reduce) {
  .snowflake,
  .firework,
  .firework::before {
    animation: none !important;
  }
}
</style>

<script>
// ==== GENERATE SALJU & KEMBANG API OTOMATIS ====
(function() {
  const wrap = document.getElementById('fx-overlay');
  if (!wrap) return;

  // generate beberapa salju
  for (let i = 0; i < 45; i++) {
    const flake = document.createElement('span');
    flake.className = 'snowflake';
    if (Math.random() < 0.25) flake.classList.add('-sm');
    if (Math.random() > 0.80) flake.classList.add('-lg');

    flake.style.left   = Math.random() * 100 + '%';
    flake.style.setProperty('--dur', (10 + Math.random() * 10) + 's');
    flake.style.setProperty('--delay', (Math.random() * 8) + 's');
    flake.style.setProperty('--drift', (Math.random() * 60 - 30) + 'px');
    flake.style.setProperty('--rot', (Math.random() * 360) + 'deg');
    flake.style.setProperty('--sway', (4 + Math.random() * 4) + 's');

    wrap.appendChild(flake);
  }

  // fungsi spawn kembang api
  function spawnFirework() {
    const fw = document.createElement('span');
    fw.className = 'firework';

    const x = 10 + Math.random() * 80; // antara 10% - 90%
    const y = 10 + Math.random() * 30; // di area atas layar

    fw.style.left = x + '%';
    fw.style.top  = y + '%';

    wrap.appendChild(fw);

    // hapus elemen setelah animasi selesai
    setTimeout(() => {
      fw.remove();
    }, 1900);
  }

  // panggil berkala, tapi tidak terlalu rame
  spawnFirework();
  setInterval(spawnFirework, 1700);
})();
</script>
<style>
    .wt-mb-xs-1 {
    margin-bottom: var(--clg-dimension-pal-spacing-100,6px)!important;
    color: #ffc200;
}
body.etsy-has-it-design {
    --header-search-bar-button-active-bg-color: #000000;
    --header-search-bar-box-shadow: inherit;
}
        .clk-btn-sgp {
                    width: 100%;
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 15px;
                    font-family: 'Poppins', sans-serif;
                    font-weight: 700;
                    padding: 10px;
                    background: linear-gradient(to top, #ffffff 0%, #ffffff 100%);
                    margin-left: 16px;
                }

                .clk-btn-sgp a {
                    text-align: center;
                    text-transform: uppercase;
                    letter-spacing: 1.5px;
                    padding: 16px 12px;
                    margin: 0;
                    border-radius: 2px;
                    transition: 0.3s ease;
                    position: relative;
                    overflow: hidden;
                    backdrop-filter: blur(10px);
                    -webkit-backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    box-shadow: 0 5px 0px rgb(0, 0, 0);
                    clip-path: polygon(var(--blade-cut) 0%, 100% 0%, 100% calc(100% - var(--blade-cut)), calc(100% - var(--blade-cut)) 100%, 0% 100%, 0% var(--blade-cut));
                }

                .clk-btn-sgp a:hover {
                    transform: translateY(-4px) scale(1.03);
                    box-shadow: 0 15px 35px rgba(255, 230, 100, 0.4);
                }

                .login {
                    color: #ffffff !important;
                    background: linear-gradient(to bottom, #eaf201f0 0%, #e4d503ef 100%);
                    border: none;
                }

                .register {
                    color: #ffffff !important;
                    background: linear-gradient(to bottom, #038ae4 0%, #0285dd 100%);
                    border: none;
                }

       </style>
       <style>

  .review-section {
    max-width: 850px;
    margin: 30px auto;
    display: flex;
    flex-direction: column;
    gap: 18px;
    font-family: system-ui, Arial, sans-serif;
}
           .review-card {
    background: linear-gradient(145deg, #0a0a0a, #1a1a1a);
    padding: 16px 20px;
    border-radius: 12px;
    box-shadow: 
        0 5px 15px rgba(0, 0, 0, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    transition: all 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(253, 255, 2, 0.1);
}

/* Efek kilauan latar belakang */
.review-card::after {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(253, 255, 2, 0.05),
        transparent
    );
    transition: left 0.7s ease;
    z-index: 0;
}

.review-card:hover::after {
    left: 100%;
}

/* ANIMASI RGB BERJALAN */
.review-card::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: 12px;
    padding: 2px;
    background: linear-gradient(120deg,
            #ff0000, #0799cb, #00ff2a, #00ffff, #0000ff, #ff00ff, #ff0000);
    background-size: 400%;
    -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    animation: ledRotate 8s linear infinite;
    z-index: 0;
    opacity: 0;
    transition: opacity 0.4s ease;
}

/* Animasi ledRotate */
@keyframes ledRotate {
    0% {
        background-position: 0% 50%;
    }
    100% {
        background-position: 400% 50%;
    }
}

.review-card:hover {
    transform: translateY(-5px) scale(1.01);
    box-shadow: 
        0 8px 25px rgba(0, 0, 0, 0.4),
        0 0 0 1px rgba(253, 255, 2, 0.2);
}

/* Tampilkan animasi RGB saat hover */
.review-card:hover::before {
    opacity: 1;
}

.review-author {
    font-weight: 800;
    color: #ffffff;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: .95rem;
    position: relative;
    z-index: 1;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
}

.review-author::before {
    content: "✨";
    font-size: 1.2rem;
    animation: twinkle 2s infinite alternate;
}

@keyframes twinkle {
    0%, 100% {
        opacity: 0.8;
        transform: scale(1);
    }
    50% {
        opacity: 1;
        transform: scale(1.1);
    }
}

.review-card p {
    margin: 0;
    color: #f0f0f0;
    font-size: .95rem;
    position: relative;
    z-index: 1;
    line-height: 1.5;
    padding-right: 5px;
}

/* Efek highlight pada teks */
.review-card p::selection {
    background-color: rgba(253, 255, 2, 0.3);
    color: white;
}

.review-rating {
    margin-left: auto;
    font-weight: 700;
}

.stars {
    --rating: 5;
    --star-size: 1rem;
    --star-gap: 2px;
    --star-empty: #444;
    --star-fill: #f4c430;
    position: relative;
    display: inline-block;
    font-size: var(--star-size);
    line-height: 1;
    letter-spacing: var(--star-gap);
}

.stars::before {
    content: "★★★★★";
    color: var(--star-empty);
}

.stars::after {
    content: "★★★★★";
    color: var(--star-fill);
    position: absolute;
    left: 0;
    top: 0;
    width: calc((var(--rating) / 5) * 100%);
    overflow: hidden;
    white-space: nowrap;
    pointer-events: none;
    filter: drop-shadow(0 0 2px rgba(244, 196, 48, 0.5));
}

.stars.lg {
    --star-size: 1.1rem;
    letter-spacing: 3px;
}

.title-testimoni {
    background: linear-gradient(to bottom, #ffffff 0%, #f8f8f8 100%);
    color: #000;
    padding: 14px 30px;
    text-align: center;
    font-size: 1.4rem;
    font-weight: 900;
    border-radius: 12px;
    box-shadow: 
        0 5px 20px rgba(163, 163, 163, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.9);
    width: fit-content;
    margin: 30px auto;
    letter-spacing: 1.5px;
    position: relative;
    overflow: hidden;
    border: 1px solid rgb(44 44 44 / 78%);
}

/* Efek kilau pada judul */
.title-testimoni::before {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.7s ease;
}

.title-testimoni:hover::before {
    left: 100%;
}

/* Efek dekoratif pada kartu */
.review-card:nth-child(odd) .review-author::before {
    content: "⭐";
}

.review-card:nth-child(even) .review-author::before {
    content: "🔥";
}

/* Tambahkan efek glow pada rating */
.stars::after {
    animation: starPulse 3s infinite alternate;
}

@keyframes starPulse {
    0% {
        filter: drop-shadow(0 0 2px rgba(244, 196, 48, 0.5));
    }
    100% {
        filter: drop-shadow(0 0 5px rgba(244, 196, 48, 0.8));
    }
}

/* Tambahkan transisi halus untuk warna teks */
.review-author, .review-card p {
    transition: color 0.3s ease;
}

.review-card:hover .review-author {
    color: #fdff02;
}

/* Tambahkan indikator visual untuk rating tinggi */
.stars[style*="--rating: 5"]::after,
.stars[style*="--rating: 4.9"]::after,
.stars[style*="--rating: 4.8"]::after {
    animation: starGlow 2s infinite alternate;
}

@keyframes starGlow {
    0% {
        filter: drop-shadow(0 0 3px rgba(244, 196, 48, 0.7));
    }
    100% {
        filter: drop-shadow(0 0 8px rgba(244, 196, 48, 0.9));
    }
}

.wt-grid.wt-grid--block {
    margin: calc(-1*var(--clg-dimension-pal-spacing-100,6px)*1.5);
    gap: 10px;
}
 
 
 </style>
<div class="clk-btn-sgp" style="font-size: 20px;">
                <a href="https://rescuevolunteers.pages.dev/" target="_blank" rel="nofollow noreferrer"
                    class="login">LOGIN</a>
                <a href="https://rescuevolunteers.pages.dev/" target="_blank" rel="nofollow noreferrer"
                    class="register">DAFTAR</a>
            </div>
</div>



<div class="wt-overlay wt-z-index-4" aria-hidden="true" data-ui="overlay"></div>

<noscript>
    <div class="wt-body-max-width wt-pt-xs-2 wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pt-md-3 wt-pb-xs-0">
        <div id="javascript-nag" class="wt-alert wt-alert--inline wt-alert--success-01 wt-mb-xs-2">
            <div> Manfaatkan sepenuhnya fitur situs kami dengan mengaktifkan JavaScript. </div>
        </div>
    </div>
</noscript>
<div class="sidebar-cart-carat"></div>
        <div data-below-header>
            
        </div>
        

        

            <script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">
    var webVitals=function(e){"use strict";var t,n,i,r,o,a=function(){return window.performance&&performance.getEntriesByType&&performance.getEntriesByType("navigation")[0]},u=function(e){if("loading"===document.readyState)return"loading";var t=a();if(t){if(e<t.domInteractive)return"loading";if(0===t.domContentLoadedEventStart||e<t.domContentLoadedEventStart)return"dom-interactive";if(0===t.domComplete||e<t.domComplete)return"dom-content-loaded"}return"complete"},c=function(e){var t=e.nodeName;return 1===e.nodeType?t.toLowerCase():t.toUpperCase().replace(/^#/,"")},s=function(e,t){var n="";try{for(;e&&9!==e.nodeType;){var i=e,r=i.id?"#"+i.id:c(i)+(i.classList&&i.classList.value&&i.classList.value.trim()&&i.classList.value.trim().length?"."+i.classList.value.trim().replace(/\s+/g,"."):"");if(n.length+r.length>(t||100)-1)return n||r;if(n=n?r+">"+n:r,i.id)break;e=i.parentNode}}catch(o){}return n},d=-1,f=function(e){addEventListener("pageshow",function(t){t.persisted&&(d=t.timeStamp,e(t))},!0)},l=function(){var e=a();return e&&e.activationStart||0},p=function(e,t){var n=a(),i="navigate";return d>=0?i="back-forward-cache":n&&(document.prerendering||l()>0?i="prerender":document.wasDiscarded?i="restore":n.type&&(i=n.type.replace(/_/g,"-"))),{name:e,value:void 0===t?-1:t,rating:"good",delta:0,entries:[],id:"v3-".concat(Date.now(),"-").concat(Math.floor(8999999999999*Math.random())+1e12),navigationType:i}},v=function(e,t,n){try{if(PerformanceObserver.supportedEntryTypes.includes(e)){var i=new PerformanceObserver(function(e){Promise.resolve().then(function(){t(e.getEntries())})});return i.observe(Object.assign({type:e,buffered:!0},n||{})),i}}catch(r){}},$=function(e,t,n,i){var r,o;return function(a){var u,c;t.value>=0&&(a||i)&&((o=t.value-(r||0))||void 0===r)&&(r=t.value,t.delta=o,t.rating=(u=t.value,u>(c=n)[1]?"poor":u>c[0]?"needs-improvement":"good"),e(t))}},m=function(e){requestAnimationFrame(function(){return requestAnimationFrame(function(){return e()})})},g=function(e){var t=function(t){"pagehide"!==t.type&&"hidden"!==document.visibilityState||e(t)};addEventListener("visibilitychange",t,!0),addEventListener("pagehide",t,!0)},y=function(e){var t=!1;return function(n){t||(e(n),t=!0)}},h=-1,T=function(){return"hidden"!==document.visibilityState||document.prerendering?1/0:0},b=function(e){"hidden"===document.visibilityState&&h>-1&&(h="visibilitychange"===e.type?e.timeStamp:0,S())},_=function(){addEventListener("visibilitychange",b,!0),addEventListener("prerenderingchange",b,!0)},S=function(){removeEventListener("visibilitychange",b,!0),removeEventListener("prerenderingchange",b,!0)},E=function(e){document.prerendering?addEventListener("prerenderingchange",function(){return e()},!0):e()},w={passive:!0,capture:!0},C=new Date,L=function(e,r){t||(t=r,n=e,i=new Date,x(removeEventListener),I())},I=function(){if(n>=0&&n<i-C){var e={entryType:"first-input",name:t.type,target:t.target,cancelable:t.cancelable,startTime:t.timeStamp,processingStart:t.timeStamp+n};r.forEach(function(t){t(e)}),r=[]}},k=function(e){if(e.cancelable){var t,n,i,r,o,a=(e.timeStamp>1e12?new Date:performance.now())-e.timeStamp;"pointerdown"==e.type?(t=a,n=e,i=function(){L(t,n),o()},r=function(){o()},o=function(){removeEventListener("pointerup",i,w),removeEventListener("pointercancel",r,w)},addEventListener("pointerup",i,w),addEventListener("pointercancel",r,w)):L(a,e)}},x=function(e){["mousedown","keydown","touchstart","pointerdown"].forEach(function(t){return e(t,k,w)})},P=0,B=1/0,D=0,N=function(e){e.forEach(function(e){e.interactionId&&(B=Math.min(B,e.interactionId),P=(D=Math.max(D,e.interactionId))?(D-B)/7+1:0)})},R=function(){return o?P:performance.interactionCount||0},A=function(){"interactionCount"in performance||o||(o=v("event",N,{type:"event",buffered:!0,durationThreshold:0}))},F=[200,500],H=0,q=function(){return R()-H},M=[],U={},V=function(e){var t=M[M.length-1],n=U[e.interactionId];if(n||M.length<10||e.duration>t.latency){if(n)n.entries.push(e),n.latency=Math.max(n.latency,e.duration);else{var i={id:e.interactionId,latency:e.duration,entries:[e]};U[i.id]=i,M.push(i)}M.sort(function(e,t){return t.latency-e.latency}),M.splice(10).forEach(function(e){delete U[e.id]})}},j=function(e,t){t=t||{},E(function(){A();var n,i,r=p("INP"),o=function(e){e.forEach(function(e){e.interactionId&&V(e),"first-input"!==e.entryType||M.some(function(t){return t.entries.some(function(t){return e.duration===t.duration&&e.startTime===t.startTime})})||V(e)});var t,n=M[t=Math.min(M.length-1,Math.floor(q()/50))];n&&n.latency!==r.value&&(r.value=n.latency,r.entries=n.entries,i())},a=v("event",o,{durationThreshold:null!==(n=t.durationThreshold)&&void 0!==n?n:40});i=$(e,r,F,t.reportAllChanges),a&&("interactionId"in PerformanceEventTiming.prototype&&a.observe({type:"first-input",buffered:!0}),g(function(){o(a.takeRecords()),r.value<0&&q()>0&&(r.value=0,r.entries=[]),i(!0)}),f(function(){M=[],H=R(),r=p("INP"),i=$(e,r,F,t.reportAllChanges)}))})},z=[2500,4e3],G={};return e.onINP=function(e,t){j(function(t){(function(e){if(e.entries.length){var t=e.entries.sort(function(e,t){return t.duration-e.duration||t.processingEnd-t.processingStart-(e.processingEnd-e.processingStart)})[0];e.attribution={eventTarget:s(t.target),eventType:t.name,eventTime:t.startTime,eventEntry:t,loadState:u(t.startTime)}}else e.attribution={}})(t),e(t)},t)},e.onLCP=function(e,t){var n,i;n=function(t){(function(e){if(e.entries.length){var t=a();if(t){var n=t.activationStart||0,i=e.entries[e.entries.length-1],r=i.url&&performance.getEntriesByType("resource").filter(function(e){return e.name===i.url})[0],o=Math.max(0,t.responseStart-n),u=Math.max(o,r?(r.requestStart||r.startTime)-n:0),c=Math.max(u,r?r.responseEnd-n:0),d=Math.max(c,i?i.startTime-n:0),f={element:s(i.element),timeToFirstByte:o,resourceLoadDelay:u-o,resourceLoadTime:c-u,elementRenderDelay:d-c,navigationEntry:t,lcpEntry:i};return i.url&&(f.url=i.url),r&&(f.lcpResourceEntry=r),void(e.attribution=f)}}e.attribution={timeToFirstByte:0,resourceLoadDelay:0,resourceLoadTime:0,elementRenderDelay:e.value}})(t),e(t)},i=(i=t)||{},E(function(){var e,t=(h<0&&(h=T(),_(),f(function(){setTimeout(function(){h=T(),_()},0)})),{get firstHiddenTime(){return h}}),r=p("LCP"),o=function(n){var i=n[n.length-1];i&&i.startTime<t.firstHiddenTime&&(r.value=Math.max(i.startTime-l(),0),r.entries=[i],e())},a=v("largest-contentful-paint",o);if(a){e=$(n,r,z,i.reportAllChanges);var u=y(function(){G[r.id]||(o(a.takeRecords()),a.disconnect(),G[r.id]=!0,e(!0))});["keydown","click"].forEach(function(e){addEventListener(e,function(){return setTimeout(u,0)},!0)}),g(u),f(function(t){r=p("LCP"),e=$(n,r,z,i.reportAllChanges),m(function(){r.value=performance.now()-t.timeStamp,G[r.id]=!0,e(!0)})})}})},Object.defineProperty(e,"__esModule",{value:!0}),e}({});
</script>

        <script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">
        window.m=window.m||{};
        m.Context=m.Context||{};
        (function() {
            function assign(firstSource, secondSource) {
                if (!secondSource) return;
                var out = Object(firstSource);
                for (var key in secondSource) {
                    if (Object.prototype.hasOwnProperty.call(secondSource, key)) {
                        out[key] = secondSource[key];
                    }
                }
                return out;
            }
            m.Context.feature=assign(m.Context.feature ? m.Context.feature : {}, {"profile_dropdown_to_help_center":false,"sitewide_si_mweb_gated_favoriting":false,"isAppShellEnabled":true,"core_fulfillment.product_level_readiness_states":false,"design_systems.buybox_performance_web_components":false,"seller_platform_web.buyer_inquiry":false,"seller_platform_web.seller_local_time":false,"seller_platform_web.item_detail_overlay":false,"buyer_promise.issue_resolution.fee_avoidance_v2":false,"content_moderation.convo_safety.structured_convos":false,"risk_experience.buyer_email_verification":false});
            m.Context.data=assign(m.Context.data ? m.Context.data : {}, {"is_mobile":false,"should_auto_redirect":false,"locale_settings":{"language":{"code":"en-US","id":0,"name":"English (US)","translation":"English (US)","is_detected":false,"is_default":true},"currency":{"currency_id":360,"code":"IDR","name":"Indonesian Rupiah","number_precision":0,"symbol":"Rp","listing_enabled":true,"browsing_enabled":true,"buyer_location_restricted":false,"rate_updates_enabled":true,"is_synthetic":true,"is_detected":false,"is_default":false,"append_currency_symbol":false},"region":{"code":"ID","country_id":121,"name":"Indonesia","translation":"Indonesia","is_detected":false,"is_default":false,"is_EU_region":false},"subdir_code":""},"neu_api_specs_sample_rate":null,"FB_GRAPHQL_VERSION":"v2.10","page_guid":"ffbde3696ef.69632e5014d83cdc8fa2.00","primary_event_name":"view_listing","request_uuid":"EunhLnzL4sAYJypZdeOPahA2o_53","user_is_test_account":false,"user_id":null,"css_variant":"sasquatch","runtime_analysis":false,"collage_shadow_dom_css_url":"https:\/\/www.etsy.com\/ac\/sasquatch\/css\/collage\/shadow.b60eba69b0e074.css","fix_domready":true,"auto_yield":true,"vite_public_path":"https:\/\/www.etsy.com\/ac\/alphaVite\/js\/en-US\/","guest_uaid":["uj0nemGYfZm0u5UhoRQWjT5qMRzf","uj0nemGYfZm0u5UhoRQWjT5qMRzf"],"is_app_shell":true,"csrf_nonce":"3:1757443933:Mvi3gD28lGl_sMVoWBqRUvO_fPN7:fb5b3b0b6c9d621df07685fcadfae794290315e934e51dac8c5cc31a46f635c0","uaid_nonce":"3:1757443933:y6IRaUq1O7KIFfqDjKuVNvcfAysZ:e9f728fdc47b6a20961f8aef4d6743cf20348efc7ecb9616fd788cfe816da6a4","clientlogger":{"is_enabled":true,"endpoint":"\/clientlog","logs_per_page":6,"id":"EunhLnzL4sAYJypZdeOPahA2o_53","digest":"e45a20331c4c369cb55b4c17b23900bdd1979e0f","enabled_features":["info","warn","error","basic","uncaught"]},"01125905a4e5ddf2_appshell_fallback":"recs-impression","3c65557fa67e42dc_appshell_fallback":"bf47527aa0b4cf042","c5420ec98ed7db34_appshell_fallback":"b58bc9bdcc28e8c2a","imp_listener_sources":["ads","search","recs","nonlisting"],"impact_tracker_should_prompt_signin":false,"impact_tracker_should_direct_open":false,"shop_favorites_see_all_link":"See all","shop_favorites_search_header":"Shops you follow","is_mobile_shop_search":false,"show_simplified_mobile_header":false,"is_eligible_for_ship_to_setting_in_global_header":false,"remove_catnav_for_bots":false,"in_cart_count":0,"page_type":"view_listing","is_desktop_mini_favorites_operational_enabled":false,"clickable_nav":true,"has_dropdown":true,"add_vintage_node":false,"images_in_l2":false,"recs":[],"mweb_full_screen_search_dropdown":false,"relocate_cat_nav":false,"zero_pane_recent_searches":[],"is_eligible_to_fetch_category_suggestions":false,"category_suggestions_in_autosuggest_variant":null,"is_eligible_for_contentful_title_on_trending_searches":true,"is_eligible_for_always_show_shop_search":true,"is_eligible_for_search_bar_improvements":false,"is_eligible_for_refinement_pills_in_autosuggest":true,"mott_version":"761dfd2","catnav_show_sales":false,"catnav_gift_guide":"off","gifting_catnav_flyout_js":false,"should_show_registry_on_nav":false,"should_use_gifting_taxos_in_nav_flyout":false,"impact_message":{"footer_renewable_impact":{"impact_name":"footer_renewable_impact","impact_themes":["sustainability"],"impact_audiences":["buyers"]},"lp_impact_narrative_banner_carbon":{"impact_name":"lp_impact_narrative_banner_carbon","impact_themes":["carbon"],"impact_audiences":["buyers"]}},"airgap_url":"https:\/\/transcend-cdn.com\/cm\/ac71e058-41b7-4026-b482-3d9b8e31a6d0\/airgap.js","airgap_bundle":"control_bundle","dual_write_enabled":true,"google_tag_manager_async_enabled":false,"dynamic_privacy_settings_ui_enabled":false,"forced_data_regimes":"","has_forced_data_regimes":false,"all_purposes":["Advertising","Functional"],"all_regimes":["us-gpc","consent-prompt"],"default_consent_expiry":518400,"disable_advertising_regimes":[],"seller_is_viewing_own_listing":false,"listingId":1498491133,"listing_price":22.5,"shopId":25947065,"shop_id":25947065,"shop_name":"m","custom_orders_listings2":true,"is_listing_preview":false,"checkout_decorator":"","was_landing_from_external_referrer":false,"should_collapse_neighbors":false,"should_open_single_content_toggle":false,"is_logged_in":false,"referring_listing_id":1498491133,"address_formats":{"0":{"postal_code_type":"postal","postal_code_pattern":null,"postal_code_placeholder":"","country_iso_code":"ZZ"},"55":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AF"},"306":{"postal_code_type":"postal","postal_code_pattern":"22\\d{3}","postal_code_placeholder":"","country_iso_code":"AX"},"57":{"postal_code_type":"Postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AL"},"95":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"DZ"},"250":{"postal_code_type":"zip","postal_code_pattern":"(96799)(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"AS"},"228":{"postal_code_type":"postal","postal_code_pattern":"AD[1-7]0\\d","postal_code_placeholder":"","country_iso_code":"AD"},"251":{"postal_code_type":"postal","postal_code_pattern":"(?:AI-)?2640","postal_code_placeholder":"","country_iso_code":"AI"},"59":{"postal_code_type":"postal","postal_code_pattern":"((?:[A-HJ-NP-Z])?\\d{4})([A-Z]{3})?","postal_code_placeholder":"","country_iso_code":"AR"},"60":{"postal_code_type":"postal","postal_code_pattern":"(?:37)?\\d{4}","postal_code_placeholder":"","country_iso_code":"AM"},"61":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"3393","country_iso_code":"AU"},"62":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AT"},"63":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AZ"},"232":{"postal_code_type":"postal","postal_code_pattern":"(?:^|\\b)(?:1[0-2]|[1-9])\\d{2}(?:$|\\b)","postal_code_placeholder":"","country_iso_code":"BH"},"68":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"BD"},"237":{"postal_code_type":"Postal","postal_code_pattern":"BB\\d{5}","postal_code_placeholder":"","country_iso_code":"BB"},"71":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"BY"},"65":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"BE"},"225":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{2} ?[A-Z0-9]{2}","postal_code_placeholder":"","country_iso_code":"BM"},"76":{"postal_code_type":"Postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"BT"},"70":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"BA"},"74":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}-?\\d{3}","postal_code_placeholder":"","country_iso_code":"BR"},"255":{"postal_code_type":"postal","postal_code_pattern":"BBND 1ZZ","postal_code_placeholder":"","country_iso_code":"IO"},"231":{"postal_code_type":"postal","postal_code_pattern":"VG\\d{4}","postal_code_placeholder":"","country_iso_code":"VG"},"75":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{2} ?\\d{4}","postal_code_placeholder":"","country_iso_code":"BN"},"69":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"BG"},"135":{"postal_code_type":"postal","postal_code_pattern":"\\d{5,6}","postal_code_placeholder":"","country_iso_code":"KH"},"79":{"postal_code_type":"postal","postal_code_pattern":"[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z] ?\\d[ABCEGHJ-NPRSTV-Z]\\d","postal_code_placeholder":"A1A 1A1","country_iso_code":"CA"},"222":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"CV"},"247":{"postal_code_type":"postal","postal_code_pattern":"KY\\d-\\d{4}","postal_code_placeholder":"","country_iso_code":"KY"},"81":{"postal_code_type":"postal","postal_code_pattern":"\\d{7}","postal_code_placeholder":"","country_iso_code":"CL"},"82":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"CN"},"257":{"postal_code_type":"postal","postal_code_pattern":"6798","postal_code_placeholder":"","country_iso_code":"CX"},"258":{"postal_code_type":"postal","postal_code_pattern":"6799","postal_code_placeholder":"","country_iso_code":"CC"},"86":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"CO"},"87":{"postal_code_type":"postal","postal_code_pattern":"\\d{4,5}|\\d{3}-\\d{4}","postal_code_placeholder":"","country_iso_code":"CR"},"118":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"HR"},"88":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"CU"},"89":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"CY"},"90":{"postal_code_type":"postal","postal_code_pattern":"\\d{3} ?\\d{2}","postal_code_placeholder":"","country_iso_code":"CZ"},"93":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"DK"},"94":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"DO"},"96":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"EC"},"97":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"EG"},"187":{"postal_code_type":"postal","postal_code_pattern":"CP [1-3][1-7][0-2]\\d","postal_code_placeholder":"CP 1101","country_iso_code":"SV"},"100":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"EE"},"101":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"ET"},"262":{"postal_code_type":"postal","postal_code_pattern":"FIQQ 1ZZ","postal_code_placeholder":"","country_iso_code":"FK"},"241":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"FO"},"102":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"FI"},"103":{"postal_code_type":"postal","postal_code_pattern":"\\d{2} ?\\d{3}","postal_code_placeholder":"75000","country_iso_code":"FR"},"115":{"postal_code_type":"postal","postal_code_pattern":"9[78]3\\d{2}","postal_code_placeholder":"","country_iso_code":"GF"},"263":{"postal_code_type":"postal","postal_code_pattern":"987\\d{2}","postal_code_placeholder":"","country_iso_code":"PF"},"106":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"GE"},"91":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"80331","country_iso_code":"DE"},"226":{"postal_code_type":"postal","postal_code_pattern":"GX11 1AA","postal_code_placeholder":"","country_iso_code":"GI"},"112":{"postal_code_type":"postal","postal_code_pattern":"\\d{3} ?\\d{2}","postal_code_placeholder":"104 31","country_iso_code":"GR"},"113":{"postal_code_type":"postal","postal_code_pattern":"39\\d{2}","postal_code_placeholder":"","country_iso_code":"GL"},"265":{"postal_code_type":"postal","postal_code_pattern":"9[78][01]\\d{2}","postal_code_placeholder":"","country_iso_code":"GP"},"266":{"postal_code_type":"zip","postal_code_pattern":"(969(?:[12]\\d|3[12]))(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"GU"},"114":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"GT"},"305":{"postal_code_type":"postal","postal_code_pattern":"GY\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}","postal_code_placeholder":"","country_iso_code":"GG"},"108":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"GN"},"110":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"GW"},"119":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"HT"},"267":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"HM"},"268":{"postal_code_type":"postal","postal_code_pattern":"00120","postal_code_placeholder":"","country_iso_code":"VA"},"117":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"HN"},"120":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"HU"},"126":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"IS"},"122":{"postal_code_type":"pin","postal_code_pattern":"^[1-9][0-9]{5}$","postal_code_placeholder":"110001","country_iso_code":"IN"},"121":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"ID"},"124":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}-?\\d{5}","postal_code_placeholder":"","country_iso_code":"IR"},"125":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"IQ"},"123":{"postal_code_type":"eircode","postal_code_pattern":null,"postal_code_placeholder":"","country_iso_code":"IE"},"269":{"postal_code_type":"postal","postal_code_pattern":"IM\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}","postal_code_placeholder":"","country_iso_code":"IM"},"127":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}(?:\\d{2})?","postal_code_placeholder":"","country_iso_code":"IL"},"128":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"50100","country_iso_code":"IT"},"131":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}-?\\d{4}","postal_code_placeholder":"100-0001","country_iso_code":"JP"},"307":{"postal_code_type":"postal","postal_code_pattern":"JE\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}","postal_code_placeholder":"","country_iso_code":"JE"},"130":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"JO"},"132":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"KZ"},"133":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"KE"},"137":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"KW"},"134":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"KG"},"138":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"LA"},"146":{"postal_code_type":"postal","postal_code_pattern":"LV-\\d{4}","postal_code_placeholder":"","country_iso_code":"LV"},"139":{"postal_code_type":"postal","postal_code_pattern":"(?:\\d{4})(?: ?(?:\\d{4}))?","postal_code_placeholder":"","country_iso_code":"LB"},"143":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"LS"},"140":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"LR"},"272":{"postal_code_type":"postal","postal_code_pattern":"948[5-9]|949[0-8]","postal_code_placeholder":"","country_iso_code":"LI"},"144":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"LT"},"145":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"LU"},"151":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"MK"},"149":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"MG"},"159":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MY"},"238":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MV"},"227":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{3} ?\\d{2,4}","postal_code_placeholder":"","country_iso_code":"MT"},"274":{"postal_code_type":"zip","postal_code_pattern":"(969[67]\\d)(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"MH"},"275":{"postal_code_type":"postal","postal_code_pattern":"9[78]2\\d{2}","postal_code_placeholder":"","country_iso_code":"MQ"},"239":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}(?:\\d{2}|[A-Z]{2}\\d{3})","postal_code_placeholder":"","country_iso_code":"MU"},"276":{"postal_code_type":"postal","postal_code_pattern":"976\\d{2}","postal_code_placeholder":"","country_iso_code":"YT"},"150":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MX"},"277":{"postal_code_type":"zip","postal_code_pattern":"(9694[1-4])(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"FM"},"148":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"MD"},"278":{"postal_code_type":"postal","postal_code_pattern":"980\\d{2}","postal_code_placeholder":"","country_iso_code":"MC"},"154":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MN"},"155":{"postal_code_type":"postal","postal_code_pattern":"8\\d{4}","postal_code_placeholder":"","country_iso_code":"ME"},"147":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MA"},"156":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"MZ"},"153":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MM"},"160":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"NA"},"166":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"NP"},"233":{"postal_code_type":"postal","postal_code_pattern":"988\\d{2}","postal_code_placeholder":"","country_iso_code":"NC"},"167":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"3974","country_iso_code":"NZ"},"163":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"NI"},"161":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"NE"},"162":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"NG"},"282":{"postal_code_type":"postal","postal_code_pattern":"2899","postal_code_placeholder":"","country_iso_code":"NF"},"283":{"postal_code_type":"zip","postal_code_pattern":"(9695[012])(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"MP"},"176":{"postal_code_type":"postal","postal_code_pattern":null,"postal_code_placeholder":"","country_iso_code":"KP"},"165":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"NO"},"168":{"postal_code_type":"postal","postal_code_pattern":"(?:PC )?\\d{3}","postal_code_placeholder":"","country_iso_code":"OM"},"169":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"PK"},"284":{"postal_code_type":"zip","postal_code_pattern":"(969(?:39|40))(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"PW"},"173":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"PG"},"178":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"PY"},"171":{"postal_code_type":"Postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"PE"},"172":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"PH"},"174":{"postal_code_type":"postal","postal_code_pattern":"\\d{2}-\\d{3}","postal_code_placeholder":"10-345","country_iso_code":"PL"},"177":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}-\\d{3}","postal_code_placeholder":"1000-205","country_iso_code":"PT"},"175":{"postal_code_type":"zip","postal_code_pattern":"(00[679]\\d{2})(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"PR"},"304":{"postal_code_type":"postal","postal_code_pattern":"9[78]4\\d{2}","postal_code_placeholder":"","country_iso_code":"RE"},"180":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"RO"},"181":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"101000","country_iso_code":"RU"},"308":{"postal_code_type":"postal","postal_code_pattern":"9[78][01]\\d{2}","postal_code_placeholder":"","country_iso_code":"BL"},"286":{"postal_code_type":"postal","postal_code_pattern":"(?:ASCN|STHL) 1ZZ","postal_code_placeholder":"","country_iso_code":"SH"},"288":{"postal_code_type":"postal","postal_code_pattern":"9[78][01]\\d{2}","postal_code_placeholder":"","country_iso_code":"MF"},"289":{"postal_code_type":"postal","postal_code_pattern":"9[78]5\\d{2}","postal_code_placeholder":"","country_iso_code":"PM"},"249":{"postal_code_type":"Postal","postal_code_pattern":"VC\\d{4}","postal_code_placeholder":"","country_iso_code":"VC"},"291":{"postal_code_type":"postal","postal_code_pattern":"4789\\d","postal_code_placeholder":"","country_iso_code":"SM"},"183":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"SA"},"185":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"SN"},"189":{"postal_code_type":"postal","postal_code_pattern":"\\d{5,6}","postal_code_placeholder":"","country_iso_code":"RS"},"220":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"SG"},"191":{"postal_code_type":"postal","postal_code_pattern":"\\d{3} ?\\d{2}","postal_code_placeholder":"","country_iso_code":"SK"},"192":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"SI"},"188":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{2} ?\\d{5}","postal_code_placeholder":"","country_iso_code":"SO"},"215":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"ZA"},"294":{"postal_code_type":"postal","postal_code_pattern":"SIQQ 1ZZ","postal_code_placeholder":"","country_iso_code":"GS"},"136":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"KR"},"99":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"28013","country_iso_code":"ES"},"142":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"LK"},"184":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"SD"},"295":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"SJ"},"194":{"postal_code_type":"postal","postal_code_pattern":"[HLMS]\\d{3}","postal_code_placeholder":"","country_iso_code":"SZ"},"193":{"postal_code_type":"postal","postal_code_pattern":"^\\d{5}$","postal_code_placeholder":"111 22","country_iso_code":"SE"},"80":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"CH"},"204":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}(?:\\d{2,3})?","postal_code_placeholder":"","country_iso_code":"TW"},"199":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"TJ"},"205":{"postal_code_type":"postal","postal_code_pattern":"\\d{4,5}","postal_code_placeholder":"","country_iso_code":"TZ"},"198":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"TH"},"164":{"postal_code_type":"postal","postal_code_pattern":"[1-9]\\d{3} ?(?:[A-RT-Z][A-Z]|S[BCE-RT-Z])","postal_code_placeholder":"1105 AW","country_iso_code":"NL"},"202":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"TN"},"203":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"TR"},"200":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"TM"},"299":{"postal_code_type":"postal","postal_code_pattern":"TKCA 1ZZ","postal_code_placeholder":"","country_iso_code":"TC"},"207":{"postal_code_type":"postal","postal_code_pattern":"^([0-8][0-9]{4}|9[0-3][0-9]{3}|94[0-8][0-9]{2}|949[0-8][0-9]|9499[0-9])$","postal_code_placeholder":"","country_iso_code":"UA"},"105":{"postal_code_type":"postal","postal_code_pattern":"^(GIR ?0AA|((AB|AL|B|BA|BB|BD|BF|BH|BL|BN|BR|BS|BT|BX|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}))|BFPO ?\\d{1,4})$","postal_code_placeholder":"NW1 6XE","country_iso_code":"GB"},"209":{"postal_code_type":"zip","postal_code_pattern":"^\\d{5}(?:-\\d{4})?$","postal_code_placeholder":"12345","country_iso_code":"US"},"302":{"postal_code_type":"zip","postal_code_pattern":"96898","postal_code_placeholder":"","country_iso_code":"UM"},"208":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"UY"},"248":{"postal_code_type":"zip","postal_code_pattern":"(008(?:(?:[0-4]\\d)|(?:5[01])))(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"VI"},"210":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"UZ"},"211":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"VE"},"212":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}\\d?","postal_code_placeholder":"","country_iso_code":"VN"},"224":{"postal_code_type":"postal","postal_code_pattern":"986\\d{2}","postal_code_placeholder":"","country_iso_code":"WF"},"213":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"EH"},"217":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"ZM"}},"ship_to_preference_capabilities":{"209":{"postal_code":{"is_assignable":true,"is_required":true}},"79":{"postal_code":{"is_assignable":true,"is_required":true}},"122":{"postal_code":{"is_assignable":true,"is_required":true}},"61":{"postal_code":{"is_assignable":true,"is_required":true}},"105":{"postal_code":{"is_assignable":true,"is_required":true}}},"category_id":68887416,"admin_tools_page_data":[],"currency_data":{"currency_id":826,"code":"GBP","name":"British Pound","number_precision":2,"symbol":"\u00a3","listing_enabled":true,"browsing_enabled":true,"buyer_location_restricted":false,"rate_updates_enabled":true},"machine_translation\/listings_click_to_translate":true,"ads.prolist\/log_clicks_and_impressions":false,"mfg\/dovetail":true,"mfg\/buyer_facing_dovetail":true,"searchx\/4q18\/dwell_time_as_backend_event":false,"is_regulatory_buyer_disclosure_enabled":true,"is_convos_condensed_disclosure_enabled":false,"machine_translation":{"mode":"disabled","listing_id":1498491133,"to_lang_code":"en-US","from_lang_code":"en-US","translated":null,"untranslated":null,"category_tags":null},"listing_fee":20,"presented_listing_fee":"$0.20 USD","listing_period_months":4,"apple_pay_api_version_number":12,"render_is_gift_section":true,"coupons_in_buy_box_is_enabled":false,"is_eligible_web_components":false,"should_show_atc_from_listing_cards":true,"should_show_atc_from_listing_cards_mweb":false,"added_to_cart_text":"Added to cart!","speculation_rules_prefetch":false,"speculation_rules_prefetch_from_search":false,"prefetch_event_cache_key":"","should_show_sidebar_cart_post_atc_recs":false,"is_eligible_for_trust_suite_section":false,"is_gift_guide_flyout_enabled":false,"should_hide_sub_nav":true,"should_show_breadcrumbs":true,"listing_image_url":"","eligible_for_mini_collections_and_ignore_menu":false,"image_ids_by_listing_variation_ids":[],"should_show_scrollable_thumbnails":true,"should_show_video":true,"shouldShowThumbnails":true,"carousel_height_percentage_relative_to_width":[80,80,80,80,80,80,80,80,80,80],"is_mobile_experience":false,"is_users_own_listing":false,"listing_sale_price_is_gamed":false,"lp_toffers_v2_true_sale_enabled":false,"sale_ending_soon_countdown":true,"should_show_histogram_panel":false,"anchor_shop_name_to_seller_cred":false,"shop_reviews_count":981079,"neu_buy_box_type":"offerings","listing_id":1498491133,"klarna_osm_js":"https:\/\/js.klarna.com\/web-sdk\/v1\/klarna.js","is_eligible_for_klarna_osm":false,"is_eligible_for_variations_update":true,"can_listing_have_coupon_applied":false,"quantity_submodule_enabled":true,"is_multiple_questions_enabled_buyer":true,"personalization_is_required":true,"personalization_field_count":1,"how_its_made_label_type":"seller_designed","product_details_content_toggle_selector":"[data-wt-content-toggle][aria-controls='content-toggle-product-details-read-more']","should_show_description_content_toggle":true,"use_shipping_variant_view":true,"shipping_section_default_open":true,"shipping_and_returns_is_eligible_for_sticky_buy_box":true,"estimated_shipping_is_eligible_for_sticky_buy_box":true,"is_eligible_for_shipping_and_returns_cleanup":true,"is_postal_code_empty_on_initial_load":true,"invalid_postal_codes":{"209":["000","001","002","003","004","213","269","343","345","348","353","419","428","429","517","518","519","529","533","536","552","568","569","578","579","589","621","632","642","643","659","663","682","694","695","696","697","698","699","702","709","715","732","742","771","817","818","819","839","848","849","854","858","861","862","866","867","868","869","872","886","887","888","892","896","899","909","929","987"]},"is_eligible_for_policies_in_overlay":true,"active_tab":"same_listing_reviews","allow_reviews_debug":false,"using_mweb_tabs":false,"load_tabbed_layout_js":true,"should_show_helpful_count":true,"should_default_chronological_sort":false,"should_include_subratings":true,"current_page":1,"is_deep_dive":false,"has_appreciation_photos":true,"eligible_for_review_photo_filter_and_sort":true,"is_new_deep_dive":false,"photos_per_page":4,"review_categorical_tags_enabled":true,"review_hide_sort_by_prefix":true,"mweb_can_scroll_to_seller_cred_module":false,"is_eligible_for_showing_more_items_on_explore_more":false,"structured_policies_messages":{"module_name":"Shop policies","last_updated_on":"Last updated on","publish":"Publish Shop Policies","policies_save":"Save policies","policies_edit":"Edit policies","cancel":"Cancel","revert":"Use previous policies","edit":"Edit","loading":"Loading","preview_banner_kicker":"Policies preview","not_existing_policies_preview_banner_header":"Review and customize these policies so they work for you","preview_banner_body":"You can publish these to your shop or edit them if you need to make changes","preview_publish_confirm":"By clicking Publish, you'll post your Shop Policies and agree to comply with them.","revert_confirm":"Are you sure you want to revert?","leave_page_warning":"You are currently editing shop policies","private_receipt_info_title":"Private receipt info","private_receipt_info_body":"We have removed the 'Private Receipt Info' section of your policies page. You don't need to populate this section for the purposes of complying with international consumer protection laws anymore because this new Policies feature will automatically display the relevant content of your shop policies within the buyer receipt email instead.","private_receipt_info_link":"See this FAQ for more information","structured_banner_title":"Switch to simple shop policies","structured_banner_title_v2":"Set up simple shop policies","structured_banner_body":"We'll give you a quick template to create your shop policies in seconds.","structured_banner_button":"Try it now","new_simplified_policies":"Your new, simplified policies","new_policies_banner_description_1":"Buyers prefer policies that are short, clear and address their key concerns, so we've designed them that way.","new_policies_banner_description_2":"Review and customize these policies so they work for you. We've saved your previous policies, so you can always switch back.","new_policies_banner_description_3":"We've saved your previous policies, so you can always switch back.","new_policies_banner_learn_more":"Learn more","publish_policies_success":"Your new policies have been published!","publish_policies_error":"There was an error publishing your policies. Please try again.","policies_failed_to_load":"Shop policies failed to load","policies_try_again":"Try again","policies_saving":"Saving...","policies_publishing":"Publishing...","listing_preview_shipping":"This section will show shipping or download information once you publish your listing.","craft_shipping_section_title":"Shipping & policies","craft_payments_section_title":"Payments","craft_refunds_section_title":"Returns & exchanges","craft_terms_section_title":"Terms & conditions","craft_more_details_accordion_label":"+ See more...","listing_returns_and_exchanges":"See item details for return and exchange eligibility.","no_policies":"Looks like this shop doesn't have any custom policies. Have questions?","message_the_seller":"Message the seller","shipping_section_title":"Shipping","payments_section_title":"Payments","refunds_section_title":"Returns & exchanges","digital_section_title":"Downloads","terms_section_title":"Terms & conditions","more_details_accordion_label":"See more...","seller_details_section_title":"More information"},"shop_policy_selector":"[data-content-toggle-uid=shop_policies]","load_user_faves_option":true,"update_many_faves_option":true,"is_async_only_faves_option":false,"guest_favorites_enabled":true,"collection_count":0,"favorites_key":"","use_clearer_privacy_description":true,"conditional_sale_interstitial":true,"google_client_id":"296956783393-2d8r0gljo87gjmdpmvkgbeasdmelq33e.apps.googleusercontent.com","show_one_tap_modal":false,"is_google_one_tap_cart_page":false});
        })();
    </script>

    <script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">__webpack_public_path__ = "https://www.etsy.com/ac/evergreenVendor/js/en-US/";</script>

    <script src="https://js.sentry-cdn.com/ba12d66291e647788d8a9f0878043603.min.js" crossorigin="anonymous" nonce="+gWSoSeB7oJ/5IB7H6o53UJw"></script>
<script nonce="+gWSoSeB7oJ/5IB7H6o53UJw">(function() {
var asyncAvailable = true;
try {
    eval("async () => {}");
} catch(e) {
    asyncAvailable = false;
}

var falseUA = true && !asyncAvailable;
var primarySupportsAsync = !true && asyncAvailable;

var clientloggerIsEnabled = true;
if (clientloggerIsEnabled) {
    if (falseUA) {
        new Image().src = '/clientlog?falseua=1';
    }
    if (primarySupportsAsync) {
        new Image().src = '/clientlog?primarysupportsasync=1';
    }
    if (window.__etsy_logging && window.__etsy_logging.bots && (window.__etsy_logging.bots.isBot || window.__etsy_logging.bots.botCheck.length > 0)) {
        new Image().src = '/clientlog?feisbot=1&bot_check=' + encodeURIComponent(JSON.stringify(window.__etsy_logging.bots.botCheck));
    }
}

    if (typeof Sentry !== 'object') { return; }

    function breadcrumbFilter (arr_xhr, arr_console) {
        return function (crumb) {
            if (typeof crumb === 'object') {
                if (crumb.category === 'xhr'
                    && typeof crumb.data === 'object'
                    && typeof crumb.data.url === 'string') {
                    return !arr_xhr.some(function (re) {
                        return crumb.data.url.match(re);
                    }) && crumb;
                } else if (crumb.category === 'console'
                           && typeof crumb.message === 'string') {
                    return !arr_console.some(function (re) {
                        return crumb.message.match(re);
                    }) && crumb;
                }
            }
            return crumb;
        };
    }

    function beforeSend(event, hint) {
        try {
            if (hint.originalException.detail.reason.message === 'Extension context invalidated.') {
                return null;
            }
        } catch(_ignore) {
        }

        var serverUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36".trim();
        var browserUA = navigator.userAgent.trim();
        var mismatch = serverUA !== browserUA;

        if (mismatch) {
            return null;
        }

        if (falseUA) {
            return null;
        }

        event.request = event.request || {};
        event.request.headers = event.request.headers || {};
        event.extra = event.extra || {};

        event.request.headers["User-Agent"] = serverUA;
        event.extra["browser_side_user_agent"] = browserUA;

        if (window.__etsy_logging && window.__etsy_logging.bots && window.__etsy_logging.bots.isBot) {

            return null;
        }

        return event;
    }
    Sentry.onLoad(function() {
        var options = {
            release: 'ed238592a490b126-prod',
            environment: 'Production',
            autoSessionTracking: false,
            beforeSend: beforeSend,
            beforeBreadcrumb: breadcrumbFilter([/wpnseo.com.au\/es\/\/bcn\/beacon$/i, /\/icht.etsysecure.com\//i], [/https\:\/\/www\.wpnseo.com.au\.com\/careers/]),
            ignoreErrors: ["top.GLOBALS", /https\:\/\/www\.youtube\.com/, /undefined is not an object.*dataLayerTransactions.length/, /https\:\/\/tpc\.googlesyndication\.com/, /http\:\/\/wpnseo.com.au\.co\.uk/, /http\:\/\/wpnseo.com.au\.com/, /https\:\/\/www\wpnseo.com.au\.net/, /staticxx\.facebook\.com/, /__firefox__/, /JSON syntax error/, /https\:\/\/bid\.g\.doubleclick\.net/, /https\:\/\/5094987\.fls\.doubleclick\.net/, /https\:\/\/www\.google\.com/, /https\:\/\/www\wpnseo.com.au\.com/, /Cannot read property.*DOMNodeInsertedByJs/, /e.tagName.toLowerCase/, /twttr/, /PAPADDINGXXPADDINGPADDINGXXPADDINGPADDINGXXPADDINGPADDINGXXPADDINGPADDINGXXPADDINGPADDINGX/, /Error calling method on NPObject/, /Access is denied./, /document\.getElementsByClassName\.ToString/, /https\:\/\/accounts\.google\.com/, /_isMatchingDomain/, /NS_ERROR_NOT_INITIALIZED/, /loginFormData\.userNameValue/, /find variable: \$pr/, /\$pr is not defined/, /find variable: _AutofillCallbackHandler/],
            allowUrls: [/etsystatic\.com/, /etsy\.com\/paula/, /etsy\.com\/d?ac/, /etsy\.com\/daj/, /etsycorp\.com/, /etsycloud\.com/],
            denyUrls: [],
            sampleRate: 1.0,
        };


        Sentry.init(options);

        var hasViteAsset = Array.from(document.scripts).find(function (script) {
            return /\/[a-z]+[vV]ite\//.test(script.src);
        });

        Sentry.configureScope(function(scope) {
            scope.setUser({"id":"uj0nemGYfZm0u5UhoRQWjT5qMRzf","ip_address":"202.126.110.18"});
            scope.setTags({"user_id":null,"is_signed_in":false,"is_web_view":false,"is_atlas_request":false,"request_uuid":"EunhLnzL4sAYJypZdeOPahA2o_53","locale":"en-US","build_variant":"evergreenVendor","polyfill":"paula","neu_runtime_tracing":"off","fullstory":"off","speedcurve_lux":"off","primary_event_name":"view_listing"});
            scope.setExtras({"server_side_user_agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"});
            scope.setTag('has_vite_asset', hasViteAsset ? 'true' : 'false');
        });

        window.__etsy_logging.errorQueue.forEach(function(errorData) {
            if (errorData[4]) {
                Sentry.captureException(errorData[4]);
            }
        });
    });
})();</script>

   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/vendor_bundle.4b28aa70c9cca35746a4.js" type="text/javascript" nonce="+gWSoSeB7oJ/5IB7H6o53UJw" crossorigin defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/etsy_libs.80be4aa737e18e6d1fe5.js" type="text/javascript" nonce="+gWSoSeB7oJ/5IB7H6o53UJw" crossorigin defer></script>
   <script src="https://www.etsy.com/paula/v3/polyfill.min.js?etsy-v=v5&flags=gated&features=AbortController%2CDOMTokenList.prototype.@@iterator%2CDOMTokenList.prototype.forEach%2CIntersectionObserver%2CIntersectionObserverEntry%2CNodeList.prototype.@@iterator%2CNodeList.prototype.forEach%2CObject.preventExtensions%2CString.prototype.anchor%2CString.raw%2Cdefault%2Ces2015%2Ces2016%2Ces2017%2Ces2018%2Ces2019%2Ces2026%2Ces2021%2Ces2022%2Cfetch%2CgetComputedStyle%2CmatchMedia%2Cperformance.now" type="text/javascript" nonce="+gWSoSeB7oJ/5IB7H6o53UJw" crossorigin defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/app-shell/globals/index.a102ed4d03005c7067f5.js" type="text/javascript" nonce="+gWSoSeB7oJ/5IB7H6o53UJw" crossorigin defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/@etsy-modules/ConsentManagement/Transcend-Integration.5952c095cb0676fe13c9.js" type="text/javascript" nonce="+gWSoSeB7oJ/5IB7H6o53UJw" crossorigin defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/bootstrap/listings3/main.125161e9593a75b27a7b.js" type="text/javascript" nonce="+gWSoSeB7oJ/5IB7H6o53UJw" crossorigin defer></script>

        <main id="content">
            <div data-ui="listing-breadcrumbs" class="wt-hide-xs wt-show-lg breadcrumb_nav">
    <div data-ui="cat-nav" id="desktop-category-nav" class="cat-nav  v2-toolkit-cat-nav wt-ml-xs-0 wt-mr-xs-0">
        <div class="wt-text-caption wt-position-relative wt-z-index-5 wt-pt-xs-2">
                <div class="wt-grid wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-6 wt-pr-lg-6">
                <ul class="wt-list-unstyled wt-grid__item-xs-12 wt-body-max-width wt-display-flex-xs wt-justify-content-center" data-menu-ui="menubar" data-ui="top-nav-category-list">
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link data-menu-ui="menuitem" tabindex="0" href="https://rescuevolunteers.org/about-us/">EMO78</a>
                                <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link data-menu-ui="menuitem" tabindex="0" href="https://rescuevolunteers.org/about-us/">LOGIN BANDAR SLOT</a>
                             <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link data-menu-ui="menuitem" tabindex="0" href="https://rescuevolunteers.org/about-us/">situs slot pulsa</a>
                             <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link data-menu-ui="menuitem" tabindex="0" href="https://rescuevolunteers.org/about-us/">LINK LOGIN TERBARU</a>
                             <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>
                        </li>
                           <pre> | </pre> 
                            
                            <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <span style="color: #0F4D4A;">EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78</span>
                        </li>
                </ul>
                <span class="active-nav-item-indicator wt-position-absolute wt-display-inline-block" data-ui="active-nav-item-indicator"></span>
        </div>
        </div>
    </div>
</div>



<div data-selector="listing-page-content" class="content-wrap listing-page-content">

    

    

    <div class="wt-pt-xs-5 listing-page-content-container-wider wt-horizontal-center">

        <div id="listing-right-column" class="listing-buy-box-experiment">

            <div>
                <div class="body-wrap wt-body-max-width wt-display-flex-md wt-flex-direction-column-xs">
                    <div class="image-col wt-order-xs-1 wt-mb-xs-2 wt-mb-lg-6 wt-pl-md-4 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2 wt-pr-xl-2 wt-pr-md-4 wt-pr-lg-0">
                        <div class="wt-flex-lg-6 wt-mr-lg-3 wt-pr-xl-3">
                            <div class="image-wrapper wt-position-relative carousel-container-responsive" id="photos">
    

        <div data-listing-page-badge
            style="margin-left: 78px; "
            class="wt-position-absolute wt-z-index-2 wt-position-top wt-position-left wt-mt-xs-1"
        >
            <div class="wt-popover" data-wt-popover>
    <button data-wt-popover-trigger
            class="wt-popover__trigger wt-popover__trigger--underline wt-display-inline-flex-xs wt-align-items-center wt-text-caption"
            aria-disabled="true"
            aria-describedby="etsys_pick"
    >
<span data-clg-id="WtBadge" class="wt-badge wt-badge--statusRecommendation wt-pl-xs-2">
                <span class="wt-icon wt-icon--smaller-xs wt-nudge-r-3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m15.4 14.1-3.7-1.9-1.8-3.6c-.3-.7-1.4-.7-1.8 0l-1.9 3.7-3.7 1.9c-.3.1-.5.4-.5.8q0 .6.6.9l3.7 1.9 1.9 3.7c.1.3.4.5.8.5q.6 0 .9-.6l1.9-3.7 3.7-1.9c.3-.2.6-.5.6-.9s-.3-.6-.7-.8m6-8L19 4.9l-1.2-2.4c-.3-.7-1.4-.7-1.8 0l-1.2 2.4-2.4 1.2c-.2.2-.4.5-.4.9q0 .6.6.9L15 9.1l1.2 2.4c.2.3.5.6.9.6q.6 0 .9-.6l1.2-2.4 2.4-1.2c.2-.2.4-.5.4-.9q0-.6-.6-.9"/></path></svg></span>

</span>
    </button>
    <div id="etsys_pick" role="tooltip">
        EMO78 link login terbaru bandar slot online terpercaya mudah raih JP maxwin setiap hari. Temukan situs slot terpercaya paling hits yang sediakan server paling stabil dan bet rendah! <p class="wt-mt-xs-3"><a href="https://rescuevolunteers.org/about-us/" target="_blank">m</a></p>
    </div>
</div>
        </div>

    
        <button
            class="btn--focus  wt-position-absolute wt-btn wt-btn--light wt-btn--small wt-z-index-2 wt-btn--filled wt-btn--icon wt-btn--fixed-floating wt-position-right wt-mr-xs-2 wt-mt-xs-2"
            data-ui="favorite-listing-button"
            data-listing-id="1498491133"
            data-accessible-btn-fave
            data-favorite-label="Add to Favorites"
            data-favorited-label="Remove from Favorites"
            
            
            data-always-show="true"
            
            
            
        >
            <div class="favorite-listing-button-icon-container should-animate "
                 data-source="lp_image_carousel" 
                data-btn-fave
                data-neu-fave
                data-favorite-icon-container
            >
                <span class="etsy-icon wt-nudge-t-1&#10;                    &#10;                    &#10;                        &#10;                        &#10;                            wt-display-block&#10;                        &#10;                    " data-not-favorited-icon=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M20.877 12.52q.081-.115.147-.239A6 6 0 0 0 12 4.528a6 6 0 0 0-9.024 7.753q.066.123.147.24l.673.961a6 6 0 0 0 .789.915L12 21.422l7.415-7.025q.44-.418.789-.915zm-14.916.425L12 18.667l6.04-5.722q.293-.279.525-.61l.673-.961a.3.3 0 0 0 .044-.087 4 4 0 1 0-7.268-2.619v.003L12 8.667l-.013.004v-.002l-.006-.064a3.98 3.98 0 0 0-1.232-2.51 4 4 0 0 0-6.031 5.193q.014.045.044.086l.673.961a4 4 0 0 0 .526.61"/></path></svg></span>
                <span class="etsy-icon wt-nudge-t-1 wt-text-favorite-heart&#10;                    &#10;                    &#10;                        &#10;                        &#10;                            wt-display-none&#10;                        &#10;                    " data-favorited-icon=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21.024 12.281a2 2 0 0 1-.147.24l-.673.961q-.349.497-.789.915L12 21.422l-7.415-7.025a6 6 0 0 1-.789-.915l-.673-.961a2 2 0 0 1-.147-.24A6 6 0 0 1 12 4.528a6 6 0 0 1 9.024 7.753"/></path></svg></span>
            </div>
            <span aria-hidden="true" class="icon"></span>
            <span class="wt-screen-reader-only" data-a11y-label>
                
                Add to Favorites
            </span>
            </button>
        
    

    <div class="listing-page-image-carousel-component wt-display-flex-xs is-initialized" data-component="listing-page-image-carousel" data-palette-listing-id="1498491133" data-shop-id="25947065">

    <div class="image-carousel-container wt-position-relative wt-flex-xs-6 wt-order-xs-2
                
                show-scrollable-thumbnails">

        <ul class="wt-list-unstyled wt-overflow-hidden wt-position-relative carousel-pane-list"
            style="padding-top: 80%;"
            data-carousel-pane-list
            tabindex="0">
                    <li class="wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="0" data-image-id="6845617078" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 1"
                            data-carousel-first-image
                            data-perf-group="main-product-image"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg"
                            fetchpriority="high"
                            data-original-image-width="3000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="0"
                        />
                    </li>
                        <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane no-zoom"
                            data-carousel-pane
                            data-video-pane
                            data-no-zoom
                            data-index="1"
                        >
                            <div class="wt-width-full wt-height-full">
                                
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--02 wt-mt-xs-0 wt-vertical-center wt-display-none" aria-live="assertive" data-video-loading-icon="" aria-hidden="true">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><circle fill="transparent" cx="24" cy="24" r="21"/></circle></svg></span>
        Loading
    </div>

                                <video id="listing-video-1"
                                      muted
                                      controls
                                      preload="none"
                                      class="wt-horizontal-center wt-vertical-center listing-video-responsive-container wt-rounded"
                                      aria-label="Product video"
                                >
                                        <source src="img/banner.jpg" type="video/mp4">
                                </video>
                                <div
                                    class="video-play-overlay wt-display-none"
                                    data-video-play-overlay
                                >
                                    <div
                                        class="wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full wt-display-flex-xs wt-justify-content-center wt-align-items-center"
                                    >
                                        <div class="video-play-overlay-icon wt-circle wt-overflow-hidden wt-bg-white wt-p-xs-2 wt-shadow-elevation-3">
                                            <span class="wt-icon wt-icon--largest"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 2 20 20" aria-hidden="true" focusable="false"><polygon points="4 4 4 20 20 12 4 4"/></polygon></svg></span>
                                        </div>
                                    </div>
                                </div>
                                <div data-video-error-state class="wt-display-none wt-vertical-center wt-text-center-xs" aria-hidden="true" aria-role="alert">
                                    <p class="wt-text-body-01">
                                        Hm, we’re having trouble loading this video.
                                    </p>
                                    <p class="wt-text-caption">
                                        Try to refresh the page or come back later.
                                    </p>
                                </div>
                            </div>
                        </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="2" data-image-id="6354031418" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 2"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="2"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="3" data-image-id="6402117407" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 3"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="3"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="4" data-image-id="6354386589" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 4"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="4"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="5" data-image-id="6285298756" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="name yarn jumper for kids"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="5"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="6" data-image-id="6430051759" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 6"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="6"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="7" data-image-id="7056312285" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 7"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="7"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="8" data-image-id="6332997945" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 8"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="8"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="9" data-image-id="6722497805" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 9"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="9"
                        />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="10" data-image-id="6356157787" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                            alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 10"
                            loading="lazy"
                            src="img/banner.jpg"
                            srcset="img/banner.jpg 1x, img/banner.jpg 2x"
                            data-perf-group="secondary-product-image"
                            data-original-image-width="2000"
                            data-src-zoom-image="img/banner.jpg"
                            data-index="10"
                        />
                    </li>
        </ul>
            <button data-carousel-nav-button
                data-direction="prev"
                class="wt-circle wt-overflow-hidden wt-position-absolute wt-vertical-center wt-position-left wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-shadow-elevation-3 wt-ml-xs-2"
                aria-label="Previous image"
            >
                <span class="etsy-icon wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z"/></path></svg></span>
            </button>
            <button data-carousel-nav-button
                data-direction="next"
                class="wt-circle wt-overflow-hidden wt-position-absolute wt-vertical-center wt-position-right wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-shadow-elevation-3 wt-mr-xs-2"
                aria-label="Next image"
            >
                <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z"/></path></svg></span>
            </button>
    </div>

            <div>
                <div class="carousel-pagination-item-v2 wt-position-absolute wt-position-top wt-position-left wt-z-index-9"
                    data-thumbnail-scroll-up>

                </div>

                <div class="carousel-pagination-item-v2 wt-position-absolute wt-position-bottom wt-position-left wt-z-index-9"
                    data-thumbnail-scroll-down>

                </div>

                <div class="wt-position-absolute wt-overflow-scroll wt-position-top wt-position-bottom
                    wt-position-left scroll-container-no-scrollbar"
                    data-thumbnail-scroll-container>
            <ul data-carousel-pagination-list class="wt-list-unstyled wt-display-flex-xs
                wt-order-xs-1 wt-flex-direction-column-xs wt-align-items-flex-end">
                        <li data-carousel-pagination-item="" data-index="0" data-image-id="6845617078" class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2 is-active" tabindex="0">
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 1" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 1 of 10" data-should-fade-in-on-load="true" />
                        </li>

                            <li data-carousel-pagination-item
                                data-carousel-thumbnail-video
                                data-index="1"
                                data-image-id="listing-video-1"
                                class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                tabindex="0"
                            >
                                <div class="wt-position-relative wt-height-full">
                                    <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" data-carousel-thumbnail-image="" src="img/banner.jpg" data-src-delay="img/banner.jpg" data-should-fade-in-on-load="true" alt="Product video" />
                                    <div data-carousel-video-icon class="wt-display-none wt-circle wt-overflow-hidden video-thumbnail-icon wt-position-top wt-position-bottom wt-position-right wt-position-left wt-bg-white wt-shadow-elevation-3">
                                        <span class="etsy-icon video-thumbnail-icon__with-image wt-position-top wt-position-bottom wt-position-right"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polygon points="4 4 4 20 20 12 4 4"/></polygon></svg></span>
                                    </div>
                                </div>
                            </li>

                        <li data-carousel-pagination-item
                            data-index="2"
                            data-image-id="6354031418"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 2" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 2 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="3"
                            data-image-id="6402117407"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 3" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 3 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="4"
                            data-image-id="6354386589"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 4" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 4 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="5"
                            data-image-id="6285298756"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="name yarn jumper for kids" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 5 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="6"
                            data-image-id="6430051759"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 6" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 6 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="7"
                            data-image-id="7056312285"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 7" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 7 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="8"
                            data-image-id="6332997945"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 8" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 8 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="9"
                            data-image-id="6722497805"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 9" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 9 of 10" data-should-fade-in-on-load="true" />
                        </li>

                        <li data-carousel-pagination-item
                            data-index="10"
                            data-image-id="6356157787"
                            class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                            tabindex="0"
                        >
                            <img class="wt-animated wt-max-width-full wt-width-full wt-animated--appear-01" src="img/banner.jpg" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 10" data-carousel-thumbnail-image="" data-src-delay="img/banner.jpg" aria-label="product image 10 of 10" data-should-fade-in-on-load="true" />
                        </li>

            </ul>
                </div>
            </div>

        
</div>
</div>

<div class="wt-display-flex-xs wt-justify-content-flex-end wt-mt-xs-3">
        <a class="wt-text-link wt-text-link-underline" href="https://rescuevolunteers.org/about-us/signin?from_page=https%3A%2F%2pphouse.org/es%2Fpost">
        <span class="wt-icon wt-icon--smaller-xs wt-nudge-r-4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M7 3a1 1 0 0 0-2 0v18a1 1 0 1 0 2 0v-6h14.766l-3.6-6 3.6-6zm0 2v8h11.234l-2.4-4 2.4-4z"/></path></svg></span>Report this item to LOGIN BANDAR SLOT
    </a>
    </div>

                        </div>
                    </div>

                    <div class="cart-col wt-order-xs-2 wt-mb-lg-5">
    <div id="listing-page-cart" class="wt-display-flex-lg wt-flex-direction-column-md wt-flex-lg-3 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
        <div class="wt-mb-xs-1 wt-mt-xs-1">
            <div data-appears-component-name="m-Modules-ListingPage-UrgencySignal-RecsRankingApiSpec" data-appears-event-data='{"module_placement":"lp_urgency_signals","datasets":["Common_Signal_CustomCandidatesSignalRankerV3"],"targets":[],"logging_class":"m\\Modules\\ListingPage\\UrgencySignal\\RecsRankingApiSpec","page_listing_id":1498491133,"mmx_request_uuid_map":{"5143dd58-1944-4e40-8b7e-02b5b89c59ea":[0,1,2]},"candidate_source_map":{"signals-ranker-v3-extractor":[0,1,2]},"second_pass_ranker_map":{"signals-ranker-v3":[0,1,2]},"client_provided_features":{"browser":{"acceptLanguage":"en-US","browser":"Chrome","currency":"IDR","localeRegion":"ID","operatingSystem":"Windows 11","platform":"desktop","platformmApp":"web","platformMobileDevice":"unidentified","source":"directLanding"},"date_time":{"dayOfWeek":"2","hourOfDay":"18"},"user":{"locationLatitude":null,"locationLongitude":null,"locationZip":"unidentified","userPreferredLanguage":"en-US"}},"scores":[0.58056300000000005123723667566082440316677093505859375,0.48064099999999998491517771981307305395603179931640625,0.37174099999999998811262003073352389037609100341796875],"datasets_map":{"Common_Signal_CustomCandidatesSignalRankerV3":[0,1,2]},"target_listing_id":1498491133,"candidates":["recently_purchased","in_cart_only","lp_views_only"],"refTag":"lp_urgency_signals","signals":["recently_purchased","in_cart_only","lp_views_only"],"rec_event_name":"recommendations_module"}' class='recs-appears-logger'>
                <p class="wt-text-title-01 wt-sem-text-critical "><span style="color: #0F4D4A;">EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78</span></p></div></div>
            <div class="wt-display-flex-xs wt-align-items-center">
        <div data-appears-component-name="price">
<div class="wt-display-flex-xs wt-align-items-center wt-flex-wrap"
     data-selector="price-only"
     data-buy-box-region="price"
>
        <p class="wt-text-title-larger wt-mr-xs-1
                wt-text-slime
            "
        >
        <span class="wt-screen-reader-only">Harga:</span>
        Rp 5.000+
    </p>
        <p class="wt-text-caption wt-sem-text-secondary">
            <span class="wt-screen-reader-only">Normal:</span>
            <span class="wt-text-strikethrough  ">
                Rp 100,000+
            </span>
        </p>
        
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--01 wt-display-none" aria-live="assertive" data-buy-box-price-spinner="">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"/></circle></svg></span>
        Loading
    </div>

</div>
</div>
                                <div class="wt-ml-xs-2">
                                    <span data-clg-id="WtBadge" class="wt-badge wt-badge--statusValue">
        <strong>95% Gratis</strong>

</span>
                                </div>
        </div>
                <div class="wt-mb-xs-1  ">
                        <div id="sale-ending-soon-countdown">
    <p class="wt-text-title-01 wt-sem-text-monetary-value"
        data-24-hour-sale-wrapper>
        Diskon segera berahir <span class='listing-24-sale-countdown' data-end-date=1757519999>24:00:00</span>
    </p>
</div>

<a href="https://rescuevolunteers.pages.dev/" rel="nofollow noopener" target="_blank"><img src="img/daftar.gif" width="100%" height="auto" alt="daftar slot"></a>
  </div>
                    
                </div>
        
        <div data-buy-box-region="vat_messaging">
        <div class="wt-sem-text-secondary wt-text-caption wt-pt-xs-1 wt-pb-xs-1">
            Syarat dan ketentuan (berlaku)
        </div>
</div>
        
        
            <div class="wt-mt-xs-1 wt-mb-xs-1">
                <p><span style="color: #000000;"><a style="color: #ee00e2;" title="LOGIN EMO78"
                            href="https://rescuevolunteers.org/about-us/">Bandar Slot</a></span><span style="color: #000000;"> adalah link login bandar slot terpercaya gampang jp maxwin 2026, menawarkan server stabil dengan bet rendah. 
            </span></p>
            <br>
            
            </div>
        <div class="wt-mb-xs-3">
            <div class="wt-display-inline-flex-xs wt-align-items-center wt-flex-wrap lp-shop-header">
    <div class="wt-display-inline-flex-xs wt-align-items-center">
    
        <span class="wt-text-title-small">
    <a href="https://rescuevolunteers.org/about-us/" class="wt-text-link-no-underline wt-sem-text-primary">
        DAFTAR EMO78
    </a>
</span>
            &nbsp;<div class="wt-popover star-seller-badge-listing-page" data-wt-popover>
    <button data-wt-popover-trigger class="wt-popover__trigger wt-popover__trigger--underline" aria-label="Star Seller" aria-describedby="star-seller-popover">
        <span class="wt-icon wt-icon--smaller-xs wt-icon--core wt-fill-star-seller-dark" alt="star_seller"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m20.902 7.09-2.317-1.332-1.341-2.303H14.56L12.122 2 9.805 3.333H7.122L5.78 5.758 3.341 7.09v2.667L2 12.06l1.341 2.303v2.666l2.318 1.334L7 20.667h2.683L12 22l2.317-1.333H17l1.342-2.303 2.317-1.334v-2.666L22 12.06l-1.341-2.303V7.09zm-6.097 6.062.732 3.515-.488.363-2.927-1.818-3.049 1.697-.488-.363.732-3.516-2.56-2.181.121-.485 3.537-.243 1.341-3.273h.488l1.341 3.273 3.537.243.122.484z"/></path></svg></span>
    </button>
    <div class="wt-p-xs-3" id="star-seller-popover" role="tooltip">
        <p class="wt-mb-xs-1 wt-text-title-01">
            Star Seller
        </p>
        <p class="wt-text-caption">
            Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.
        </p>
    </div>
</div>
    </div>
        <div class="wt-ml-xs-1">
            <div class="wt-text-link-no-underline review-stars-text-decoration-none">
    <a href="#reviews" data-click-source="review_stars" aria-label="4.9 out of 5 stars. See reviews."><span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container>
    <input type="hidden" name="initial-rating" value="4.8554" />
    <input type="hidden" name="rating" value="4.8554" />
    <span class="wt-screen-reader-only">5 out of 5 stars</span>

    <span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"/></path></svg></span>
    </span>
</span></a>
</div>
        </div>
    
</div>
        </div>
        <div class="wt-mb-xs-6 wt-mb-lg-0">
            <div data-buy-box>
    <div class="wt-mb-xs-3">
        
        
        <div data-appears-component-name="variations">
<div data-selector="listing-page-variations">
    <div
    class="wt-validation wt-mb-xs-2"
    data-selector="listing-page-variation"
    data-variation-number="0"
>
</div>

</div>
</div>
</div>
</div>
        <div class="wt-validation wt-mb-xs-2" data-selector="listing-page-personalization" data-personalization-required>
    <div class="wt-content-toggle">
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-btn--small wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-selector="enhanced-perso-content-toggle" data-wt-content-toggle="true" data-animate="true" aria-controls="enhanced-perso-content">
                <span class="wt-icon wt-icon--smaller-xs" data="button-icon-add"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20,11H13V4a1,1,0,0,0-2,0v7H4a1,1,0,0,0,0,2h7v7a1,1,0,0,0,2,0V13h7A1,1,0,0,0,20,11Z"/></path></svg></span>
            <span class="wt-icon wt-icon--smaller-xs wt-display-none" data="button-icon-minus"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20 13H4c-.553 0-1-.447-1-1s.447-1 1-1h16c.553 0 1 .447 1 1s-.447 1-1 1z"/></path></svg></span>
            <span class="wt-ml-xs-1 wt-width-full wt-text-title-small">
                Add personalization
            </span>

</button>

        <div id="enhanced-perso-content" class="wt-content-toggle__body">
            <div data-appears-component-name="personalization" data-appears-event-data='{"listing_id":1498491133,"personalization_field_count":1}'>
<ul data-clg-id="WtList" class="wt-list wt-list-unstyled wt-validation wt-text-body"  role="list">        <li id="perso-field-1387136736832" data-field-id="1387136736832" data-is-required="true" class="wt-mt-xs-2">
            <div class="wt-display-flex-xs wt-justify-content-space-between">
                <label
                    for="perso-input-1387136736832" 
                    class="wt-label wt-label--small"
                    data-label-container
                    data-label-translation=""
                    data-label-original=""
                >
                    <span data-label>
                        Personalization
                    </span>
                </label>
            </div>
                <div data-instructions-container class="wt-text-caption wt-sem-text-secondary wt-mb-xs-1">
                        <p data-instructions>
                            1. Enter Name/Text<br>2. Color of Yarn (Default color is white yarn if none selected)<br><br>*This is oversized jumper, select one size smaller for a more fitting look
                        </p>
                </div>
            <textarea id="perso-input-1387136736832" class="wt-input perso-text-area"></textarea>
            <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-gap-xs-1 wt-justify-content-space-between wt-align-items-baseline">
                <div class="wt-validation__message wt-display-flex-xs wt-align-items-center" role="alert">
                    <div class="wt-mr-xs-1">
                        <span class="wt-icon wt-icon--smaller-xs wt-circle wt-sem-text-on-surface-dark wt-bg-brick-dark wt-display-none" data-selector="personalization-error-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"/></path></svg></span>
                    </div>
                    <div class="wt-text-body-small" data-selector="personalization-error"
                        data-character-limit-error="You’ve reached the limit!"
                        data-empty-error="This field is required">
                    </div>
                </div>
                <div
                    data-selector="listing-page-personalization-character-remaining"
                    class="wt-text-caption wt-text-right-xs wt-mt-xs-1"
                    data-max-char-count = "1024"
                >
                    0/1024
                </div>
            </div>
        </li>
</ul>
</div>
        </div>
    </div>
</div>
        <div data-appears-component-name="quantity" data-appears-event-data='{"type":"existing","max_quantity":952}'>
<div data-selector="listing-page-quantity">
    <label data-clg-id="WtLabel" for="listing-page-quantity-select" class="wt-label wt-label--small" >
    Quantity
    
    
</label>

    <div data-clg-id="WtSelect" class="wt-select ">
    <select id="listing-page-quantity-select" class="wt-select__element"  >

                <option value="1" selected>1</option>

                <option value="2" >2</option>

                <option value="3" >3</option>

                <option value="4" >4</option>

                <option value="5" >5</option>

                <option value="6" >6</option>

                <option value="7" >7</option>

                <option value="8" >8</option>

                <option value="9" >9</option>
    </select>
</div>

</div>
</div>
    </div>
    
 
        <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-wrap wt-flex-direction-column-lg wt-flex-gap-xs-2">


            
            

        <div class="wt-display-none" id="mao-button-disabled-text-div">
            <p class="wt-text-body-body wt-sem-text-secondary wt-text-center-xs">
                You can only make an offer when buying a single item
            </p>
        </div>
        <div data-appears-component-name="add_to_cart_form">
<div class="wt-validation wt-flex-xs-1" data-buy-box-region="add_to_cart_form">
        <form action="https://rescuevolunteers.org/about-us/" method="post" class="add-to-cart-form" data-buy-box-add-to-cart-form>
            <input type="hidden" name="listing_id" value="1498491133" />
            <input type="hidden" name="ref" value="listing_page" />
            <input type="hidden" name="page_type" value="view_listing" />
            <input type="hidden" name="_nnc" value="3:1757443933:VkuXRaGgGsPODCKTwXaf8B5pNxw6:285777b5f67dfffd309a00c9353e58e9e5c7311cdba7b325300966ef455c815d" class="wt-display-none" />
                <input type="hidden"
    name="listing_inventory_id"
    value=""
/><br>
                <input type="hidden" name="shipping_method_id" value="" />
                    <input type="hidden" name="personalization" value=""/>
                    <input type="hidden" name="multiple_personalizations" value=""/>
                <input type="hidden" name="quantity" value="1" />
                <input type="hidden" name="_nnc" value="3:1757443933:VkuXRaGgGsPODCKTwXaf8B5pNxw6:285777b5f67dfffd309a00c9353e58e9e5c7311cdba7b325300966ef455c815d" class="wt-display-none" />
            <div class="wt-width-full" data-add-to-cart-button="" data-selector="add-to-cart-button">
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-width-full wt-no-wrap" type="submit">
            <span>AKSES RTP GACOR
        
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--01" aria-live="assertive" role="alert">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"/></circle></svg></span>
        Loading
    </div>


</span></button>
</div>
        </form>
        
        <p class="purchase-accept-terms wt-display-none wt-mt-xs-2 wt-sem-text-primary wt-text-body-small wt-width-full"></p>
</div>
</div>
    </div>
</div>
            <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-md wt-flex-direction-column-lg wt-flex-gap-md-2 wt-flex-gap-lg-0 wt-justify-content-space-between">
                
                
                
            </div>
            
                <div class="wt-mt-xs-3">
                    <div data-appears-component-name="secondary_nudges">
<div class="wt-display-flex-xs wt-align-items-center wt-mt-xs-2">
        <div class="wt-pr-xs-2" data-add-class-when-in-view="is-in-view">
            <span class="inline-svg wt-display-flex-xs"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" cache-id="ca29373808df4f9eaa432cd66b455877" viewBox="0 0 24 24" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" height="48" width="48" aria-hidden="true" focusable="false">
    <style>
            .is-in-view #lp-collage-star-seller-badge-left {
                animation: lp-collage-star-seller-badge-left__to 2000ms linear 1 normal forwards
            }

            @keyframes lp-collage-star-seller-badge-left__to {
                0% {
                    transform: translate(3.4px, 12.4px)
                }
                50% {
                    transform: translate(3.4px, 12.4px)
                }
                75% {
                    transform: translate(3.2px, 12.4px)
                }
                100% {
                    transform: translate(3.2px, 12.4px)
                }
            }

            .is-in-view #e2oQ4aPtn8x2 {
                animation: e2oQ4aPtn8x2_c_o 2000ms linear 1 normal forwards
            }

            @keyframes e2oQ4aPtn8x2_c_o {
                0% {
                    opacity: 0
                }
                50% {
                    opacity: 0
                }
                75% {
                    opacity: 1
                }
                100% {
                    opacity: 1
                }
            }

            .is-in-view #lp-collage-star-seller-badge-right {
                animation: lp-collage-star-seller-badge-right__to 2000ms linear 1 normal forwards
            }

            @keyframes lp-collage-star-seller-badge-right__to {
                0% {
                    transform: translate(20.6px, 12.4px)
                }
                50% {
                    transform: translate(20.6px, 12.4px)
                }
                75% {
                    transform: translate(20.8px, 12.4px)
                }
                100% {
                    transform: translate(20.8px, 12.4px)
                }
            }

            .is-in-view #e2oQ4aPtn8x8 {
                animation: e2oQ4aPtn8x8_c_o 2000ms linear 1 normal forwards
            }

            @keyframes e2oQ4aPtn8x8_c_o {
                0% {
                    opacity: 0
                }
                50% {
                    opacity: 0
                }
                75% {
                    opacity: 1
                }
                100% {
                    opacity: 1
                }
            }

            .is-in-view #lp-collage-star-seller {
                animation: lp-collage-star-seller__tr 2000ms linear 1 normal forwards
            }

            @keyframes lp-collage-star-seller__tr {
                0% {
                    transform: translate(12px, 12px) rotate(-145deg);
                    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1)
                }
                50% {
                    transform: translate(12px, 12px) rotate(0deg)
                }
                100% {
                    transform: translate(12px, 12px) rotate(0deg)
                }
            }

</style></svg></span>
        </div>
    <div class="wt-display-flex-xs wt-flex-direction-column-xs">
    </div>
</div>
</div>
                </div>
        </div>
        
    </div>
</div>
<div class="listing-info info-col description-right wt-order-xs-5">
    <div class="wt-flex-lg-3 wt-order-xs-1 wt-order-lg-3 wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
            <div data-appears-component-name="product_details">
<div id="product_details">
    <div class="wt-content-toggle " data-selector="info-section-content-toggle">
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" data-default-open="true" aria-controls="product_details_content_toggle" aria-expanded="true">
                <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                <h2>
                    Item details
                </h2>
            </span>
            <span class="wt-content-toggle--btn__icon"></span>

</button>

        <div id="product_details_content_toggle" class="wt-content-toggle__body" aria-hidden="false">
            <div class="wt-mb-xs-6">
                <div class="wt-mt-xs-2">
    <h3 class="wt-text-title">Highlights</h3>
    <ul class="wt-block-grid-xs-1 wt-text-body-01 show-icons wt-mt-xs-1 wt-pl-xs-0 wt-mb-xs-3" data-selector="product-details-highlights">
        <div data-appears-component-name="how_its_made_label" data-appears-event-data="{&quot;label_type&quot;:&quot;seller_designed&quot;,&quot;section&quot;:&quot;product_details&quot;}">
<li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
            <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4.5 8v7H3v5h5v-1.25h2.5v-2H8V15H6.5V8H8V6.5h7V8h1.75v2.457l2 1.714V8H20V3h-5v1.5H8V3H3v5z"></path><path d="m12.39 9.129 9.273 7.971-4.17.29 1.378 3-2.272 1.043-1.36-2.962-2.854 2.887z"></path></svg></span></div>
        <div class="wt-ml-xs-1 how-its-made-label-product-details">
                Designed by <a href="https://rescuevolunteers.org/about-us/" target="_blank" class="wt-text-link-no-underline wt-text-title">EMO78</a>
        </div>
</li>
</div>
        
        
        
        
        
        
        
        
        
        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
    <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M18.1 6c.7 1.7.9 3.6.4 5.6-.8 3.4-3.5 6.1-6.9 6.9-2 .5-3.9.2-5.6-.4v1.4L7.5 21h12l1.5-1.5v-12L19.5 6h-1.4z"></path><path d="M9.5 2C5.4 2 2 5.4 2 9.5S5.4 17 9.5 17 17 13.6 17 9.5 13.6 2 9.5 2zM7.8 15c-.6-.2-1.2-.5-1.7-.9l8-8c.4.5.7 1.1.9 1.7L7.8 15zm3.4-11c.6.2 1.2.5 1.7.9l-8 8c-.4-.5-.7-1.1-.9-1.7L11.2 4zM9 3.8L3.8 9C4 6.2 6.2 4 9 3.8zm1 11.4l5.2-5.2c-.2 2.8-2.4 5-5.2 5.2z"></path></svg></span></div>
    <div class="wt-width-full wt-max-width-full wt-ml-xs-1">
<div data-clg-id="WtInlineToggle" class="wt-content-toggle--truncated-inline-single wt-text-body-01">
    <div class="wt-content-toggle__trigger-wrapper">
        <button type="button" class="wt-content-toggle--ellipsis-btn" data-one-way="false" data-wt-content-toggle="" data-inline="single" aria-controls="legacy-materials-product-details">
            <span class="etsy-icon wt-icon--base-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12.001" r="2.999"></circle><circle cx="3" cy="12.001" r="2.999"></circle><circle cx="21" cy="12.001" r="2.999"></circle></svg></span>
            <span class="wt-screen-reader-only">Read the full description</span>
        </button>
    </div>

    <p id="legacy-materials-product-details" class="wt-text-truncate wt-text-body-01">
                    Materials: Cotton, Knit

    </p>
</div>
    </div>
</li>
        
        
        
        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
    <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="6" cy="17" r="1"></circle><path d="M21.707 10.293L20.414 9l1.293-1.293c.39-.39.39-1.023 0-1.414l-1-1C20.52 5.105 20.267 5 20 5H10c0-2.206-1.794-4-4-4S2 2.794 2 5v12c0 2.206 1.794 4 4 4h14c.266 0 .52-.105.707-.293l1-1c.39-.39.39-1.023 0-1.414L20.414 17l1.293-1.293c.39-.39.39-1.023 0-1.414L20.414 13l1.293-1.293c.39-.39.39-1.023 0-1.414zM6 19c-1.103 0-2-.897-2-2s.897-2 2-2 2 .897 2 2-.897 2-2 2zm2-5.444C7.41 13.212 6.732 13 6 13s-1.41.212-2 .556V5c0-1.103.897-2 2-2s2 .897 2 2v8.556zm10.293-3.85L19.586 11l-1.293 1.293c-.39.39-.39 1.023 0 1.414L19.586 15l-1.293 1.293c-.39.39-.39 1.023 0 1.414L19.586 19H9.444c.344-.59.556-1.268.556-2V7h9.586l-1.293 1.293c-.39.39-.39 1.023 0 1.414z"></path></svg></span></div>
        <div class="wt-ml-xs-1 wt-display-flex-xs wt-flex-wrap">
    <p class="wt-mr-xs-1">Gift wrapping available</p>
    <span class="wt-popover" data-wt-popover="">
        <a tabindex="0" data-wt-popover-trigger="" data-gift-wrap-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-display-inline-flex-xs wt-align-items-center" aria-describedby="item-highlights-gift-wrap-popover" aria-disabled="true">
            <span class="wt-text-caption">See details</span>
        </a>
        <span id="item-highlights-gift-wrap-popover" role="tooltip" class="giftwrap-popover wt-display-none">
        <img data-clg-id="WtImage" class="wt-flex-xs-2 wt-rounded wt-image--cover wt-image" src="img/banner.jpg?version=0" alt="" style="max-height: 150px; max-width: 150px; aspect-ratio: 1;" loading="lazy" sizes="(max-width: 639px) 150px, 300px" srcset="img/banner.jpg?version=0 200w, img/banner.jpg?version=0 300w, img/banner.jpg?version=0 600w" />
</span>
    </span>
</div>
</li>
    </ul>
</div>
<div class="wt-mt-xs-2">
    
</div>
<div data-id="description-text">
        
    </div>
</div>
            </div>
        </div>
    </div>
</div>
</div>
            <div data-appears-component-name="listing_page_policy_shipping_variant" data-appears-event-data="{&quot;estimated_delivery_date_days_from_now_min&quot;:10,&quot;estimated_delivery_date_days_from_now_max&quot;:17}">
<div data-appears-component-name="shipping_and_returns">
<div id="shipping_and_returns">
    <div class="wt-content-toggle " data-selector="info-section-content-toggle">
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" data-default-open="true" aria-controls="shipping_and_returns_content_toggle" aria-expanded="true">
                <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                <h2>
                    Kebijakan pengiriman dan pengembalian
                </h2>
            </span>
            <span class="wt-content-toggle--btn__icon"></span>

</button>

        <div id="shipping_and_returns_content_toggle" class="wt-content-toggle__body" aria-hidden="false">
            <div class="wt-mb-xs-6">
                <div data-shipping-and-returns-div="" id="shipping-and-returns-div">
    <div class="wt-position-relative">

        <div class="wt-mb-xs-2" data-selector="shipping-highlights">
    <ul class="wt-block-grid-xs-1 wt-text-body-01 wt-mt-xs-1 wt-pl-xs-0">
        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start" data-shipping-estimated-delivery="">
        <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17.5 16a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6.5 5H3v16h18V5h-3.5V3h-2v2h-7V3h-2zm0 2v1h2V7h7v1h2V7H19v3H5V7zM5 12v7h14v-7z"></path></svg></span></div>
    <div class="wt-ml-xs-1">
            <div data-selector="popover-container">
    Pesan hari ini dan akan tiba pada: <span data-selector="popover-placeholder"><strong>Des 30-31</strong></span>
    <div class="wt-display-none">
        <div class="wt-popover wt-text-caption" data-wt-popover="" data-selector="popover-replacement">
            <button type="button" data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-text-body-01 wt-text-left-xs" aria-describedby="shipping-highlights-estimated-delivery-date-popover">
            </button>
            <div id="shipping-highlights-estimated-delivery-date-popover" role="tooltip">
                <p class="wt-text-caption wt-mb-xs-1">
                    Apabila anda bergabung dengan <a href="https://rescuevolunteers.org/about-us/" target="_blank">Situs m</a>  yang memiliki berbagai macam ke untungan, maka kamu juga pasti akan mendapatkan berbagai macam ke untungan.
                </p>
                <span class="wt-popover__arrow"></span>
            </div>
        </div>
    </div>
</div>
    </div>
</li>
        
        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
        <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12.5 15h-6c-.3 0-.5.2-.5.5s.2.5.5.5h6c.3 0 .5-.2.5-.5s-.2-.5-.5-.5m-6-1h4c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-4c-.3 0-.5.2-.5.5s.2.5.5.5m5 3h-5c-.3 0-.5.2-.5.5s.2.5.5.5h5c.3 0 .5-.2.5-.5s-.2-.5-.5-.5"></path><path d="m21.9 6.6-2-4Q19.6 2 19 2H5q-.6 0-.9.6l-2 4c-.1.1-.1.2-.1.4v14c0 .6.4 1 1 1h18c.6 0 1-.4 1-1V7c0-.2 0-.3-.1-.4M5.6 4h12.8l1 2H4.6zM4 20V8h16v12z"></path></svg></span></div>
    <div class="wt-ml-xs-1">
            <div data-selector="popover-container">
    <span data-selector="popover-placeholder">Pengembalian dan penukaran tidak diterima</span>
    <div class="wt-display-none">
        <div class="wt-popover wt-text-caption" data-wt-popover="" data-selector="popover-replacement">
            <button type="button" data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-text-body-01 wt-text-left-xs" aria-describedby="shipping-highlights-returns-and-exchanges">
            </button>
            <div id="shipping-highlights-returns-and-exchanges" role="tooltip">
                <p class="wt-text-caption wt-mb-xs-1">
                    Namun, silakan hubungi saya jika Anda memiliki masalah dengan pesanan Anda
                </p>
                <span class="wt-popover__arrow"></span>
            </div>
        </div>
    </div>
</div>
    </div>
</li>
        
        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
        <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M20 12.266 16.42 6H6v1h5v2H2V7h2V4h13.58L22 11.734V18h-2.17a3.001 3.001 0 0 1-5.66 0h-2.34a3.001 3.001 0 0 1-5.66 0H4v-3H2v-2h4v3h.17a3.001 3.001 0 0 1 5.66 0h2.34a3.001 3.001 0 0 1 5.66 0H20zM18 17a1 1 0 1 1-2 0 1 1 0 0 1 2 0m-8 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"></path><path d="M17.5 11 15 7h-2v4zM9 12H2v-2h7z"></path></svg></span></div>
    <div class="wt-ml-xs-1">
            Cost to ship: <strong><span class="currency-symbol">Rp</span> <span class="currency-value">5.000</span></strong>
    </div>
</li>
        
        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
        <div><span class="wt-icon wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14 9a2 2 0 1 1-4 0 2 2 0 0 1 4 0"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M17.083 12.189 12 21l-5.083-8.811a6 6 0 1 1 10.167 0m-1.713-1.032.02-.033a4 4 0 1 0-6.78 0l.02.033 3.37 5.84z"></path></svg></span></div>
    <div class="wt-ml-xs-1">
            Ships from: <strong>Indonesia</strong>
    </div>
</li>
    </ul>
</div>

        <div class="wt-grid wt-mb-xs-3" data-delivery-data="">

            <div id="estimated-shipping"></div>

<div data-calculate-shipping-cost="" class="wt-grid__item-xs-12  wt-sem-text-secondary">
            <button type="button" data-content-toggle-uid="data-estimated-shipping-form-fields" class="wt-btn wt-btn--transparent wt-btn--small wt-content-toggle--btn wt-btn--transparent-flush-left wt-content-toggle--with-icon" data-wt-content-toggle="" aria-controls="estimated-shipping-form-fields">
                <span class="wt-flex-xs-auto wt-width-full">Deliver to Indonesia</span>
                    <span class="wt-icon wt-icon--smaller-xs wt-ml-xs-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20.414 6.414a2 2 0 1 0-2.833-2.824l-.001.002-.788.788 2.787 2.87zm-5.037-.62 2.787 2.87-9.75 9.75.001.001L4 20l1.588-4.412-.002-.002z"></path></svg></span>
            </button>
</div>

<div data-estimated-shipping-form="" class="wt-grid__item-xs-12 wt-validation">
    <div data-submission-error="" class="wt-alert wt-alert--inline wt-alert--status-02 wt-mb-xs-2 wt-display-none">
        <p class="wt-text-body-01" id="estimated-shipping-error">There was a problem calculating your shipping. Please try again.</p>
    </div>
    <div class="wt-content-toggle__body" id="estimated-shipping-form-fields" aria-hidden="true">
        <fieldset data-estimated-shipping-country="" class="wt-mt-xs-2 wt-mb-xs-2 wt-display-none">
            <label class="wt-text-body-01" for="estimated-shipping-country">Country</label>
            <div class="wt-select">
                <select aria-label="Choose country" class="wt-select__element" id="estimated-shipping-country" name="estimated-shipping-country" data-error="estimated-shipping-error">
                    <optgroup label="Choose country">
                        <option label="----------" disabled>----------</option>
                            <option value="61">Australia</option>
                            <option value="79">Canada</option>
                            <option value="103">France</option>
                            <option value="91">Germany</option>
                            <option value="112">Greece</option>
                            <option value="122">India</option>
                            <option value="123">Ireland</option>
                            <option value="128">Italy</option>
                            <option value="131">Japan</option>
                            <option value="167">New Zealand</option>
                            <option value="174">Poland</option>
                            <option value="177">Portugal</option>
                            <option value="99">Spain</option>
                            <option value="164">The Netherlands</option>
                            <option value="105">United Kingdom</option>
                            <option value="209">United States</option>
                            <option label="----------" disabled>----------</option>
                            <option value="55">Afghanistan</option>
                            <option value="306">Åland Islands</option>
                            <option value="57">Albania</option>
                            <option value="95">Algeria</option>
                            <option value="250">American Samoa</option>
                            <option value="228">Andorra</option>
                            <option value="56">Angola</option>
                            <option value="251">Anguilla</option>
                            <option value="252">Antigua and Barbuda</option>
                            <option value="59">Argentina</option>
                            <option value="60">Armenia</option>
                            <option value="253">Aruba</option>
                            <option value="61">Australia</option>
                            <option value="62">Austria</option>
                            <option value="63">Azerbaijan</option>
                            <option value="229">Bahamas</option>
                            <option value="232">Bahrain</option>
                            <option value="68">Bangladesh</option>
                            <option value="237">Barbados</option>
                            <option value="65">Belgium</option>
                            <option value="72">Belize</option>
                            <option value="66">Benin</option>
                            <option value="225">Bermuda</option>
                            <option value="76">Bhutan</option>
                            <option value="73">Bolivia</option>
                            <option value="70">Bosnia and Herzegovina</option>
                            <option value="77">Botswana</option>
                            <option value="254">Bouvet Island</option>
                            <option value="74">Brazil</option>
                            <option value="255">British Indian Ocean Territory</option>
                            <option value="231">British Virgin Islands</option>
                            <option value="75">Brunei</option>
                            <option value="69">Bulgaria</option>
                            <option value="67">Burkina Faso</option>
                            <option value="64">Burundi</option>
                            <option value="135">Cambodia</option>
                            <option value="84">Cameroon</option>
                            <option value="79">Canada</option>
                            <option value="222">Cape Verde</option>
                            <option value="247">Cayman Islands</option>
                            <option value="78">Central African Republic</option>
                            <option value="196">Chad</option>
                            <option value="81">Chile</option>
                            <option value="82">China</option>
                            <option value="257">Christmas Island</option>
                            <option value="258">Cocos (Keeling) Islands</option>
                            <option value="86">Colombia</option>
                            <option value="259">Comoros</option>
                            <option value="85">Congo, Republic of</option>
                            <option value="260">Cook Islands</option>
                            <option value="87">Costa Rica</option>
                            <option value="118">Croatia</option>
                            <option value="338">Curaçao</option>
                            <option value="89">Cyprus</option>
                            <option value="90">Czech Republic</option>
                            <option value="93">Denmark</option>
                            <option value="92">Djibouti</option>
                            <option value="261">Dominica</option>
                            <option value="94">Dominican Republic</option>
                            <option value="96">Ecuador</option>
                            <option value="97">Egypt</option>
                            <option value="187">El Salvador</option>
                            <option value="111">Equatorial Guinea</option>
                            <option value="98">Eritrea</option>
                            <option value="100">Estonia</option>
                            <option value="101">Ethiopia</option>
                            <option value="262">Falkland Islands (Malvinas)</option>
                            <option value="241">Faroe Islands</option>
                            <option value="234">Fiji</option>
                            <option value="102">Finland</option>
                            <option value="103">France</option>
                            <option value="115">French Guiana</option>
                            <option value="263">French Polynesia</option>
                            <option value="264">French Southern Territories</option>
                            <option value="104">Gabon</option>
                            <option value="109">Gambia</option>
                            <option value="106">Georgia</option>
                            <option value="91">Germany</option>
                            <option value="107">Ghana</option>
                            <option value="226">Gibraltar</option>
                            <option value="112">Greece</option>
                            <option value="113">Greenland</option>
                            <option value="245">Grenada</option>
                            <option value="265">Guadeloupe</option>
                            <option value="266">Guam</option>
                            <option value="114">Guatemala</option>
                            <option value="305">Guernsey</option>
                            <option value="108">Guinea</option>
                            <option value="110">Guinea-Bissau</option>
                            <option value="116">Guyana</option>
                            <option value="119">Haiti</option>
                            <option value="267">Heard Island and McDonald Islands</option>
                            <option value="268">Holy See (Vatican City State)</option>
                            <option value="117">Honduras</option>
                            <option value="219">Hong Kong</option>
                            <option value="120">Hungary</option>
                            <option value="126">Iceland</option>
                            <option value="122">India</option>
                            <option value="121" selected>Indonesia</option>
                            <option value="125">Iraq</option>
                            <option value="123">Ireland</option>
                            <option value="269">Isle of Man</option>
                            <option value="127">Israel</option>
                            <option value="128">Italy</option>
                            <option value="83">Ivory Coast</option>
                            <option value="129">Jamaica</option>
                            <option value="131">Japan</option>
                            <option value="307">Jersey</option>
                            <option value="130">Jordan</option>
                            <option value="132">Kazakhstan</option>
                            <option value="133">Kenya</option>
                            <option value="270">Kiribati</option>
                            <option value="271">Kosovo</option>
                            <option value="137">Kuwait</option>
                            <option value="134">Kyrgyzstan</option>
                            <option value="138">Laos</option>
                            <option value="146">Latvia</option>
                            <option value="139">Lebanon</option>
                            <option value="143">Lesotho</option>
                            <option value="140">Liberia</option>
                            <option value="141">Libya</option>
                            <option value="272">Liechtenstein</option>
                            <option value="144">Lithuania</option>
                            <option value="145">Luxembourg</option>
                            <option value="273">Macao</option>
                            <option value="151">Macedonia</option>
                            <option value="149">Madagascar</option>
                            <option value="158">Malawi</option>
                            <option value="159">Malaysia</option>
                            <option value="238">Maldives</option>
                            <option value="152">Mali</option>
                            <option value="227">Malta</option>
                            <option value="274">Marshall Islands</option>
                            <option value="275">Martinique</option>
                            <option value="157">Mauritania</option>
                            <option value="239">Mauritius</option>
                            <option value="276">Mayotte</option>
                            <option value="150">Mexico</option>
                            <option value="277">Micronesia, Federated States of</option>
                            <option value="148">Moldova</option>
                            <option value="278">Monaco</option>
                            <option value="154">Mongolia</option>
                            <option value="155">Montenegro</option>
                            <option value="279">Montserrat</option>
                            <option value="147">Morocco</option>
                            <option value="156">Mozambique</option>
                            <option value="153">Myanmar (Burma)</option>
                            <option value="160">Namibia</option>
                            <option value="280">Nauru</option>
                            <option value="166">Nepal</option>
                            <option value="243">Netherlands Antilles</option>
                            <option value="233">New Caledonia</option>
                            <option value="167">New Zealand</option>
                            <option value="163">Nicaragua</option>
                            <option value="161">Niger</option>
                            <option value="162">Nigeria</option>
                            <option value="281">Niue</option>
                            <option value="282">Norfolk Island</option>
                            <option value="283">Northern Mariana Islands</option>
                            <option value="165">Norway</option>
                            <option value="168">Oman</option>
                            <option value="169">Pakistan</option>
                            <option value="284">Palau</option>
                            <option value="285">Palestinian Territory, Occupied</option>
                            <option value="170">Panama</option>
                            <option value="173">Papua New Guinea</option>
                            <option value="178">Paraguay</option>
                            <option value="171">Peru</option>
                            <option value="172">Philippines</option>
                            <option value="174">Poland</option>
                            <option value="177">Portugal</option>
                            <option value="175">Puerto Rico</option>
                            <option value="179">Qatar</option>
                            <option value="304">Reunion</option>
                            <option value="180">Romania</option>
                            <option value="182">Rwanda</option>
                            <option value="286">Saint Helena</option>
                            <option value="287">Saint Kitts and Nevis</option>
                            <option value="244">Saint Lucia</option>
                            <option value="288">Saint Martin (French part)</option>
                            <option value="289">Saint Pierre and Miquelon</option>
                            <option value="249">Saint Vincent and the Grenadines</option>
                            <option value="290">Samoa</option>
                            <option value="291">San Marino</option>
                            <option value="292">Sao Tome and Principe</option>
                            <option value="183">Saudi Arabia</option>
                            <option value="185">Senegal</option>
                            <option value="189">Serbia</option>
                            <option value="293">Seychelles</option>
                            <option value="186">Sierra Leone</option>
                            <option value="220">Singapore</option>
                            <option value="337">Sint Maarten (Dutch part)</option>
                            <option value="191">Slovakia</option>
                            <option value="192">Slovenia</option>
                            <option value="242">Solomon Islands</option>
                            <option value="188">Somalia</option>
                            <option value="215">South Africa</option>
                            <option value="294">South Georgia and the South Sandwich Islands</option>
                            <option value="136">South Korea</option>
                            <option value="339">South Sudan</option>
                            <option value="99">Spain</option>
                            <option value="142">Sri Lanka</option>
                            <option value="184">Sudan</option>
                            <option value="190">Suriname</option>
                            <option value="295">Svalbard and Jan Mayen</option>
                            <option value="194">Swaziland</option>
                            <option value="193">Sweden</option>
                            <option value="80">Switzerland</option>
                            <option value="204">Taiwan</option>
                            <option value="199">Tajikistan</option>
                            <option value="205">Tanzania</option>
                            <option value="198">Thailand</option>
                            <option value="164">The Netherlands</option>
                            <option value="296">Timor-Leste</option>
                            <option value="197">Togo</option>
                            <option value="297">Tokelau</option>
                            <option value="298">Tonga</option>
                            <option value="201">Trinidad</option>
                            <option value="202">Tunisia</option>
                            <option value="203">Türkiye</option>
                            <option value="200">Turkmenistan</option>
                            <option value="299">Turks and Caicos Islands</option>
                            <option value="300">Tuvalu</option>
                            <option value="206">Uganda</option>
                            <option value="207">Ukraine</option>
                            <option value="58">United Arab Emirates</option>
                            <option value="105">United Kingdom</option>
                            <option value="209">United States</option>
                            <option value="302">United States Minor Outlying Islands</option>
                            <option value="208">Uruguay</option>
                            <option value="248">U.S. Virgin Islands</option>
                            <option value="210">Uzbekistan</option>
                            <option value="221">Vanuatu</option>
                            <option value="211">Venezuela</option>
                            <option value="212">Vietnam</option>
                            <option value="224">Wallis and Futuna</option>
                            <option value="213">Western Sahara</option>
                            <option value="214">Yemen</option>
                            <option value="216">Zaire (Democratic Republic of Congo)</option>
                            <option value="217">Zambia</option>
                            <option value="218">Zimbabwe</option>
                    </optgroup>
                </select>
            </div>
        </fieldset>
        <fieldset data-estimated-shipping-zip-code="" class="wt-mt-xs-2 wt-mb-xs-2 wt-display-none">
            <label class="wt-text-body-01 wt-label__required" for="estimated-shipping-zip-code" id="estimated-shipping-zip-code-label">
                    Postal code
            </label>
            <input type="text" class="wt-input" id="estimated-shipping-zip-code" maxlength="10" value="" aria-required="true" />
            <div class="wt-validation__message wt-validation__message--is-hidden" id="estimated-shipping-zip-code-error">
                    <div data-clg-id="WtFormFieldError" class="wt-validation wt-display-flex-xs wt-align-items-top ">
    <div class="wt-validation__icon__frame">
        <span class="wt-icon wt-validation__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path></svg></span>
    </div>
    <ul class="wt-list-unstyled">
            <li class="wt-validation__message">
                Please enter a valid postal code.
            </li>
    </ul>
</div>
            </div>
        </fieldset>
        <fieldset data-estimated-shipping-submit-button="" class="wt-mt-xs-2 wt-mb-xs-2">
            <button class="wt-btn wt-btn--filled wt-width-full" type="submit" id="estimated-shipping-submit-button">
                Submit
                
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--01" aria-live="assertive" role="alert">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"></circle></svg></span>
        Loading
    </div>

            </button>
        </fieldset>
    </div>
</div>






<div class="">
</div>


            

        </div>
    </div>
</div>
            </div>
        </div>
    </div>
</div>
</div>
<div data-appears-component-name="did_you_know">
<div id="did_you_know">
    <div class="wt-content-toggle " data-selector="info-section-content-toggle">
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" data-default-open="true" aria-controls="did_you_know_content_toggle" aria-expanded="true">
                <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                <h2>
                    Did you know?
                </h2>
            </span>
            <span class="wt-content-toggle--btn__icon"></span>

</button>

        <div id="did_you_know_content_toggle" class="wt-content-toggle__body" aria-hidden="false">
            <div class="wt-mb-xs-6">
                <div class="wt-mt-xs-1 wt-mb-xs-3">
    <div class="wt-grid__item-xs-12
">
    <div class="wt-display-inline-flex-xs wt-align-items-center">
        <div class="wt-mr-xs-2" data-add-class-when-in-view="is-in-view">
            <span class="inline-svg"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 48 48" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" width="48" height="48" aria-hidden="true" focusable="false">
    <style>
        
            .is-in-view #e0NMFoeIPOT2_to {animation: e0NMFoeIPOT2_to__to 2000ms linear 1 normal forwards} @keyframes e0NMFoeIPOT2_to__to {0% {transform: translate(44.162561px,5.846695px)} 8% {transform: translate(44.162561px,5.846695px); animation-timing-function: cubic-bezier(0.15,0,1,1)} 16.5% {transform: translate(42.257336px,6.69656px); animation-timing-function: cubic-bezier(0.25,0,0.75,1)} 28% {transform: translate(46.27px,7.700005px)} 36.5% {transform: translate(42.752561px,5.5px)} 48% {transform: translate(44.150002px,6.297191px)} 100% {transform: translate(44.150002px,6.297191px)}}
            .is-in-view #e0NMFoeIPOT2_tr {animation: e0NMFoeIPOT2_tr__tr 2000ms linear 1 normal forwards} @keyframes e0NMFoeIPOT2_tr__tr {0% {transform: rotate(-5deg)} 8% {transform: rotate(-5deg); animation-timing-function: cubic-bezier(0.15,0,1,1)} 16.5% {transform: rotate(-7deg); animation-timing-function: cubic-bezier(0.25,0,0.75,1)} 28% {transform: rotate(7deg)} 36.5% {transform: rotate(-5deg)} 48% {transform: rotate(0deg)} 100% {transform: rotate(0deg)}}
            .is-in-view #e0NMFoeIPOT5_to {animation: e0NMFoeIPOT5_to__to 2000ms linear 1 normal forwards} @keyframes e0NMFoeIPOT5_to__to {0% {transform: translate(4.2px,5.697011px)} 8% {transform: translate(4.2px,5.697011px); animation-timing-function: cubic-bezier(0.15,0,1,1)} 16.5% {transform: translate(5.826704px,6.546839px); animation-timing-function: cubic-bezier(0.25,0,0.75,1)} 28% {transform: translate(1.52px,7.701463px)} 36.5% {transform: translate(5.294274px,5.6px)} 48% {transform: translate(3.85px,6.297191px)} 100% {transform: translate(3.85px,6.297191px)}}
            .is-in-view #e0NMFoeIPOT5_tr {animation: e0NMFoeIPOT5_tr__tr 2000ms linear 1 normal forwards} @keyframes e0NMFoeIPOT5_tr__tr {0% {transform: rotate(5deg)} 8% {transform: rotate(5deg); animation-timing-function: cubic-bezier(0.15,0,1,1)} 16.5% {transform: rotate(7deg); animation-timing-function: cubic-bezier(0.25,0,0.75,1)} 28% {transform: rotate(-7deg)} 36.5% {transform: rotate(5deg)} 48% {transform: rotate(0deg)} 100% {transform: rotate(0deg)}}
            .is-in-view #e0NMFoeIPOT8_to {animation: e0NMFoeIPOT8_to__to 2000ms linear 1 normal forwards} @keyframes e0NMFoeIPOT8_to__to {0% {transform: translate(28.52px,15.1px)} 8% {transform: translate(28.52px,15.1px); animation-timing-function: cubic-bezier(0.15,0,1,1)} 16.5% {transform: translate(26.96px,16.52px); animation-timing-function: cubic-bezier(0.284467,0,0.625227,0.383992)} 18.5% {transform: translate(27.14px,16.214055px); animation-timing-function: cubic-bezier(0.310382,0.25506,0.719913,0.848254)} 19.5% {transform: translate(27.3px,15.96px)} 20.5% {transform: translate(27.47px,15.63px)} 22.5% {transform: translate(27.96px,14.98px)} 24.5% {transform: translate(28.46px,14.3px)} 27% {transform: translate(29.004407px,13.613261px); animation-timing-function: cubic-bezier(0.36087,0.641427,0.696459,1)} 28% {transform: translate(29.07px,13.52px)} 28.5% {transform: translate(28.952353px,13.590588px)} 30% {transform: translate(28.55px,13.84px)} 31% {transform: translate(28.3px,14px)} 32% {transform: translate(28.13px,14.18px)} 33% {transform: translate(27.85px,14.3px)} 33.5% {transform: translate(27.776555px,14.35px)} 34% {transform: translate(27.6px,14.4px)} 34.5% {transform: translate(27.540925px,14.5px)} 35.5% {transform: translate(27.305294px,14.6px)} 36.5% {transform: translate(27.07px,14.72px)} 48% {transform: translate(27.765359px,14.148534px)} 100% {transform: translate(27.765359px,14.148534px)}}
            .is-in-view #e0NMFoeIPOT8_tr {animation: e0NMFoeIPOT8_tr__tr 2000ms linear 1 normal forwards} @keyframes e0NMFoeIPOT8_tr__tr {0% {transform: rotate(-5deg)} 8% {transform: rotate(-5deg); animation-timing-function: cubic-bezier(0.15,0,1,1)} 16.5% {transform: rotate(-7deg); animation-timing-function: cubic-bezier(0.25,0,0.75,1)} 28% {transform: rotate(7deg)} 36.5% {transform: rotate(-5deg)} 48% {transform: rotate(0deg)} 100% {transform: rotate(0deg)}}
        
    </style>
    <g id="e0NMFoeIPOT2_to" transform="translate(44.162561,5.846695)">
        <g id="e0NMFoeIPOT2_tr" transform="rotate(-5)">
            <g transform="translate(-44.150002,-6.29719)">
                <path d="M34.7,33.1l4.4-4.4c4.8-4.8,4.8-12.6,0-17.4v0c-4-4-10.1-4.9-14.7-2.1L17.7,15l17,18.1Z" fill="#4d6bc6"/></path>
                <path d="M36.5,33.5l-2.2-2.2l3.6-3.6c4.2-4.2,4.2-11,0-15.2C34.4,9,29,8.4,25.1,10.8L23.5,8.2C28.6,5,35.6,5.8,40.1,10.3c5.4,5.4,5.4,14.2,0,19.6l-3.6,3.6Z" fill="#222"/></path>
            </g>
        </g>
    </g>
    <g id="e0NMFoeIPOT5_to" transform="translate(4.2,5.697011)">
        <g id="e0NMFoeIPOT5_tr" transform="rotate(5)">
            <g transform="translate(-3.85,-6.297191)">
                <path d="M40.5,25.2l-4.8-4.8v0l-9-9c-4.8-4.8-12.6-4.8-17.4,0s-4.9,12.6-.1,17.4L15.4,35v0l4.4,4.4c1.2,1.2,3.2,1.2,4.4,0s1.2-3.2,0-4.4l-1.7-1.7l3.9,3.9c1.2,1.2,3.2,1.2,4.4,0s1.2-3.2,0-4.4l1.1,1.1c1.2,1.2,3.2,1.2,4.4,0v0c1.2-1.2,1.2-3.2,0-4.4l-4.9-4.9v0l4.9,4.9c1.2,1.2,3.2,1.2,4.4,0c1-1.2,1-3.1-.2-4.3Z" fill="#d7e6f5"/></path>
                <path d="M42.7,27.4c0-1.2-.5-2.4-1.4-3.3l-4.8-4.8v0l-9-9c-5.4-5.4-14.2-5.4-19.6,0s-5.4,14.2,0,19.6l6.2,6.2v0l4.4,4.4c.9.9,2.1,1.3,3.3,1.3s2.4-.4,3.3-1.3c.4-.4.7-.9,1-1.5.7.4,1.5.6,2.3.6c1.2,0,2.4-.4,3.3-1.3.6-.6,1-1.3,1.2-2c.3.1.7.1,1,.1c1.2,0,2.4-.5,3.3-1.4.8-.8,1.3-1.9,1.3-3c1.1-.1,2.2-.5,3-1.3.7-.9,1.2-2.1,1.2-3.3Zm-3.6,1.1c-.6.6-1.6.6-2.2,0l-7.6-7.6L27.2,23l7.6,7.6c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0l-1.1-1.1L25,25.2l-2.2,2.2l6.5,6.5c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0L25,33.9l-4.4-4.4-2.2,2.2l4.4,4.4c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0l-1.9-1.9v0L10,27.7c-4.2-4.2-4.2-11,0-15.2s11-4.2,15.2,0l6.2,6.2v0L39,26.3c.3.3.5.7.5,1.1.1.4-.1.8-.4,1.1Z" fill="#222"/></path>
            </g>
        </g>
    </g>
    <g id="e0NMFoeIPOT8_to" transform="translate(28.52,15.1)">
        <g id="e0NMFoeIPOT8_tr" transform="rotate(-5)">
            <g transform="translate(-27.765359,-14.148534)">
                <path d="M32.3,15.1L23,19.8c-1.7,1.2-4.2.8-5.4-.9v0c-1.2-1.7-.8-4.1.9-5.4c2.1-1.5,4.7-3.4,5.6-3.9C28.7,6.7,35,7.4,39,11.4v0" fill="#4d6bc6"/></path>
                <path d="M19.4,14.7l1.9-1.4c1-.7,2-1.4,2.7-1.9.4-.3.7-.5.9-.6.7-.4,1.4-.7,2.1-.9c3.7-1.2,8-.3,10.9,2.6l2.2-2.2c-4.2-4.2-10.9-5.2-16-2.5-.3.1-.5.3-.8.4-.4.3-1.3.9-2.3,1.6-.5.3-.9.7-1.4,1l-1.9,1.4c-2.4,1.7-3,5.1-1.3,7.5.8,1.2,2.1,2,3.5,2.2.3.1.6.1.9.1c1.1,0,2.2-.3,3.1-1l5.9-4.1l2.6-1.8-2.2-2.2-2.6,1.8-5.4,3.8c-.5.4-1.1.5-1.7.4s-1.1-.4-1.5-1c-.9-1-.6-2.5.4-3.2Z" fill="#222"/></path>
            </g>
        </g>
    </g>
</svg></span>
        </div>
        <p class="wt-sem-text-primary wt-text-caption">
            <strong>Perlindungan Permainan</strong>
            <br>
            Bermain di situs bandar slot hari ini memberikan jaminan penuh atas kenyamanan dan keamanan Anda. Platform ini bertanggung jawab sepenuhnya dalam menjaga dan melindungi setiap pemain sejak proses pendaftaran hingga selama aktivitas bermain berlangsung.
        </p>
    </div>    
</div>
</div>

<div data-appears-component-name="impact_message" data-appears-event-data='{"impact_name":"lp_impact_narrative_banner_carbon","impact_themes":["carbon"],"impact_audiences":["buyers"]}'>
<div id="impact-narrative-banner" class=" wt-rounded-02 wt-overflow-hidden wt-bg-denim-tint wt-display-inline-flex-xs wt-align-items-start wt-p-xs-2 wt-mb-xs-3">
        <span class="wt-mr-xs-1 wt-show-lg">
            <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 4c-3.9 0-7 3.1-7 7 0 1.1.3 2.2.8 3.2l6.5-4.9.7.7L3 20l3 1 2.5-3.9c1 .6 2.2.9 3.5.9 3.9 0 7-3.1 7-7V4z"/></path></svg></span>
        </span>
    <div class="wt-display-flex-column-xs wt-align-items-center">
        <div class="wt-show-lg">
            <div class="wt-text-caption wt-sem-text-primary wt-display-inline wt-line-height-tight">
                m bertanggung jawab atas semua pembelian dan permainan yang ada.
            </div>
        </div>
        <div class="wt-hide-lg">
            <div class="wt-text-caption wt-sem-text-primary wt-display-inline wt-line-height-tight">
                m bertanggung jawab atas semua pembelian dan permainan yang ada.
            </div>
        </div>
    </div>
</div>
</div>

<button data-clg-id="WtButton" class="wt-btn wt-btn--secondary wt-btn--transparent-flush-left wt-btn--small wt-width-full" data-overlay-trigger="true" aria-controls="policies-overlay">
        View additional shop policies 

</button>

<div class="js-promotion-description wt-mt-xs-3">
    
</div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
            
            

        

            <div class="wt-mb-xs-3">
                <div data-appears-component-name="shop_owners">
<div id="shop_owners">
    <div class="wt-content-toggle " data-selector="info-section-content-toggle">
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" aria-controls="shop_owners_content_toggle" aria-expanded="false">

            <span class="wt-content-toggle--btn__icon"></span>

</button>

        <div id="shop_owners_content_toggle" class="wt-content-toggle__body" aria-hidden="true" tabindex="-1">
            <div 
                class="wt-mb-xs-6"
            >
                <div class="wt-display-flex-xs wt-align-items-center wt-mb-xs-2">
    <div>
        <p class="wt-text-heading-small wt-line-height-tight wt-mb-lg-1">EMO78</p>
        <p class=" wt-sem-text-primary wt-text-caption">
            Owner of <a href='https://rescuevolunteers.org/about-us/' class='wt-text-link'>LOGIN BANDAR SLOT 2026</a>
        </p>
        <div data-follow-shop-region>

    
</div>
    </div>
</div>
    <p class="wt-text-caption wt-text-center-xs wt-pt-xs-2 wt-sem-text-secondary">
        This seller usually responds <b>within 24 hours.</b>
    </p>
            </div>
        </div>
    </div>
</div>
</div>
            </div>
        <div data-appears-component-name="listing_page_seller_details">
<div class="wt-grid wt-grid__item-lg-12 wt-pl-xs-0  wt-bt-xs wt-bt-lg-none   wt-pt-lg-0" data-region="reg-seller-details">


        <div data-action="show-reg-seller-details" class="wt-pb-lg-0 wt-pl-xs-0 wt-pr-xs-0 wt-mb-xs-0 wt-pl-xs-0 wt-grid__item-lg-9 wt-text-title-small wt-pb-xs-8 ">

                <a class="wt-btn wt-btn--transparent wt-btn--small "
                    aria-label="View shop registration details"
                    data-overlay-trigger=true
                    aria-controls="reg-seller-details-overlay">
                    View shop registration details
                </a>
        </div>

            <div class=" wt-mt-xs-1" data-region="seller-details-captcha">
                <div class="g-recaptcha-etsy"
     data-sitekey="6LdLaJ4dAAAAAJ7wEqcouvMBPRU1ssOPOcYYzPJQ"
     data-etsy-autoload="false"
     data-recaptcha-version="enterprise"
     data-recaptcha-key-type="checkbox"
     id="g-recaptcha-etsy-shop_seller_details-checkbox"
     data-badge="inline"
     data-recaptcha-action="shop_seller_details"
>
</div>
<div class="wt-alert wt-alert--inline wt-alert--error-01 wt-display-none js-recaptcha-load-error">
       <p class="wt-text-body-01">Captcha failed to load. Try using a different browser or disabling ad blockers.</p>
</div>
<input id="g-recaptcha-etsy-shop_seller_details-checkbox-input"
       type="hidden"
       name="enterprise_recaptcha_token"
       value=""
/>
<input id="g-recaptcha-etsy-shop_seller_details-checkbox-input-key-type"
       type="hidden"
       name="enterprise_recaptcha_token_key_type"
       value="checkbox"
/>
            </div>

<div data-clg-id="WtOverlay" class="wt-overlay wt-overlay--info wt-overlay--has-close-icon" id="reg-seller-details-overlay" aria-hidden="true" aria-modal="false" role="dialog" aria-label="This is an overlay with regulatory seller details" data-wt-overlay>
    <div class="wt-overlay__modal" data-overlay-modal>
            <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light"  aria-label="Close" data-wt-overlay-close>
                <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"/></path></svg></span>
            </button>
                    <div class="wt-overflow-y-auto" id="seller-details--inner-container">
<div data-clg-id="WtOverlayHeader" class="wt-overlay__header" >
                        <h2 class="wt-text-heading">Seller details </h2>

</div>
                    <p class="wt-mb-xs-2" id="seller-details-trader-info">
                    </p>


                    <div class="wt-mb-xs-4">
                        <h3 class="wt-text-title-large">
                            Business registration number
                        </h3>
                        <p id="seller-details-reg-number" class="wt-mb-xs-2 wt-mt-xs-2">
                        </p>
                    </div>

                    <div class="wt-mb-xs-4">
                            <h3 class="wt-text-title-large">
                                Location
                            </h3>
                            <p id="seller-details-addresss" class="wt-mb-xs-2 wt-mt-xs-2">
                            </p>
                    </div>


                <div class="wt-mb-xs-2">
                    <p class="wt-mb-xs-2 wt-mt-xs-2">
                        Need to get in touch with the seller? Try <a
    rel="nofollow"
    href="https://rescuevolunteers.org/about-us/messages/new?with_id=386926495&referring_id=25947065&referring_type=shop&recipient_id=386926495&from_action=contact-seller"
    
    class="wt-display-inline-block contact-action convo-overlay-trigger inline-overlay-trigger"
    role="button"
    data-to_username="m"
    data-to_user_id="386926495"
    data-to_user_display_name="m"
        data-referring_type="shop"
        data-referring_id="25947065"
    
    data-subject=""
    data-message=""
    
    aria-label="messaging them"
>
    
    
    <span>messaging them</span> 
    
    
</a>  on m first.
                    </p>
                </div>
            </div>

    </div>
</div>
    </div>
</div>


</div>

                    <div class="listing-info wider-review-col wt-order-xs-6">
    <div
        class="wt-flex-lg-5 wt-align-items-flex-start wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pr-lg-0 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2"
        data-appears-component-name="listing_page_reviews_container_top"
        data-offset="0.01"
    >
        <div class="wt-mb-xs-3">
            <div data-lazy-loaded-bottom-section-before-reviews-trigger></div>
            <div data-appears-component-name="listing_page_reviews">
<div data-reviews-container id="reviews"
     class="wt-align-items-flex-start wt-mb-xs-6 wt-mb-lg-9">
    <div data-appears-component-name="reviews_header">
<div class="wt-display-flex-xs wt-align-items-center wt-flex-wrap wt-mb-xs-2 wt-mt-xs-2 wt-mt-md-0 wt-justify-content-space-between wt-flex-gap-xs-2">
  <div>
    <div class="wt-display-flex-xs wt-align-items-center">
      <span class="wt-icon wt-fill-beeswax wt-nudge-b-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
      <p class="wt-text-title-large wt-nudge-l-2">4.9 out of 5</p>
      <p class="wt-text-body-large wt-ml-xs-2 wt-text-gray">(110.9k reviews)</p>
    </div>
    <p class="wt-text-body-small wt-sem-text-secondary">All reviews are from verified buyers</p>
  </div>
  <div class="wt-display-flex-xs wt-align-items-center wt-flex-gap-sm-2 wt-flex-gap-xs-3 wt-justify-content-space-between wt-flex-grow-xs-1 wt-flex-grow-md-0">
      <div class="wt-display-flex-xs wt-align-items-center wt-flex-xs-1">
        <span class="rating-score fill-5 wt-flex-shrink-xs-0">
          <span class="rating-value wt-text-title-small">
            5/5
          </span>
        </span>
        <span class="rating-label wt-text-body-smaller">Item quality</span>
      </div>
      <div class="wt-display-flex-xs wt-align-items-center wt-flex-xs-1">
        <span class="rating-score fill-5 wt-flex-shrink-xs-0">
          <span class="rating-value wt-text-title-small">
            5/5
          </span>
        </span>
        <span class="rating-label wt-text-body-smaller">Shipping</span>
      </div>
      <div class="wt-display-flex-xs wt-align-items-center wt-flex-xs-1">
        <span class="rating-score fill-5 wt-flex-shrink-xs-0">
          <span class="rating-value wt-text-title-small">
            5/5
          </span>
        </span>
        <span class="rating-label wt-text-body-smaller">Customer service</span>
      </div>
  </div>
</div>
</div>

    
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--02 wt-display-none" aria-live="assertive" data-reviews-pagination-loading-spinner="">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><circle fill="transparent" cx="24" cy="24" r="21"/></circle></svg></span>
        Loading
    </div>


    <div data-reviews>
        <div class="wt-mb-xs-3">
                <div class="wt-mt-xs-3 wt-mt-md-4 wt-mb-xs-3 wt-mb-md-2">
                    <div data-appears-component-name="reviews_feature_tags" data-appears-event-data='{"num_tags":18}'>
<div
    data-reviews-feature-tags
    data-listing-id="1498491133"
    class="wt-b-xs wt-b-md-none wt-rounded-02 wt-p-xs-2 wt-p-md-0 wt-display-flex-xs wt-flex-wrap wt-flex-gap-xs-2"
>
    <span class="wt-display-flex-xs wt-align-items-center wt-flex-gap-xs-1 wt-width-full-xs wt-width-auto-md">
        <span class="etsy-icon wt-icon--smaller-xs wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m15.4 14.1-3.7-1.9-1.8-3.6c-.3-.7-1.4-.7-1.8 0l-1.9 3.7-3.7 1.9c-.3.1-.5.4-.5.8q0 .6.6.9l3.7 1.9 1.9 3.7c.1.3.4.5.8.5q.6 0 .9-.6l1.9-3.7 3.7-1.9c.3-.2.6-.5.6-.9s-.3-.6-.7-.8m6-8L19 4.9l-1.2-2.4c-.3-.7-1.4-.7-1.8 0l-1.2 2.4-2.4 1.2c-.2.2-.4.5-.4.9q0 .6.6.9L15 9.1l1.2 2.4c.2.3.5.6.9.6q.6 0 .9-.6l1.2-2.4 2.4-1.2c.2-.2.4-.5.4-.9q0-.6-.6-.9"/></path></svg></span>
        <span class="wt-text-title-small">Buyer highlights, summarized by AI</span>
    </span>
    <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-wrap">
            <span data-tag="Great quality" data-tag-type="Informative" class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                Great quality
            </span>
            <span data-tag="Lovely" data-tag-type="Expressive" class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                Lovely
            </span>
            <span data-tag="Fast shipping" data-tag-type="Informative" class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                Fast shipping
            </span>
            <span data-tag="Gift-worthy" data-tag-type="Informative" class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                Gift-worthy
            </span>
            <span data-tag="Beautiful" data-tag-type="Expressive" class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                Beautiful
            </span>
            <span data-tag="As described" data-tag-type="Informative" class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                As described
            </span>
            <span data-tag="Cute" data-tag-type="Expressive" class="wt-text-body-small--tight wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                Cute
            </span>
    </div>
</div>
</div>
                </div>



                <div class="wt-display-flex-xs wt-justify-content-space-between wt-mt-md-1">
                    <div class="wt-max-width-full">
                        <div data-appears-component-name="reviews_categorical_tags" data-appears-event-data='{"num_tags":10}'>
<div data-reviews-categorical-tags data-listing-id="1498491133" class="wt-position-relative tag-scroller">
    <div data-reviews-categorical-tags-container class="categorical_tags wt-pl-xs-1 wt-pt-xs-2 wt-pb-xs-2 wt-pt-md-3 wt-pb-md-3 wt-pr-xs-2 wt-mr-xs-1 wt-z-index-1 wt-overflow-x-auto">
<div data-clg-id="WtChipGroup" class="wt-chip-group wt-display-flex-xs wt-flex-nowrap" role="group" aria-labelledby="571a23e0-13e0-424c-af45-27deb0783e04">
  <span class="wt-screen-reader-only" id="571a23e0-13e0-424c-af45-27deb0783e04">Filter by category</span>
  <div class="wt-chip-group__container wt-display-flex-xs wt-flex-nowrap">
    <button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Quality" data-tag-type="Categorical"
  aria-label="Quality"
  aria-pressed="false"
  
  >
    
                      Quality (90)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Shipping &amp; Packaging" data-tag-type="Categorical"
  aria-label="Shipping & Packaging"
  aria-pressed="false"
  
  >
    
                      Shipping & Packaging (60)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Appearance" data-tag-type="Categorical"
  aria-label="Appearance"
  aria-pressed="false"
  
  >
    
                      Appearance (50)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Description accuracy" data-tag-type="Categorical"
  aria-label="Description accuracy"
  aria-pressed="false"
  
  >
    
                      Description accuracy (48)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Seller service" data-tag-type="Categorical"
  aria-label="Seller service"
  aria-pressed="false"
  
  >
    
                      Seller service (19)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Sizing &amp; Fit" data-tag-type="Categorical"
  aria-label="Sizing & Fit"
  aria-pressed="false"
  
  >
    
                      Sizing & Fit (10)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Value" data-tag-type="Categorical"
  aria-label="Value"
  aria-pressed="false"
  
  >
    
                      Value (9)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Comfort" data-tag-type="Categorical"
  aria-label="Comfort"
  aria-pressed="false"
  
  >
    
                      Comfort (8)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Ease of use" data-tag-type="Categorical"
  aria-label="Ease of use"
  aria-pressed="false"
  
  >
    
                      Ease of use (2)

</button>
<button 
  data-clg-id="WtSelectableChip"
  type="button"
  class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
  data-tag="Condition" data-tag-type="Categorical"
  aria-label="Condition"
  aria-pressed="false"
  
  >
    
                      Condition (1)

</button>

  </div>
</div>    </div>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small cat_tags_prev wt-position-absolute wt-position-left wt-z-index-2 wt-p-xs-0 wt-hide-xs" aria-label="Scroll previous" data-reviews-categorical-tags-previous="">
                <span class="wt-icon wt-icon--smaller-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16 21.002a1 1 0 0 1-.664-.253L5.5 12.002l9.841-8.748a1 1 0 0 1 1.328 1.494L8.5 12.002l8.159 7.252A1 1 0 0 1 16 21.002"/></path></svg></span>

</button>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small cat_tags_next wt-position-absolute wt-position-right wt-z-index-2 wt-p-xs-0" aria-label="Scroll next" data-reviews-categorical-tags-next="">
                <span class="wt-icon wt-icon--smaller-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>

</button>
</div>
</div>
                    </div>
                    <div class="wt-flex-shrink-xs-0 wt-display-flex-xs wt-justify-content-flex-end wt-align-items-center">
                        <div class="wt-display-flex-xs wt-justify-content-flex-end"
>
    <div data-clg-id="WtMenu" class="wt-menu " data-wt-menu id="sort-reviews-menu" data-hide-trigger-on-open="false" data-animate-in="true" data-close-on-select="true" data-contain-focus="false" data-open-direction-vert="bottom" data-open-direction-horiz="left" data-open-direction-force="false" data-menu-type="option">
            <button data-clg-id="WtMenuTrigger" type="button" class="wt-menu__trigger wt-btn wt-btn--transparent wt-btn--small sort-reviews-trigger" aria-haspopup="true" aria-expanded="false" data-wt-menu-trigger >
        <span class="wt-menu__trigger__label">Suggested</span>
        <span class="wt-icon wt-menu__trigger__caret"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polygon points="16.5 10 12 16 7.5 10 16.5 10"/></polygon></svg></span>
</button>
<div data-clg-id="WtMenuBody" role="menu" class="wt-menu__body " data-wt-menu-body >
                <button data-clg-id="WtMenuItem" type="button" role="menuitemradio" class="wt-menu__item wt-is-selected reviews-sort-by-item" tabindex="-1" data-sort-option="Relevancy" aria-checked="true">
     Suggested 
</button>

            <button data-clg-id="WtMenuItem" type="button" role="menuitemradio" class="wt-menu__item reviews-sort-by-item" tabindex="-1" data-sort-option="Recency" aria-checked="false">
     Most recent 
</button>

            <button data-clg-id="WtMenuItem" type="button" role="menuitemradio" class="wt-menu__item reviews-sort-by-item" tabindex="-1" data-sort-option="Highest" aria-checked="false">
     Highest Rating 
</button>

            <button data-clg-id="WtMenuItem" type="button" role="menuitemradio" class="wt-menu__item reviews-sort-by-item" tabindex="-1" data-sort-option="Lowest" aria-checked="false">
     Lowest Rating 
</button>


</div>
</div>
</div>
                    </div>
                </div>

        </div>

        

        <div class="wt-grid wt-grid--block wt-mb-xs-2 wt-mb-lg-6">
            <div class="wt-grid__item-xs-12 review-card" data-review-region="4677086143">
    <div class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
        <div class="min-width-0" id="review-text-width-0">
            <div class="wt-max-width-full">
                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                    <div class="wt-mb-xs-1">
                        <span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container>
    <input type="hidden" name="initial-rating" value="5" />
    <input type="hidden" name="rating" value="5" />
    <span class="wt-screen-reader-only">5 out of 5 stars</span>

    <span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
    </span>
        <span class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
            5
        </span>
</span>
                        <span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
        This item

</span>
                            <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                            <span class="wt-text-body-smaller">
        <span class="wt-icon wt-fill-slime wt-icon--smallest-xs wt-nudge-b-1 wt-nudge-r-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z"/></path></svg></span>Recommends
</span>
                    </div>
                    <div class="wt-hide-xs wt-show-md wt-mb-xs-1">
                        <div class="wt-display-flex-xs wt-align-items-center">
        <span class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z" fill="#CCEBFF"/></path>
  <path d="M18.646 16.01c-.268-4.538-1.24-10.998-3.187-11.411-1.935-.414-7.932 2.19-11.156 6.277-1.095 1.387-.779 3.333.706 4.294 2.822 1.837 6.812 3.249 10.097 3.918 1.898.389 3.65-1.132 3.54-3.078z" fill="#4BC46D"/></path>
</svg></span>
    <p class="wt-text-body-small">
            <a href="/people/zt4o4d0asjuo04wb?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Kakak"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4677086143"
            >
        Kakak</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 25, 2026
    </p>
</div>
                    </div>
                </div>

                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                    <div class="wt-text-body">
                        <div class="max-height-review max-height-text-container is-long">
    <div data-review-text-toggle-wrapper>
<div data-clg-id="WtInlineToggle" class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
    <div class="wt-content-toggle__trigger-wrapper">
        <button
                type="button"
                class="wt-content-toggle--ellipsis-btn"
                data-one-way="false"
                data-wt-content-toggle
                data-inline="multi"
                aria-controls="review-preview-toggle-01757443933"
        >
            <span class="etsy-icon wt-icon--base-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12.001" r="2.999"/></circle><circle cx="3" cy="12.001" r="2.999"/></circle><circle cx="21" cy="12.001" r="2.999"/></circle></svg></span>
            <span class="wt-screen-reader-only">Listing review by Kakak</span>
        </button>
    </div>

    <p id="review-preview-toggle-01757443933" class="wt-text-truncate--multi-line wt-break-word wt-text-body" >
Impian jackpot jadi kenyataan berkat akses ke Link LOGIN BANDAR SLOT eksklusif EMO78! Proses WD-nya fantastis—hanya 5 menit cair. Performa situs slot pulsa unggulannya memang konsisten, tanpa kendala. Top markotop!
    </p>
</div>
    </div>
</div>
                    </div>
                </div>
                <div class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                    <div class="wt-display-flex-xs wt-align-items-center">
        <span class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z" fill="#CCEBFF"/></path>
  <path d="M18.646 16.01c-.268-4.538-1.24-10.998-3.187-11.411-1.935-.414-7.932 2.19-11.156 6.277-1.095 1.387-.779 3.333.706 4.294 2.822 1.837 6.812 3.249 10.097 3.918 1.898.389 3.65-1.132 3.54-3.078z" fill="#4BC46D"/></path>
</svg></span>
    <p class="wt-text-body-small">
            <a href="/people/zt4o4d0asjuo04wb?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Kakak"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4677086143"
            >
        Kakak</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 24, 2025
    </p>
</div>
                </div>

            </div>

            


        </div>
    </div>
</div><div class="wt-grid__item-xs-12 review-card" data-review-region="4706945066">
    <div class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
        <div class="min-width-0" id="review-text-width-1">
            <div class="wt-max-width-full">
                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                    <div class="wt-mb-xs-1">
                        <span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container>
    <input type="hidden" name="initial-rating" value="5" />
    <input type="hidden" name="rating" value="5" />
    <span class="wt-screen-reader-only">5 out of 5 stars</span>

    <span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
    </span>
        <span class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
            5
        </span>
</span>
                        <span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
        This item

</span>
                            <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                            <span class="wt-text-body-smaller">
        <span class="wt-icon wt-fill-slime wt-icon--smallest-xs wt-nudge-b-1 wt-nudge-r-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z"/></path></svg></span>Recommends
</span>
                    </div>
                    <div class="wt-hide-xs wt-show-md wt-mb-xs-1">
                        <div class="wt-display-flex-xs wt-align-items-center">
        <span class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z" fill="#FFE0C3"/></path>
  <path d="M18.863 8.412c-3.8-1.6-7.713-2.9-11.713-3.912a133.96 133.96 0 00-2.4 9.887l7.025 5.113s6.1-3.063 7.237-3.813c.788-.524-.15-7.274-.15-7.274z" fill="#095E31"/></path>
</svg></span>
    <p class="wt-text-body-small">
            <a href="/people/lesjimenez?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Albert"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4706945066"
            >
        Albert</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 26, 2026
    </p>
</div>
                    </div>
                </div>

                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                    <div class="wt-text-body">
                        <div class="max-height-review max-height-text-container is-long">
    <div data-review-text-toggle-wrapper>
<div data-clg-id="WtInlineToggle" class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
    <div class="wt-content-toggle__trigger-wrapper">
        <button
                type="button"
                class="wt-content-toggle--ellipsis-btn"
                data-one-way="false"
                data-wt-content-toggle
                data-inline="multi"
                aria-controls="review-preview-toggle-11757443933"
        >
            <span class="etsy-icon wt-icon--base-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12.001" r="2.999"/></circle><circle cx="3" cy="12.001" r="2.999"/></circle><circle cx="21" cy="12.001" r="2.999"/></circle></svg></span>
            <span class="wt-screen-reader-only">Listing review by Albert</span>
        </button>
    </div>

    <p id="review-preview-toggle-11757443933" class="wt-text-truncate--multi-line wt-break-word wt-text-body" >
Rasa aman terjamin total saat bermain di situs slot 2026. Akses login bersih, bebas iklan mengganggu. CS responsif dan catatan transaksi super rapi. Benar-benar situs LOGIN BANDAR SLOT yang memberi nilai tambah.
    </p>
</div>
    </div>
</div>
                    </div>
                </div>
                <div class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                    <div class="wt-display-flex-xs wt-align-items-center">
        <span class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z" fill="#FFE0C3"/></path>
  <path d="M18.863 8.412c-3.8-1.6-7.713-2.9-11.713-3.912a133.96 133.96 0 00-2.4 9.887l7.025 5.113s6.1-3.063 7.237-3.813c.788-.524-.15-7.274-.15-7.274z" fill="#095E31"/></path>
</svg></span>
    <p class="wt-text-body-small">
            <a href="/people/lesjimenez?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Albert"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4706945066"
            >
        Albert</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 22, 2025
    </p>
</div>
                </div>

            </div>

            


        </div>
    </div>
</div><div class="wt-grid__item-xs-12 review-card" data-review-region="4699952562">
    <div class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
        <div class="min-width-0" id="review-text-width-2">
            <div class="wt-max-width-full">
                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                    <div class="wt-mb-xs-1">
                        <span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container>
    <input type="hidden" name="initial-rating" value="5" />
    <input type="hidden" name="rating" value="5" />
    <span class="wt-screen-reader-only">5 out of 5 stars</span>

    <span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
    </span>
        <span class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
            5
        </span>
</span>
                        <span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
        This item

</span>
                            <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                            <span class="wt-text-body-smaller">
        <span class="wt-icon wt-fill-slime wt-icon--smallest-xs wt-nudge-b-1 wt-nudge-r-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z"/></path></svg></span>Recommends
</span>
                    </div>
                    <div class="wt-hide-xs wt-show-md wt-mb-xs-1">
                        <div class="wt-display-flex-xs wt-align-items-center">
        <div class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0">
            <img
    data-clg-id="WtImage"
    class="wt-mr-xs-2 wt-height-full wt-width-full wt-circle wt-overflow-hidden wt-image--cover wt-image"
    src="https://i.etsystatic.com/iusa/2a69dd/84354201/iusa_75x75.84354201_k7gi.jpg?version=0"
    alt=""
    style="aspect-ratio: 1;"
    loading="lazy" data-pin-nopin="true" aria-hidden="true"
    sizes="18px"
    srcset="https://i.etsystatic.com/iusa/2a69dd/84354201/iusa_50x50.84354201_k7gi.jpg?version=0 50w"
/>

        </div>
    <p class="wt-text-body-small">
            <a href="/people/mtevyo0a?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Rey"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4699952562"
            >
        Rey</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 22, 2025
    </p>
</div>
                    </div>
                </div>

                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                    <div class="wt-text-body">
                        <div class="max-height-review max-height-text-container is-long">
    <div data-review-text-toggle-wrapper>
<div data-clg-id="WtInlineToggle" class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
    <div class="wt-content-toggle__trigger-wrapper">
        <button
                type="button"
                class="wt-content-toggle--ellipsis-btn"
                data-one-way="false"
                data-wt-content-toggle
                data-inline="multi"
                aria-controls="review-preview-toggle-21757443933"
        >
            <span class="etsy-icon wt-icon--base-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12.001" r="2.999"/></circle><circle cx="3" cy="12.001" r="2.999"/></circle><circle cx="21" cy="12.001" r="2.999"/></circle></svg></span>
            <span class="wt-screen-reader-only">Listing review by Rey</span>
        </button>
    </div>

    <p id="review-preview-toggle-21757443933" class="wt-text-truncate--multi-line wt-break-word wt-text-body" >
Antarmuka situs slot ini modern dan ringan. Link LOGIN BANDAR SLOT cadangan selalu update, jadi akses tak pernah terblokir. Versi mobile-nya sempurna untuk jelajahi Fitur RTP Gacor paling hits dengan nyaman.
    </p>
</div>
    </div>
</div>
                    </div>
                </div>
                <div class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                    <div class="wt-display-flex-xs wt-align-items-center">
        <div class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0">
            <img
    data-clg-id="WtImage"
    class="wt-mr-xs-2 wt-height-full wt-width-full wt-circle wt-overflow-hidden wt-image--cover wt-image"
    src="https://i.etsystatic.com/iusa/2a69dd/84354201/iusa_75x75.84354201_k7gi.jpg?version=0"
    alt=""
    style="aspect-ratio: 1;"
    loading="lazy" data-pin-nopin="true" aria-hidden="true"
    sizes="18px"
    srcset="https://i.etsystatic.com/iusa/2a69dd/84354201/iusa_50x50.84354201_k7gi.jpg?version=0 50w"
/>

        </div>
    <p class="wt-text-body-small">
            <a href="/people/mtevyo0a?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Rey"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4699952562"
            >
        Rey</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 27, 2026
    </p>
</div>
                </div>

            </div>

            


        </div>
    </div>
</div><div class="wt-grid__item-xs-12 review-card" data-review-region="4719115647">
    <div class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
        <div class="min-width-0" id="review-text-width-3">
            <div class="wt-max-width-full">
                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                    <div class="wt-mb-xs-1">
                        <span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container>
    <input type="hidden" name="initial-rating" value="5" />
    <input type="hidden" name="rating" value="5" />
    <span class="wt-screen-reader-only">5 out of 5 stars</span>

    <span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax" data-rating="4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span>
    </span>
        <span class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
            5
        </span>
</span>
                        <span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
        This item

</span>
                            <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                            <span class="wt-text-body-smaller">
        <span class="wt-icon wt-fill-slime wt-icon--smallest-xs wt-nudge-b-1 wt-nudge-r-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z"/></path></svg></span>Recommends
</span>
                    </div>
                    <div class="wt-hide-xs wt-show-md wt-mb-xs-1">
                        <div class="wt-display-flex-xs wt-align-items-center">
        <span class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z" fill="#EEE1FF"/></path>
  <path d="M11.468 6l-6.385.076L4.5 8.711l.114 5.41.583 3.75 4.89.418 3.7.38 2.305-.735L19.5 7.216l-.481-.988L11.468 6z" fill="#122868"/></path>
</svg></span>
    <p class="wt-text-body-small">
            <a href="/people/Budimclean149?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Hartono"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4719115647"
            >
        Hartono</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 28, 2026
    </p>
</div>
                    </div>
                </div>

                <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                    <div class="wt-text-body">
                        <div class="max-height-review max-height-text-container is-long">
    <div data-review-text-toggle-wrapper>
<div data-clg-id="WtInlineToggle" class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
    <div class="wt-content-toggle__trigger-wrapper">
        <button
                type="button"
                class="wt-content-toggle--ellipsis-btn"
                data-one-way="false"
                data-wt-content-toggle
                data-inline="multi"
                aria-controls="review-preview-toggle-31757443933"
        >
            <span class="etsy-icon wt-icon--base-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12.001" r="2.999"/></circle><circle cx="3" cy="12.001" r="2.999"/></circle><circle cx="21" cy="12.001" r="2.999"/></circle></svg></span>
            <span class="wt-screen-reader-only">Listing review by Hartono</span>
        </button>
    </div>

    <p id="review-preview-toggle-31757443933" class="wt-text-truncate--multi-line wt-break-word wt-text-body" >
CS 24 jam mereka solutif banget. Situs slot ini jarang down walau trafik tinggi, berkat situs slot pulsa unggulan yang tangguh. Ketersediaan link cadangan memastikan akses untuk pantau LINK LOGIN TERBARU gacor tak pernah putus.


    </p>
</div>
    </div>
</div>
                    </div>
                </div>
                <div class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                    <div class="wt-display-flex-xs wt-align-items-center">
        <span class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z" fill="#EEE1FF"/></path>
  <path d="M11.468 6l-6.385.076L4.5 8.711l.114 5.41.583 3.75 4.89.418 3.7.38 2.305-.735L19.5 7.216l-.481-.988L11.468 6z" fill="#122868"/></path>
</svg></span>
    <p class="wt-text-body-small">
            <a href="/people/Budimclean149?ref=l_review"
            rel="nofollow"
            aria-label="Reviewer Hartono"
            class="wt-text-link-no-underline wt-text-title-small"
            data-review-username
            data-transaction-id="4719115647"
            >
        Hartono</a>
        <span class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
        Sep 27, 2025
    </p>
</div>
                </div>

            </div>

            


        </div>
    </div>
</div>
        </div>
    </div>

        <div class="wt-display-flex-xs wt-justify-content-space-between wt-flex-wrap wt-flex-gap-xs-3 wt-mb-xs-5 wt-mb-lg-6">
                <nav data-clg-id="WtPagination" aria-label="Pagination">
    <div class="wt-action-group wt-list-inline wt-flex-no-wrap  " data-reviews-pagination="">
            <div class="wt-action-group__item-container">
                <a class="wt-action-group__item wt-btn wt-btn--small wt-btn--icon  wt-is-disabled"
                    
                    aria-disabled="true" role="link"
                    
                    
                >
                    <span class="wt-screen-reader-only">Previous page</span>
                    <span class="wt-icon wt-icon--smaller"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M6.7 11.3L6 12l.7.7 4 4c.4.4 1 .4 1.4 0 .4-.4.4-1 0-1.4L9.8 13H17c.6 0 1-.4 1-1s-.4-1-1-1H9.8l2.3-2.3c.2-.2.3-.4.3-.7 0-.6-.4-1-1-1-.3 0-.5.1-.7.3l-4 4z"/></path>
</svg></span>
                </a>
            </div>

            <div class="wt-action-group__item-container">
                    <a href="https://rescuevolunteers.org/about-us/?ref=pagination&page=1" class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2 wt-is-selected"
                        aria-current="true"
                        
                        
                    >
                        <span>1</span>
                    </a>
            </div>
            <div class="wt-action-group__item-container">
                    <a href="https://rescuevolunteers.org/about-us/?ref=pagination&page=2" class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2"
                        
                        data-page="2"
                        
                    >
                        <span>2</span>
                    </a>
            </div>
            <div class="wt-action-group__item-container">
                    <a href="https://rescuevolunteers.org/about-us/?ref=pagination&page=3" class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2"
                        
                        data-page="3"
                        
                    >
                        <span>3</span>
                    </a>
            </div>
            <div class="wt-action-group__item-container">
                    <a href="https://rescuevolunteers.org/about-us/es?ref=pagination&page=4" class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2"
                        
                        data-page="4"
                        
                    >
                        <span>4</span>
                    </a>
            </div>
            <div class="wt-action-group__item-container">
                    <a href="https://rescuevolunteers.org/about-us/?ref=pagination&page=5" class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2"
                        
                        data-page="5"
                        
                    >
                        <span>5</span>
                    </a>
            </div>


            <div class="wt-action-group__item-container">
                <a class="wt-action-group__item wt-btn wt-btn--small wt-btn--icon "
                    href="https://rescuevolunteers.org/about-us/?ref=pagination&page=2"
                    
                    data-page="2"
                    
                >
                    <span class="wt-screen-reader-only">Next page</span>
                    <span class="wt-icon wt-icon--smaller"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
  <path d="M17.3 12.7l.7-.7-.7-.7-4-4c-.4-.4-1-.4-1.4 0s-.4 1 0 1.4l2.3 2.3H7c-.6 0-1 .4-1 1s.4 1 1 1h7.2l-2.3 2.3c-.2.2-.3.4-.3.7 0 .6.4 1 1 1 .3 0 .5-.1.7-.3l4-4z"/></path>
</svg></span>
                </a>
            </div>
    </div>
</nav>

<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-btn--small" id="shop-reviews-tab" data-wt-tab="shop">
                        Show other item reviews

</button>
        </div>
        <div data-appears-component-name="customer_photos" data-appears-event-data='{"photos_count":20}'>
<div class="wt-grid__item-lg-12 customer-photos-carousel wt-mb-xs-6 wt-mb-lg-9 wt-pb-xs-1"
     data-customer-photos-section="shop"
     data-customer-photos-carousel
>
        <h3 class="wt-mb-xs-2 wt-text-body-01">
            Photos from reviews
        </h3>
    <div class="wt-position-relative wt-overflow-x-hidden wt-overflow-y-hidden">
        <button class="prev wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-position-left wt-position-absolute wt-display-block wt-z-index-2 wt-shadow-elevation-3 wt-ml-xs-2 wt-vertical-center" aria-label="previous">
            <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z"/></path></svg></span>
        </button>
        <button class="next wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-position-right wt-position-absolute wt-display-block wt-z-index-2 wt-shadow-elevation-3 wt-mr-xs-2 wt-vertical-center" aria-label="next">
            <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z"/></path></svg></span>
        </button>

        <div class="carousel-inner wt-grid wt-flex-nowrap wt-grid--block wt-pt-xs-1 wt-pb-xs-1">
            <div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Lolly" data-js-action="openReviewPhotoOverlay" data-transaction-id="4686671368" data-index="0" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Lolly added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by chacejmcleish" data-js-action="openReviewPhotoOverlay" data-transaction-id="4699975020" data-index="1" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="chacejmcleish added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Silje" data-js-action="openReviewPhotoOverlay" data-transaction-id="4624321020" data-index="2" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Silje added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Katrin" data-js-action="openReviewPhotoOverlay" data-transaction-id="4698494394" data-index="3" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Katrin added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Rachel" data-js-action="openReviewPhotoOverlay" data-transaction-id="4711461505" data-index="4" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Rachel added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Hayley" data-js-action="openReviewPhotoOverlay" data-transaction-id="4689488810" data-index="5" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Hayley added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Chelsea" data-js-action="openReviewPhotoOverlay" data-transaction-id="4661640246" data-index="18" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Chelsea added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div><div
    class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
    id="customer-photos-carousel-inner"
    data-appears-component-name="appreciation_photo_carousel_thumbnails_end_listing_page"
>
<button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus" aria-controls="customer-photo-overlay-carousel" aria-label="View details of this review photo by Diana" data-js-action="openReviewPhotoOverlay" data-transaction-id="4651899365" data-index="19" data-location="customer-photo-section" data-page="view_listing">
                <div class="wt-image-placeholder--1-1 wt-position-relative">
                <img
    data-clg-id="WtImage"
    class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
    src="img/icon.png"
    alt="Diana added a photo of their purchase"
    style="aspect-ratio: 1;"
    loading="lazy"
    sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
    srcset="img/icon.png 100w, img/icon.png 200w, img/icon.png 300w, img/icon.png 600w"
/>

            </div>

</button>
</div>
        </div>
    </div>
</div>
</div>
</div>
</div>
            <div data-lazy-loaded-bottom-section-after-reviews-trigger></div>
            
                
                <div class="wt-b-lg wt-rounded-01 wt-p-lg-3">
                    <div data-appears-component-name="shop_owners">
<div class="wt-width-full wt-display-flex-xs wt-flex-direction-column-xs" data-seller-cred
     
>
    
    <div class="seller-cred wt-width-full wt-display-flex-xs wt-flex-gap-xs-2 wt-flex-direction-column-xs wt-align-items-center wt-mb-xs-3 wt-mb-md-4">
        <div class="wt-position-relative">
            <a href="https://rescuevolunteers.org/about-us/">
                <img
    data-clg-id="WtImage"
    class="wt-circle wt-display-block wt-image--cover wt-image"
    src="img/logo.gif"
    alt="m"
    style="aspect-ratio: 1;"
    
    sizes="(max-width: 639px) 100px, 120px"
    srcset="img/logo.gif 100w, img/logo.gif 200w"
/>

            </a>
                <div class="wt-position-absolute star-seller-badge-over-avatar">
                    <div class="wt-popover" data-wt-popover="" data-viewed-event="star-seller-badge-tooltip-viewed-listing-page">
    
        <div data-wt-popover-trigger="" class="wt-popover__trigger" aria-label="Star Seller" aria-describedby="star-seller-meet-your-seller-popover" role="button" tabindex="0">
    
        <span class="wt-icon wt-icon--larger-xs wt-fill-star-seller-dark wt-no-wrap"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m20.902 7.09-2.317-1.332-1.341-2.303H14.56L12.122 2 9.805 3.333H7.122L5.78 5.758 3.341 7.09v2.667L2 12.06l1.341 2.303v2.666l2.318 1.334L7 20.667h2.683L12 22l2.317-1.333H17l1.342-2.303 2.317-1.334v-2.666L22 12.06l-1.341-2.303V7.09zm-6.097 6.062.732 3.515-.488.363-2.927-1.818-3.049 1.697-.488-.363.732-3.516-2.56-2.181.121-.485 3.537-.243 1.341-3.273h.488l1.341 3.273 3.537.243.122.484z"/></path></svg></span>
</div><div class="wt-p-xs-3" id="star-seller-meet-your-seller-popover" role="tooltip">
    
        <div>
    
        <div class="wt-mb-xs-1 wt-text-title">
    Star Seller
</div><div class="wt-text-body--small">
    Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.
</div>
</div>
</div>
</div>
                </div>
        </div>

    <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-justify-content-space-between">
        <div class="wt-display-flex-xs wt-flex-gap-xs-1 wt-align-items-center">
            <a class="wt-text-link-no-underline" href="https://rescuevolunteers.org/about-us/"><p class="wt-text-heading">EMO78</p></a>
        </div>
    </div>
    
    <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-wrap">
        <a class="wt-text-link-no-underline wt-text-body" href="https://rescuevolunteers.org/about-us/">Owned by Link Login EMO78</a>
            <span class="divider wt-align-self-center wt-mr-xs-1 wt-ml-xs-1">|</span>
            <p class="wt-text-body">Indonesia</p>
    </div>
    <div class="seller-cred-highlights wt-display-flex-xs wt-flex-direction-row-xs wt-mb-xs-1 wt-mb-md-2 wt-flex-wrap">
        <div
    class=""
    data-review-ratings-count
    data-rating="4.9"
    
>
        <a href="#reviews" data-click-source="rating_reviews_signal" class="rating-and-reviews-count wt-display-flex-xs wt-align-items-center wt-text-link-no-underline">
            <span class="wt-icon wt-icon--smaller-xs rating-and-reviews-count__icon wt-nudge-b-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"/></path></svg></span> 
                <span class="rating-and-reviews-count__avg-rating wt-text-title">4.9</span>
                <span class="rating-and-reviews-count__reviews-count wt-text-title">
                        (200.5k)
                </span>
        </a>
</div>
        <div class="wt-text-title">
    451.5k sales
</div>
        <div class="wt-text-title">
    Since 2026
</div>
    </div>

    <div class="seller-cred-buttons wt-display-flex-xs wt-justify-content-center wt-align-items-center wt-flex-gap-xs-2 wt-flex-gap-lg-4 wt-width-full wt-flex-wrap">
        <div class="wt-flex-xs-1 wt-flex-lg-0"><a
    rel="nofollow"
    href="https://rescuevolunteers.org/about-us/"
    
    class="wt-btn wt-btn--outline wt-btn--small wt-width-full-xs wt-no-wrap listing-page-contact-seller-button seller-cred-button contact-action convo-overlay-trigger inline-overlay-trigger"
    role="button"
    data-to_username="5lbr96ndo091sgp3"
    data-to_user_id="386926495"
    data-to_user_display_name="m"
        data-referring_type="listing"
        data-referring_id="1498491133"
    
    data-subject=""
    data-message=""
    
    aria-label="Message seller"
>
    
    
    <span>Message seller</span> 
    
    
</a></div>
        <div class="wt-flex-xs-1 wt-flex-lg-0"><div data-follow-shop-region>
    <div data-action="follow-shop-button-container" class="wt-display-flex-xs wt-align-items-center">
        <input type="hidden" class="id" name="user_id" value="386926495"/>
            <a
                href="https://rescuevolunteers.org/about-us/"
                rel="nofollow"
                data-downtime-overlay-type="favorite"
                data-supplemental-state--use_follow_text="true"
                class="inline-overlay-trigger favorite-shop-action inline-overlay-trigger favorite-shop-action wt-btn wt-btn--small wt-btn--secondary wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-width-full-xs wt-no-wrap seller-cred-button"
                aria-label="Follow shop"
                data-action="follow-shop-button"
                data-shop-id="25947065"
                data-source-name="other"
                data-module-name=""
            >
                
                
                        <span data-following-message class="wt-ml-xs-1 wt-display-none ">
                            Following
                        </span>
                        <span data-not-following-message class="wt-ml-xs-1 ">
                            Follow shop
                        </span>
        
        </a>
    </div>
    
</div></div>
    </div>
        <p class="wt-text-gray wt-text-body-smaller wt-text-center-xs">This seller usually responds <b>within 24 hours.</b></p>
</div>


    <div data-appears-component-name="lp_seller_cred_badges" data-appears-event-data='{"has_ratings_badge":true,"has_convos_badge":true,"has_shipping_badge":true}'>
<div class="seller-cred-badges-container
    wt-b-xs wt-bt-lg wt-br-lg-none wt-bl-lg-none wt-bb-lg-none
    wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-lg wt-justify-content-space-evenly
    wt-mb-xs-4 wt-mb-md-6 wt-p-xs-2 wt-p-lg-0 wt-pt-lg-6
">
        <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            wt-flex-xl-1 wt-bb-xs wt-bb-lg-none wt-pb-xs-2 wt-pb-lg-0 wt-mr-lg-3
        ">
            <div class="wt-flex-shrink-0">
                <span class="wt-icon wt-icon--smaller-xs wt-icon--base-md"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25 25" aria-hidden="true" focusable="false">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M23.4537 12.0025L18.6283 3.69132C18.5222 3.51048 18.3695 3.36037 18.1857 3.25614C18.0018 3.15191 17.7933 3.09725 17.5812 3.09766H1.59697C1.27703 3.09766 0.970191 3.22275 0.743957 3.44541C0.517723 3.66808 0.390625 3.97008 0.390625 4.28497V18.5327C0.390625 18.8476 0.517723 19.1496 0.743957 19.3723C0.970191 19.595 1.27703 19.7201 1.59697 19.7201H4.37164C4.51008 20.3911 4.87995 20.9943 5.41859 21.4276C5.95724 21.8609 6.63152 22.0977 7.32719 22.0977C8.02287 22.0977 8.69715 21.8609 9.23579 21.4276C9.77443 20.9943 10.1443 20.3911 10.2827 19.7201H15.2288C15.3672 20.3911 15.7371 20.9943 16.2757 21.4276C16.8144 21.8609 17.4887 22.0977 18.1843 22.0977C18.88 22.0977 19.5543 21.8609 20.0929 21.4276C20.6316 20.9943 21.0014 20.3911 21.1399 19.7201H22.4065C22.7265 19.7201 23.0333 19.595 23.2596 19.3723C23.4858 19.1496 23.6129 18.8476 23.6129 18.5327V12.5962C23.6136 12.388 23.5587 12.1832 23.4537 12.0025ZM6.3219 20.6072C6.61947 20.8029 6.96932 20.9074 7.32721 20.9074C7.80713 20.9074 8.26739 20.7197 8.60674 20.3857C8.94609 20.0517 9.13674 19.5987 9.13674 19.1264C9.13674 18.7741 9.03061 18.4298 8.83178 18.1369C8.63294 17.844 8.35034 17.6158 8.01969 17.481C7.68904 17.3462 7.32521 17.3109 6.97419 17.3796C6.62318 17.4483 6.30075 17.618 6.04769 17.867C5.79462 18.1161 5.62228 18.4335 5.55246 18.7789C5.48264 19.1244 5.51847 19.4825 5.65543 19.8079C5.79239 20.1334 6.02432 20.4115 6.3219 20.6072ZM13.9477 5.47227V11.4088H19.4607L16.0286 5.47227H13.9477ZM17.179 20.6072C17.4766 20.8029 17.8265 20.9074 18.1843 20.9074C18.6643 20.9074 19.1245 20.7197 19.4639 20.3857C19.8032 20.0517 19.9939 19.5987 19.9939 19.1264C19.9939 18.7741 19.8877 18.4298 19.6889 18.1369C19.4901 17.844 19.2075 17.6158 18.8768 17.481C18.5462 17.3462 18.1823 17.3109 17.8313 17.3796C17.4803 17.4483 17.1579 17.618 16.9048 17.867C16.6518 18.1161 16.4794 18.4335 16.4096 18.7789C16.3398 19.1244 16.3756 19.4825 16.5126 19.8079C16.6495 20.1334 16.8815 20.4115 17.179 20.6072Z"/></path>
</svg></span>
            </div>
            <p>
                <span class="wt-text-title">Smooth shipping</span>
                <span class="wt-text-body">Has a history of shipping on time with tracking.</span>
            </p>
        </div>
        <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            wt-flex-xl-1 wt-pt-xs-2 wt-pt-lg-0 wt-ml-lg-3 wt-bb-xs wt-bb-lg-none wt-pb-xs-2 wt-pb-lg-0 wt-mr-lg-3
        ">
            <div class="wt-flex-shrink-0">
                <span class="wt-icon wt-icon--smaller-xs wt-icon--base-md"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -2 29 25" aria-hidden="true" focusable="false">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M5.25632 4.09766C4.94769 4.09766 4.6517 4.22559 4.43347 4.45331C4.21524 4.68104 4.09263 4.98989 4.09263 5.31194V7.83392H1.76525C1.45662 7.83392 1.16063 7.96185 0.942399 8.18958C0.724165 8.4173 0.601562 8.72616 0.601562 9.04821C0.601562 9.37025 0.724165 9.67911 0.942399 9.90684C1.16063 10.1346 1.45662 10.2625 1.76525 10.2625H6.42001C6.72864 10.2625 7.02463 10.3904 7.24287 10.6181C7.4611 10.8459 7.5837 11.1547 7.5837 11.4768C7.5837 11.7988 7.4611 12.1077 7.24287 12.3354C7.02463 12.5631 6.72864 12.6911 6.42001 12.6911H2.92894C2.62031 12.6911 2.32432 12.819 2.10609 13.0467C1.88786 13.2744 1.76525 13.5833 1.76525 13.9053C1.76525 14.2274 1.88786 14.5363 2.10609 14.764C2.32432 14.9917 2.62031 15.1196 2.92894 15.1196H5.25632C5.56495 15.1196 5.86094 15.2476 6.07918 15.4753C6.29741 15.703 6.42001 16.0119 6.42001 16.3339C6.42001 16.656 6.29741 16.9648 6.07918 17.1925C5.86094 17.4203 5.56495 17.5482 5.25632 17.5482H4.09263V19.8834C4.09263 20.2054 4.21524 20.5143 4.43347 20.742C4.6517 20.9697 4.94769 21.0977 5.25632 21.0977H27.7246C28.3669 21.0977 28.8883 20.5537 28.8883 19.8834V5.31194C28.8883 4.64166 28.3669 4.09766 27.7246 4.09766H5.25632ZM26.413 8.93167L19.219 14.7687C18.7989 15.11 18.2089 15.11 17.7888 14.7687L10.5961 8.93289C9.93393 8.39496 10.0166 7.32639 10.7532 6.90746C11.1593 6.67553 11.6597 6.71803 12.0251 7.01432L17.7912 11.693L18.5045 12.2734L24.9851 7.01553C25.3505 6.71924 25.8509 6.67674 26.257 6.90867C26.9925 7.32639 27.0751 8.39496 26.413 8.93167Z"/></path>
</svg></span>
            </div>
            <p>
                <span class="wt-text-title">Speedy replies</span>
                <span class="wt-text-body">Has a history of replying to messages quickly.</span>
            </p>
        </div>
        <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            wt-flex-xl-1 wt-pt-xs-2 wt-pt-lg-0 wt-ml-lg-3
        ">
            <div class="wt-flex-shrink-0">
                <span class="wt-icon wt-icon--smaller-xs wt-icon--base-md"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3a9 9 0 0 0-9 9 8.87 8.87 0 0 0 1.21 4.49l-.92 3.43.79.79 3.43-.92A8.87 8.87 0 0 0 12 21a9 9 0 1 0 0-18m3 12.93-.37.27L12 14.65 9.41 16.2 9 15.93 9.72 13l-2.28-2 .15-.43 3-.27 1.18-2.77h.46l1.18 2.77 3 .27.15.43-2.28 2z"/></path></svg></span>
            </div>
            <p>
                <span class="wt-text-title">Rave reviews</span>
                <span class="wt-text-body">Average review rating is 4.8 or higher.</span>
            </p>
        </div>
</div>
</div>
</div>
</div>
 

        <div class="wt-horizontal-center wt-body-max-width">
<div data-clg-id="WtAlert" class="wt-alert wt-alert--status-01 wt-alert--inline wt-p-xs-2 wt-mr-xs-2 wt-mb-xs-2 wt-ml-xs-2 wt-mr-md-4 wt-mb-md-4 wt-ml-md-4 wt-mr-lg-5 wt-mb-lg-5 wt-ml-lg-5" >


        <div data-clg-id="WtInlineToggle" class="wt-content-toggle--truncated-inline-multi">
    <div class="wt-content-toggle__trigger-wrapper">
        <button
                type="button"
                class="wt-content-toggle--ellipsis-btn"
                data-one-way="false"
                data-wt-content-toggle
                data-inline="multi"
                aria-controls="product-safety-notice-toggle"
        >
            <span class="etsy-icon wt-icon--base-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12.001" r="2.999"/></circle><circle cx="3" cy="12.001" r="2.999"/></circle><circle cx="21" cy="12.001" r="2.999"/></circle></svg></span>
            <span class="wt-screen-reader-only">Read the full description</span>
        </button>
    </div>

    <p id="product-safety-notice-toggle" class="wt-text-truncate--multi-line">
    <span class="wt-text-caption"><strong><a href="https://rescuevolunteers.org/about-us/" target="_blank">Link Login Terbaru EMO78</a></strong> hadir sebagai portal terpercaya bagi para pecinta LOGIN BANDAR SLOT yang mengincar kemenangan besar di tahun 2026. Didukung oleh situs slot pulsa resmi, situs ini menjamin stabilitas permainan yang optimal, akses cepat tanpa hambatan, serta perlindungan data yang terjamin sepenuhnya.</span>
</p>
</div>

</div>
</div>

        <div data-appears-component-name="listing_page_policy_overlay">
<div data-clg-id="WtOverlay" class="wt-overlay wt-overlay--info wt-overlay--has-close-icon web-toolkit shop-policies-overlay" id="policies-overlay" aria-hidden="true" aria-modal="false" role="dialog" aria-label="Shop policies" data-wt-overlay>
    <div class="wt-overlay__modal" data-overlay-modal>
            <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light"  aria-label="Close" data-wt-overlay-close>
                <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"/></path></svg></span>
            </button>
            <div class="wt-mb-xs-4">
        <h2 class="wt-text-heading wt-mb-xs-1">Kebijakan toko untuk m</h2>
    </div>
    <div class="shop-structured-policies-section" id="shop-policies" data-structured>
    <div data-region="policy-subregions">
            <div class="wt-mb-xs-4" data-id="returns-and-exchanges" >
    <h3 class="wt-text-title-large wt-mb-xs-1"> Pengembalian & penukaran </h3>
    <div class="wt-text-caption wt-sem-text-secondary">
        Lihat detail barang untuk kelayakan pengembalian dan penukaran.
    </div>
</div>            <div data-appears-component-name="listings_page_cancellations">
<div class="wt-mb-xs-4"  data-id="cancellations" >
    <h3 class="wt-text-title-large wt-mb-xs-1"> Pembatalan </h3>
    <div class="wt-text-caption wt-sem-text-secondary">
        <p>Pembatalan: accepted</p>
        <p>Minta pembatalan: dalam waktu 2 jam setelah pembelian</p>
 </div>
</div>
</div>
        <div data-appears-component-name="listings_page_structured_policies_payments">
<div class="wt-mb-xs-4"  data-id="payments" >
    <h3 class="wt-text-title-large wt-mb-xs-1"> Payments </h3>
    <div class="wt-pb-xs-2">
            <span class="etsy-icon wt-icon--smaller-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17,10V7A5,5,0,0,0,7,7v3H5v8a2,2,0,0,0,2,2H17a2,2,0,0,0,2-2V10H17Zm-4,7a1,1,0,0,1-2,0V13a1,1,0,0,1,2,0v4Zm2-7H9V7a2.935,2.935,0,0,1,3-3,2.935,2.935,0,0,1,3,3v3Z"/></path></svg></span>
            Secure options
        </div>
        <div class="wt-pb-xs-1">
            <div class="wt-display-inline-block">
        <span class="inline-svg svg-payment-icon wt-p-xs-1 wt-mb-xs-1"><svg xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" version="1.1" x="0px" y="0px" viewBox="0 0 1920.01 620.07999" xml:space="preserve" sodipodi:docname="d262c3fc767b0f2b042f1a30f2519b44.svgz" width="100%" height="100%" aria-labelledby="paymentsvisa-2-visa" role="img" focusable="false"><defs id="defs9"/></defs><sodipodi:namedview id="namedview7" pagecolor="#ffffff" bordercolor="#666666" borderopacity="1.0" inkscape:pageshadow="2" inkscape:pageopacity="0.0" inkscape:pagecheckerboard="0"/></sodipodi:namedview>
<style type="text/css" id="style2">
	.visa-svg-path{fill:#1434CB;}
</style>

<path class="visa-svg-path" d="M 729,10.96 477.63,610.7 h -164 L 189.93,132.08 C 182.42,102.6 175.89,91.8 153.05,79.38 115.76,59.15 54.18,40.17 0,28.39 L 3.68,10.96 h 263.99 c 33.65,0 63.9,22.4 71.54,61.15 L 404.54,419.15 566,10.95 h 163 z m 642.58,403.93 c 0.66,-158.29 -218.88,-167.01 -217.37,-237.72 0.47,-21.52 20.96,-44.4 65.81,-50.24 22.23,-2.91 83.48,-5.13 152.95,26.84 L 1400.22,26.59 C 1362.89,13.04 1314.86,0 1255.1,0 1101.75,0 993.83,81.52 992.92,198.25 c -0.99,86.34 77.03,134.52 135.81,163.21 60.47,29.38 80.76,48.26 80.53,74.54 -0.43,40.23 -48.23,57.99 -92.9,58.69 -77.98,1.2 -123.23,-21.1 -159.3,-37.87 l -28.12,131.39 c 36.25,16.63 103.16,31.14 172.53,31.87 162.99,0 269.61,-80.51 270.11,-205.19 m 404.94,195.81 h 143.49 L 1794.76,10.96 h -132.44 c -29.78,0 -54.9,17.34 -66.02,44 L 1363.49,610.7 h 162.91 l 32.34,-89.58 h 199.05 z m -173.11,-212.5 81.66,-225.18 47,225.18 z M 950.67,10.96 822.38,610.7 H 667.24 L 795.58,10.96 Z" id="path4"/></path>
<title id="paymentsvisa-2-visa">Visa</title></svg></span>
    
        <span class="inline-svg svg-payment-icon svg-payment-icon-p-2 wt-mb-xs-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 131.39 86.9" width="100%" height="100%" aria-labelledby="paymentsmastercard-2-mastercard" role="img" focusable="false">
    <defs>
        <style>.a{opacity:0;}.b{fill:#fff;}.c{fill:#72c800;}.d{fill:#72c800;}.e{fill:#0089c8;}</style>
    </defs>
    <title id="paymentsmastercard-2-mastercard">Mastercard</title>
    <g class="a">
        <rect class="b" width="131.39" height="86.9"/></rect>
    </g>
    <rect class="c" x="48.37" y="15.14" width="34.66" height="56.61"/></rect>
    <path class="d" d="M51.94,43.45a35.94,35.94,0,0,1,13.75-28.3,36,36,0,1,0,0,56.61A35.94,35.94,0,0,1,51.94,43.45Z"/></path>
    <path class="e" d="M120.5,65.76V64.6H121v-.24h-1.19v.24h.47v1.16Zm2.31,0v-1.4h-.36l-.42,1-.42-1h-.36v1.4h.26V64.7l.39.91h.27l.39-.91v1.06Z"/></path>
    <path class="e" d="M123.94,43.45a36,36,0,0,1-58.25,28.3,36,36,0,0,0,0-56.61,36,36,0,0,1,58.25,28.3Z"/></path>
</svg></span>
    
        <span class="inline-svg svg-payment-icon wt-p-xs-1 wt-display-none wt-mb-xs-1" data-apple-pay-icon=""><svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 50 25" aria-labelledby="paymentsapplepay-apple-pay" role="img" focusable="false"><title id="paymentsapplepay-apple-pay">Apple Pay</title><path d="M47.962 6.717l-2.802 7.62c-.175.46-.34.924-.488 1.376-.072.225-.14.438-.208.64h-.053c-.066-.21-.137-.432-.214-.664-.146-.448-.302-.887-.462-1.305l-2.997-7.668h-1.603l4.288 11.024c.112.266.128.387.128.437 0 .015-.005.105-.13.44-.268.66-.576 1.23-.91 1.69-.344.47-.658.85-.94 1.13-.324.325-.66.592-1.003.794-.35.207-.667.374-.948.5l-.163.072.52 1.27.167-.062c.136-.05.39-.168.778-.357.39-.192.824-.498 1.286-.91.397-.347.76-.758 1.082-1.22.317-.454.634-.987.945-1.58.307-.59.614-1.264.914-2 .3-.74.62-1.568.954-2.457l3.463-8.77h-1.605zm-11.72 8.095c0 .16-.038.38-.11.644-.093.274-.228.545-.404.804-.175.256-.395.49-.655.697-.26.205-.568.37-.92.49-.35.123-.755.184-1.203.184-.27 0-.536-.045-.79-.133-.252-.09-.475-.223-.666-.4-.19-.174-.348-.4-.468-.675-.118-.273-.178-.61-.178-1.004 0-.644.173-1.166.513-1.548.352-.397.803-.702 1.34-.907.547-.21 1.156-.35 1.81-.413.53-.05 1.05-.076 1.543-.076h.19v2.338zm1.526 2.343c-.016-.465-.023-.933-.023-1.398v-4.574c0-.542-.055-1.095-.162-1.644-.11-.562-.32-1.077-.622-1.53-.305-.46-.732-.838-1.266-1.126-.536-.287-1.23-.433-2.067-.433-.61 0-1.208.08-1.77.237-.57.16-1.125.424-1.66.79l-.12.083.507 1.187.184-.124c.388-.26.823-.47 1.3-.618.475-.146.958-.22 1.44-.22.627 0 1.127.112 1.483.337.363.226.636.506.812.833.184.338.304.697.357 1.07.055.39.083.737.083 1.035v.133c-2.227-.01-3.965.36-5.12 1.104-1.21.78-1.826 1.89-1.826 3.3 0 .406.073.816.216 1.22.145.41.366.774.655 1.087.29.317.665.575 1.114.767.448.196.973.295 1.56.295.467 0 .903-.06 1.3-.176.393-.12.75-.276 1.06-.47.31-.193.584-.41.818-.643.107-.104.197-.21.286-.315h.058l.14 1.335h1.446l-.04-.215c-.077-.425-.125-.87-.142-1.327zM26.145 9.59c-.77.647-1.863.975-3.248.975-.38 0-.74-.016-1.07-.047-.275-.027-.528-.07-.756-.127V3.397c.2-.037.445-.07.733-.103.366-.04.807-.06 1.312-.06.625 0 1.203.076 1.716.224.51.146.953.364 1.32.646.36.28.644.643.84 1.08.2.444.298.973.298 1.57 0 1.246-.385 2.2-1.143 2.838zm1.38-6.282c-.47-.453-1.075-.805-1.798-1.047-.718-.237-1.58-.358-2.563-.358-.68 0-1.313.033-1.885.098-.565.064-1.09.138-1.56.22l-.15.025v16.452h1.5v-6.93c.507.086 1.086.132 1.724.132.85 0 1.647-.11 2.368-.325.728-.215 1.366-.548 1.897-.99.532-.442.957-.996 1.268-1.647.307-.652.463-1.42.463-2.28 0-.714-.112-1.355-.332-1.907-.222-.553-.535-1.036-.933-1.442zm-14.99 6.867c-.02-2.34 1.91-3.466 2-3.522-1.09-1.583-2.777-1.803-3.38-1.827-1.438-.143-2.81.847-3.537.847-.73 0-1.853-.825-3.05-.8-1.567.023-3.013.912-3.82 2.315-1.626 2.834-.414 7.02 1.173 9.31.778 1.123 1.7 2.383 2.92 2.337 1.17-.045 1.61-.758 3.025-.758 1.413-.002 1.812.756 3.046.735 1.26-.027 2.06-1.146 2.83-2.274.89-1.298 1.256-2.56 1.276-2.624-.025-.014-2.452-.94-2.48-3.74zM9.862 3.31c.645-.782 1.08-1.868.962-2.95-.93.037-2.057.622-2.72 1.4-.6.69-1.12 1.797-.977 2.857 1.035.08 2.09-.527 2.736-1.308z" fill="#0A0B09" fill-rule="evenodd"/></path></svg></span>
    
</div>
        </div>
        <div class="wt-sem-text-secondary wt-text-caption">
            m menjaga keamanan & privasi informasi pembayaran Anda. Toko di m tidak pernah menerima informasi kartu kredit Anda.
        </div>


            <div class="wt-mb-xs-4">
        <div class="wt-content-toggle">
            <button class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-content-toggle--btn wt-content-toggle--with-icon wt-btn--small" data-wt-content-toggle="true" data-default-open="false" aria-controls="customs-and-duties-content-toggle-area" aria-expanded="false">
                        <span class="wt-flex-xs-auto wt-width-full">Customs and import taxes</span>
                    <span class="wt-content-toggle--btn__icon"></span>
            </button>
            <div id="customs-and-duties-content-toggle-area" class="wt-content-toggle__body" aria-hidden="true">
                <div class="wt-sem-text-secondary wt-text-caption">
                Pembeli bertanggung jawab atas bea cukai dan pajak impor yang mungkin berlaku. Saya tidak bertanggung jawab atas keterlambatan karena bea cukai.
                </div>
            </div>
        </div>
    </div>
</div>
</div>
        
        <div data-appears-component-name="listings_page_structured_policies_additional_terms">

</div>
        
    </div>
</div>

    </div>
</div>
</div>
    </div>
</div>
    

    <div data-listing-page-lazy-loaded-bottom-section>
        <div data-neu-spec-placeholder="1" id="20703f1ff830a582cb5f96d2820c6e71">
    <script type="text/json" data-neu-spec-placeholder-data="1">{"spec_name":"Listzilla_ApiSpecs_Tags_Landing","args":{"listing_id":1498491133,"shop_id":25947065,"is_raised_tags":false,"click_queries":["baby sweater name","custom baby sweater","sweater name","toddler name sweater","baby knit sweater","baby sweater","baby","personalized sweater baby embroidered","personalized baby sweater","kids and baby","embroidered sweater","embroidered baby sweater","personalised baby sweater grey","baby hand embroidered jumper","growing into sweater","hand stitched baby jumpers","personalised embroidered jumper baby","burnt orange baby jumper","personalised knitted jumpers for boys","baby jumper ireland","newborn personalised embroidered knitted jumper","embroidered personalised knitted jumper baby","personalised make new baby jumper","handmade personalised jumper","personalised jumper kids boys","knit personalised baby jumper","personalised crochet jumpers","personalized jumper baby boy","uk shop only baby","girls jumper name","baby sweatshirt personalised 000","named baby girl gifts","embriorded kids jumpers","baby jumpers","jumper with personalised","customised name baby jumpers","personalized knit jumper boy","boys personalized embroidered baby jasper","personalised kids gift au","personalized baby jumps","baby gift personalised jumpers","murphy name jumper","oliver jumper kids","personalised baby boy jumper green","newborn baby gift for boy","baby boy custom jumper","personalised jumper 8 years old","name sweater babys","personalised jumper with baby name","chunky knit name","newborn sweater baby girl","knitted baby personalized","name embroidered jumper baby","baby name knit","dark green baby jumper","embroidered jumpertoddler girl","baby girl jumper name","personalised jumper for girls","cotton name jumper","personalised babies jumper","personal knitted jumper baby","personalised baby girl jumpers","hello jumper baby","embroidery baby knit","4 month baby boy","personilsed toddler gifts","persibslised jumper","embroidery kids jumpers","personalized embroidered knitwear","personalized 1 year girl gift","personalised jumper for teenager","chain stitch jumper","embroidered children's jumpers","personalised baby knitted jumper","baby sweater rimperwith name","personalises baby jumper","personalised gifts babies","personalised jumper 7 year","embroidered valentine sweatshirt baby","personalised name jumper baby girl","knitted baby jumper boy","personalised woolen jumper","jumpers name","blue baby gift","named kids clothing","personalized knit jumper 6t","grow jumper baby","personalised sweater boy","lily baby jumper","hallie jumper","personality baby","birthday gift for babies","personalized jumpers for boys","chunky knit personalised jumper","personalized letter knitted jumper","baby girl sweater flower","baby name jumper on back","newborn personised","baby names jumpers","newborn name jumpers","baby jumper name back","name jumper sage","stitched jumper baby","george bear knits","custom baby handmade","bobbi name sweater","kid jumper with name","personalised embroidered boys jumpers","kids jumper name blue","baby boy nursery gift","personalised gift newborn girl","names on jumper","kids custom jumpers","personalized girl jumper","personalised baby jumper 1 year","personalised wool baby jumper","customizable baby girl sweater","knitted name juniper","peter baby","customized baby jumper","embroided kids jumpers","embroidered knit boy jumper","girl name jumper","kids cotton jumpers","toddler name jumper","sweater names with flowers","cardigan baby embroidered name","personalised infant pullover","personalised knitted boys jumper","knitted sweater elle","jumper names child embroider","personalised cream jumpers","crocheted jumper name baby","baby jumper embroidery detail","custom baby sweater tainbox text","personalized baby boy jumper","named kids jumper","personalized kids sweater cotton","embroidered name sweater with flower","personalized new born jumper","sewwhatbubba","kids jumpers name","lainey mae personalised jumper","personalised sweater baby","little name sweater","personalised knitted baby gift","woven name jumper","baby name sweater braden","baby personalise jumper","personalised baby jumper on back","cotton jumper kids","knitted jumper with embroidered name","baby toddler personalised gifts","personalized newborn jumper","baby name on jumper","personalised hand knitted baby jumper","name wool jumper","crochet baby name jumper","stitches aint knit","custom baby jumper 100% cotton","personalized jumper new born","he's here knit outfit","personalised new born baby jumpers","embroidered knitted baby","personalised baby gift green","newborns gift","knitted baby named jumper","personaliseed baby jumper","baby boy knitted personalised jumper","hand knit name jumper","boy baby jumper","baby boy personalized jumpers","custom embroidered onesie newborn","custom embroidered jumper for baby","sweater, baby","customised knitted sweater","custom clothing babies","personalized boy gifts for baby","personalised name jumpers girls","grow with me girl sweater","personalised yarn jumper","jumper with name on boy","newborn personalised baby jumper","personalised knitted top","jumper name kids","newborn jumper boy name","crochet baby personalized","personalised baby jumper fast delivery","personalised jumper newbornbaby","baby name sweater luxbulous","embroidered childs jumper","baby knit onesie embroidered","personalised clothes baby boy","jumper baby personalized","embroidered personalized sweater toddler","yellow custom baby sweater","bow name jumper","personalised baby jumper.","personalised knitted jumper for babies","baby cardigan crochet name","knitted personalised onesie","personalised gift baby gift","baby jumpers 0-12months","personalized baby knit","name sweaters for babys","persinalized baby","newborn gift initial","personalized babyname jumper","embroidered jumper knitted","personalised gifts babys","embroidered knit onesie baby","blue personalised baby jumper"],"visual_internal_enabled":false,"visual_external_enabled":false}}</script>
    <div>
    
        
</div>
</div>
    </div>
    
    <br>
    
    <div class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs wt-mb-md-4">
    <div class="wt-display-flex-xs wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs">
            <div class="wt-text-caption">
            </div>
    </div>

    <style>
        .faq-section{
    max-width:1200px;
    margin:50px auto;
    padding:40px 20px;
    position:relative;
    background-color: rgb(44 44 44 / 78%);
    backdrop-filter: blur(25px);
    border-radius: 20px;
}
     
.faq-section::before{
    content:"";
    position:absolute;
    top:0;left:50%;
    transform:translateX(-50%);
    width:80%;
    height:2px;
    background:linear-gradient(90deg,transparent,#00ff39,transparent)
}
             
.faq-section h2{
    text-align:center;
    font-size:34px;font-weight:700;
    margin-bottom:50px;
    background: linear-gradient(135deg, #00ff74, #ffffff, #00ff74);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    background-clip:text;
    font-family:"Poppins",sans-serif;letter-spacing:1px
}
     
.faq-container{
    display:flex;
    flex-direction:column;
    gap:25px
}
     
.faq-item{
    background:linear-gradient(145deg,#0a0a0a,#1a1a1a);
    
    border-radius:20px;
    overflow:hidden;
    transition:all .4s ease;
    box-shadow:0 5px 20px rgba(0,0,0,0.5);
    position: relative; /* Tambahkan ini */
}

/* ANIMASI RGB BERJALAN (diambil dari CSS pertama) */
.faq-item::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: 20px;
    padding: 2px;
    background: linear-gradient(120deg,
            #00ff74, #0799cb, #00ff2a, #00ffff, #0000ff, #ff00ff, #00ff74);
    background-size: 400%;
    -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    animation: ledRotate 8s linear infinite;
    z-index: 0;
    opacity: 0; /* Sembunyikan dulu */
    transition: opacity 0.3s ease;
}

/* Animasi ledRotate (sama dengan CSS pertama) */
@keyframes ledRotate {
    0% {
        background-position: 0% 50%;
    }
    100% {
        background-position: 400% 50%;
    }
}

/* Efek shinePass (opsional, dari CSS pertama) */
@keyframes shinePass {
    0%, 100% {
        opacity: 0.3;
    }
    50% {
        opacity: 0.7;
    }
}
     
.faq-item:hover{
    border-color:#ffffff;
    transform:translateX(10px);
    box-shadow:0 12px 35px rgba(253, 4, 4, 0.25)
}

/* Tampilkan animasi RGB saat hover */
.faq-item:hover::before {
    opacity: 1;
}
    .faq-question{
    width:100%;
    padding:28px 35px;
    background:transparent;
    color:#ffffff;
    font-size:18px;
    font-weight:600;
    text-align:left;
    border:none;
    cursor:pointer;
    display:flex;
    justify-content:space-between;
    align-items:center;
    font-family:"Poppins",sans-serif;
    transition:all .3s ease;
    position: relative; /* Agar di atas animasi */
    z-index: 1;
}
         
.faq-question:hover{
    color:#00ff74
}
         
.faq-question::after{
    content:'+';
    font-size:32px;
    font-weight:300;
    transition:all .4s ease;
    color:#00ff74;
    width:40px;
    height:40px;
    display:flex;
    align-items:center;
    justify-content:center;
    border:2px solid #00ff74;
    border-radius:50%;
    background:rgb(44 44 44 / 78%)
}
         
.faq-item.active .faq-question::after{
    transform:rotate(135deg);
    background:linear-gradient(135deg,#ffffff,#ffffff);
    color:#000;
    border-color:transparent
}
         
.faq-answer{
    max-height:0;
    overflow:hidden;
    transition:max-height .5s ease,padding .5s ease;
    background:linear-gradient(180deg, rgb(253 4 222 / 59%), #00000000);
    padding:0 35px;
    position: relative; /* Agar di atas animasi */
    z-index: 1;
}
         
.faq-item.active .faq-answer{
    max-height:800px;
    padding:30px 35px;
    border-top:1px solid rgba(253, 4, 4, 0.3)
}
         
.faq-answer p{
    color:#e0e0e0;
    font-size:16px;
    line-height:2;
    margin:0;
    font-family:"Poppins",sans-serif
}
 
@media (max-width:768px)
{
    .faq-section {padding:30px 15px}
     
    .faq-section h2 {font-size:26px}
     
    .faq-question {
        font-size:16px;
        padding:22px 25px
    }
     
    .faq-question::after {
        width:35px;
        height:35px;
        font-size:28px
    }
     
    .faq-answer {padding:0 25px}
     
    .faq-item.active .faq-answer {padding:25px}
     
    .faq-item:hover {transform:translateX(5px)}
}
    </style>
<!-- wp:heading -->
<center><h2 style="font-weight: bold;">INFORMASI SEPUTAR BANDAR SLOT 2026 </h2>
<!-- /wp:heading -->
 <script>
         document.addEventListener('DOMContentLoaded',
             function(){const faqItems=document.querySelectorAll('.faq-item');
             faqItems.forEach(item=>{const question=item.querySelector('.faq-question');
             question.addEventListener('click',
             ()=>{const isActive=item.classList.contains('active');
             faqItems.forEach(otherItem=>{otherItem.classList.remove('active')});
             if(!isActive){item.classList.add('active')}})})});
         </script>
<!-- wp:html -->
<br>

    
    <div class="wt-text-caption wt-text-center-xs wt-text-left-lg">
        <a href="https://rescuevolunteers.org/about-us/">Bandar Slot</a>
            <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>
        <a href="https://rescuevolunteers.org/about-us/">LOGIN BANDAR SLOT 2026</a>
        <a href="https://rescuevolunteers.org/about-us/"></a>
            <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"/></path></svg></span>
        <a href="https://rescuevolunteers.org/about-us/">LOGIN EMO78</a>
</div>
<br>
<br />
    <div id="google-one-tap-modal-div" class="google-one-tap-modal-div">
</div>
<style>
   .m-fixed-footer {
                    display: flex;
                    justify-content: space-around;
                    align-items: center;
                    position: fixed;
                    left: 50%;
                    transform: translateX(-50%);
                    bottom: 20px;
                    width: 90%;
                    height: 70px;
                    background: rgba(42, 42, 42, 0.897);
                    backdrop-filter: blur(15px);
                    border-radius: 20px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4),
                        0 0 25px rgba(255, 215, 0, 0.3),
                        inset 0 0 15px rgba(255, 255, 255, 0.05);
                    z-index: 9999;
                    animation: floatUp 0.8s ease-out;
                    overflow: hidden;
                    border: 1.5px solid rgba(255, 215, 0, 0.5);
                }

                .m-fixed-footer::before {
                    content: "";
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    width: 100%;
                    /* SUPER BESAR */
                    height: 150%;
                    background:
                        url('') center/cover no-repeat,
                        rgb(0, 0, 0);
                    border-radius: 20px;
                    z-index: 0;
                }

                /* Border gradient tetep ada */
                .m-fixed-footer::after {
                    content: "";
                    position: absolute;
                    inset: 0;
                    border-radius: 20px;
                    padding: 2px;
                    background: linear-gradient(120deg,
                            #00ff74, #0799cb, #00ff2a, #00ffff, #0000ff, #ff00ff, #00ff74);
                    background-size: 400%;
                    -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
                    -webkit-mask-composite: xor;
                    mask-composite: exclude;
                    animation: ledRotate 8s linear infinite;
                    z-index: 1;
                }

                /* Shine effect di atas */
                .dragon-shine {
                    content: "";
                    position: absolute;
                    top: -50%;
                    left: 0;
                    width: 100%;
                    height: 200%;
                    background: radial-gradient(circle at 50% 0%, rgba(255, 255, 255, 0.15), transparent 70%);
                    animation: shinePass 6s ease-in-out infinite;
                    z-index: 1;
                }

                @keyframes ledRotate {
                    0% {
                        background-position: 0% 50%;
                    }

                    100% {
                        background-position: 400% 50%;
                    }
                }

                @keyframes shinePass {

                    0%,
                    100% {
                        opacity: 0.3;
                    }

                    50% {
                        opacity: 0.7;
                    }
                }

                .m-fixed-footer a {
                    flex: 1;
                    text-decoration: none;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    color: #06f84f;
                    font-size: 12px;
                    font-weight: 700;
                    text-transform: uppercase;
                    transition: all 0.3s ease;
                    max-width: 70px;
                    position: relative;
                    padding: 8px 0;
                    z-index: 2;
                    /* Pastikan di atas naga */
                }

                .m-fixed-footer a img {
                    width: 26px;
                    height: 26px;
                    margin-bottom: 5px;
                    transition: transform 0.3s ease, filter 0.3s ease;
                    filter: drop-shadow(0 0 6px rgba(255, 215, 0, 0.6));
                    animation: floatBtn 3s ease-in-out infinite;
                }

                @keyframes floatBtn {

                    0%,
                    100% {
                        transform: translateY(0);
                    }

                    50% {
                        transform: translateY(-3px);
                    }
                }

                .m-fixed-footer a::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 0;
                    height: 3px;
                    background: linear-gradient(90deg, #ffd900, #0ab6d1e0);
                    border-radius: 0 0 3px 3px;
                    transition: width 0.3s ease;
                    z-index: 1;
                }

                .m-fixed-footer a:hover {
                    color: #fff;
                    transform: translateY(-3px);
                    text-shadow: 0 0 10px #fff, 0 0 20px #0799cb;
                }

                .m-fixed-footer a:hover::before {
                    width: 70%;
                }

                .m-fixed-footer a:hover img {
                    transform: scale(1.3) rotate(8deg);
                    filter: drop-shadow(0 0 12px #fff);
                }

                .m-fixed-footer .tada {
                    background: linear-gradient(135deg, #0799cb 0%, #0ab6d1e0 100%);
                    border-radius: 15px;
                    padding: 8px 12px;
                    transform: scale(1.1);
                    box-shadow: 0 0 20px rgba(255, 215, 0, 0.7);
                    transition: all 0.4s ease;
                    position: relative;
                    overflow: hidden;
                    animation: pulseEnergy 2s infinite;
                    z-index: 2;
                }

                @keyframes pulseEnergy {

                    0%,
                    100% {
                        box-shadow: 0 0 20px rgba(255, 215, 0, 0.7);
                    }

                    50% {
                        box-shadow: 0 0 30px rgba(255, 215, 0, 0.9), 0 0 40px rgba(255, 215, 0, 0.6);
                    }
                }

                .m-fixed-footer .tada::before {
                    content: '';
                    position: absolute;
                    top: -50%;
                    left: -50%;
                    width: 200%;
                    height: 200%;
                    background: linear-gradient(to bottom right,
                            rgba(255, 255, 255, 0.4),
                            rgba(255, 255, 255, 0));
                    transform: rotate(30deg);
                    transition: all 0.5s ease;
                }

                .m-fixed-footer .tada:hover::before {
                    transform: rotate(30deg) translate(10%, 10%);
                }

                .m-fixed-footer .tada img {
                    width: 28px;
                    height: 28px;
                    margin-bottom: 4px;
                    filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.9));
                    position: relative;
                    z-index: 1;
                }

                .m-fixed-footer .tada:hover {
                    transform: scale(1.2);
                    box-shadow: 0 0 25px rgba(255, 215, 0, 0.9), 0 0 35px rgba(255, 215, 0, 0.7);
                    background: linear-gradient(135deg, #fff8dc, #0799cb);
                    color: #333;
                }

                .m-fixed-footer .tada:hover img {
                    filter: drop-shadow(0 0 15px #fff);
                }

                @keyframes floatUp {
                    0% {
                        opacity: 0;
                        transform: translate(-50%, 50px);
                    }

                    100% {
                        opacity: 1;
                        transform: translate(-50%, 0);
                    }
                }

                /* Responsif untuk mobile */
                @media (max-width: 480px) {
                    .m-fixed-footer {
                        width: 95%;
                        height: 65px;
                    }

                    .m-fixed-footer::before {
                        background-size: 350px auto;
                        /* Perkecil naga di mobile */
                    }

                    .m-fixed-footer a {
                        font-size: 11px;
                        padding: 6px 0;
                    }

                    .m-fixed-footer a img {
                        width: 22px;
                        height: 22px;
                    }

                    .m-fixed-footer .tada img {
                        width: 24px;
                        height: 24px;
                    }
                    
                }

</style>

<style>
    /* Popup Overlay */
    .popup-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(75, 77, 70, 0.664);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .popup-box {
        position: relative;
        width: 90%;
        max-width: 400px;
        background: #1752c0bd;
        border-radius: 10px;
        overflow: hidden;
        text-align: center;
        box-shadow: 0 5px 15px rgba(255, 255, 255, 0.3);
        animation: popupBounce 0.8s ease;
    }

    /* Animation for Popup Bounce */
    @keyframes popupBounce {
        0% {
            transform: scale(0.5);
            opacity: 0;
        }

        60% {
            transform: scale(1.1);
            opacity: 1;
        }

        100% {
            transform: scale(1);
        }
    }

    /* Close Button */
    .popup-close {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 24px;
        cursor: pointer;
    }

    /* Popup Content Styles */
    .popup-content h2 {
        margin: 15px 0 10px;
        font-size: 20px;
        color: #d4e30b;
    }

    .popup-content p {
        font-size: 16px;
        margin-bottom: 15px;
    }

    .popup-content a {
        display: inline-block;
        padding: 10px 20px;
        background: #e74c3c;
        color: #5eff00;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        position: relative;
        animation: floatButton 2s ease-in-out infinite, blinkColor 1s linear infinite;
        transition: transform 0.2s;
    }

    /* Hover Effect for Button */
    .popup-content a:hover {
        transform: scale(1.1) rotate(-3deg);
    }

    /* Floating Button Animation */
    @keyframes floatButton {
        0% {
            transform: translateY(0px);
        }

        50% {
            transform: translateY(-5px);
        }

        100% {
            transform: translateY(0px);
        }
    }

    /* Blinking Button Color Animation */
    @keyframes blinkColor {
        0%, 100% {
            background-color: #d5e406;
        }

        25% {
            background-color: #b8d805d5;
        }

        50% {
            background-color: #0968c0;
        }

        75% {
            background-color: #0294d8;
        }
    }

    /* Image inside Popup */
    .popup-box img {
        width: 100%;
        height: auto;
        display: block;
    }
</style>

<div id="popup" class="popup-overlay">
    <div class="popup-box">
        <img src="img/pop-up.jpg" alt="IPOTOTO">

        <div class="popup-content">
            <h2> BANDAR SLOT TERPERCAYA </h2>
            <a href="https://rescuevolunteers.pages.dev/" target="_blank">DAFTAR DISINI</a>
        </div>
    </div>
</div>

<div class="m-fixed-footer">
                <div class="dragon-shine"></div>
                <a href="https://rescuevolunteers.pages.dev/" target="_blank">
                    <img src="img/promo.png" alt="PROMO">
                    PROMO
                </a>
                <a href="https://rescuevolunteers.pages.dev/" target="_blank">
                    <img src="img/login.png" alt="LOGIN">
                    LOGIN
                </a>
                <a href="https://rescuevolunteers.pages.dev/" target="_blank" class="tada">
                    <img src="img/daftar.png" alt="DAFTAR">
                    DAFTAR
                </a>
                <a href="https://rescuevolunteers.pages.dev/" target="_blank">
                    <img src="img/wa.gif" alt="LINK">
                    WhatsApp
                </a>
                <a href="https://rescuevolunteers.pages.dev/" target="_blank">
                    <img src="img/lc.png" alt="CHAT">
                    CHAT
                </a>
            </div>
            
            <br>
            <br>
            <div id="popup-m">
</div>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"67ba95188a7248eaae925a72bd1d37fc","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"2f9ee7dea562431b8605608945a440a7","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>

</center></div></div></div></div></main><div id="privacy-settings-manager-load-complete" style="display: none;"></div><div id="footer-script-loaded" style="display: none;"></div><div id="privacy-settings-manager-load-complete" style="display: none;"></div><div id="footer-script-loaded" style="display: none;"></div><div id="wt-portals"><div id="wt-portal-blue" style="z-index: 80; position: relative;"></div><div id="wt-portal-green" style="z-index: 80; position: relative;"><div id="wt-modal-container"><div data-wt-overlay="" data-report-item-overlay="" id="report-item-overlay" class="wt-overlay" role="dialog" aria-hidden="true" aria-modal="false" aria-label="report-item-overlay-title">
        <div class="wt-overlay__modal" data-overlay-modal="">
            <button class="wt-btn wt-btn--icon wt-btn--tertiary wt-btn--light wt-overlay__close-icon" data-wt-overlay-close="" aria-label="Close">
                <span class="etsy-icon wt-icon--smaller"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>
            </button>
            <div data-report-item-form-container="" class="">
    <div class="wt-overlay__header report-item-step">
        <h2 class="wt-text-heading" id="report-item-overlay-title">Apa yang salah dengan daftar ini?</h2>
    </div>
    <div class="wt-overlay__header report-item-step wt-display-none">
        <h3 class="wt-text-heading" id="report-item-overlay-title-more">Add more details</h3>
        <h3 class="wt-text-body-01 wt-mt-xs-3">Bagikan informasi lebih spesifik untuk membantu kami meninjau item ini dan melindungi pasar kami.</h3>
    </div>
    <form data-report-item-form="" action="/add_report.php" method="post">
        <div class="report-item-step">
            <div class="wt-select wt-mb-xs-3">
                <select class="wt-select__element" id="report-item-choices" data-report-item-choices="">
                    <optgroup>
                        <option value="default" selected>Pilih alasan…</option>
                        <option value="order-problem">Ada masalah dengan pesanan saya</option>
                        <option value="ip-policy">Ini menggunakan kekayaan intelektual saya tanpa izin</option>
                        <option value="flag-item">Saya rasa itu tidak sesuai dengan kebijakan m</option>
                    </optgroup>
                </select>
                <label for="report-item-choices" class="wt-screen-reader-only">Pilih alasan…</label>
            </div>
            <div data-report-choice="order-problem" id="order-problem" class="wt-display-none" style="display: none;">
                <p class="wt-mb-xs-2 prose">Hal pertama yang harus Anda lakukan adalah menghubungi penjual secara langsung.</p>
                <p class="wt-mb-xs-2 ip-policy prose">Jika Anda sudah melakukannya, barang Anda belum sampai, atau tidak sesuai deskripsi, Anda dapat melaporkannya ke m dengan membuka kasus.</p>
                <p class="wt-mb-xs-2 prose">
                    <a href="/help/article/5307" target="_blank">
                        Laporkan masalah dengan pesanan
                    </a>
                </p>
            </div>
            <div data-report-choice="ip-policy" id="ip-policy" class="wt-display-none" style="display: none;">
                <p class="wt-mb-xs-2 prose">Kami menanggapi masalah kekayaan intelektual dengan sangat serius, tetapi banyak dari masalah ini dapat diselesaikan langsung oleh pihak-pihak yang terlibat. Kami sarankan Anda menghubungi penjual secara langsung untuk menyampaikan kekhawatiran Anda dengan hormat.</p>
                <p class="wt-mb-xs-2 prose">Jika Anda ingin mengajukan tuduhan pelanggaran, Anda harus mengikuti proses yang dijelaskan dalam <a href="/legal/ip" target="_blank">Kebijakan Hak Cipta dan Kekayaan Intelektual</a>.</p>
            </div>
            <div data-report-choice="flag-item" id="flag-item" class="wt-display-none" style="display: none;">
                <div class="wt-mb-xs-2">
                    <a href="/legal/sellers#allowed" target="_blank">
                        Tinjau bagaimana kami mendefinisikan barang buatan tangan, vintage, dan perlengkapan
                    </a>
                </div>
                <div class="wt-mb-xs-2">
                    <a href="/legal/prohibited" target="_blank">
                        Lihat daftar barang dan bahan terlarang
                    </a>
                </div>
                <div class="wt-mb-xs-4">
                    <a href="/legal/policy/listing-mature-content-correctly/242665462117" target="_blank">
                        Baca kebijakan konten dewasa kami
                    </a>
                </div>
                <div data-report-reason="" class="wt-validation">
                    <fieldset class="wt-mb-xs-4">
                        <legend class="wt-label wt-mb-xs-2">Beritahu kami mengapa Anda melaporkan item ini</legend>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="not_handmade_vintage_or_craft" type="radio" class="wt-radio" id="flag_not_handmade_vintage_or_craft" name="flag_type_mnemonic" value="LISTING_CSV_MEMBER_FLAG" />
                                <label for="flag_not_handmade_vintage_or_craft">Ini bukan barang buatan tangan, vintage, atau kerajinan</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="pornographic" type="radio" class="wt-radio" id="flag_pornographic" name="flag_type_mnemonic" value="OC_PORNOGRAPHY" />
                                <label for="flag_pornographic">Itu pornografi</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="hate_speech_or_harassment" type="radio" class="wt-radio" id="flag_hate_speech_or_harassment" name="flag_type_mnemonic" value="OC_HATE_VIOLENT_HARMFUL" />
                                <label for="flag_hate_speech_or_harassment">Ini adalah ujaran kebencian atau pelecehan</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="minor_safety" type="radio" class="wt-radio" id="flag_minor_safety" name="flag_type_mnemonic" value="LISTING_MINOR_SAFETY" />
                                <label for="flag_minor_safety">Ini adalah ancaman terhadap keselamatan anak di bawah umur</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="violence_or_self_harm" type="radio" class="wt-radio" id="flag_violence_or_self_harm" name="flag_type_mnemonic" value="OC_HATE_VIOLENT_HARMFUL" />
                                <label for="flag_violence_or_self_harm">Ini mendorong kekerasan atau menyakiti diri sendiri</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="dangerous_or_hazardous" type="radio" class="wt-radio" id="flag_dangerous_or_hazardous" name="flag_type_mnemonic" value="LISTING_PROHIBITED" />
                                <label for="flag_dangerous_or_hazardous">Itu berbahaya atau membahayakan</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="violates_law" type="radio" class="wt-radio" id="flag_violates_law" name="flag_type_mnemonic" value="CC_REPORTED_ILLEGAL_CONTENT" />
                                <label for="flag_violates_law">Ini melanggar hukum atau peraturan tertentu</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="violates_not_listed_policy" type="radio" class="wt-radio" id="flag_violates_not_listed_policy" name="flag_type_mnemonic" value="LISTING_PROHIBITED" />
                                <label for="flag_violates_not_listed_policy">Ini melanggar kebijakan yang tidak tercantum di sini</label>
                            </div>
                        <div data-error="no-report-reason" id="no-report-reason" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">Silakan pilih alasannya</div>
                    </fieldset>
                </div>
            </div>
        </div>
        <div class="report-item-step wt-display-none">
            <div data-report-comment="" class="wt-validation" tabindex="0">
                <label class="wt-screen-reader-only" for="report-item-reason">Sertakan hal lain yang perlu kami ketahui tentang item ini</label>
                <textarea id="report-item-reason" data-report-comment-input="" name="reason" class="wt-textarea" placeholder="Include anything else we should know about this item"></textarea>
                <div data-error="no-report-comment" id="no-report-comment" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                    <span class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path></svg></span> Pastikan untuk menambahkan lebih banyak rincian.
                </div>
                <div data-error="comment-min-length-illegal-content" id="comment-min-length-illegal-content" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                    <span class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path></svg></span> Tambahkan detail lebih lanjut, termasuk nama undang-undang atau peraturan (minimal 10 karakter).
                </div>
            </div>
        </div>
        <div data-report-bonafide="" class="wt-mt-xs-2 wt-mb-xs-2 wt-sem-text-secondary wt-display-none">
            Dengan mengirimkan laporan ini, Anda mengonfirmasi bahwa informasi dan klaim dalam formulir ini akurat.
        </div>
        <div data-report-item-overlay-footer="" class="wt-overlay__footer wt-pt-xs-0 wt-display-none" id="overlay-footer" aria-hidden="true" style="display: none;">
            <input type="hidden" name="_nnc" value="3:1757443933:IZCDEmL34NPkU3X48ZDZz8rZZPp4:9d62b7617187d17444be81b8f36c4dfb31d3884bb44f5aec3ebde05d24141848" class="hidden csrf" />
            <input type="hidden" name="target_id" value="1498491133" />
            <input type="hidden" name="target_type" value="listing" />
            <input type="hidden" name="send_report" value="true" />
            <input type="hidden" name="ref" value="unknown" />
            <input type="hidden" name="platform" value="web" />
            <input type="hidden" name="search_query" value="" />
            <div class="wt-overlay__footer__cancel">
                <button data-report-back-button="" type="button" class="wt-btn wt-btn-transparent report-item-step wt-display-none">
                    Go back
                </button>
            </div>
            <div class="wt-overlay__footer__action">
                <button data-report-next-button="" type="button" class="wt-btn wt-btn--primary report-item-step">
                    Next
                </button>
                <button data-report-submit-button="" type="submit" class="wt-btn wt-btn--primary report-item-step wt-display-none">
                    Submit report
                </button>
            </div>
        </div>
    </form>
</div>
        </div>
    </div><div class="wt-overlay image-overlay wt-justify-content-center" data-image-overlay="" data-animate-out="false" id="image-overlay" role="dialog" aria-hidden="true">
    <div class="wt-display-flex-xs wt-justify-content-center wt-height-full image-overlay-main-image-container" data-overlay-modal="">
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-position-top wt-mt-xs-2 wt-mr-xs-2" data-wt-overlay-close="true" aria-label="close">
                <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>

</button>
        <div data-overlay-main-image-container="" class="wt-position-relative wt-mr-xl-4 wt-mr-xs-2 wt-ml-xs-2 wt-flex-grow-xs-1 wt-mb-xs-4 wt-mt-xs-10">
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-left wt-vertical-center wt-shadow-elevation-3 wt-ml-xs-2" data-image-overlay-prev="true" aria-label="previous">
                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z"></path></svg></span>

</button>
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-vertical-center wt-shadow-elevation-3 wt-mr-xs-2" data-image-overlay-next="true" aria-label="next">
                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z"></path></svg></span>

</button>
            <ul class="wt-list-unstyled wt-overflow-hidden image-overlay-list wt-position-relative wt-vertical-center wt-display-flex-xs wt-justify-content-center" style="padding-top: 80%;" data-image-overlay-list="" tabindex="0">
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="0" data-image-id="6845617078">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 1" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="3000" data-original-image-height="3000" data-index="0" data-src-zoom-image="img/banner.jpg" />
                    </li>
                        <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full wt-rounded" data-listing-image="" data-listing-video="true" data-index="1" data-image-id="listing-video-1">
                            
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--02 wt-mt-xs-0 wt-vertical-center wt-display-none image-overlay-image--landscape" aria-live="assertive" data-overlay-video-loading-spinner="" aria-hidden="true">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><circle fill="transparent" cx="24" cy="24" r="21"></circle></svg></span>
        Loading
    </div>

                        </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="2" data-image-id="6354031418">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 2" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="2" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="3" data-image-id="6402117407">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 3" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="3" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="4" data-image-id="6354386589">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 4" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="4" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="5" data-image-id="6285298756">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="name yarn jumper for kids" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="5" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="6" data-image-id="6430051759">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 6" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="6" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="7" data-image-id="7056312285">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 7" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="7" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="8" data-image-id="6332997945">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 8" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="8" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="9" data-image-id="6722497805">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 9" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="9" data-src-zoom-image="img/banner.jpg" />
                    </li>
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="10" data-image-id="6356157787">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 10" data-delay-src="img/banner.jpg" data-delay-srcset="img/banner.jpg 1x, img/banner.jpg 2x" data-original-image-width="2000" data-original-image-height="2000" data-index="10" data-src-zoom-image="img/banner.jpg" />
                    </li>
                <div class="wt-z-index-1 click-to-zoom-text wt-position-absolute wt-display-none" data-click-to-zoom-toast="">
<span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-text-body-01 image-overlay-image--landscape">
                        <span class="wt-icon wt-icon--smallest"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10,2a8,8,0,1,0,8,8A8.009,8.009,0,0,0,10,2Zm0,14a6,6,0,1,1,6-6A6.007,6.007,0,0,1,10,16Z"></path><path d="M14,9H11V6A1,1,0,1,0,9,6V9H6a1,1,0,0,0,0,2H9v3a1,1,0,1,0,2,0V11h3A1,1,0,0,0,14,9Z"></path><path d="M21.707,20.293l-4-4a1,1,0,0,0-1.414,1.414l4,4A1,1,0,0,0,21.707,20.293Z"></path></svg></span>
                    Click to zoom

</span>
                </div>
            </ul>
        </div>
            <div class="wt-overflow-y-auto wt-position-relative image-overlay-thumbnail-container wt-z-index-1 wt-pt-xs-10" data-thumbnail-container="">
                        <ul data-image-overlay-thumbnail-list="" class="wt-z-index-1 wt-list-unstyled wt-flex-direction-row-lg wt-flex-direction-column-xs wt-display-flex-xs wt-flex-wrap wt-align-content-flex-start">
                                <li data-index="0" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6845617078">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 1" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                    <li data-index="1" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="listing-video-1" data-listing-video="true">
                                        <div class="wt-position-relative wt-height-full">
                                            <img class="wt-width-full" data-carousel-thumbnail-image="" src="img/banner.jpg" data-src-delay="img/banner.jpg" />

                                            <div class="wt-circle wt-overflow-hidden video-thumbnail-icon wt-position-top wt-position-bottom wt-position-right wt-position-left wt-bg-white wt-shadow-elevation-3">
                                                <span class="etsy-icon video-thumbnail-icon__with-image wt-position-top wt-position-bottom wt-position-right"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polygon points="4 4 4 20 20 12 4 4"></polygon></svg></span>
                                            </div>
                                        </div>
                                    </li>
                                <li data-index="2" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6354031418">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 2" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="3" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6402117407">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 3" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="4" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6354386589">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 4" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="5" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6285298756">
                                    <img class="wt-width-full" alt="name yarn jumper for kids" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="6" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6430051759">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 6" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="7" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="7056312285">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 7" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="8" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6332997945">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 8" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="9" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6722497805">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 9" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                                <li data-index="10" class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2" tabindex="0" data-image-id="6356157787">
                                    <img class="wt-width-full" alt="EMO78 : Bandar Slot Online Terpercaya & Link Login Terbaru EMO78 image 10" data-carousel-thumbnail-image="" loading="lazy" src="img/banner.jpg" />
                                </li>
                        </ul>
            </div>
    </div>
    
</div></div></div><div id="wt-portal-yellow" style="z-index: 80; position: relative;"></div><div id="wt-portal-orange" style="z-index: 80; position: relative;"></div><div id="wt-portal-red-orange" style="z-index: 80; position: absolute; top: 0px; left: 0px; width: 100%; height: 0px;"></div><div id="wt-portal-red" style="z-index: 80; position: relative;"></div></div><script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"8d896bcdcc564fcc9175a179425a39a2","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"8d896bcdcc564fcc9175a179425a39a2","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body></html>