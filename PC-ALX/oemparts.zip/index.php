<!DOCTYPE html>
<html lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml" style="--vh: 37.95px;">
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta http-equiv="content-language" content="en-US"/>
        <meta name="referrer" content="no-referrer-when-downgrade">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <meta name="pinterest" content="nosearch"/>
        <meta name="csrf_nonce" content="3:1767581183:Dueo7HTEdKKuCaOPQLF9leJJaBgF:5d64ce01db381faeb206e48dfbf9e9458dc8ed4f58a75fa048835229147a6ee3"/>
        <meta name="uaid_nonce" content="3:1767581183:Bc02qJIr_PWqrUA8RqlGjNfgQvVS:52f671049afb6b57d3446ad4d532a00d530e069b842a79fc752650686b58da89"/>
        <meta name="css_dist_path" content="/ac/sasquatch/css/"/>
        <meta name="dist" content="202601021767390739"/>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            !function(e) {
                var r = e.__etsy_logging = {};
                r.errorQueue = [],
                e.onerror = function(e, o, t, n, s) {
                    r.errorQueue.push([e, o, t, n, s])
                }
                ,
                r.firedEvents = [];
                r.perf = {
                    e: [],
                    t: !1,
                    MARK_MEASURE_PREFIX: "_etsy_mark_measure_",
                    prefixMarkMeasure: function(e) {
                        return "_etsy_mark_measure_" + e
                    }
                },
                e.PerformanceObserver && (r.perf.o = new PerformanceObserver((function(e) {
                    r.perf.e = r.perf.e.concat(e.getEntries())
                }
                )),
                r.perf.o.observe({
                    entryTypes: ["element", "navigation", "longtask", "paint", "mark", "measure", "resource", "layout-shift"]
                }));
                var o = [];
                r.eventpipe = {
                    q: o,
                    logEvent: function(e) {
                        o.push(e)
                    },
                    logEventImmediately: function(e) {
                        o.push(e)
                    }
                };
                var t = !(Object.assign && Object.values && Object.fromEntries && e.Promise && Promise.prototype.finally && e.NodeList && NodeList.prototype.forEach)
                  , n = !!e.CefSharp || !!e.__pw_resume
                  , s = !e.PerformanceObserver || !PerformanceObserver.supportedEntryTypes || 0 === PerformanceObserver.supportedEntryTypes.length
                  , a = !e.navigator || !e.navigator.sendBeacon
                  , p = t || n
                  , u = [];
                t && u.push("fp"),
                s && u.push("fo"),
                a && u.push("fb"),
                n && u.push("fg"),
                r.bots = {
                    isBot: p,
                    botCheck: u
                }
            }(window);
        </script>
        <link rel="stylesheet" href="https://www.etsy.com/dac/site-chrome/components/components.60d9c77b63b670,site-chrome/header/header.60d9c77b63b670,__modules__CategoryNav__src__/Views/ButtonMenu/Menu.02149cde20b454,site-chrome/footer/footer.60d9c77b63b670,gdpr/settings-overlay.60d9c77b63b670.css?variant=sasquatch" type="text/css"/>
        <link rel="stylesheet" href="https://www.etsy.com/dac/common/stars-svg.60d9c77b63b670,neu/modules/favorite_listing_button.60d9c77b63b670,neu/modules/quickview.60d9c77b63b670,neu/modules/listing_card.60d9c77b63b670,listzilla/responsive/listing-page-desktop.60d9c77b63b670,category-nav/v2/breadcrumb_nav.fe3bd9d216295e,web-toolkit-v2/modules/forms/radios.60d9c77b63b670,listing-page/image-carousel/responsive.60d9c77b63b670,listzilla/image-overlay.60d9c77b63b670,__modules__ListingPage__src__/Price/styles.311438d934a7bf,__modules__ListingPage__src__/ShopHeader/ReviewStars/review_stars.02149cde20b454,common/simple-overlay.fe3bd9d216295e,neu/payment_icons.4657989d4f1a6d,neu/apple_pay.fe3bd9d216295e,neu/google_pay.60d9c77b63b670,listings3/checkout/single-listing.60d9c77b63b670,common/forms.60d9c77b63b670,neu/klarna.fe3bd9d216295e,shop2/modules/regulatory-seller-details.fe3bd9d216295e,shop2/modules/seller-additional-details.fe3bd9d216295e,web-toolkit-v2/modules/banners/banners.60d9c77b63b670,neu/common/follow-shop-button.fe3bd9d216295e,__modules__Reviews__src__/Components/Header/styles-redesign.60d9c77b63b670,__modules__ListingPage__src__/Reviews/Triage/reviews.a4b442c86de614,web-toolkit-v2/modules/signals-indicators/signal.60d9c77b63b670,web-toolkit-v2/modules/signals-indicators/signal-group.60d9c77b63b670,web-toolkit-v2/modules/dialogs/sheets.262a49566fcdd8,web-toolkit-v2/modules/dialogs/dialogs.262a49566fcdd8,__modules__Reviews__src__/DeepDive/ListingPage/styles.13cdcb5ec2d553,reviews/histogram.9705e010d5492f,web-toolkit-v2/modules/chips/selectable_chip.60d9c77b63b670,web-toolkit-v2/modules/chips/chip_group.60d9c77b63b670,reviews/categorical-tags.60d9c77b63b670,web-toolkit-v2/modules/panels/panels.60d9c77b63b670,listzilla/appreciation-photos-section.59867976de67c6,neu/common/responsive_listing_grid.7f91974893c9a8,neu/modules/favorite_button_defaults.60d9c77b63b670,common/listing_card_text_badge.fe3bd9d216295e,neu/modules/listing_card_signals.60d9c77b63b670,__modules__ListingPage__src__/SellerCred/Header/styles.60d9c77b63b670,shop2/common/rating-and-reviews-count.60d9c77b63b670,__modules__ListingPage__src__/SellerCred/Badges/styles.60d9c77b63b670,__modules__ListingPage__src__/SellerCred/ShopReviews/View.60d9c77b63b670,listzilla/responsive/review-content-modal.60d9c77b63b670,appreciation_photos/photo_overlay.60d9c77b63b670,__modules__ListingPage__src__/Recommendations/RecsRibbon/view.60d9c77b63b670,__modules__ListingPage__src__/Recommendations/CombinedAdsAndRecs/ads_row_header.60d9c77b63b670,listings3/structured-policies.fe3bd9d216295e,listzilla/responsive/tags.60d9c77b63b670,web-toolkit-v2/modules/action_groups/action_groups.60d9c77b63b670,__modules__ConditionalSaleInterstitial__src__/styles.02149cde20b454.css?variant=sasquatch" type="text/css"/>
        <script>
            //these inline functions are required because transcend, a 3rd party saas company, requires we load airgap.js below
            //via <script src and not in javascript.  To handle the onerror case, it can't import any files.
            //
            //todo: this is from https://stackoverflow.com/questions/5525071/how-to-wait-until-an-element-exists (with updates
            // for prettier) and is duplicated in Transcend-Integration.ts. Ideally we would find a place both
            // files could call.
            function waitForElm(selector) {
                return new Promise( (resolve) => {
                    if (document.querySelector(selector)) {
                        return resolve(document.querySelector(selector));
                    }

                    const observer = new MutationObserver( () => {
                        if (document.querySelector(selector)) {
                            observer.disconnect();
                            resolve(document.querySelector(selector));
                        }
                    }
                    );

                    // If you get "parameter 1 is not of type 'Node'" error, see https://stackoverflow.com/a/77855838/492336
                    observer.observe(document.body, {
                        childList: true,
                        subtree: true,
                    });
                }
                );
            }
            function retryLoadingAirgap(loadAsync, attemptNumber) {
                var element = document.createElement("script");
                element.type = "text/javascript";
                element.src = "https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js";
                if (loadAsync) {
                    element.setAttribute('data-cfasync', true);
                    element.async = true;
                }

                element.onerror = (error) => {
                    if (attemptNumber < 3) {
                        window.__etsy_logging.eventpipe.logEvent({
                            event_name: `transcend_cmp_airgap_preliminary_failure`,
                            airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                            airgap_bundle: 'control_bundle',
                            error: error,
                            retryAttempt: attemptNumber,
                            attemptWasAsyncLoad: loadAsync
                        });
                        retryLoadingAirgap(false, attemptNumber + 1);
                    } else {
                        try {
                            //ideally we would have the same STATSD here as in transcend-integration.ts
                            //but we can't import STATSD into mustache files.  This only occurs 0.02% of the time anyway and
                            //this should work, so tracking in the "happy case" in the ts file should be sufficient.
                            window.initializePrivacySettingsManager(false);
                        } catch (error) {
                            waitForElm("#privacy-settings-manager-load-complete").then( () => {
                                window.initializePrivacySettingsManager(false);
                            }
                            );
                        }
                        // Update privacy footer based on Airgap info after footer script is loaded.
                        waitForElm("#footer-script-loaded").then( () => {
                            window.updatePrivacySettingsFooterTextBasedOnRegime();
                        }
                        );

                        window.__etsy_logging.eventpipe.logEvent({
                            event_name: `transcend_cmp_airgap_load_failure`,
                            airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                            airgap_bundle: 'control_bundle',
                            error: error,
                            retryAttempts: attemptNumber
                        });
                    }
                }

                var head = document.getElementsByTagName('head')[0];
                head.appendChild(element);
            }

            function handleErrorLoadingAirgap() {
                window.__etsy_logging.eventpipe.logEvent({
                    event_name: `transcend_cmp_airgap_preliminary_failure`,
                    airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                    airgap_bundle: 'control_bundle',
                    retryAttempt: 1,
                    attemptWasAsyncLoad: true
                });

                retryLoadingAirgap(true, 2);
            }

        
        </script>
        <script data-cfasync="true" data-ui="off" src="https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js" onerror="(function() { handleErrorLoadingAirgap(); })()" async=""></script>
        <title>ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026</title>
        <meta name="description" content="ALEXISTOGEL adalah link situs slot88 gacor terpercaya hari ini menyediakan server mpo slot terbaik demi memudahkan pemain raih maxwin 2026 sekarang juga!"/>
        <meta name="robots" content="max-image-preview:large"/>
        <script type="application/ld+json">
            {
                "@type": "Product",
                "@context": "https:\/\/schema.org",
                "url": "https:\/\/www.etsy.com\/listing\/slot-gacor-2026\/gaming-logo-design-service-with-username",
                "name": "ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026",
                "sku": "slot-gacor-2026",
                "gtin": "n\/a",
                "description": "\ud83d\udd25 Get This Epic Gaming Logo \ud83d\udd25\n\nDo you like this design? You can buy it or request to have your username added FOR FREE!\n\n\ud83d\udc80 What do you get?\n\u2705 A high-impact logo to stand out on Twitch, YouTube, Discord, and more.\n\u2705 Your username added at no extra cost.\n\u2705 High-quality file ready to use.\n\n\u26a0\ufe0f Important:\n\u274c This logo cannot be resold or modified.\n\u274c It is for personal branding use only.\n\n\ud83d\udcb0 Buy the logo and make it yours.\n\ud83c\udd93 Request to have your username added for free.\n\n\ud83d\ude80 Message me now and give your gaming brand a unique identity!",
                "image": [
                    {
                        "@type": "ImageObject",
                        "@context": "https:\/\/schema.org",
                        "author": "Alexistogel",
                        "contentURL": "https:\/\/i.etsystatic.com\/31714225\/r\/il\/e2c8af\/6714763093\/il_fullxfull.6714763093_1lku.jpg",
                        "description": "May include: A stylized fox logo design featuring a fox head wearing a black hoodie with pink accents. The fox has glowing white eyes and a pink nose. The text &quot;premium logo&quot; is displayed in pink.",
                        "thumbnail": "https:\/\/i.etsystatic.com\/31714225\/r\/il\/e2c8af\/6714763093\/il_340x270.6714763093_1lku.jpg"
                    }
                ],
                "category": "Slot Gacor < Situs Slot < ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026",
                "brand": {
                    "@type": "Brand",
                    "@context": "https:\/\/schema.org",
                    "name": "Alexistogel"
                },
                "logo": "https:\/\/i.etsystatic.com\/31714225\/r\/isla\/487a73\/75107933\/isla_500x500.75107933_93xnywqa.jpg",
                "aggregateRating": {
                    "@type": "AggregateRating",
                    "ratingValue": "4.9",
                    "reviewCount": 461
                },
                "offers": {
                    "@type": "Offer",
                    "eligibleQuantity": 997,
                    "price": "6.10",
                    "priceCurrency": "USD",
                    "availability": "https:\/\/schema.org\/InStock",
                    "shippingDetails": {
                        "@type": "OfferShippingDetails",
                        "shippingRate": {
                            "@type": "MonetaryAmount",
                            "value": "0",
                            "currency": "USD"
                        }
                    }
                },
                "review": [
                    {
                        "@type": "Review",
                        "reviewRating": {
                            "@type": "Rating",
                            "ratingValue": 5,
                            "bestRating": 5
                        },
                        "datePublished": "2025-09-29",
                        "reviewBody": "Alexistogel emang luar biasa dan layak jadi rekomendasi situs slot gacor 2026 yang resmi dan terpercaya di Indonesia. Kalian wajib mampir kesini karena ada bocoran informasi RTP live terakurat untuk bekal bermain slot gacor hari ini...",
                        "author": {
                            "@type": "Person",
                            "name": "Jakarta, M Surya"
                        }
                    }
                ]
            }</script>
        <script type="application/ld+json">
            {
                "@context": "https:\/\/schema.org",
                "@type": "BreadcrumbList",
                "itemListElement": [
                    {
                        "@type": "ListItem",
                        "position": 1,
                        "name": "Slot Gacor",
                        "item": "https:\/\/www.etsy.com\/c\/art-and-collectibles?explicit=1&ref=breadcrumb_listing"
                    },
                    {
                        "@type": "ListItem",
                        "position": 2,
                        "name": "Situs Slot",
                        "item": "https:\/\/www.etsy.com\/c\/art-and-collectibles\/drawing-and-illustration?explicit=1&ref=breadcrumb_listing"
                    },
                    {
                        "@type": "ListItem",
                        "position": 3,
                        "name": "ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026",
                        "item": "https:\/\/www.etsy.com\/c\/art-and-collectibles\/drawing-and-illustration\/digital?explicit=1&ref=breadcrumb_listing"
                    }
                ]
            }</script>
        <meta name="twitter:site" content="@Etsy" value=""/>
        <meta name="twitter:card" content="summary_large_image" value=""/>
        <meta name="twitter:app:name:iphone" content="Etsy" value=""/>
        <meta name="twitter:app:url:iphone" content="etsy://listing/slot-gacor-2026?ref=TwitterProductCard" value=""/>
        <meta name="twitter:app:id:iphone" content="477128284" value=""/>
        <meta name="twitter:app:name:ipad" content="Etsy" value=""/>
        <meta name="twitter:app:url:ipad" content="etsy://listing/slot-gacor-2026?ref=TwitterProductCard" value=""/>
        <meta name="twitter:app:id:ipad" content="477128284" value=""/>
        <meta name="twitter:app:name:googleplay" content="Etsy" value=""/>
        <meta name="twitter:app:url:googleplay" content="etsy://listing/slot-gacor-2026?ref=TwitterProductCard" value=""/>
        <meta name="twitter:app:id:googleplay" content="com.etsy.android" value=""/>
        <meta property="og:title" content="ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026"/>
        <meta property="og:description" content="ALEXISTOGEL adalah link situs slot88 gacor terpercaya hari ini menyediakan server mpo slot terbaik demi memudahkan pemain raih maxwin 2026 sekarang juga!"/>
        <meta property="og:type" content="product"/>
        <meta property="og:url" content="https://oemparts.net/?utm_source=OpenGraph&amp;utm_medium=PageTools&amp;utm_campaign=Share"/>
        <meta property="og:image" content="https://i.etsystatic.com/31714225/r/il/e2c8af/6714763093/il_1080xN.6714763093_1lku.jpg"/>
        <meta property="product:price:amount" content="13.50"/>
        <meta property="product:price:currency" content="EUR"/>
        <meta property="al:ios:url" content="etsy://listing/slot-gacor-2026?ref=applinks_ios"/>
        <meta property="al:ios:app_store_id" content="477128284"/>
        <meta property="al:ios:app_name" content="Etsy"/>
        <meta property="al:android:url" content="etsy://listing/slot-gacor-2026?ref=applinks_android"/>
        <meta property="al:android:package" content="com.etsy.android"/>
        <meta property="al:android:app_name" content="Etsy"/>
        <link rel="preconnect" href="//i.etsystatic.com" crossorigin="anonymous"/>
        <link rel="preconnect" href="//i.etsystatic.com"/>
        <link rel="preload" as="image" imagesrcset="https://s6.imgcdn.dev/Y7rD8w.jpg 1x, https://i.etsystatic.com/31714225/r/il/e2c8af/6714763093/il_1588xN.6714763093_1lku.jpg 2x" fetchpriority="high"/>
        <link rel="canonical" href="https://oemparts.net/"/>
        <link rel="amphtml" href="https://login-alx-slot-gacor.b-cdn.net/moran.html"/>
        <link rel="alternate" href="https://oemparts.net/" hreflang="en"/>
        <link rel="alternate" href="https://www.etsy.com/fi-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-FI"/>
        <link rel="alternate" href="https://www.etsy.com/au/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-AU"/>
        <link rel="alternate" href="https://www.etsy.com/ca/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-CA"/>
        <link rel="alternate" href="https://www.etsy.com/dk-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-DK"/>
        <link rel="alternate" href="https://www.etsy.com/hk-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-HK"/>
        <link rel="alternate" href="https://www.etsy.com/ie/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-IE"/>
        <link rel="alternate" href="https://www.etsy.com/il-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-IL"/>
        <link rel="alternate" href="https://www.etsy.com/in-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-IN"/>
        <link rel="alternate" href="https://www.etsy.com/nz/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-NZ"/>
        <link rel="alternate" href="https://www.etsy.com/no-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-NO"/>
        <link rel="alternate" href="https://www.etsy.com/se-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-SE"/>
        <link rel="alternate" href="https://www.etsy.com/sg-en/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-SG"/>
        <link rel="alternate" href="https://www.etsy.com/uk/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-GB"/>
        <link rel="alternate" href="https://www.etsy.com/de/listing/slot-gacor-2026/gaming-logo-design-service-mit" hreflang="de"/>
        <link rel="alternate" href="https://www.etsy.com/at/listing/slot-gacor-2026/gaming-logo-design-service-mit" hreflang="de-AT"/>
        <link rel="alternate" href="https://www.etsy.com/ch/listing/slot-gacor-2026/gaming-logo-design-service-mit" hreflang="de-CH"/>
        <link rel="alternate" href="https://www.etsy.com/fr/listing/slot-gacor-2026/service-de-conception-de-logo-de-jeu" hreflang="fr"/>
        <link rel="alternate" href="https://www.etsy.com/ca-fr/listing/slot-gacor-2026/service-de-conception-de-logo-de-jeu" hreflang="fr-CA"/>
        <link rel="alternate" href="https://www.etsy.com/nl/listing/slot-gacor-2026/gaminglogo-ontwerpservice-met" hreflang="nl"/>
        <link rel="alternate" href="https://www.etsy.com/be/listing/slot-gacor-2026/gaminglogo-ontwerpservice-met" hreflang="nl-BE"/>
        <link rel="alternate" href="https://www.etsy.com/it/listing/slot-gacor-2026/servizio-di-progettazione-di-loghi-per" hreflang="it"/>
        <link rel="alternate" href="https://www.etsy.com/es/listing/slot-gacor-2026/servicio-de-diseno-de-logotipos-de" hreflang="es"/>
        <link rel="alternate" href="https://www.etsy.com/mx/listing/slot-gacor-2026/servicio-de-diseno-de-logotipos-de" hreflang="es-MX"/>
        <link rel="alternate" href="https://www.etsy.com/jp/listing/slot-gacor-2026/yz-ming-fukigmurogodezainsbisu-o-twitch" hreflang="ja"/>
        <link rel="alternate" href="https://www.etsy.com/pl/listing/slot-gacor-2026/usuga-projektowania-logo-dla-gier-z-nazw" hreflang="pl"/>
        <link rel="alternate" href="https://www.etsy.com/pt/listing/slot-gacor-2026/servico-de-design-de-logotipo-de-jogos" hreflang="pt"/>
        <link rel="alternate" href="https://www.etsy.com/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="x-default"/>
        <link rel="alternate" href="https://www.etsy.com/listing/slot-gacor-2026/gaming-logo-design-service-with-username" hreflang="en-US"/>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            __webpack_public_path__ = "https://www.etsy.com/ac/primaryVendor/js/en-US/";
        </script>
        <link rel="shortcut icon" href="https://s6.imgcdn.dev/Y7SJhu.png"/>
        <link rel="icon" href="https://s6.imgcdn.dev/Y7SJhu.png" type="image/png" sizes="32x32"/>
        <link rel="icon" href="https://s6.imgcdn.dev/Y7SJhu.png" type="image/png" sizes="16x16"/>
        <link rel="apple-touch-icon" href="https://s6.imgcdn.dev/Y7SJhu.png" sizes="180x180"/>
        <link rel="mask-icon" href="/images/safari-pinned-tab.svg" color="rgb(241, 100, 30)"/>
        <link rel="manifest" href="/site.webmanifest"/>
        <meta name="apple-mobile-web-app-title" content="Etsy"/>
        <meta name="application-name" content="Etsy"/>
        <meta name="msapplication-TileColor" content="#F1641E"/>
        <meta name="theme-color" content="rgb(255, 255, 255)"/>
        <link type="application/opensearchdescription+xml" rel="search" href="/osdd.php" title="Etsy"/>
        <style>
            .chrome-footer--ehi .chrome-footer__etsy-finds {
                background: #2bb983;
                color: #fff;
            }

            .wt-sem-bg-surface-highlight-dark {
                background: #141414 !important;
            }

            .chrome-footer--ehi {
                background: #0c0c0c !important;
            }

            .chrome-footer--ehi .chrome-footer__app-link {
                background: #000 !important;
            }
        </style>
        <script async="" src="//resources.xg4ken.com/js/v2/ktag.js?tid=KT-N3B63-3EB"></script>
        <script src="https://js.adsrvr.org/up_loader.1.1.0.js" async=""></script>
        <script defer src="https://res4.applovin.com/p/104/b/bs.c9e1074f5b3f9fc8ea15d152add07294-1.iife.js"></script>
        <script defer src="https://res4.applovin.com/p/104/hs/hs.iife.js"></script>
        <script type="text/javascript" async="" src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/995917074/?random=1767581183282&amp;cv=11&amp;fst=1767581183282&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be5ca1v883287104z86935543za20gzb6935543zd6935543xea&amp;gcd=13t3t3t3t5l1&amp;dma=0&amp;tag_exp=103116026~103200004~104527907~104528501~104684208~104684211~105391252~115583767~115938466~115938468~116184927~116184929~116251938~116251940&amp;u_w=1024&amp;u_h=1024&amp;url=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026&amp;frm=0&amp;tiba=Gaming%20Logo%20Design%20Service%20With%20Username%20%7C%20Twitch%20Logo%2C%20Youtube%20Logo%2C%20Kick%20Logo%2C%20Discord%20Logo%2C%20Tiktok%20Logo%2C%20Stream%20Design%2C%20Twitch%20Graphic%20-%20Etsy&amp;hn=www.googleadservices.com&amp;npa=0&amp;pscdl=noapi&amp;auid=1615451382.1767581183&amp;uaa=&amp;uab=&amp;uafvl=&amp;uamb=0&amp;uam=&amp;uap=&amp;uapv=&amp;uaw=0&amp;_tu=KA&amp;data=ecomm_prodid%3Dslot-gacor-2026%3Becomm_pagetype%3Dproduct%3Becomm_totalvalue%3D13.50%3Becomm_rec_prodid%3D%3Becomm_category%3D%3Becomm_pvalue%3D%3Becomm_quantity%3D%3Ba%3D%3Bg%3D%3Bhasaccount%3Dfalse%3Bcqs%3D%3Brp%3D%3Bly%3D%3Bhs%3D%3B_google_crm_id%3D%3Bads_data_redaction%3Dfalse&amp;rfmt=3&amp;fmt=4" nonce="F1O4w7W9k6N12m5YiFU/l8Jn"></script>
        <script src="https://bat.bing.com/p/action/4020083.js" type="text/javascript" async="" data-ueto="ueto_9c95279c42"></script>
        <script charset="utf-8" src="https://siteintercept.qualtrics.com/dxjsmodule/11.c331591598597e4e3e65.chunk.js?Q_CLIENTVERSION=2.40.0&amp;Q_CLIENTTYPE=web&amp;Q_BRANDID=www.etsy.com"></script>
        <script charset="utf-8" src="https://siteintercept.qualtrics.com/dxjsmodule/7.22a8f8e4f6c751d8767a.chunk.js?Q_CLIENTVERSION=2.40.0&amp;Q_CLIENTTYPE=web&amp;Q_BRANDID=www.etsy.com"></script>
        <script async="" src="//resources.xg4ken.com/js/v2/ktag.js?tid=KT-N3B63-3EB"></script>
        <script src="https://js.adsrvr.org/up_loader.1.1.0.js" async=""></script>
        <script defer src="https://res4.applovin.com/p/104/b/bs.c9e1074f5b3f9fc8ea15d152add07294-1.iife.js"></script>
        <script defer src="https://res4.applovin.com/p/104/hs/hs.iife.js"></script>
        <script defer src="https://res4.applovin.com/p/104/b/bs.c9e1074f5b3f9fc8ea15d152add07294-1.iife.js"></script>
        <script defer src="https://res4.applovin.com/p/104/hs/hs.iife.js"></script>
    </head>
    <body class="ui-toolkit transitional-wide etsy-has-it-design is-responsive no-touch en-US USD US wt-browser-has-no-hover-support" data-language="en-US" data-currency="USD" data-region="US" data-hover-none="true" data-visual-focus-state="true" data-mobile-viewport-height="true">
        <script data-client-id="klarna_live_client_aUYvcCg0dlhaVjAvTFN1NCgjQyQ3S0dQKTUxZ0lldEgsYTViNmJkOTItNzIyYS00ODk2LTg4MmItNzg2OTMwMTM2YTcwLDEsanoxdWljSXVoaTR0TFB4aTNEK3A4UlhmWWtaRkxLRWNndUpvUnlDL3Y2TT0" data-environment="production" src="https://js.klarna.com/web-sdk/v1/klarna.js"></script>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            !function(a, b, c, d, e, f) {
                a.ddjskey = e;
                a.ddoptions = f || null;
                var m = b.createElement(c)
                  , n = b.getElementsByTagName(c)[0];
                m.async = 1,
                m.defer = 1,
                m.src = d,
                n.parentNode.insertBefore(m, n)
            }(window, document, "script", "https://www.etsy.com/include/tags.js", "D013AA612AB2224D03B2318D0F5B19", {
                endpoint: "https://www.etsy.com/include/tags.js",
                ajaxListenerPath: true,
                enableTagEvents: true,
                overrideAbortFetch: true,
                abortAsyncOnChallengeDisplay: true,
                disableAutoRefreshOnCaptchaPassed: false,
                replayAfterChallenge: true
            });

            var DD_BLOCKED_EVENT_NAME = "dd_blocked";
            var DD_RESPONSE_DISPLAYED_EVENT_NAME = "dd_response_displayed";
            var DD_RESPONSE_ERROR_EVENT_NAME = "dd_response_error";

            window.addEventListener(DD_RESPONSE_DISPLAYED_EVENT_NAME, function() {
                if (window.Sentry && window.Sentry.setTag) {
                    window.Sentry.setTag(DD_RESPONSE_DISPLAYED_EVENT_NAME, true);
                }
            });

            window.addEventListener(DD_BLOCKED_EVENT_NAME, function() {
                if (window.Sentry && window.Sentry.setTag) {
                    window.Sentry.setTag(DD_BLOCKED_EVENT_NAME, true);
                }
            });

            window.addEventListener(DD_RESPONSE_ERROR_EVENT_NAME, function() {
                if (window.Sentry && window.Sentry.setTag) {
                    window.Sentry.setTag(DD_RESPONSE_ERROR_EVENT_NAME, true);
                }
            });
        </script>
        <div data-above-header="" class="wt-z-index-5 wt-position-relative"></div>
        <div data-selector="header-cat-nav-wrapper" data-menu-ui="menubar">
            <div id="gnav-header" class=" gnav-header global-nav v2-toolkit-gnav-header wt-z-index-6 wt-sem-bg-elevation-0 wt-position-relative " data-as-version="10_12672349415_19" data-count-ajax="" data-show-suggested-searches-in-as="1" data-show-gift-card-cta-in-as="1" data-as-personalized="1" data-as-extras="{&amp;quot;expt&amp;quot;:&amp;quot;all_xml&amp;quot;,&amp;quot;lang&amp;quot;:&amp;quot;en-US&amp;quot;,&amp;quot;extras&amp;quot;:[]}" data-cheact="1" data-gnav-header="">
                <header id="gnav-header-inner" class="global-enhancements-header wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-width-full wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-lg-6 wt-pr-lg-6 wt-bb-xs wt-bb-lg-none gnav-header-inner wt-pt-lg-2 
        
        
        " role="banner">
                    <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
                        !function(e) {
                            var r = e.__etsy_logging;
                            if (r && r.perf && r.perf.prefixMarkMeasure) {
                                var n = r.perf.prefixMarkMeasure("logo_render");
                                e.performance && e.performance.mark && e.requestAnimationFrame((function() {
                                    setTimeout((function() {
                                        e.performance.mark(n)
                                    }
                                    ))
                                }
                                ))
                            }
                        }(window);
                    </script>
                    <div class="wt-pb-lg-0 wt-pt-sm-1 wt-pt-lg-0 wt-pr-xs-1 " data-header-logo-container="">
                        <a href="https://oemparts.net/" elementtiming="ux-global-nav">
                            <span class="wt-screen-reader-only">Etsy</span>
                            <span class="etsy-icon wt-display-block wt-fill-orange wt-nudge-r-3 wt-nudge-t-1 logo-dimensions" id="logo">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 24" aria-hidden="true" focusable="false">
                                    <path d="M42.973 23.998C45.006 23.998 46.673 23.321 47.768 22.045 48.89 20.716 49.254 19.386 49.254 16.675V7.739C49.254 7.008 49.254 6.2 49.306 5.627 49.332 5.13 48.889 5.027 48.497 5.184 47.377 5.627 46.412 5.861 45.11 6.148 44.797 6.226 44.667 6.435 44.667 6.67S44.826 7.166 45.32 7.14C46.492 7.088 46.804 7.323 46.804 8.18V13.941C46.621 15.504 45.32 16.833 43.678 16.833 42.192 16.833 41.332 15.843 41.332 13.81V7.738C41.332 7.008 41.358 6.2 41.384 5.627 41.41 5.13 40.994 5.027 40.575 5.184 39.48 5.601 38.568 5.861 37.343 6.148 37.004 6.226 36.873 6.435 36.873 6.67S37.03 7.166 37.525 7.14C38.592 7.088 38.879 7.323 38.879 8.18V14.254C38.879 17.094 40.52 18.37 42.969 18.37 44.482 18.37 46.072 17.51 46.802 15.92V18.033C46.801 19.699 46.462 20.768 45.785 21.576 45.082 22.411 44.17 22.88 42.997 22.88 41.615 22.879 40.86 22.383 40.86 21.654 40.86 21.42 40.938 21.158 40.938 20.794 40.938 20.117 40.468 19.517 39.739 19.517 38.827 19.517 38.385 20.22 38.385 21.03 38.385 22.437 39.922 24 42.97 24M31.3 18.474C34.296 18.474 36.146 16.65 36.146 14.435 36.146 10.032 29.293 11.151 29.293 8.311 29.293 7.216 30.075 6.304 31.508 6.304 32.836 6.304 33.853 6.904 34.399 8.154L34.66 8.754C34.921 9.352 35.65 9.223 35.572 8.623L35.312 6.487C35.26 6.122 35.156 5.965 34.842 5.836 33.852 5.393 32.782 5.184 31.637 5.184 28.823 5.184 27.18 6.931 27.18 9.094 27.18 13.576 34.033 12.404 34.033 15.218 34.033 16.337 33.121 17.328 31.375 17.328 29.863 17.329 28.95 16.704 28.274 15.295L27.884 14.487C27.647 13.99 26.918 14.122 27.023 14.774L27.387 17.119C27.439 17.46 27.57 17.563 27.858 17.694 28.977 18.215 29.89 18.475 31.296 18.475M22.464 18.5C24.262 18.5 25.487 17.562 25.955 15.92 26.14 15.348 25.54 15.009 25.175 15.583 24.679 16.442 23.95 16.807 23.115 16.807 22.048 16.807 21.5 16.024 21.5 14.592V6.696L24.94 6.722C25.33 6.722 25.487 6.357 25.487 6.045 25.487 5.706 25.304 5.419 24.887 5.419L21.5 5.445V3.464C21.5 3.125 21.291 2.968 21.03 2.968A.6.6 0 0 0 20.535 3.228C19.597 4.664 18.97 5.158 17.512 5.705 17.199 5.834 17.016 6.017 17.016 6.252 17.016 6.512 17.146 6.694 17.538 6.694H19.049V14.877C19.049 17.25 20.431 18.5 22.462 18.5M11.806 17.014H7.27C5.863 17.014 5.499 16.65 5.499 15.424V9.692H9.147C10.501 9.691 10.919 10.056 11.387 11.384L11.753 12.454C11.962 13.079 12.794 13.104 12.794 12.376 12.69 10.29 12.69 7.84 12.742 5.756 12.794 5.027 11.959 5.053 11.752 5.678L11.388 6.748C10.918 8.102 10.553 8.52 9.147 8.52H5.499V1.745C5.499 1.38 5.654 1.223 6.046 1.223H11.493C13.083 1.223 13.759 1.665 14.255 3.047L14.855 4.742C15.089 5.419 15.896 5.316 15.896 4.664L15.844.468C15.845.13 15.637 0 15.35 0H.599C.13 0 0 .26 0 .522 0 .782.13 1.017.573 1.069 2.398 1.2 2.71 1.565 2.71 2.633V15.715C2.71 16.705 2.398 17.043.677 17.175.261 17.226.13 17.46.13 17.722S.26 18.244.703 18.244H15.61C15.896 18.244 16.105 18.114 16.105 17.776L16.157 13.58C16.157 12.928 15.35 12.85 15.141 13.502L14.594 15.196C14.15 16.604 13.394 17.021 11.806 17.021"></path>
                                </svg>
                            </span>
                        </a>
                    </div>
                    <div class="wt-width-full wt-display-flex-xs wt-pr-lg-3 wt-flex-lg-1 order-mobile-tablet-2" data-hamburger-search-container="">
                        <button data-id="hamburger" class="wt-btn wt-btn--transparent wt-btn--icon wt-hide-lg
               wt-btn--transparent-flush-left
                         wt-mb-xs-2
               
               wt-mb-lg-0
               header-button" aria-controls="mobile-catnav-overlay" tab-index="0">
                            <span class="wt-screen-reader-only">Browse
          </span>
                            <span class="wt-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                    <path d="M21 7H3V5h18zm-5 6H3v-2h13zm5 6H3v-2h18z"></path>
                                </svg>
                            </span>
                        </button>
                        <div class="wt-display-inline-block wt-flex-xs-1 wt-pl-lg-0
                wt-mb-xs-2
        
        wt-mb-lg-0">
                            <form id="gnav-search" class="global-enhancements-search-nav wt-position-relative wt-display-flex-xs" method="GET" action="/search.php" role="search" data-gnav-search="" data-ge-search-clearable="">
                                <label for="global-enhancements-search-query" class="wt-label wt-screen-reader-only">Search for items or shops
</label>
                                <div class="search-container" data-id="search-bar">
                                    <div class="wt-input-btn-group global-enhancements-search-input-btn-group emphasized_search_bar emphasized_search_bar_grey_bg search-bar-container" data-id="search-suggestions-trigger">
                                        <input id="global-enhancements-search-query" data-id="search-query" data-search-input="" type="text" name="search_query" class="wt-input wt-input-btn-group__input global-enhancements-search-input-btn-group__input
                    wt-pr-xs-7
                                        
                    " placeholder="Search for anything" value="" autocomplete="off" autocorrect="off" autocapitalize="off" role="combobox" aria-autocomplete="both" aria-controls="global-enhancements-search-suggestions" aria-expanded="false"/>
                                        <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small position-absolute-important wt-position-right wt-z-index-9 wt-animated  wt-animated--is-hidden
            
            search-close-btn-margin-right " data-search-close-btn="">
                                            <span class="wt-screen-reader-only">Clear search</span>
                                            <span class="wt-icon wt-icon--smaller wt-nudge-t-1">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path>
                                                </svg>
                                            </span>
                                        </button>
                                        <button type="submit" class="wt-input-btn-group__btn global-enhancements-search-input-btn-group__btn
                
                " value="Search" aria-label="Search" data-id="gnav-search-submit-button">
                                            <span class="wt-icon wt-nudge-b-2 wt-nudge-r-1">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5 19a8.46 8.46 0 0 0 5.262-1.824l4.865 4.864 1.414-1.414-4.865-4.865A8.5 8.5 0 1 0 10.5 19m0-2a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13"></path>
                                                </svg>
                                            </span>
                                        </button>
                                    </div>
                                    <div id="global-enhancements-search-suggestions" class="global-nav-menu__body
            search-suggestions-container
             wt-width-full wt-max-width-full
            " data-id="search-suggestions"></div>
                                </div>
                                <input id="search-js-router-enabled" type="hidden" value="true"/>
                                <input type="hidden" value="all" name="search_type" id="search-type"/>
                            </form>
                        </div>
                    </div>
                    <a data-selector="skip-to-content-marketplace" class="global-enhancements-skip-to-content wt-screen-reader-only wt-focusable" href="#content">
                        <div id="skip-to-content-wrapper" class="wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-body-max-width wt-width-full wt-height-full wt-position-absolute wt-position-top wt-position-left wt-position-right wt-bg-denim wt-z-index-10">
                            <label class="wt-btn wt-btn--transparent wt-btn--light">Skip to Content
        </label>
                        </div>
                    </a>
                    <div class="mobile-catnav-wrapper wt-overlay wt-overlay--peek wt-overlay--peek-left wt-p-xs-0" data-wt-overlay="" id="mobile-catnav-overlay" aria-hidden="true" aria-modal="false" role="dialog"></div>
                    <div class="wt-flex-shrink-xs-0" data-primary-nav-container="">
                        <nav aria-label="Main">
                            <ul class="wt-display-flex-xs wt-justify-content-space-between wt-list-unstyled wt-m-xs-0 wt-align-items-center">
                                <li>
                                    <button class="wt-btn wt-btn--small wt-btn--transparent wt-mr-xs-1 inline-overlay-trigger signin-header-action select-signin header-button">Sign in
    </button>
                                </li>
                                <li data-gift-mode-nav-container="">
                                    <span class="wt-tooltip wt-tooltip--disabled-touch" data-wt-tooltip="">
                                        <a href="/gift-mode?ref=gm_utility_nav" class=" wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon reduced-margin-xs header-button" data-gift-mode-nav-link="" aria-labelledby="ge-tooltip-label-gift-mode">
                                            <span class="etsy-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M5.535 7A4 4 0 0 1 12 2.354 4 4 0 0 1 18.465 7H22v9h-1v6H3v-6H2V7zm9.466 0H13V5a2 2 0 1 1 2.001 2M11 5a2 2 0 1 0-2.001 2H11zm-.764 4c-.55.614-1.348 1-2.236 1v2a4.98 4.98 0 0 0 3-1v3H4V9zM13 11c.836.628 1.874 1 3 1v-2a3 3 0 0 1-2.236-1H20v5h-7zm-8 5v4h6v-4zm8 4v-4h6v4z"></path>
                                                </svg>
                                            </span>
                                        </a>
                                        <span id="ge-tooltip-label-gift-mode" role="tooltip" data-registry-label-tooltip="">Gifts
            
        </span>
                                    </span>
                                </li>
                                <li data-ge-nav-menu="cart" data-ge-hover-event-name="gnav_hover_cart_menu">
                                    <span class="wt-tooltip wt-tooltip--bottom-left wt-tooltip--disabled-touch" data-wt-tooltip="" data-header-cart-button="">
                                        <a aria-label="Cart" href="https://www.etsy.com/cart?ref=hdr-cart" class="wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon header-button">
                                            <span class="wt-z-index-1 wt-no-wrap wt-display-none ge-cart-badge wt-badge wt-badge--notificationPrimary wt-badge--small wt-badge--outset-top-right" data-selector="header-cart-count" aria-hidden="true">0
            </span>
                                            <span class="wt-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="m5.766 5-.618-3H1v2h2.518l2.17 10.535L6.18 17h14.307l2.4-12zM7.82 15l-1.6-8h14.227l-1.6 8z"></path>
                                                    <path d="M10.667 20.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m8.333 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0"></path>
                                                </svg>
                                            </span>
                                        </a>
                                        <span role="tooltip" aria-hidden="true">Cart</span>
                                    </span>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </header>
            </div>
        </div>
        <div class="wt-overlay wt-z-index-4" aria-hidden="true" data-ui="overlay"></div>
        <noscript>
            <div class="wt-body-max-width wt-pt-xs-2 wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pt-md-3 wt-pb-xs-0">
                <div id="javascript-nag" class="wt-alert wt-alert--inline wt-alert--success-01 wt-mb-xs-2">
                    <div>Take full advantage of our site features by enabling JavaScript. </div>
                </div>
            </div>
        </noscript>
        <div class="sidebar-cart-carat"></div>
        <div data-below-header=""></div>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            window.Etsy = window.Etsy || {};
            Etsy.Context = Etsy.Context || {};
            (function() {
                function assign(firstSource, secondSource) {
                    if (!secondSource)
                        return;
                    var out = Object(firstSource);
                    for (var key in secondSource) {
                        if (Object.prototype.hasOwnProperty.call(secondSource, key)) {
                            out[key] = secondSource[key];
                        }
                    }
                    return out;
                }
                Etsy.Context.feature = assign(Etsy.Context.feature ? Etsy.Context.feature : {}, {
                    "profile_dropdown_to_help_center": false,
                    "isAppShellEnabled": true,
                    "is_footer_ships_from_listing_page_parity_enabled": true,
                    "buyer_listing_third_variation_support": false,
                    "seller_platform_web.buyer_inquiry": false,
                    "seller_platform_web.seller_local_time": false,
                    "seller_platform_web.item_detail_overlay": false,
                    "buyer_promise.issue_resolution.fee_avoidance_v2": false,
                    "content_moderation.convo_safety.structured_convos": false,
                    "risk_experience.buyer_email_verification": false
                });
                Etsy.Context.data = assign(Etsy.Context.data ? Etsy.Context.data : {}, {
                    "is_mobile": false,
                    "should_auto_redirect": false,
                    "locale_settings": {
                        "language": {
                            "code": "en-US",
                            "id": 0,
                            "name": "English (US)",
                            "translation": "English (US)",
                            "is_detected": true,
                            "is_default": true
                        },
                        "currency": {
                            "currency_id": 840,
                            "code": "USD",
                            "name": "United States Dollar",
                            "number_precision": 2,
                            "symbol": "$",
                            "listing_enabled": true,
                            "browsing_enabled": true,
                            "buyer_location_restricted": false,
                            "is_synthetic": true,
                            "is_detected": false,
                            "is_default": true,
                            "append_currency_symbol": false
                        },
                        "region": {
                            "code": "US",
                            "country_id": 209,
                            "name": "United States",
                            "translation": "United States",
                            "is_detected": false,
                            "is_default": true,
                            "is_EU_region": false
                        },
                        "subdir_code": ""
                    },
                    "neu_api_specs_sample_rate": null,
                    "FB_GRAPHQL_VERSION": "v2.10",
                    "page_guid": "1013787c4f59.2cb290d6285e47edaacf.00",
                    "primary_event_name": "view_listing",
                    "request_uuid": "EuMw1pPObQo6EVtSyTVqcmLfFy83",
                    "user_is_test_account": false,
                    "user_id": null,
                    "css_variant": "sasquatch",
                    "runtime_analysis": false,
                    "collage_shadow_dom_css_url": "https:\/\/www.etsy.com\/ac\/sasquatch\/css\/collage\/shadow.15e0d247e4d1e9.css",
                    "vite_public_path": "https:\/\/www.etsy.com\/ac\/alphaVite\/js\/en-US\/",
                    "collage_translations": {
                        "ad": "Ad",
                        "ad_by_etsy_seller": "Ad by Etsy Seller",
                        "dismiss": "Dismiss",
                        "loading": "Loading",
                        "add_to_favorites": "Add to favorites",
                        "remove_from_favorites": "Added to favorites. Remove?",
                        "required": "Required",
                        "optional_parenthetical": "(optional)",
                        "star_seller": "Star Seller"
                    },
                    "guest_uaid": ["kePC9k86zGLotnxjXL_IhE3c4kU6", "kePC9k86zGLotnxjXL_IhE3c4kU6"],
                    "is_app_shell": true,
                    "csrf_nonce": "3:1767581183:riXKYAhiV6ZqL8bSMjs2Gic5qWIZ:e1dea5a476f72e78ef554ace8000ef81ecf76372daf130f8299cfbf24d424a22",
                    "uaid_nonce": "3:1767581183:Bc02qJIr_PWqrUA8RqlGjNfgQvVS:52f671049afb6b57d3446ad4d532a00d530e069b842a79fc752650686b58da89",
                    "clientlogger": {
                        "is_enabled": true,
                        "endpoint": "\/clientlog",
                        "logs_per_page": 6,
                        "id": "EuMw1pPObQo6EVtSyTVqcmLfFy83",
                        "digest": "c00000850c6988297eda71d7139a084c01697e15",
                        "enabled_features": ["info", "warn", "error", "basic", "uncaught"]
                    },
                    "01125905a4e5ddf2_appshell_fallback": "recs-impression",
                    "3c65557fa67e42dc_appshell_fallback": "b6030e06d55c918d5",
                    "c5420ec98ed7db34_appshell_fallback": "b7aa59b4fe4c53e4d",
                    "imp_listener_sources": ["ads", "search", "recs", "nonlisting"],
                    "impact_tracker_should_prompt_signin": false,
                    "impact_tracker_should_direct_open": false,
                    "shop_favorites_see_all_link": "See all",
                    "shop_favorites_search_header": "Shops you follow",
                    "is_mobile_shop_search": false,
                    "show_simplified_mobile_header": false,
                    "is_eligible_for_ship_to_setting_in_global_header": false,
                    "remove_catnav_for_bots": true,
                    "should_show_w2a_gated_favoriting": false,
                    "in_cart_count": 0,
                    "page_type": "view_listing",
                    "clickable_nav": true,
                    "mweb_full_screen_search_dropdown": false,
                    "relocate_cat_nav": false,
                    "is_eligible_for_always_show_shop_search": false,
                    "is_eligible_for_search_bar_improvements": false,
                    "is_eligible_for_refinement_pills_in_autosuggest": false,
                    "mott_version": "a8c03b6",
                    "catnav_show_sales": false,
                    "catnav_gift_guide": "off",
                    "gifting_catnav_flyout_js": false,
                    "should_show_registry_on_nav": false,
                    "should_use_gifting_taxos_in_nav_flyout": false,
                    "impact_message": {
                        "footer_renewable_impact": {
                            "impact_name": "footer_renewable_impact",
                            "impact_themes": ["sustainability"],
                            "impact_audiences": ["buyers"]
                        }
                    },
                    "airgap_url": "https:\/\/transcend-cdn.com\/cm\/ac71e058-41b7-4026-b482-3d9b8e31a6d0\/airgap.js",
                    "airgap_bundle": "control_bundle",
                    "dual_write_enabled": true,
                    "google_tag_manager_async_enabled": false,
                    "dynamic_privacy_settings_ui_enabled": false,
                    "forced_data_regimes": "",
                    "has_forced_data_regimes": false,
                    "all_purposes": ["Advertising", "Functional"],
                    "all_regimes": ["us-gpc", "consent-prompt"],
                    "default_consent_expiry": 518400,
                    "disable_advertising_regimes": [],
                    "seller_is_viewing_own_listing": false,
                    "listingId": slot-gacor-2026,
                    "listing_price": 13.5,
                    "shopId": 31714225,
                    "shop_id": 31714225,
                    "shop_name": "StreamLegends",
                    "custom_orders_listings2": true,
                    "is_listing_preview": false,
                    "checkout_decorator": "",
                    "was_landing_from_external_referrer": false,
                    "should_collapse_neighbors": false,
                    "should_open_single_content_toggle": false,
                    "is_logged_in": false,
                    "referring_listing_id": slot-gacor-2026,
                    "address_formats": {
                        "0": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": null,
                            "postal_code_placeholder": "",
                            "country_iso_code": "ZZ"
                        },
                        "55": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AF"
                        },
                        "306": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "22\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AX"
                        },
                        "57": {
                            "postal_code_type": "Postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AL"
                        },
                        "95": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "DZ"
                        },
                        "250": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(96799)(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AS"
                        },
                        "228": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "AD[1-7]0\\d",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AD"
                        },
                        "251": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "(?:AI-)?2640",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AI"
                        },
                        "59": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "((?:[A-HJ-NP-Z])?\\d{4})([A-Z]{3})?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AR"
                        },
                        "60": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "(?:37)?\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AM"
                        },
                        "61": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "3393",
                            "country_iso_code": "AU"
                        },
                        "62": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AT"
                        },
                        "63": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "AZ"
                        },
                        "232": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "(?:^|\\b)(?:1[0-2]|[1-9])\\d{2}(?:$|\\b)",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BH"
                        },
                        "68": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BD"
                        },
                        "237": {
                            "postal_code_type": "Postal",
                            "postal_code_pattern": "BB\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BB"
                        },
                        "71": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BY"
                        },
                        "65": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BE"
                        },
                        "225": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[A-Z]{2} ?[A-Z0-9]{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BM"
                        },
                        "76": {
                            "postal_code_type": "Postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BT"
                        },
                        "70": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BA"
                        },
                        "74": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}-?\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BR"
                        },
                        "255": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "BBND 1ZZ",
                            "postal_code_placeholder": "",
                            "country_iso_code": "IO"
                        },
                        "231": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "VG\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "VG"
                        },
                        "75": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[A-Z]{2} ?\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BN"
                        },
                        "69": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BG"
                        },
                        "135": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5,6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KH"
                        },
                        "79": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z] ?\\d[ABCEGHJ-NPRSTV-Z]\\d",
                            "postal_code_placeholder": "A1A 1A1",
                            "country_iso_code": "CA"
                        },
                        "222": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CV"
                        },
                        "247": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "KY\\d-\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KY"
                        },
                        "81": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{7}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CL"
                        },
                        "82": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CN"
                        },
                        "257": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "6798",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CX"
                        },
                        "258": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "6799",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CC"
                        },
                        "86": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CO"
                        },
                        "87": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4,5}|\\d{3}-\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CR"
                        },
                        "118": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "HR"
                        },
                        "88": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CU"
                        },
                        "89": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CY"
                        },
                        "90": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3} ?\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CZ"
                        },
                        "93": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "DK"
                        },
                        "94": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "DO"
                        },
                        "96": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "EC"
                        },
                        "97": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "EG"
                        },
                        "187": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "CP [1-3][1-7][0-2]\\d",
                            "postal_code_placeholder": "CP 1101",
                            "country_iso_code": "SV"
                        },
                        "100": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "EE"
                        },
                        "101": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "ET"
                        },
                        "262": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "FIQQ 1ZZ",
                            "postal_code_placeholder": "",
                            "country_iso_code": "FK"
                        },
                        "241": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "FO"
                        },
                        "102": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "FI"
                        },
                        "103": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{2} ?\\d{3}",
                            "postal_code_placeholder": "75000",
                            "country_iso_code": "FR"
                        },
                        "115": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78]3\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GF"
                        },
                        "263": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "987\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PF"
                        },
                        "106": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GE"
                        },
                        "91": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "80331",
                            "country_iso_code": "DE"
                        },
                        "226": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "GX11 1AA",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GI"
                        },
                        "112": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3} ?\\d{2}",
                            "postal_code_placeholder": "104 31",
                            "country_iso_code": "GR"
                        },
                        "113": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "39\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GL"
                        },
                        "265": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78][01]\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GP"
                        },
                        "266": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(969(?:[12]\\d|3[12]))(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GU"
                        },
                        "114": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GT"
                        },
                        "305": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "GY\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GG"
                        },
                        "108": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GN"
                        },
                        "110": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GW"
                        },
                        "119": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "HT"
                        },
                        "267": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "HM"
                        },
                        "268": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "00120",
                            "postal_code_placeholder": "",
                            "country_iso_code": "VA"
                        },
                        "117": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "HN"
                        },
                        "120": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "HU"
                        },
                        "126": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "IS"
                        },
                        "122": {
                            "postal_code_type": "pin",
                            "postal_code_pattern": "^[1-9][0-9]{5}$",
                            "postal_code_placeholder": "110001",
                            "country_iso_code": "IN"
                        },
                        "121": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "ID"
                        },
                        "124": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}-?\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "IR"
                        },
                        "125": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "IQ"
                        },
                        "123": {
                            "postal_code_type": "eircode",
                            "postal_code_pattern": null,
                            "postal_code_placeholder": "",
                            "country_iso_code": "IE"
                        },
                        "269": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "IM\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "IM"
                        },
                        "127": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}(?:\\d{2})?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "IL"
                        },
                        "128": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "50100",
                            "country_iso_code": "IT"
                        },
                        "131": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}-?\\d{4}",
                            "postal_code_placeholder": "100-0001",
                            "country_iso_code": "JP"
                        },
                        "307": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "JE\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "JE"
                        },
                        "130": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "JO"
                        },
                        "132": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KZ"
                        },
                        "133": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KE"
                        },
                        "137": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KW"
                        },
                        "134": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KG"
                        },
                        "138": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LA"
                        },
                        "146": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "LV-\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LV"
                        },
                        "139": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "(?:\\d{4})(?: ?(?:\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LB"
                        },
                        "143": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LS"
                        },
                        "140": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LR"
                        },
                        "272": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "948[5-9]|949[0-8]",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LI"
                        },
                        "144": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LT"
                        },
                        "145": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LU"
                        },
                        "151": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MK"
                        },
                        "149": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MG"
                        },
                        "159": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MY"
                        },
                        "238": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MV"
                        },
                        "227": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[A-Z]{3} ?\\d{2,4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MT"
                        },
                        "274": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(969[67]\\d)(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MH"
                        },
                        "275": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78]2\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MQ"
                        },
                        "239": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}(?:\\d{2}|[A-Z]{2}\\d{3})",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MU"
                        },
                        "276": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "976\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "YT"
                        },
                        "150": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MX"
                        },
                        "277": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(9694[1-4])(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "FM"
                        },
                        "148": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MD"
                        },
                        "278": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "980\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MC"
                        },
                        "154": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MN"
                        },
                        "155": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "8\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "ME"
                        },
                        "147": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MA"
                        },
                        "156": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MZ"
                        },
                        "153": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MM"
                        },
                        "160": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NA"
                        },
                        "166": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NP"
                        },
                        "233": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "988\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NC"
                        },
                        "167": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "3974",
                            "country_iso_code": "NZ"
                        },
                        "163": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NI"
                        },
                        "161": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NE"
                        },
                        "162": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NG"
                        },
                        "282": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "2899",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NF"
                        },
                        "283": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(9695[012])(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MP"
                        },
                        "176": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": null,
                            "postal_code_placeholder": "",
                            "country_iso_code": "KP"
                        },
                        "165": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "NO"
                        },
                        "168": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "(?:PC )?\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "OM"
                        },
                        "169": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PK"
                        },
                        "284": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(969(?:39|40))(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PW"
                        },
                        "173": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PG"
                        },
                        "178": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PY"
                        },
                        "171": {
                            "postal_code_type": "Postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PE"
                        },
                        "172": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PH"
                        },
                        "174": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{2}-\\d{3}",
                            "postal_code_placeholder": "10-345",
                            "country_iso_code": "PL"
                        },
                        "177": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}-\\d{3}",
                            "postal_code_placeholder": "1000-205",
                            "country_iso_code": "PT"
                        },
                        "175": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(00[679]\\d{2})(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PR"
                        },
                        "304": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78]4\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "RE"
                        },
                        "180": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "RO"
                        },
                        "181": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "101000",
                            "country_iso_code": "RU"
                        },
                        "308": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78][01]\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "BL"
                        },
                        "286": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "(?:ASCN|STHL) 1ZZ",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SH"
                        },
                        "288": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78][01]\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "MF"
                        },
                        "289": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "9[78]5\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "PM"
                        },
                        "249": {
                            "postal_code_type": "Postal",
                            "postal_code_pattern": "VC\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "VC"
                        },
                        "291": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "4789\\d",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SM"
                        },
                        "183": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SA"
                        },
                        "185": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SN"
                        },
                        "189": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5,6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "RS"
                        },
                        "220": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SG"
                        },
                        "191": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3} ?\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SK"
                        },
                        "192": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SI"
                        },
                        "188": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[A-Z]{2} ?\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SO"
                        },
                        "215": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "ZA"
                        },
                        "294": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "SIQQ 1ZZ",
                            "postal_code_placeholder": "",
                            "country_iso_code": "GS"
                        },
                        "136": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "KR"
                        },
                        "99": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "28013",
                            "country_iso_code": "ES"
                        },
                        "142": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "LK"
                        },
                        "184": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SD"
                        },
                        "295": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SJ"
                        },
                        "194": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[HLMS]\\d{3}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "SZ"
                        },
                        "193": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "^\\d{5}$",
                            "postal_code_placeholder": "111 22",
                            "country_iso_code": "SE"
                        },
                        "80": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "CH"
                        },
                        "204": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{3}(?:\\d{2,3})?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TW"
                        },
                        "199": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TJ"
                        },
                        "205": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4,5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TZ"
                        },
                        "198": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TH"
                        },
                        "164": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "[1-9]\\d{3} ?(?:[A-RT-Z][A-Z]|S[BCE-RT-Z])",
                            "postal_code_placeholder": "1105 AW",
                            "country_iso_code": "NL"
                        },
                        "202": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TN"
                        },
                        "203": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TR"
                        },
                        "200": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TM"
                        },
                        "299": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "TKCA 1ZZ",
                            "postal_code_placeholder": "",
                            "country_iso_code": "TC"
                        },
                        "207": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "^([0-8][0-9]{4}|9[0-3][0-9]{3}|94[0-8][0-9]{2}|949[0-8][0-9]|9499[0-9])$",
                            "postal_code_placeholder": "",
                            "country_iso_code": "UA"
                        },
                        "105": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "^(GIR ?0AA|((AB|AL|B|BA|BB|BD|BF|BH|BL|BN|BR|BS|BT|BX|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}))|BFPO ?\\d{1,4})$",
                            "postal_code_placeholder": "NW1 6XE",
                            "country_iso_code": "GB"
                        },
                        "209": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "^\\d{5}(?:-\\d{4})?$",
                            "postal_code_placeholder": "12345",
                            "country_iso_code": "US"
                        },
                        "302": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "96898",
                            "postal_code_placeholder": "",
                            "country_iso_code": "UM"
                        },
                        "208": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "UY"
                        },
                        "248": {
                            "postal_code_type": "zip",
                            "postal_code_pattern": "(008(?:(?:[0-4]\\d)|(?:5[01])))(?:[ \\-](\\d{4}))?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "VI"
                        },
                        "210": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{6}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "UZ"
                        },
                        "211": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{4}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "VE"
                        },
                        "212": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}\\d?",
                            "postal_code_placeholder": "",
                            "country_iso_code": "VN"
                        },
                        "224": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "986\\d{2}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "WF"
                        },
                        "213": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "EH"
                        },
                        "217": {
                            "postal_code_type": "postal",
                            "postal_code_pattern": "\\d{5}",
                            "postal_code_placeholder": "",
                            "country_iso_code": "ZM"
                        }
                    },
                    "ship_to_preference_capabilities": {
                        "209": {
                            "postal_code": {
                                "is_assignable": true,
                                "is_required": true
                            }
                        },
                        "79": {
                            "postal_code": {
                                "is_assignable": true,
                                "is_required": true
                            }
                        },
                        "122": {
                            "postal_code": {
                                "is_assignable": true,
                                "is_required": true
                            }
                        },
                        "61": {
                            "postal_code": {
                                "is_assignable": true,
                                "is_required": true
                            }
                        },
                        "105": {
                            "postal_code": {
                                "is_assignable": true,
                                "is_required": true
                            }
                        }
                    },
                    "category_id": 68887416,
                    "admin_tools_page_data": [],
                    "plkey": "LT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5:slot-gacor-2026",
                    "plqv": false,
                    "currency_data": {
                        "currency_id": 978,
                        "code": "EUR",
                        "name": "Euro",
                        "number_precision": 2,
                        "symbol": "\u20ac",
                        "listing_enabled": true,
                        "browsing_enabled": true,
                        "buyer_location_restricted": false,
                        "is_synthetic": true,
                        "buyer_markup_rate": 0.04549999999999999877875467291232780553400516510009765625
                    },
                    "machine_translation\/listings_click_to_translate": true,
                    "ads.prolist\/log_clicks_and_impressions": false,
                    "mfg\/dovetail": true,
                    "mfg\/buyer_facing_dovetail": true,
                    "searchx\/4q18\/dwell_time_as_backend_event": false,
                    "is_regulatory_buyer_disclosure_enabled": true,
                    "is_convos_condensed_disclosure_enabled": false,
                    "buyer_listing_third_variation_support": false,
                    "is_move_js_inits_enabled": false,
                    "machine_translation": {
                        "mode": "disabled",
                        "listing_id": slot-gacor-2026,
                        "to_lang_code": "en-US",
                        "from_lang_code": "en-US",
                        "translated": null,
                        "untranslated": null,
                        "category_tags": null
                    },
                    "listing_fee": 20,
                    "presented_listing_fee": "$0.20 USD",
                    "listing_period_months": 4,
                    "apple_pay_api_version_number": 12,
                    "render_is_gift_section": true,
                    "coupons_in_buy_box_is_enabled": false,
                    "should_show_atc_from_listing_cards": true,
                    "should_show_atc_from_listing_cards_mweb": false,
                    "added_to_cart_text": "Added to cart!",
                    "speculation_rules_prefetch": false,
                    "speculation_rules_prefetch_from_page": null,
                    "prefetch_event_cache_key": "",
                    "is_eligible_for_trust_suite_section": false,
                    "init_module_dwell_logger": true,
                    "is_gift_guide_flyout_enabled": true,
                    "should_hide_sub_nav": true,
                    "should_show_breadcrumbs": true,
                    "listing_image_url": "",
                    "eligible_for_mini_collections_and_ignore_menu": false,
                    "image_ids_by_listing_variation_ids": [],
                    "shouldShowThumbnails": false,
                    "carousel_height_percentage_relative_to_width": [80],
                    "is_mobile_experience": false,
                    "is_users_own_listing": false,
                    "lp_toffers_v2_true_sale_enabled": true,
                    "lp_toffers_v2_gamed_sale_enabled": false,
                    "gamed_sales_v3_enabled": false,
                    "sale_ending_soon_countdown": true,
                    "should_show_histogram_panel": false,
                    "anchor_shop_name_to_seller_cred": false,
                    "shop_reviews_count": 461,
                    "neu_buy_box_type": "offerings",
                    "listing_id": slot-gacor-2026,
                    "klarna_osm_js": "https:\/\/js.klarna.com\/web-sdk\/v1\/klarna.js",
                    "is_eligible_for_klarna_osm": true,
                    "is_eligible_for_variations_update": true,
                    "can_listing_have_coupon_applied": false,
                    "is_eligible_for_policies_in_overlay": true,
                    "how_its_made_label_type": "seller_designed",
                    "product_details_content_toggle_selector": "[data-wt-content-toggle][aria-controls='content-toggle-product-details-read-more']",
                    "should_show_description_content_toggle": true,
                    "current_page": 1,
                    "is_new_deep_dive": true,
                    "is_reviews_triage": true,
                    "is_reviews_triage_redesign": true,
                    "eligible_for_review_photo_filter_and_sort": true,
                    "category_path": [66, 75, 77],
                    "use_review_photo_aesthetics_default_sort": true,
                    "use_review_photo_aesthetics_v2_default_sort": false,
                    "deep_dive_sheet_position": "bottom",
                    "should_show_pcv_in_deep_dive": false,
                    "should_show_sort_in_deep_dive_mweb": false,
                    "listingcard:76259aa00420994429fb4bfa81729f60:LTd6acd0eda8d1568af7d6b568e92a47085cda6708": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "01125905a4e5ddf2": "recs-impression",
                    "3c65557fa67e42dc": "b6030e06d55c918d5",
                    "c5420ec98ed7db34": "b7aa59b4fe4c53e4d",
                    "listingcard:76259aa00420994429fb4bfa81729f60:LTce88ccd5ade56ec561a896afeeb37f3ec0c40527": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:76259aa00420994429fb4bfa81729f60:LTd2df43dddcd20d8bee137f0e1c6445191f036b4d": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:76259aa00420994429fb4bfa81729f60:LT5a60be73b420a183807b17a20a76b33efee75712": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "mweb_can_scroll_to_seller_cred_module": false,
                    "time_utils_formats": {
                        "default": {
                            "default": "%B %e, %Y",
                            "short": "%b %e, %Y",
                            "short_no_leading_zeros": "%b %e, %Y",
                            "short_dow": "%a, %b %e, %Y",
                            "hourminute": "%l:%M%P",
                            "hourminutecap": "%l:%M %p",
                            "hourminutetz": "%l:%M%P %Z",
                            "shorthourminute": "%l:%M",
                            "hour": "%l%P",
                            "daymonth": "%b %e",
                            "daymonthyear": "%b %e, %Y",
                            "daylongmonth": "%B %e",
                            "long": "%B %e, %Y",
                            "short_time": "%b %e, %Y %R %Z",
                            "twoline": "%b %e\n%Y ",
                            "numerical": "%m\/%d\/%Y",
                            "yyyy_mm_dd": "%Y-%m-%d",
                            "monthyear": "%B %Y",
                            "monthyear_twoline": "%B\n%Y",
                            "monthyearshort": "%b %Y",
                            "month_day_year_short": "%m\/%d\/%y",
                            "dow_month_date": "%a %b %e",
                            "dow_month_date_conversation": "%a, %b %e",
                            "month": "%b",
                            "longmonth": "%B",
                            "day": "%e",
                            "year": "%Y",
                            "longmonthyear": "%B %Y"
                        }
                    },
                    "time_utils_locale": {
                        "months": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        "shortMonths": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                        "days": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                        "shortDays": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                        "AM": "AM",
                        "am": "am",
                        "PM": "PM",
                        "pm": "pm"
                    },
                    "mys_should_show_shop_reviews": true,
                    "mys_shop_reviews_show_disclaimer": true,
                    "mys_shop_reviews_update_header_copy": true,
                    "mys_shop_reviews_prioritize_photos": false,
                    "listingcard:b0c6b5f15f4702704b735c829fe0b93b:LT07c451b44f29cda1ca68fe1829a6a0a28434fc9c": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:b0c6b5f15f4702704b735c829fe0b93b:LT9a35507a38e26688c5d95a9da440b754aa9d4a99": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:b0c6b5f15f4702704b735c829fe0b93b:LTc0f71ae08f9c2b81cbe07b5f8952dcffc99dbe62": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:b0c6b5f15f4702704b735c829fe0b93b:LTe4184ffd33c43051a8b97c48b3da0999de0c46d5": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:b0c6b5f15f4702704b735c829fe0b93b:LT321c3b3881f8d109df8a8a71496374ec0db01274": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "listingcard:b0c6b5f15f4702704b735c829fe0b93b:LTff2b362c418a6c20f85b98aad3f07ad7efd19983": {
                        "plkey": null,
                        "plkey_input_name": "plkey",
                        "encoded_impression": ""
                    },
                    "structured_policies_messages": {
                        "module_name": "Shop policies",
                        "last_updated_on": "Last updated on",
                        "publish": "Publish Shop Policies",
                        "policies_save": "Save policies",
                        "policies_edit": "Edit policies",
                        "cancel": "Cancel",
                        "revert": "Use previous policies",
                        "edit": "Edit",
                        "loading": "Loading",
                        "preview_banner_kicker": "Policies preview",
                        "not_existing_policies_preview_banner_header": "Review and customize these policies so they work for you",
                        "preview_banner_body": "You can publish these to your shop or edit them if you need to make changes",
                        "preview_publish_confirm": "By clicking Publish, you'll post your Shop Policies and agree to comply with them.",
                        "revert_confirm": "Are you sure you want to revert?",
                        "leave_page_warning": "You are currently editing shop policies",
                        "private_receipt_info_title": "Private receipt info",
                        "private_receipt_info_body": "We have removed the 'Private Receipt Info' section of your policies page. You don't need to populate this section for the purposes of complying with international consumer protection laws anymore because this new Policies feature will automatically display the relevant content of your shop policies within the buyer receipt email instead.",
                        "private_receipt_info_link": "See this FAQ for more information",
                        "structured_banner_title": "Switch to simple shop policies",
                        "structured_banner_title_v2": "Set up simple shop policies",
                        "structured_banner_body": "We'll give you a quick template to create your shop policies in seconds.",
                        "structured_banner_button": "Try it now",
                        "new_simplified_policies": "Your new, simplified policies",
                        "new_policies_banner_description_1": "Buyers prefer policies that are short, clear and address their key concerns, so we've designed them that way.",
                        "new_policies_banner_description_2": "Review and customize these policies so they work for you. We've saved your previous policies, so you can always switch back.",
                        "new_policies_banner_description_3": "We've saved your previous policies, so you can always switch back.",
                        "new_policies_banner_learn_more": "Learn more",
                        "publish_policies_success": "Your new policies have been published!",
                        "publish_policies_error": "There was an error publishing your policies. Please try again.",
                        "policies_failed_to_load": "Shop policies failed to load",
                        "policies_try_again": "Try again",
                        "policies_saving": "Saving...",
                        "policies_publishing": "Publishing...",
                        "listing_preview_shipping": "This section will show shipping or download information once you publish your listing.",
                        "craft_shipping_section_title": "Shipping & policies",
                        "craft_payments_section_title": "Payments",
                        "craft_refunds_section_title": "Returns & exchanges",
                        "craft_terms_section_title": "Terms & conditions",
                        "craft_more_details_accordion_label": "+ See more...",
                        "listing_returns_and_exchanges": "See item details for return and exchange eligibility.",
                        "no_policies": "Looks like this shop doesn't have any custom policies. Have questions?",
                        "message_the_seller": "Message the seller",
                        "shipping_section_title": "Shipping",
                        "payments_section_title": "Payments",
                        "refunds_section_title": "Returns & exchanges",
                        "digital_section_title": "Downloads",
                        "terms_section_title": "Terms & conditions",
                        "more_details_accordion_label": "See more...",
                        "seller_details_section_title": "More information"
                    },
                    "shop_policy_selector": "[data-content-toggle-uid=shop_policies]",
                    "has_external_mobile_image_tags": false,
                    "tag_cards_with_image": ".w4gqnv13p0a4",
                    "conditional_sale_interstitial": true,
                    "google_client_id": "296956783393-2d8r0gljo87gjmdpmvkgbeasdmelq33e.apps.googleusercontent.com",
                    "show_one_tap_modal": false,
                    "is_google_one_tap_cart_page": false
                });
            }
            )();
        </script>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            __webpack_public_path__ = "https://www.etsy.com/ac/primaryVendor/js/en-US/";
        </script>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            (function() {
                var asyncAvailable = true;
                try {
                    eval("async () => {}");
                } catch (e) {
                    asyncAvailable = false;
                }

                var falseUA = false && !asyncAvailable;
                var primarySupportsAsync = !false && asyncAvailable;

                var clientloggerIsEnabled = true;
                if (clientloggerIsEnabled) {
                    if (falseUA) {
                        new Image().src = '/clientlog?falseua=1';
                    }
                    if (primarySupportsAsync) {
                        new Image().src = '/clientlog?primarysupportsasync=1';
                    }
                    if (window.__etsy_logging && window.__etsy_logging.bots && (window.__etsy_logging.bots.isBot || window.__etsy_logging.bots.botCheck.length > 0)) {
                        new Image().src = '/clientlog?feisbot=1&bot_check=' + encodeURIComponent(JSON.stringify(window.__etsy_logging.bots.botCheck));
                    }
                }

            }
            )();
        </script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/vendor_bundle.13bcfe5f1bf09197c0f7.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/etsy_libs.0e9af00a686bf3575d99.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/paula/v3/polyfill.min.js?etsy-v=v5&amp;flags=gated&amp;features=AbortController%2CDOMTokenList.prototype.@@iterator%2CDOMTokenList.prototype.forEach%2CIntersectionObserver%2CIntersectionObserverEntry%2CNodeList.prototype.@@iterator%2CNodeList.prototype.forEach%2CObject.preventExtensions%2CString.prototype.anchor%2CString.raw%2Cdefault%2Ces2015%2Ces2016%2Ces2017%2Ces2018%2Ces2019%2Ces2020%2Ces2021%2Ces2022%2Cfetch%2CgetComputedStyle%2CmatchMedia%2Cperformance.now" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/app-shell/globals/index.efc8889cc8adfdea0f81.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/@etsy-modules/ConsentManagement/Transcend-Integration.a2296b243a81e0e76f93.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/bootstrap/listings3/main.99b6ec87dfe91a4d61ea.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/async/component-islands/vendor.3b5e595e81443e589719.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <script src="https://www.etsy.com/ac/primaryVendor/js/en-US/@etsy-modules/Seo/InternalLinksModule/read-more.2d318710459e7d6227c3.js" type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn" crossorigin="" defer></script>
        <main id="content">
            <div data-ui="listing-breadcrumbs" class="wt-hide-xs wt-show-lg breadcrumb_nav">
                <div data-ui="cat-nav" id="desktop-category-nav" class="cat-nav  v2-toolkit-cat-nav wt-ml-xs-0 wt-mr-xs-0">
                    <div class="wt-text-caption wt-position-relative wt-z-index-5 wt-pt-xs-2">
                        <div class="wt-grid wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-6 wt-pr-lg-6">
                            <ul class="wt-list-unstyled wt-grid__item-xs-12 wt-body-max-width wt-display-flex-xs wt-justify-content-center" data-menu-ui="menubar" data-ui="top-nav-category-list">
                                <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                                    <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://oemparts.net/">Alexistogel</a>
                                    <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                        </svg>
                                    </span>
                                </li>
                                <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                                    <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://oemparts.net/">Situs Slot</a>
                                    <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                        </svg>
                                    </span>
                                </li>
                                <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                                    <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://oemparts.net/">Slot Gacor</a>
                                    <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                        </svg>
                                    </span>
                                </li>
                                <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                                    <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://oemparts.net/">Slot Terpercaya</a>
                                    <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                        </svg>
                                    </span>
                                </li>
                                <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                                    <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://oemparts.net/">Slot Gacor Hari Ini</a>
                                    <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                        </svg>
                                    </span>
                                </li>
                                <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                                    <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://oemparts.net/">ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026</a>
                                </li>
                            </ul>
                            <span class="active-nav-item-indicator wt-position-absolute wt-display-inline-block" data-ui="active-nav-item-indicator"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div data-selector="listing-page-content" class="content-wrap listing-page-content">
                <div class="wt-pt-xs-5 listing-page-content-container-wider wt-horizontal-center">
                    <div id="listing-right-column" class="listing-buy-box-experiment">
                        <div>
                            <div class="body-wrap wt-body-max-width wt-display-flex-md wt-flex-direction-column-xs">
                                <div class="image-col wt-order-xs-1 wt-mb-xs-2 wt-mb-lg-6 wt-pl-md-4 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2 wt-pr-xl-2 wt-pr-md-4 wt-pr-lg-0">
                                    <div class="wt-flex-lg-6 wt-mr-lg-3 wt-pr-xl-3">
                                        <div class="image-wrapper wt-position-relative carousel-container-responsive" id="photos">
                                            <button class="btn--focus inline-overlay-trigger favorite-item-action wt-position-absolute wt-btn wt-btn--light wt-btn--small wt-z-index-2
            wt-btn--filled wt-btn--icon wt-btn--fixed-floating wt-position-right wt-mr-xs-2 wt-mt-xs-2
            " data-ui="favorite-listing-button" data-listing-id="slot-gacor-2026" data-accessible-btn-fave="" data-favorite-label="Add to Favorites" data-favorited-label="Remove from Favorites" data-always-show="true">
                                                <div class="favorite-listing-button-icon-container should-animate " data-source="lp_image_carousel" data-btn-fave="" data-neu-fave="" data-favorite-icon-container="">
                                                    <span class="etsy-icon wt-nudge-t-1
                    
                    
                        
                        
                            wt-display-block
                        
                    " data-not-favorited-icon="">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.877 12.52q.081-.115.147-.239A6 6 0 0 0 12 4.528a6 6 0 0 0-9.024 7.753q.066.123.147.24l.673.961a6 6 0 0 0 .789.915L12 21.422l7.415-7.025q.44-.418.789-.915zm-14.916.425L12 18.667l6.04-5.722q.293-.279.525-.61l.673-.961a.3.3 0 0 0 .044-.087 4 4 0 1 0-7.268-2.619v.003L12 8.667l-.013.004v-.002l-.006-.064a3.98 3.98 0 0 0-1.232-2.51 4 4 0 0 0-6.031 5.193q.014.045.044.086l.673.961a4 4 0 0 0 .526.61"></path>
                                                        </svg>
                                                    </span>
                                                    <span class="etsy-icon wt-nudge-t-1 wt-text-favorite-heart
                    
                    
                        
                        
                            wt-display-none
                        
                    " data-favorited-icon="">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <path d="M21.024 12.281a2 2 0 0 1-.147.24l-.673.961q-.349.497-.789.915L12 21.422l-7.415-7.025a6 6 0 0 1-.789-.915l-.673-.961a2 2 0 0 1-.147-.24A6 6 0 0 1 12 4.528a6 6 0 0 1 9.024 7.753"></path>
                                                        </svg>
                                                    </span>
                                                </div>
                                                <span aria-hidden="true" class="icon"></span>
                                                <span class="wt-screen-reader-only" data-a11y-label="">Add to Favorites
            </span>
                                            </button>
                                            <div class="listing-page-image-carousel-component wt-display-flex-xs is-initialized" data-component="listing-page-image-carousel" data-palette-listing-id="slot-gacor-2026" data-shop-id="31714225">
                                                <div class="image-carousel-container wt-position-relative wt-flex-xs-6 wt-order-xs-2
                wt-mb-xs-1
                ">
                                                    <ul class="wt-list-unstyled wt-overflow-hidden wt-position-relative carousel-pane-list" style="padding-top: 80%;" data-carousel-pane-list="" tabindex="0">
                                                        <li class=" wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="0" data-image-id="6714763093" data-palette-listing-image="">
                                                            <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded" alt="May include: A stylized fox logo design featuring a fox head wearing a black hoodie with pink accents. The fox has glowing white eyes and a pink nose. The text &quot;premium logo&quot; is displayed in pink." data-carousel-first-image="" data-perf-group="main-product-image" src="https://s6.imgcdn.dev/Y7rD8w.jpg" srcset="https://s6.imgcdn.dev/Y7rD8w.jpg 1x, https://i.etsystatic.com/31714225/r/il/e2c8af/6714763093/il_1588xN.6714763093_1lku.jpg 2x" fetchpriority="high" data-original-image-width="2362" data-src-zoom-image="https://i.etsystatic.com/31714225/r/il/e2c8af/6714763093/il_fullxfull.6714763093_1lku.jpg" data-index="0"/>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wt-display-flex-xs wt-justify-content-flex-end wt-mt-xs-3">
                                            <a class="wt-text-link wt-text-link-underline" href="https://oemparts.net/">
                                                <span class="wt-icon wt-icon--smaller-xs wt-nudge-r-4">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7 3a1 1 0 0 0-2 0v18a1 1 0 1 0 2 0v-6h14.766l-3.6-6 3.6-6zm0 2v8h11.234l-2.4-4 2.4-4z"></path>
                                                    </svg>
                                                </span>
                                                Report this item to Etsy
    
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-col wt-order-xs-2 wt-mb-lg-5">
                                    <div id="listing-page-cart" class="wt-display-flex-lg wt-flex-direction-column-md wt-flex-lg-3 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
                                        <div class="
            wt-mt-xs-1">
                                            <p class="wt-text-title-small wt-sem-text-critical">Peminat Terbanyak 888.888 Orang Mengunjungi Dalam 24 Jam Terakhir</p>
                                        </div>
                                        <div class="wt-display-flex-xs wt-align-items-center wt-flex-wrap">
                                            <div data-appears-component-name="price">
                                                <div class="wt-display-flex-xs      wt-align-items-baseline          wt-flex-wrap appears-ready" data-selector="price-only" data-buy-box-region="price">
                                                    <p class="wt-text-title-larger wt-mr-xs-1
                wt-text-black
">
                                                        <span class="wt-mr-xs-1">Now</span>
                                                        <span class="wt-screen-reader-only">Price:</span>
                                                        Rp.19.000
    
                                                    </p>
                                                    <p class="wt-text-caption
        ">
                                                        <span class="wt-screen-reader-only">Original Price:</span>
                                                        <span class="wt-text-strikethrough
                lp_toffers_v2_original_price wt-nudge-b-1
                ">Rp. 190.000
            </span>
                                                    </p>
                                                    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--01 wt-display-none" aria-live="assertive" data-buy-box-price-spinner="">
                                                        <span class="wt-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                <circle fill="transparent" cx="12" cy="12" r="10"></circle>
                                                            </svg>
                                                        </span>
                                                        Loading
    
                                                    </div>
                                                    <span data-clg-id="WtSignal" class="wt-signal wt-signal--promote-strong   ">
                                                        <strong>New markdown!</strong>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wt-mb-xs-1 
                
                wt-display-flex-xs">
                                            <div>
                                                <p class="wt-text-title-small wt-sem-text-monetary-value">90% off
    </p>
                                            </div>
                                            <span id="discount-and-countdown-separator" class="wt-sem-text-monetary-value wt-mr-xs-1 wt-ml-xs-1">•</span>
                                            <div id="sale-ending-soon-countdown">
                                                <p class="wt-text-title-small wt-sem-text-monetary-value" data-24-hour-sale-wrapper="">1 x 24 jam
    </p>
                                            </div>
                                        </div>
                                        <div data-buy-box-region="vat_messaging"></div>
                                        <div class="wt-mt-xs-1 wt-mb-xs-1">
                                            <img src="https://s6.imgcdn.dev/Y7SEWB.gif" alt="Alexistogel" width="50%"/>
                                            <h1 data-buy-box-listing-title="true" tabindex="0" class="pdp-mod-product-badge-title">ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026
</h1>
                                            <p>ALEXISTOGEL adalah link situs slot88 gacor terpercaya hari ini menyediakan server mpo slot terbaik demi memudahkan pemain raih maxwin 2026 sekarang juga!</p>
                                        </div>
                                        <div class="wt-mb-xs-3">
                                            <div class="wt-display-inline-flex-xs wt-align-items-center wt-flex-wrap wt-flex-gap-xs-1 lp-shop-header">
                                                <div class="wt-display-inline-flex-xs wt-align-items-center
        
    ">
                                                    <span class="wt-text-title-small">
                                                        <a href="https://oemparts.net/" class="wt-text-link-no-underline wt-sem-text-primary">SLOT GACOR
        </a>
                                                    </span>
                                                </div>
                                                <div class="wt-text-link-no-underline review-stars-text-decoration-none">
                                                    <a href="#reviews" data-click-source="review_stars" aria-label="4.9 out of 5 stars. See reviews.">
                                                        <span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container="">
                                                            <input type="hidden" name="initial-rating" value="4.8712"/>
                                                            <input type="hidden" name="rating" value="4.8712"/>
                                                            <span class="wt-screen-reader-only">5 out of 5 stars</span>
                                                            <span>
                                                                <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="0">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false">
                                                                        <path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path>
                                                                    </svg>
                                                                </span>
                                                                <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false">
                                                                        <path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path>
                                                                    </svg>
                                                                </span>
                                                                <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="2">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false">
                                                                        <path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path>
                                                                    </svg>
                                                                </span>
                                                                <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="3">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false">
                                                                        <path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path>
                                                                    </svg>
                                                                </span>
                                                                <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="4">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false">
                                                                        <path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path>
                                                                    </svg>
                                                                </span>
                                                            </span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wt-mb-xs-6 wt-mb-lg-0">
                                            <div data-buy-box="">
                                                <div class="wt-mb-xs-3">
                                                    <div data-appears-component-name="variations">
                                                        <div data-selector="listing-page-variations" class="appears-ready"></div>
                                                    </div>
                                                </div>
                                                <div class="wt-mb-xs-2">
                                                    <div class="klarna-vertical-placeholder" data-klarna-client-id="klarna_live_client_aUYvcCg0dlhaVjAvTFN1NCgjQyQ3S0dQKTUxZ0lldEgsYTViNmJkOTItNzIyYS00ODk2LTg4MmItNzg2OTMwMTM2YTcwLDEsanoxdWljSXVoaTR0TFB4aTNEK3A4UlhmWWtaRkxLRWNndUpvUnlDL3Y2TT0" data-klarna-environment="production" data-klarna-osm-container="" data-buy-box-region="klarna_osm_messaging">
                                                        <klarna-placement data-key="credit-promotion-auto-size" data-locale="en-US" data-purchase-amount="610"></klarna-placement>
                                                        <div class="wt-sem-text-secondary wt-text-caption wt-m-xs"></div>
                                                    </div>
                                                </div>
                                                <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-wrap wt-flex-direction-column-lg wt-flex-gap-xs-2">
                                                    <div class="wt-display-none" id="mao-button-disabled-text-div">
                                                        <p class="wt-text-body-body wt-sem-text-secondary wt-text-center-xs">You can only make an offer when buying a single item
            </p>
                                                    </div>
                                                    <div data-appears-component-name="add_to_cart_form">
                                                        <div class="wt-validation wt-flex-xs-1 appears-ready" data-buy-box-region="add_to_cart_form">
                                                            <form action="/cart/listing.php" method="post" class="add-to-cart-form" data-buy-box-add-to-cart-form="">
                                                                <input type="hidden" name="listing_id" value="slot-gacor-2026"/>
                                                                <input type="hidden" name="ref" value="listing_page"/>
                                                                <input type="hidden" name="_nnc" value="3:1767581183:e2_gDuGZ9lSE7PxIQHoFPIk_6qID:8d70c1ef6762f835c52a76edfd12086a845de3dda248ccaf719b1d7797fd52fa" class="wt-display-none"/>
                                                                <input type="hidden" name="listing_inventory_id" value="24297532518"/>
                                                                <input type="hidden" name="shipping_method_id" value=""/>
                                                                <input type="hidden" name="quantity" value="1"/>
                                                                <input type="hidden" name="_nnc" value="3:1767581183:e2_gDuGZ9lSE7PxIQHoFPIk_6qID:8d70c1ef6762f835c52a76edfd12086a845de3dda248ccaf719b1d7797fd52fa" class="wt-display-none"/>
                                                                <div class="wt-width-full" data-add-to-cart-button="" data-selector="add-to-cart-button">
                                                                    <button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-width-full wt-no-wrap" type="submit">
                                                                        <span>
                                                                            Add to cart
        
    
                                                                            <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--01" aria-live="assertive" role="alert">
                                                                                <span class="wt-icon">
                                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                        <circle fill="transparent" cx="12" cy="12" r="10"></circle>
                                                                                    </svg>
                                                                                </span>
                                                                                Loading
    
                                                                            </div>
                                                                        </span>
                                                                    </button>
                                                                </div>
                                                            </form>
                                                            <p class="purchase-accept-terms wt-display-none wt-mt-xs-2 wt-sem-text-primary wt-text-body-small wt-width-full"></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-md wt-flex-direction-column-lg wt-flex-gap-md-2 wt-flex-gap-lg-0 wt-justify-content-space-between"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="listing-info info-col description-right wt-order-xs-5">
                                    <div class="wt-flex-lg-3 wt-order-xs-1 wt-order-lg-3 wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
                                        <div data-appears-component-name="product_details">
                                            <div id="product_details" class="appears-ready">
                                                <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                    <button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" data-default-open="true" aria-controls="product_details_content_toggle" aria-expanded="true">
                                                        <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                            <h2>Item details
                </h2>
                                                        </span>
                                                        <span class="wt-content-toggle--btn__icon"></span>
                                                    </button>
                                                    <div id="product_details_content_toggle" class="wt-content-toggle__body" aria-hidden="false">
                                                        <div class="wt-mb-xs-6">
                                                            <div class="wt-mt-xs-2">
                                                                <h3 class="wt-text-title">Highlights</h3>
                                                                <ul class="wt-block-grid-xs-1 wt-text-body-01 show-icons wt-mt-xs-1 wt-pl-xs-0 wt-mb-xs-3" data-selector="product-details-highlights">
                                                                    <div data-appears-component-name="how_its_made_label" data-appears-event-data="{&quot;label_type&quot;:&quot;seller_designed&quot;,&quot;section&quot;:&quot;product_details&quot;}">
                                                                        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start appears-ready">
                                                                            <div>
                                                                                <span class="wt-icon wt-nudge-b-2">
                                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                        <path d="M4.5 8v7H3v5h5v-1.25h2.5v-2H8V15H6.5V8H8V6.5h7V8h1.75v2.457l2 1.714V8H20V3h-5v1.5H8V3H3v5z"></path>
                                                                                        <path d="m12.39 9.129 9.273 7.971-4.17.29 1.378 3-2.272 1.043-1.36-2.962-2.854 2.887z"></path>
                                                                                    </svg>
                                                                                </span>
                                                                            </div>
                                                                            <div class="wt-ml-xs-1 how-its-made-label-product-details">
                                                                                Design by <a href="https://oemparts.net/" target="_blank" class="wt-text-link-no-underline wt-text-title">Alexistogel</a>
                                                                            </div>
                                                                        </li>
                                                                    </div>
                                                                    <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
                                                                        <div>
                                                                            <span class="wt-icon wt-nudge-b-2">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                    <path d="M21 12.32a7 7 0 0 0 0-.82A7.5 7.5 0 0 0 8.71 5.73a6.63 6.63 0 0 1 3.06 1.75c.13.12.24.26.36.39l-.89.89A6 6 0 1 0 7 19h12.5a3.5 3.5 0 0 0 1.5-6.68m-9 5.35-3.51-2.11 1-1.72 1.49.89V11h2v3.73l1.49-.89 1 1.72z"></path>
                                                                                </svg>
                                                                            </span>
                                                                        </div>
                                                                        <div class="wt-ml-xs-1">Slot Gacor Terlengkap & Terfavorit
        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div class="wt-mt-xs-2"></div>
                                                            <div data-id="description-text">
                                                                <div id="content-toggle-product-details-read-more" class="wt-content-toggle__body wt-content-toggle__body--truncated wt-content-toggle__body--truncated-02" aria-hidden="true" tabindex="-1">
                                                                    <p data-product-details-description-text-content="" class="wt-text-body-01 wt-break-word">Alexistogel hadir sebagai rekomendasi situs slot gacor 2026 resmi dan terpercaya di Indonesia. Dengan segudang koleksi permainan yang lengkap dan favorit dari provider ternama, Alexistogel menawarkan berbagai jenis permainan slot gacor hari ini yang dibekali dengan RTP tertinggi dan terancang untuk memberikan kesempatan maxwin tanpa batas.
        </p>
                                                                    <br/>
                                                                    <p data-product-details-description-text-content="" class="wt-text-body-01 wt-break-word">Sebagai situs slot gacor 2026 yang terpercaya, kami Alexistogel selalu mengutamakan kualitas permainan dan kenyamanan para member setia. Setiap game yang kami sediakan telah melewati proses seleksi ketat agar memastikan peforma tetap stabil, grafis menarik, serta sistem fair play yang transaparan. Hal ini membuat para user lebih aman dan nyaman saat bermain, baik pemula maupun pemain berpengalaman.
        </p>
                                                                </div>
                                                                <div class="wt-text-center-xs">
                                                                    <button type="button" class="wt-content-toggle--btn wt-btn wt-btn--small wt-btn--transparent" data-wt-content-toggle="" data-read-more-label-closed="Learn more about this item" data-read-more="true" aria-controls="content-toggle-product-details-read-more" data-default-open="false" aria-describedby="">Learn more about this item</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div data-appears-component-name="digital_delivery">
                                            <div id="digital_delivery" class="appears-ready">
                                                <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                    <button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" data-default-open="true" aria-controls="digital_delivery_content_toggle" aria-expanded="true">
                                                        <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                            <h2>Delivery
                </h2>
                                                        </span>
                                                        <span class="wt-content-toggle--btn__icon"></span>
                                                    </button>
                                                    <div id="digital_delivery_content_toggle" class="wt-content-toggle__body" aria-hidden="false">
                                                        <div class="wt-mb-xs-6">
                                                            <div id="digital-download-delivery-div" class="wt-grid wt-mb-xs-5">
                                                                <div class="wt-grid__item-xs-12">
                                                                    <p class="wt-text-heading-small wt-mt-xs-1 wt-mb-xs-3 wt-line-height-tight">Slot Gacor</p>
                                                                    <p class="wt-text-body-01 wt-sem-text-secondary wt-mb-xs-3 wt-line-height-tight">
                                                                        Alexistogel juga rutin menghadirkan promo menarik, dan event khusus yang menambah nilai lebih bagi para member...
                <a href="https://oemparts.net/" target="_blank" class="wt-sem-text-secondary" data-listings-track-click="" data-event-name="digital_download_delivery_link_clicked">Slot Gacor Hari Ini
                </a>
                                                                    </p>
                                                                    <p class="wt-text-body-01 wt-line-height-tight">Proses Deposit Otomatis &amp;Withdraw Tercepat Hanya 1 Sampai 3 Menit On Time.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div data-appears-component-name="did_you_know_toggle">
                                            <div id="did_you_know_toggle" class="appears-ready">
                                                <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                    <button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" data-default-open="true" aria-controls="did_you_know_toggle_content_toggle" aria-expanded="true">
                                                        <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                            <h2>Did you know?
                </h2>
                                                        </span>
                                                        <span class="wt-content-toggle--btn__icon"></span>
                                                    </button>
                                                    <div id="did_you_know_toggle_content_toggle" class="wt-content-toggle__body" aria-hidden="false">
                                                        <div class="wt-mb-xs-6">
                                                            <div class="wt-mt-xs-1 wt-mb-xs-3">
                                                                <div class="wt-grid__item-xs-12
        wt-mt-xs-4 wt-mt-md-2 wt-mb-xs-6 wt-mb-md-0
    ">
                                                                    <div class="wt-display-inline-flex-xs wt-align-items-center">
                                                                        <div class="wt-mr-xs-2" data-add-class-when-in-view="is-in-view">
                                                                            <span class="inline-svg">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 48 48" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" width="48" height="48" aria-hidden="true" focusable="false">
                                                                                    <style>
                                                                                        .is-in-view #e0NMFoeIPOT2_to {
                                                                                            animation: e0NMFoeIPOT2_to__to 2000ms linear 1 normal forwards
                                                                                        }

                                                                                        @keyframes e0NMFoeIPOT2_to__to {
                                                                                            0% {
                                                                                                transform: translate(44.162561px,5.846695px)
                                                                                            }

                                                                                            8% {
                                                                                                transform: translate(44.162561px,5.846695px);
                                                                                                animation-timing-function: cubic-bezier(0.15,0,1,1)
                                                                                            }

                                                                                            16.5% {
                                                                                                transform: translate(42.257336px,6.69656px);
                                                                                                animation-timing-function: cubic-bezier(0.25,0,0.75,1)
                                                                                            }

                                                                                            28% {
                                                                                                transform: translate(46.27px,7.700005px)
                                                                                            }

                                                                                            36.5% {
                                                                                                transform: translate(42.752561px,5.5px)
                                                                                            }

                                                                                            48% {
                                                                                                transform: translate(44.150002px,6.297191px)
                                                                                            }

                                                                                            100% {
                                                                                                transform: translate(44.150002px,6.297191px)
                                                                                            }
                                                                                        }

                                                                                        .is-in-view #e0NMFoeIPOT2_tr {
                                                                                            animation: e0NMFoeIPOT2_tr__tr 2000ms linear 1 normal forwards
                                                                                        }

                                                                                        @keyframes e0NMFoeIPOT2_tr__tr {
                                                                                            0% {
                                                                                                transform: rotate(-5deg)
                                                                                            }

                                                                                            8% {
                                                                                                transform: rotate(-5deg);
                                                                                                animation-timing-function: cubic-bezier(0.15,0,1,1)
                                                                                            }

                                                                                            16.5% {
                                                                                                transform: rotate(-7deg);
                                                                                                animation-timing-function: cubic-bezier(0.25,0,0.75,1)
                                                                                            }

                                                                                            28% {
                                                                                                transform: rotate(7deg)
                                                                                            }

                                                                                            36.5% {
                                                                                                transform: rotate(-5deg)
                                                                                            }

                                                                                            48% {
                                                                                                transform: rotate(0deg)
                                                                                            }

                                                                                            100% {
                                                                                                transform: rotate(0deg)
                                                                                            }
                                                                                        }

                                                                                        .is-in-view #e0NMFoeIPOT5_to {
                                                                                            animation: e0NMFoeIPOT5_to__to 2000ms linear 1 normal forwards
                                                                                        }

                                                                                        @keyframes e0NMFoeIPOT5_to__to {
                                                                                            0% {
                                                                                                transform: translate(4.2px,5.697011px)
                                                                                            }

                                                                                            8% {
                                                                                                transform: translate(4.2px,5.697011px);
                                                                                                animation-timing-function: cubic-bezier(0.15,0,1,1)
                                                                                            }

                                                                                            16.5% {
                                                                                                transform: translate(5.826704px,6.546839px);
                                                                                                animation-timing-function: cubic-bezier(0.25,0,0.75,1)
                                                                                            }

                                                                                            28% {
                                                                                                transform: translate(1.52px,7.701463px)
                                                                                            }

                                                                                            36.5% {
                                                                                                transform: translate(5.294274px,5.6px)
                                                                                            }

                                                                                            48% {
                                                                                                transform: translate(3.85px,6.297191px)
                                                                                            }

                                                                                            100% {
                                                                                                transform: translate(3.85px,6.297191px)
                                                                                            }
                                                                                        }

                                                                                        .is-in-view #e0NMFoeIPOT5_tr {
                                                                                            animation: e0NMFoeIPOT5_tr__tr 2000ms linear 1 normal forwards
                                                                                        }

                                                                                        @keyframes e0NMFoeIPOT5_tr__tr {
                                                                                            0% {
                                                                                                transform: rotate(5deg)
                                                                                            }

                                                                                            8% {
                                                                                                transform: rotate(5deg);
                                                                                                animation-timing-function: cubic-bezier(0.15,0,1,1)
                                                                                            }

                                                                                            16.5% {
                                                                                                transform: rotate(7deg);
                                                                                                animation-timing-function: cubic-bezier(0.25,0,0.75,1)
                                                                                            }

                                                                                            28% {
                                                                                                transform: rotate(-7deg)
                                                                                            }

                                                                                            36.5% {
                                                                                                transform: rotate(5deg)
                                                                                            }

                                                                                            48% {
                                                                                                transform: rotate(0deg)
                                                                                            }

                                                                                            100% {
                                                                                                transform: rotate(0deg)
                                                                                            }
                                                                                        }

                                                                                        .is-in-view #e0NMFoeIPOT8_to {
                                                                                            animation: e0NMFoeIPOT8_to__to 2000ms linear 1 normal forwards
                                                                                        }

                                                                                        @keyframes e0NMFoeIPOT8_to__to {
                                                                                            0% {
                                                                                                transform: translate(28.52px,15.1px)
                                                                                            }

                                                                                            8% {
                                                                                                transform: translate(28.52px,15.1px);
                                                                                                animation-timing-function: cubic-bezier(0.15,0,1,1)
                                                                                            }

                                                                                            16.5% {
                                                                                                transform: translate(26.96px,16.52px);
                                                                                                animation-timing-function: cubic-bezier(0.284467,0,0.625227,0.383992)
                                                                                            }

                                                                                            18.5% {
                                                                                                transform: translate(27.14px,16.214055px);
                                                                                                animation-timing-function: cubic-bezier(0.310382,0.25506,0.719913,0.848254)
                                                                                            }

                                                                                            19.5% {
                                                                                                transform: translate(27.3px,15.96px)
                                                                                            }

                                                                                            20.5% {
                                                                                                transform: translate(27.47px,15.63px)
                                                                                            }

                                                                                            22.5% {
                                                                                                transform: translate(27.96px,14.98px)
                                                                                            }

                                                                                            24.5% {
                                                                                                transform: translate(28.46px,14.3px)
                                                                                            }

                                                                                            27% {
                                                                                                transform: translate(29.004407px,13.613261px);
                                                                                                animation-timing-function: cubic-bezier(0.36087,0.641427,0.696459,1)
                                                                                            }

                                                                                            28% {
                                                                                                transform: translate(29.07px,13.52px)
                                                                                            }

                                                                                            28.5% {
                                                                                                transform: translate(28.952353px,13.590588px)
                                                                                            }

                                                                                            30% {
                                                                                                transform: translate(28.55px,13.84px)
                                                                                            }

                                                                                            31% {
                                                                                                transform: translate(28.3px,14px)
                                                                                            }

                                                                                            32% {
                                                                                                transform: translate(28.13px,14.18px)
                                                                                            }

                                                                                            33% {
                                                                                                transform: translate(27.85px,14.3px)
                                                                                            }

                                                                                            33.5% {
                                                                                                transform: translate(27.776555px,14.35px)
                                                                                            }

                                                                                            34% {
                                                                                                transform: translate(27.6px,14.4px)
                                                                                            }

                                                                                            34.5% {
                                                                                                transform: translate(27.540925px,14.5px)
                                                                                            }

                                                                                            35.5% {
                                                                                                transform: translate(27.305294px,14.6px)
                                                                                            }

                                                                                            36.5% {
                                                                                                transform: translate(27.07px,14.72px)
                                                                                            }

                                                                                            48% {
                                                                                                transform: translate(27.765359px,14.148534px)
                                                                                            }

                                                                                            100% {
                                                                                                transform: translate(27.765359px,14.148534px)
                                                                                            }
                                                                                        }

                                                                                        .is-in-view #e0NMFoeIPOT8_tr {
                                                                                            animation: e0NMFoeIPOT8_tr__tr 2000ms linear 1 normal forwards
                                                                                        }

                                                                                        @keyframes e0NMFoeIPOT8_tr__tr {
                                                                                            0% {
                                                                                                transform: rotate(-5deg)
                                                                                            }

                                                                                            8% {
                                                                                                transform: rotate(-5deg);
                                                                                                animation-timing-function: cubic-bezier(0.15,0,1,1)
                                                                                            }

                                                                                            16.5% {
                                                                                                transform: rotate(-7deg);
                                                                                                animation-timing-function: cubic-bezier(0.25,0,0.75,1)
                                                                                            }

                                                                                            28% {
                                                                                                transform: rotate(7deg)
                                                                                            }

                                                                                            36.5% {
                                                                                                transform: rotate(-5deg)
                                                                                            }

                                                                                            48% {
                                                                                                transform: rotate(0deg)
                                                                                            }

                                                                                            100% {
                                                                                                transform: rotate(0deg)
                                                                                            }
                                                                                        }
                                                                                    </style>
                                                                                    <g id="e0NMFoeIPOT2_to" transform="translate(44.162561,5.846695)">
                                                                                        <g id="e0NMFoeIPOT2_tr" transform="rotate(-5)">
                                                                                            <g transform="translate(-44.150002,-6.29719)">
                                                                                                <path d="M34.7,33.1l4.4-4.4c4.8-4.8,4.8-12.6,0-17.4v0c-4-4-10.1-4.9-14.7-2.1L17.7,15l17,18.1Z" fill="#4d6bc6"></path>
                                                                                                <path d="M36.5,33.5l-2.2-2.2l3.6-3.6c4.2-4.2,4.2-11,0-15.2C34.4,9,29,8.4,25.1,10.8L23.5,8.2C28.6,5,35.6,5.8,40.1,10.3c5.4,5.4,5.4,14.2,0,19.6l-3.6,3.6Z" fill="#222"></path>
                                                                                            </g>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g id="e0NMFoeIPOT5_to" transform="translate(4.2,5.697011)">
                                                                                        <g id="e0NMFoeIPOT5_tr" transform="rotate(5)">
                                                                                            <g transform="translate(-3.85,-6.297191)">
                                                                                                <path d="M40.5,25.2l-4.8-4.8v0l-9-9c-4.8-4.8-12.6-4.8-17.4,0s-4.9,12.6-.1,17.4L15.4,35v0l4.4,4.4c1.2,1.2,3.2,1.2,4.4,0s1.2-3.2,0-4.4l-1.7-1.7l3.9,3.9c1.2,1.2,3.2,1.2,4.4,0s1.2-3.2,0-4.4l1.1,1.1c1.2,1.2,3.2,1.2,4.4,0v0c1.2-1.2,1.2-3.2,0-4.4l-4.9-4.9v0l4.9,4.9c1.2,1.2,3.2,1.2,4.4,0c1-1.2,1-3.1-.2-4.3Z" fill="#d7e6f5"></path>
                                                                                                <path d="M42.7,27.4c0-1.2-.5-2.4-1.4-3.3l-4.8-4.8v0l-9-9c-5.4-5.4-14.2-5.4-19.6,0s-5.4,14.2,0,19.6l6.2,6.2v0l4.4,4.4c.9.9,2.1,1.3,3.3,1.3s2.4-.4,3.3-1.3c.4-.4.7-.9,1-1.5.7.4,1.5.6,2.3.6c1.2,0,2.4-.4,3.3-1.3.6-.6,1-1.3,1.2-2c.3.1.7.1,1,.1c1.2,0,2.4-.5,3.3-1.4.8-.8,1.3-1.9,1.3-3c1.1-.1,2.2-.5,3-1.3.7-.9,1.2-2.1,1.2-3.3Zm-3.6,1.1c-.6.6-1.6.6-2.2,0l-7.6-7.6L27.2,23l7.6,7.6c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0l-1.1-1.1L25,25.2l-2.2,2.2l6.5,6.5c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0L25,33.9l-4.4-4.4-2.2,2.2l4.4,4.4c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0l-1.9-1.9v0L10,27.7c-4.2-4.2-4.2-11,0-15.2s11-4.2,15.2,0l6.2,6.2v0L39,26.3c.3.3.5.7.5,1.1.1.4-.1.8-.4,1.1Z" fill="#222"></path>
                                                                                            </g>
                                                                                        </g>
                                                                                    </g>
                                                                                    <g id="e0NMFoeIPOT8_to" transform="translate(28.52,15.1)">
                                                                                        <g id="e0NMFoeIPOT8_tr" transform="rotate(-5)">
                                                                                            <g transform="translate(-27.765359,-14.148534)">
                                                                                                <path d="M32.3,15.1L23,19.8c-1.7,1.2-4.2.8-5.4-.9v0c-1.2-1.7-.8-4.1.9-5.4c2.1-1.5,4.7-3.4,5.6-3.9C28.7,6.7,35,7.4,39,11.4v0" fill="#4d6bc6"></path>
                                                                                                <path d="M19.4,14.7l1.9-1.4c1-.7,2-1.4,2.7-1.9.4-.3.7-.5.9-.6.7-.4,1.4-.7,2.1-.9c3.7-1.2,8-.3,10.9,2.6l2.2-2.2c-4.2-4.2-10.9-5.2-16-2.5-.3.1-.5.3-.8.4-.4.3-1.3.9-2.3,1.6-.5.3-.9.7-1.4,1l-1.9,1.4c-2.4,1.7-3,5.1-1.3,7.5.8,1.2,2.1,2,3.5,2.2.3.1.6.1.9.1c1.1,0,2.2-.3,3.1-1l5.9-4.1l2.6-1.8-2.2-2.2-2.6,1.8-5.4,3.8c-.5.4-1.1.5-1.7.4s-1.1-.4-1.5-1c-.9-1-.6-2.5.4-3.2Z" fill="#222"></path>
                                                                                            </g>
                                                                                        </g>
                                                                                    </g>
                                                                                </svg>
                                                                            </span>
                                                                        </div>
                                                                        <p class="wt-sem-text-primary wt-text-caption">
                                                                            <strong>Alexistogel Proteksi Pembelian</strong>
                                                                            <br/>
                                                                            Berbelanjalah dengan percaya diri di Alexistogel karena jika terjadi masalah dengan pesanan, kami akan membantu Anda untuk semua pembelian yang memenuhi syarat —
            <a href="https://oemparts.net/" target="_blank" class="wt-text-link">see program terms
            </a>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <button data-clg-id="WtButton" class="wt-btn wt-btn--secondary wt-btn--transparent-flush-left wt-btn--small wt-width-full" data-overlay-trigger="true" aria-controls="policies-overlay">View additional shop policies 

</button>
                                                            <div class="js-promotion-description "></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wt-mb-xs-3">
                                            <div data-appears-component-name="shop_owners">
                                                <div id="shop_owners" class="appears-ready">
                                                    <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                        <button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush" data-wt-content-toggle="true" data-animate="true" aria-controls="shop_owners_content_toggle" aria-expanded="false">
                                                            <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                                <h2>About-us
                </h2>
                                                            </span>
                                                            <span class="wt-content-toggle--btn__icon"></span>
                                                        </button>
                                                        <div id="shop_owners_content_toggle" class="wt-content-toggle__body" aria-hidden="true" tabindex="-1">
                                                            <div class="wt-mb-xs-6">
                                                                <div class="wt-display-flex-xs wt-align-items-center wt-mb-xs-2">
                                                                    <div class="wt-thumbnail-larger wt-mr-xs-3">
                                                                        <img data-clg-id="WtImage" class="wt-height-full wt-width-full wt-rounded-01 wt-overflow-hidden wt-image--cover wt-image" src="https://s6.imgcdn.dev/Y7SJhu.png" alt="Abel" style="aspect-ratio: 1;" loading="lazy" sizes="75px" srcset="https://s6.imgcdn.dev/Y7SJhu.png 100w, https://s6.imgcdn.dev/Y7SJhu.png 200w"/>
                                                                    </div>
                                                                    <div>
                                                                        <p class="wt-text-heading-small wt-line-height-tight wt-mb-lg-1">Slot Gacor</p>
                                                                        <p class=" wt-sem-text-primary wt-text-caption">
                                                                            Owner of <a href="https://www.etsy.com/shop/Alexistogel?ref=l2-about-shopname&amp;from_page=listing" class="wt-text-link">Alexistogel</a>
                                                                        </p>
                                                                        <div data-follow-shop-region="">
                                                                            <div data-action="follow-shop-button-container" class="wt-display-flex-xs wt-align-items-center">
                                                                                <input type="hidden" class="id" name="user_id" value="525012624"/>
                                                                                <a href="https://oemparts.net/" rel="nofollow" data-downtime-overlay-type="favorite" data-supplemental-state--use_follow_text="true" class="inline-overlay-trigger favorite-shop-action wt-btn wt-btn--small wt-btn--transparent follow-shop-button-listing-header-v3 wt-btn--transparent-flush-left" aria-label="Follow shop" data-action="follow-shop-button" data-shop-id="31714225" data-source-name="listing_header" data-module-name="">
                                                                                    <span class="etsy-icon wt-icon--smaller-xs" data-not-following-icon="">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                            <path d="M12,21C10.349,21,2,14.688,2,9,2,5.579,4.364,3,7.5,3A6.912,6.912,0,0,1,12,5.051,6.953,6.953,0,0,1,16.5,3C19.636,3,22,5.579,22,9,22,14.688,13.651,21,12,21ZM7.5,5C5.472,5,4,6.683,4,9c0,4.108,6.432,9.325,8,10,1.564-.657,8-5.832,8-10,0-2.317-1.472-4-3.5-4-1.979,0-3.7,2.105-3.721,2.127L11.991,8.1,11.216,7.12C11.186,7.083,9.5,5,7.5,5Z"></path>
                                                                                        </svg>
                                                                                    </span>
                                                                                    <span class="etsy-icon wt-icon--smaller-xs wt-display-none wt-text-brick" data-following-icon="">
                                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                            <path d="M16.5,3A6.953,6.953,0,0,0,12,5.051,6.912,6.912,0,0,0,7.5,3C4.364,3,2,5.579,2,9c0,5.688,8.349,12,10,12S22,14.688,22,9C22,5.579,19.636,3,16.5,3Z"></path>
                                                                                        </svg>
                                                                                    </span>
                                                                                    <span data-following-message="" class="wt-ml-xs-1 listing-header-v3-message wt-display-inline-block wt-position-relative wt-display-none ">Following
                        </span>
                                                                                    <span data-not-following-message="" class="wt-ml-xs-1 listing-header-v3-message wt-display-inline-block wt-position-relative ">Follow shop
                        </span>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <a rel="nofollow" href="https://login-alx-slot-gacor.b-cdn.net/moran.html" class="wt-btn wt-btn--outline wt-width-full contact-action convo-overlay-trigger inline-overlay-trigger" role="button" data-to_username="7p97h5ef307p3gdc" data-to_user_id="525012624" data-to_user_display_name="Alexistogel" data-referring_type="listing" data-referring_id="slot-gacor-2026" data-subject="" data-message="" aria-label="Message Alexistogel">
                                                                    <span>Message Alexistogel</span>
                                                                </a>
                                                                <p class="wt-text-caption wt-text-center-xs wt-pt-xs-2 wt-sem-text-secondary">
                                                                    This seller usually responds <b>within 24 hours.</b>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div data-appears-component-name="listing_page_seller_details">
                                            <div class="wt-grid wt-grid__item-lg-12 wt-pl-xs-0 wt-bt-xs wt-bt-lg-none wt-pt-lg-0 appears-ready" data-region="reg-seller-details">
                                                <div data-action="show-reg-seller-details" class="wt-pb-lg-0 wt-pl-xs-0 wt-pr-xs-0 wt-pl-xs-0 wt-mb-xs-0 wt-grid__item-lg-9 wt-text-title-small wt-pb-xs-8 ">
                                                    <a class="wt-btn wt-btn--transparent wt-btn--small" aria-label="View shop registration details" data-overlay-trigger="true" aria-controls="reg-seller-details-overlay">View shop registration details
                </a>
                                                </div>
                                                <div class=" wt-mt-xs-1" data-region="seller-details-captcha">
                                                    <div class="g-recaptcha-etsy" data-sitekey="6LdLaJ4dAAAAAJ7wEqcouvMBPRU1ssOPOcYYzPJQ" data-etsy-autoload="false" data-recaptcha-version="enterprise" data-recaptcha-key-type="checkbox" id="g-recaptcha-etsy-shop_seller_details-checkbox" data-badge="inline" data-recaptcha-action="shop_seller_details"></div>
                                                    <div class="wt-alert wt-alert--inline wt-alert--error-01 wt-display-none js-recaptcha-load-error">
                                                        <p class="wt-text-body-01">Captcha failed to load. Try using a different browser or disabling ad blockers.</p>
                                                    </div>
                                                    <input id="g-recaptcha-etsy-shop_seller_details-checkbox-input" type="hidden" name="enterprise_recaptcha_token" value=""/>
                                                    <input id="g-recaptcha-etsy-shop_seller_details-checkbox-input-key-type" type="hidden" name="enterprise_recaptcha_token_key_type" value="checkbox"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="listing-info wider-review-col wt-order-xs-6">
                                    <div class="wt-flex-lg-5 wt-align-items-flex-start wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pr-lg-0 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2" data-appears-component-name="listing_page_reviews_container_top" data-offset="0.01">
                                        <div class="wt-mb-xs-3 appears-ready">
                                            <div data-appears-component-name="listing_page_reviews" data-appears-event-data="{&quot;transaction_ids&quot;:[4728956483],&quot;reviews_with_text&quot;:1,&quot;reviews_older_than_three_months&quot;:1,&quot;reviews_under_three_stars&quot;:0,&quot;fired_on_plus_more&quot;:false,&quot;tab_fetched&quot;:&quot;same_listing_reviews&quot;,&quot;listing_rating_count&quot;:1,&quot;shop_rating_count&quot;:461,&quot;page&quot;:&quot;listing&quot;,&quot;listing_id&quot;:slot-gacor-2026,&quot;page_number&quot;:1,&quot;sort_option&quot;:&quot;Relevancy&quot;,&quot;is_mobile_or_tablet&quot;:false,&quot;is_reviews_untabbed&quot;:false,&quot;is_initial_load&quot;:true,&quot;tag_filters&quot;:[],&quot;rating_filter&quot;:null}" data-dwell-component-name="listing_page_reviews" data-dwell-logger-uuid="be02117a-fe7c-48d7-9a32-cd02a523f109" class="dwell-ready">
                                                <div data-reviews-container="" id="reviews" class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-gap-xs-4 wt-mt-xs-2 wt-mt-lg-0 appears-ready">
                                                    <div class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-center">
                                                        <h2 class="wt-text-title">Item reviews</h2>
                                                    </div>
                                                    <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-gap-xs-2">
                                                        <div data-appears-component-name="reviews_header">
                                                            <div class="reviews-header appears-ready">
                                                                <div class="reviews-header-ratings wt-display-flex-xs  wt-flex-wrap">
                                                                    <div class="reviews-rating wt-display-flex-xs wt-flex-direction-row-xs wt-align-items-center">
                                                                        <div class="wt-display-flex-xs wt-align-items-center">
                                                                            <span class="wt-icon wt-icon--larger wt-fill-beeswax wt-nudge-b-1">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                    <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                </svg>
                                                                            </span>
                                                                            <p>
                                                                                <span class="reviews-rating wt-pal-grid-pr-xs-100">5.0</span>
                                                                            </p>
                                                                        </div>
                                                                        <p class="reviews-rating-label wt-text-body-smaller">Item average</p>
                                                                    </div>
                                                                    <div class="reviews-header-subratings wt-display-flex-xs ">
                                                                        <div class="reviews-subrating wt-display-flex-xs wt-align-items-center reviews-subrating--sm-grid">
                                                                            <span class="rating-score rating-score--large fill-5 wt-flex-shrink-xs-0">
                                                                                <span class="rating-value wt-text-title-small">5.0</span>
                                                                            </span>
                                                                            <span class="rating-label wt-text-body-smaller">Kecepatan</span>
                                                                        </div>
                                                                        <div class="reviews-subrating wt-display-flex-xs wt-align-items-center reviews-subrating--sm-grid">
                                                                            <span class="rating-score rating-score--large fill-5 wt-flex-shrink-xs-0">
                                                                                <span class="rating-value wt-text-title-small">5.0</span>
                                                                            </span>
                                                                            <span class="rating-label wt-text-body-smaller">Kelengkapan</span>
                                                                        </div>
                                                                        <div class="reviews-subrating wt-display-flex-xs wt-align-items-center reviews-subrating--sm-grid">
                                                                            <span class="rating-score rating-score--large fill-5 wt-flex-shrink-xs-0">
                                                                                <span class="rating-value wt-text-title-small">5.0</span>
                                                                            </span>
                                                                            <span class="rating-label wt-text-body-smaller">Customer service</span>
                                                                        </div>
                                                                        <div class="reviews-recommends wt-display-flex-xs wt-align-items-center reviews-subrating--sm-grid">
                                                                            <span class="rating-score rating-score--large wt-flex-shrink-xs-0" style="--fill: 100%;">
                                                                                <span class="rating-value wt-text-title-small">100%
                    </span>
                                                                            </span>
                                                                            <span class="rating-label wt-text-body-smaller">Rekomendasi Pemain</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="listing-reviews-triage">
                                                        <div class="wt-block-grid-xs-1  wt-pal-grid-mb-xs-150" data-triage-reviews="">
                                                            <div class="listing-reviews-triage__review-container wt-block-grid__item wt-pb-xs-3">
                                                                <div class="listing-reviews-triage__review-card wt-card wt-width-full" data-triage-listing-review-card="">
                                                                    <button class="wt-text-left-xs wt-sem-bg-elevation-0 wt-p-xs-0 wt-b-xs-none wt-width-full" data-triage-listing-review="" data-transaction-id="4728956483">
                                                                        <div class="wt-pal-grid-mb-xs-050">
                                                                            <div data-clg-id="WtStaticStars" class="wt-star-rating__frame wt-star-rating__frame--caption">
                                                                                <div role="img" class="wt-star-rating wt-display-inline-block" aria-label="Rating 5 out of 5 stars.">
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="wt-display-inline-block">
                                                                                    <span></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="wt-display-flex-xs wt-flex-wrap wt-pal-grid-mb-xs-100 wt-flex-gap-xs-1">
                                                                            <p class="wt-text-title-small--tight wt-sem-text-primary">Zaynudin</p>
                                                                            <p class="wt-bl-xs wt-pal-grid-pl-xs-050 wt-text-body-small--tight wt-sem-text-secondary">Nov 25, 2025</p>
                                                                            <div data-clg-id="WtSignalGroup" class="wt-signal-group wt-signal-group--horizontal wt-text-title-smallest">
                                                                                <span class="wt-bl-xs wt-pal-grid-pl-xs-050">
                                                                                    <span data-clg-id="WtSignal" class="wt-signal wt-signal--generic-subtle   ">
                                                                                        <span class="wt-icon wt-icon--smallest-xs wt-signal__icon">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M21 3H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8.65l4.73 3.78a1 1 0 0 0 1.4-.15A1 1 0 0 0 18 20v-3h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 12.05h-4V18l-3.38-2.71a.92.92 0 0 0-.62-.22H4V5h16zM8 11a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                        Seller response


                                                                                    </span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <p class="wt-text-body-small wt-sem-text-primary wt-text-truncate--multi-line" data-triage-review-text="">Main di Alexistogel enak banget, gamenya lengkap dan banyak yang gacor. Baru main sebentar udah dikasih wd besar, btw gue baru maxwin hehe...</p>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="listing-reviews-triage">
                                                        <div class="wt-block-grid-xs-1  wt-pal-grid-mb-xs-150" data-triage-reviews="">
                                                            <div class="listing-reviews-triage__review-container wt-block-grid__item wt-pb-xs-3">
                                                                <div class="listing-reviews-triage__review-card wt-card wt-width-full" data-triage-listing-review-card="">
                                                                    <button class="wt-text-left-xs wt-sem-bg-elevation-0 wt-p-xs-0 wt-b-xs-none wt-width-full" data-triage-listing-review="" data-transaction-id="4728956483">
                                                                        <div class="wt-pal-grid-mb-xs-050">
                                                                            <div data-clg-id="WtStaticStars" class="wt-star-rating__frame wt-star-rating__frame--caption">
                                                                                <div role="img" class="wt-star-rating wt-display-inline-block" aria-label="Rating 5 out of 5 stars.">
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="wt-display-inline-block">
                                                                                    <span></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="wt-display-flex-xs wt-flex-wrap wt-pal-grid-mb-xs-100 wt-flex-gap-xs-1">
                                                                            <p class="wt-text-title-small--tight wt-sem-text-primary">Nino Mahardika</p>
                                                                            <p class="wt-bl-xs wt-pal-grid-pl-xs-050 wt-text-body-small--tight wt-sem-text-secondary">Des 15, 2025</p>
                                                                            <div data-clg-id="WtSignalGroup" class="wt-signal-group wt-signal-group--horizontal wt-text-title-smallest">
                                                                                <span class="wt-bl-xs wt-pal-grid-pl-xs-050">
                                                                                    <span data-clg-id="WtSignal" class="wt-signal wt-signal--generic-subtle   ">
                                                                                        <span class="wt-icon wt-icon--smallest-xs wt-signal__icon">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M21 3H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8.65l4.73 3.78a1 1 0 0 0 1.4-.15A1 1 0 0 0 18 20v-3h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 12.05h-4V18l-3.38-2.71a.92.92 0 0 0-.62-.22H4V5h16zM8 11a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                        Seller response


                                                                                    </span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <p class="wt-text-body-small wt-sem-text-primary wt-text-truncate--multi-line" data-triage-review-text="">Jujurly, gue baru main slot gacor, sejauh ini Alexistogel paling konsisten. Hampir tiap hari ada aja slot yang ngasih jatah, jadi gue betah main disini...</p>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="listing-reviews-triage">
                                                        <div class="wt-block-grid-xs-1  wt-pal-grid-mb-xs-150" data-triage-reviews="">
                                                            <div class="listing-reviews-triage__review-container wt-block-grid__item wt-pb-xs-3">
                                                                <div class="listing-reviews-triage__review-card wt-card wt-width-full" data-triage-listing-review-card="">
                                                                    <button class="wt-text-left-xs wt-sem-bg-elevation-0 wt-p-xs-0 wt-b-xs-none wt-width-full" data-triage-listing-review="" data-transaction-id="4728956483">
                                                                        <div class="wt-pal-grid-mb-xs-050">
                                                                            <div data-clg-id="WtStaticStars" class="wt-star-rating__frame wt-star-rating__frame--caption">
                                                                                <div role="img" class="wt-star-rating wt-display-inline-block" aria-label="Rating 5 out of 5 stars.">
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="wt-display-inline-block">
                                                                                    <span></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="wt-display-flex-xs wt-flex-wrap wt-pal-grid-mb-xs-100 wt-flex-gap-xs-1">
                                                                            <p class="wt-text-title-small--tight wt-sem-text-primary">Iffan Fauzan</p>
                                                                            <p class="wt-bl-xs wt-pal-grid-pl-xs-050 wt-text-body-small--tight wt-sem-text-secondary">Des 30, 2025</p>
                                                                            <div data-clg-id="WtSignalGroup" class="wt-signal-group wt-signal-group--horizontal wt-text-title-smallest">
                                                                                <span class="wt-bl-xs wt-pal-grid-pl-xs-050">
                                                                                    <span data-clg-id="WtSignal" class="wt-signal wt-signal--generic-subtle   ">
                                                                                        <span class="wt-icon wt-icon--smallest-xs wt-signal__icon">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M21 3H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8.65l4.73 3.78a1 1 0 0 0 1.4-.15A1 1 0 0 0 18 20v-3h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 12.05h-4V18l-3.38-2.71a.92.92 0 0 0-.62-.22H4V5h16zM8 11a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                        Seller response


                                                                                    </span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <p class="wt-text-body-small wt-sem-text-primary wt-text-truncate--multi-line" data-triage-review-text="">Suka banget sama Alexistogel karena banyak pilihan game dan jarang zonk. Deposit cepat, mainnya lancar, maxwin bukan cuma mimpi...</p>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="listing-reviews-triage">
                                                        <div class="wt-block-grid-xs-1  wt-pal-grid-mb-xs-150" data-triage-reviews="">
                                                            <div class="listing-reviews-triage__review-container wt-block-grid__item wt-pb-xs-3">
                                                                <div class="listing-reviews-triage__review-card wt-card wt-width-full" data-triage-listing-review-card="">
                                                                    <button class="wt-text-left-xs wt-sem-bg-elevation-0 wt-p-xs-0 wt-b-xs-none wt-width-full" data-triage-listing-review="" data-transaction-id="4728956483">
                                                                        <div class="wt-pal-grid-mb-xs-050">
                                                                            <div data-clg-id="WtStaticStars" class="wt-star-rating__frame wt-star-rating__frame--caption">
                                                                                <div role="img" class="wt-star-rating wt-display-inline-block" aria-label="Rating 5 out of 5 stars.">
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                    <span class="wt-star-rating__icon__frame">
                                                                                        <span class="wt-icon wt-star-rating__icon--smaller">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="wt-display-inline-block">
                                                                                    <span></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="wt-display-flex-xs wt-flex-wrap wt-pal-grid-mb-xs-100 wt-flex-gap-xs-1">
                                                                            <p class="wt-text-title-small--tight wt-sem-text-primary">Yudit Anggara</p>
                                                                            <p class="wt-bl-xs wt-pal-grid-pl-xs-050 wt-text-body-small--tight wt-sem-text-secondary">Jan 02, 2026</p>
                                                                            <div data-clg-id="WtSignalGroup" class="wt-signal-group wt-signal-group--horizontal wt-text-title-smallest">
                                                                                <span class="wt-bl-xs wt-pal-grid-pl-xs-050">
                                                                                    <span data-clg-id="WtSignal" class="wt-signal wt-signal--generic-subtle   ">
                                                                                        <span class="wt-icon wt-icon--smallest-xs wt-signal__icon">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                                <path d="M21 3H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8.65l4.73 3.78a1 1 0 0 0 1.4-.15A1 1 0 0 0 18 20v-3h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 12.05h-4V18l-3.38-2.71a.92.92 0 0 0-.62-.22H4V5h16zM8 11a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                        Seller response


                                                                                    </span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <p class="wt-text-body-small wt-sem-text-primary wt-text-truncate--multi-line" data-triage-review-text="">Pakai server mana ini bos? slot gacor nya gampang banget maxwin...</p>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div id="deep-dive-root"></div>
                                                </div>
                                            </div>
                                            <div class="wt-b-lg wt-rounded-01 wt-p-lg-3">
                                                <div data-appears-component-name="shop_owners">
                                                    <div class="wt-width-full wt-display-flex-xs wt-flex-direction-column-xs appears-ready" data-seller-cred="">
                                                        <div class="seller-cred wt-width-full wt-display-flex-xs wt-flex-gap-xs-2 wt-flex-direction-column-xs wt-align-items-center wt-mb-xs-3 wt-mb-md-4">
                                                            <div class="wt-position-relative">
                                                                <a href="https://oemparts.net/?ref=shop_profile&amp;listing_id=slot-gacor-2026">
                                                                    <img data-clg-id="WtImage" class="wt-circle wt-display-block wt-image--cover wt-image" src="https://s6.imgcdn.dev/Y7SJhu.png" alt="StreamLegends" style="aspect-ratio: 1;" sizes="(max-width: 639px) 65px, 80px" srcset="https://s6.imgcdn.dev/Y7SJhu.png 100w, https://s6.imgcdn.dev/Y7SJhu.png 200w"/>
                                                                </a>
                                                            </div>
                                                            <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-justify-content-space-between">
                                                                <div class="wt-display-flex-xs wt-flex-gap-xs-1 wt-align-items-center">
                                                                    <a class="wt-text-link-no-underline" href="https://www.etsy.com/shop/StreamLegends?ref=shop_profile&amp;listing_id=slot-gacor-2026">
                                                                        <p class="wt-text-heading">Slot Gacor</p>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-wrap wt-justify-content-center">
                                                                <a class="wt-text-link-no-underline wt-text-body" href="https://www.etsy.com/shop/StreamLegends?ref=shop_profile&amp;listing_id=slot-gacor-2026">Owned by Alexistogel</a>
                                                                <span class="divider wt-align-self-center wt-mr-xs-1 wt-ml-xs-1">|</span>
                                                                <p class="wt-text-body">Indonesia</p>
                                                            </div>
                                                            <div class="seller-cred-highlights wt-display-flex-xs wt-flex-direction-row-xs wt-mb-xs-1 wt-mb-md-2 wt-flex-wrap wt-justify-content-center">
                                                                <div class="" data-review-ratings-count="" data-rating="4.9">
                                                                    <div class="rating-and-reviews-count wt-display-flex-xs wt-align-items-center">
                                                                        <span class="wt-icon wt-icon--smaller-xs rating-and-reviews-count__icon wt-nudge-b-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                <path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path>
                                                                            </svg>
                                                                        </span>
                                                                        <span class="rating-and-reviews-count__avg-rating wt-text-title">4.9</span>
                                                                        <button data-reviews-deep-dive-trigger="" class="wt-text-link-no-underline">
                                                                            <span class="rating-and-reviews-count__reviews-count wt-text-title">(888)
                    </span>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                                <div class="wt-text-title">3k User Gacor
</div>
                                                                <div data-appears-component-name="lp_seller_cred_tenure" data-appears-event-data="{&quot;tenure&quot;:&quot;4 years&quot;}">
                                                                    <div class="wt-text-title appears-ready">Since 2015
</div>
                                                                </div>
                                                            </div>
                                                            <div class="seller-cred-buttons wt-display-flex-xs wt-justify-content-center wt-align-items-center wt-flex-gap-xs-2 wt-flex-gap-lg-4 wt-width-full wt-flex-wrap">
                                                                <div class="wt-flex-xs-1 wt-flex-lg-0">
                                                                    <a rel="nofollow" href="https://login-alx-slot-gacor.b-cdn.net/moran.html" class="wt-btn wt-btn--outline wt-btn--small wt-width-full-xs wt-no-wrap listing-page-contact-seller-button seller-cred-button contact-action convo-overlay-trigger inline-overlay-trigger" role="button" data-to_username="7p97h5ef307p3gdc" data-to_user_id="525012624" data-to_user_display_name="Abel" data-referring_type="listing" data-referring_id="slot-gacor-2026" data-subject="" data-message="" aria-label="Message seller">
                                                                        <span>Message seller</span>
                                                                    </a>
                                                                </div>
                                                                <div class="wt-flex-xs-1 wt-flex-lg-0">
                                                                    <div data-follow-shop-region="">
                                                                        <div data-action="follow-shop-button-container" class="wt-display-flex-xs wt-align-items-center">
                                                                            <input type="hidden" class="id" name="user_id" value="525012624"/>
                                                                            <a href="https://oemparts.net/" rel="nofollow" data-downtime-overlay-type="favorite" data-supplemental-state--use_follow_text="true" class="inline-overlay-trigger favorite-shop-action inline-overlay-trigger favorite-shop-action wt-btn wt-btn--small wt-btn--secondary wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-width-full-xs wt-no-wrap seller-cred-button" aria-label="Follow shop" data-action="follow-shop-button" data-shop-id="31714225" data-source-name="other" data-module-name="">
                                                                                <span data-following-message="" class="wt-ml-xs-1 wt-display-none ">Following
                        </span>
                                                                                <span data-not-following-message="" class="wt-ml-xs-1 ">Follow shop
                        </span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p class="wt-sem-text-secondary wt-text-body-smaller wt-text-center-xs">
                                                                This seller usually responds <b>within 24 hours.</b>
                                                            </p>
                                                        </div>
                                                        <div data-appears-component-name="lp_seller_cred_badges" data-appears-event-data="{&quot;has_ratings_badge&quot;:true,&quot;has_convos_badge&quot;:false,&quot;has_shipping_badge&quot;:false}">
                                                            <div class="seller-cred-badges-container     wt-b-xs wt-bt-lg wt-br-lg-none wt-bl-lg-none wt-bb-lg-none     wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-lg wt-justify-content-space-evenly     wt-mb-xs-4 wt-mb-md-6 wt-p-xs-2 wt-p-lg-0 wt-pt-lg-6  appears-ready">
                                                                <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            
        ">
                                                                    <div class="wt-flex-shrink-0">
                                                                        <span class="wt-icon wt-icon--smaller-xs wt-icon--base-md">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                                <path d="M12 3a9 9 0 0 0-9 9 8.87 8.87 0 0 0 1.21 4.49l-.92 3.43.79.79 3.43-.92A8.87 8.87 0 0 0 12 21a9 9 0 1 0 0-18m3 12.93-.37.27L12 14.65 9.41 16.2 9 15.93 9.72 13l-2.28-2 .15-.43 3-.27 1.18-2.77h.46l1.18 2.77 3 .27.15.43-2.28 2z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                    <p>
                                                                        <span class="wt-text-title">Rave reviews</span>
                                                                        <span class="wt-text-body">Average review rating is 4.8 or higher.</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="mys-shop-reviews-root" data-shop-id="31714225" data-shop-reviews-count="461" data-listing-id="slot-gacor-2026"></div>
                                                        <div id="mys-shop-reviews-root" data-shop-id="40031159" data-shop-reviews-count="17322"></div>
                                                        <style>
                                                            /* Wrapper: mencegah layout “lompat”, aman di mobile */
                                                            .table-wrap {
                                                                width: 100%;
                                                                margin: 16px 0 24px;
                                                                overflow-x: auto;
                                                                /* scroll horizontal saat viewport sempit */
                                                                -webkit-overflow-scrolling: touch;
                                                                background: #fff;
                                                                border: 1px solid #e5e7eb;
                                                                border-radius: 12px;
                                                                box-shadow: 0 8px 24px rgba(0,0,0,.06);
                                                            }

                                                            /* Tabel inti */
                                                            .info-table {
                                                                width: 100%;
                                                                border-collapse: collapse;
                                                                min-width: 420px;
                                                                /* cegah pecah di layar sangat kecil */
                                                                font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
                                                                font-size: 10px;
                                                                color: #1f2937;
                                                                /* gray-800 */
                                                            }

                                                            /* Sel */
                                                            .info-table td {
                                                                padding: 12px 14px;
                                                                vertical-align: top;
                                                                border-top: 1px solid #f1f5f9;
                                                                /* gray-100 */
                                                            }

                                                            /* Baris pertama tanpa border top */
                                                            .info-table tr:first-child td {
                                                                border-top: 0;
                                                            }

                                                            /* Kolom kiri: tampil seperti heading */
                                                            .info-table td:first-child {
                                                                width: 10%;
                                                                font-weight: 700;
                                                                color: #0f172a;
                                                                /* slate-900 */
                                                                white-space: nowrap;
                                                            }

                                                            /* Zebra striping */
                                                            .info-table tr:nth-child(even) td {
                                                                background: #fafafa;
                                                            }

                                                            /* Hover halus (desktop) */
                                                            @media (hover: hover) {
                                                                .info-table tr:hover td {
                                                                    background: #fff7ed;
                                                                    /* sedikit oranye lembut */
                                                                }
                                                            }

                                                            /* Rating badge */
                                                            .rating {
                                                                display: inline-block;
                                                                font-weight: 700;
                                                                padding: 4px 8px;
                                                                border-radius: 8px;
                                                                background: #fef3c7;
                                                                /* amber-100 */
                                                                border: 1px solid #fde68a;
                                                                /* amber-200 */
                                                                line-height: 1;
                                                            }

                                                            /* Mode gelap opsional (ikut preferensi OS) */
                                                            @media (prefers-color-scheme: dark) {
                                                                .table-wrap {
                                                                    background: #2e2e2e;
                                                                    border-color: #1f2937;
                                                                    box-shadow: none;
                                                                }

                                                                .info-table {
                                                                    color: #e5e7eb;
                                                                }

                                                                .info-table td {
                                                                    border-top-color: #1f2937;
                                                                }

                                                                .info-table tr:nth-child(even) td {
                                                                    background: #606060;
                                                                }

                                                                .info-table tr:hover td {
                                                                    background: #0f1b2e;
                                                                }

                                                                .info-table td:first-child {
                                                                    color: #f8fafc;
                                                                }

                                                                .rating {
                                                                    background: #1d2a3f;
                                                                    border-color: #334155;
                                                                    color: #eab308;
                                                                }
                                                            }
                                                        </style>
                                                        <!-- WRAPPER untuk stabilitas & responsivitas -->
                                                        <div class="table-wrap">
                                                            <table class="info-table">
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                            <b>Jenis Game</b>
                                                                        </td>
                                                                        <td>Slot Gacor</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <b>Minimal Deposit</b>
                                                                        </td>
                                                                        <td>Rp 5.000</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <b>Minimal Withdraw</b>
                                                                        </td>
                                                                        <td>Rp 25.000</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <b>Transaksi Pembayaran</b>
                                                                        </td>
                                                                        <td>QRIS/DANA/OVO/GoPay/ShopeePay/BankIndonesia</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <b>Perkiraan Waktu Proses</b>
                                                                        </td>
                                                                        <td>10-60 Detik</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <b>Rating</b>
                                                                        </td>
                                                                        <td>
                                                                            <span class="rating">5.0 ⭐</span>
                                                                            - 999.9K ulasan
        
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <center>
                                                                <img src="https://s6.imgcdn.dev/Y7SEWB.gif" width="20%" alt="Alexistogel"/>
                                                            </center>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wt-body-max-width wt-mb-xs-6 wt-pr-xs-2 wt-pl-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-5 wt-pr-lg-5">
                            <div class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs wt-mb-md-4">
                                <div class="wt-display-flex-xs wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs">
                                    <div class="wt-pr-xs-2 wt-text-caption">Listed on Jan 7, 2026
            </div>
                                    <div class="wt-text-caption">
                                        <a rel="nofollow" class="wt-text-link" href="/listing/slot-gacor-2026/gaming-logo-design-service-with-username/favoriters?ref=l2-collection-count">One favorite
                </a>
                                    </div>
                                </div>
                            </div>
                            <div class="wt-text-caption wt-text-center-xs wt-text-left-lg">
                                <a href="https://www.etsy.com/?ref=breadcrumb_listing">Alexistogel</a>
                                <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                    </svg>
                                </span>
                                <a href="https://www.etsy.com/c/art-and-collectibles?ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=&amp;ref=breadcrumb_listing&amp;pro=1&amp;dd=1&amp;plkey=LT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%3Aslot-gacor-2026&amp;explicit=1">Situs Slot</a>
                                <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                    </svg>
                                </span>
                                <a href="https://www.etsy.com/c/art-and-collectibles/drawing-and-illustration?ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=&amp;ref=breadcrumb_listing&amp;pro=1&amp;dd=1&amp;plkey=LT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%3Aslot-gacor-2026&amp;explicit=1">Slot Gacor</a>
                                <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path>
                                    </svg>
                                </span>
                                <a href="https://www.etsy.com/c/art-and-collectibles/drawing-and-illustration/digital?ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=&amp;ref=breadcrumb_listing&amp;pro=1&amp;dd=1&amp;plkey=LT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%3Aslot-gacor-2026&amp;explicit=1">ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026</a>
                            </div>
                            <div id="google-one-tap-modal-div" class="google-one-tap-modal-div"></div>
                            <div id="listing-page-post-add-to-cart-overlay"></div>
                            <div class="wt-overlay wt-overlay--peek" id="conditional-sale-interstitial-overlay" aria-hidden="true" data-wt-overlay="" role="dialog" aria-modal="false" aria-label="">
                                <div class="wt-overlay__modal" data-overlay-modal="">
                                    <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light" data-wt-overlay-close="">
                                        <span class="wt-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                <path d="M3.793 5.207 10.586 12l-6.793 6.793 1.414 1.414L12 13.414l6.793 6.793 1.414-1.414L13.414 12l6.793-6.793-1.414-1.414L12 10.586 5.207 3.793z"></path>
                                            </svg>
                                        </span>
                                    </button>
                                    <div data-conditional-sale-content=""></div>
                                    <div data-conditional-sale-loading="" class="wt-width-full wt-height-full wt-z-index-3">
                                        <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--02" aria-live="assertive">
                                            <span class="wt-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true" focusable="false">
                                                    <circle fill="transparent" cx="24" cy="24" r="21"></circle>
                                                </svg>
                                            </span>
                                            Loading
    
                                        </div>
                                    </div>
                                    <div data-conditional-sale-load-failure="">
                                        <div data-clg-id="WtBanner" class="wt-banner wt-banner--warning-01" id="etsywebtoolkitbannerswtbanner695b25ffc93fa" data-prop-id="etsywebtoolkitbannerswtbanner695b25ffc93fa" data-prop-type="static" data-prop-style-type="warning-01" data-prop-is-open="true" data-wt-neu-rendered="">
                                            <div data-clg-id="WtBannerContent" class="wt-banner__layout">
                                                <div class="wt-display-flex-xs wt-align-items-center">
                                                    <div class="wt-banner__icon-frame wt-hide-xs wt-show-sm ">
                                                        <span class="etsy-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.035 2.627a2 2 0 0 1 3.93 0 6.7 6.7 0 0 1 4.56 4.905L21 18.333H3L5.475 7.532a6.7 6.7 0 0 1 4.56-4.905m1.921 1.706a4.694 4.694 0 0 0-4.531 3.645L5.51 16.333h12.98l-1.915-8.355a4.694 4.694 0 0 0-4.531-3.645z"></path>
                                                                <path d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <div>
                                                        <div>
                                                            <p class="wt-banner__title">There was a problem loading the content
                </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wt-banner__buttons">
                                                    <button data-clg-id="WtButton" class="wt-btn wt-btn--primary wt-btn--small" data-wt-banner-cta-button="" type="button">Try again
</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="footer" class="content-wrap-inner-blank-noborder"></div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <div id="collage-footer" class="site-footer chrome-footer chrome-footer--ehi  ">
            <footer>
                <div class="chrome-footer__etsy-finds">
                    <div class="wt-text-center-xs wt-pl-xs-4 wt-pr-xs-4 wt-pt-xs-3 wt-pt-md-6">
                        <form action="/email-subscriptions/form?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026" method="POST" class="subscribe-form not-signed-in" data-finds-form="">
                            <input type="hidden" name="campaign_name" value=""/>
                            <input type="hidden" name="campaign_slug" value="new_at_etsy"/>
                            <input type="hidden" name="subscribe" value="true"/>
                            <input type="hidden" name="ref" value=""/>
                            <input type="hidden" name="_nnc" value="3:1767581183:S707WNCWiaCQVZNivVb0nPPJU0j5:9de427b682b2ac2821fcbea2e47afbac839234616c3add866910e09e661979e7" class="wt-display-none"/>
                            <div class="wt-mb-xs-3">
                                <p class="wt-text-title-01 wt-mb-xs-2">ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026</p>
                            </div>
                            <div class="wt-max-width-sm wt-validation">
                                <label class="wt-label wt-mt-xs-4 wt-screen-reader-only" for="email-list-signup-email-input">Enter your email</label>
                                <div class="wt-input-btn-group" data-email-list-signup-form-elements="">
                                    <input class="wt-input-btn-group__input wt-text-body-01" id="email-list-signup-email-input" placeholder="Enter your email" name="email_address" data-email-list-signup-email-input=""/>
                                    <button type="submit" class="wt-btn wt-input-btn-group__btn" data-email-list-signup-btn-input="">
                                        Subscribe
                        
                                        <div class="wt-spinner wt-spinner--01 wt-display-none" role="alert" aria-live="assertive">
                                            <span class="etsy-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <circle fill="transparent" cx="12" cy="12" r="10"></circle>
                                                </svg>
                                            </span>
                                            Loading
                       
                                        </div>
                                    </button>
                                </div>
                            </div>
                            <div class="g-recaptcha-etsy" data-sitekey="6Ldgkr0ZAAAAAGnf08YhMemepXW29Ux9rtJCcBD3" data-etsy-autoload="false" data-recaptcha-version="enterprise" data-recaptcha-key-type="score" id="g-recaptcha-etsy-public_email_subscribe-score" data-badge="inline" data-recaptcha-action="public_email_subscribe"></div>
                            <div class="wt-alert wt-alert--inline wt-alert--error-01 wt-display-none js-recaptcha-load-error">
                                <p class="wt-text-body-01">Captcha failed to load. Try using a different browser or disabling ad blockers.</p>
                            </div>
                            <input id="g-recaptcha-etsy-public_email_subscribe-score-input" type="hidden" name="enterprise_recaptcha_token" value=""/>
                            <input id="g-recaptcha-etsy-public_email_subscribe-score-input-key-type" type="hidden" name="enterprise_recaptcha_token_key_type" value="score"/>
                            <div class="wt-text-center wt-mt-xs-2 wt-validation wt-max-width-sm">
                                <div class="wt-validation__message wt-validation__message--is-hidden wt-text-body-01" id="email-list-signup-invalid-email" role="alert" aria-live="polite" data-invalid-email="" data-submission-error-response="">Please enter a valid email address.
            </div>
                                <div class="wt-alert wt-alert--inline wt-alert--status-01 wt-display-none wt-text-body-01" role="alert" aria-live="polite" data-requires-signin="" data-submission-response="">
                                    Looks like you already have an account! Please <a href="/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026&amp;workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2NzU4MTc4MzozZjc4MDZlMWE3MzY3Yzc3MGE2MTU3MmU3ZDdlMjRjYw==" data-campaign-slug="new_at_etsy">Log in</a>
                                    to subscribe.
            
                                </div>
                                <div class="wt-alert wt-alert--inline wt-alert--status-01 wt-display-none wt-text-body-01" role="alert" aria-live="polite" data-requires-signup="" data-submission-response="">
                                    You &#39;ve already signed up for some newsletters, but you haven &#39;t confirmed your address. <a href="/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026" class="" data-campaign-slug="new_at_etsy">Register</a>
                                    to confirm your address.
            
                                </div>
                                <div class="wt-alert wt-alert--inline wt-alert--success-01 wt-display-none wt-text-body-01" role="alert" aria-live="polite" data-success-signed-in="" data-success-no-email-signed-in="" data-success-no-email-signed-out="" data-submission-response="">You &#39;ve been successfully signed up!
            </div>
                                <div class="wt-alert wt-alert--inline wt-alert--success-01 wt-display-none wt-text-body-01" role="alert" aria-live="polite" data-success-signed-out="" data-submission-response="">Great! We &#39;ve sent you an email to confirm your subscription.
            </div>
                                <div class="wt-validation__message wt-validation__message--is-hidden wt-text-body-01" id="email-list-signup-generic-error" role="alert" aria-live="polite" data-generic-error="" data-submission-error-response="">There was a problem subscribing you to this newsletter.
            </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div data-appears-component-name="impact_message" data-appears-event-data="{&quot;impact_name&quot;:&quot;footer_renewable_impact&quot;,&quot;impact_themes&quot;:[&quot;sustainability&quot;],&quot;impact_audiences&quot;:[&quot;buyers&quot;]}">
                    <div class="footer-impact-callout wt-position-relative appears-ready">
                        <div class="wt-sem-bg-surface-highlight-dark wt-sem-text-on-surface-dark wt-text-center-xs wt-text-body-01 wt-pb-xs-4 wt-pt-xs-4">
                            <div class="wt-popover wt-popover--top" data-wt-popover="">
                                <button data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-display-flex-md wt-align-items-center" aria-describedby="footer-environmental-impact-popover-content">
                                    <div class="wt-flex-md-auto wt-mb-xs-1 wt-mb-md-0">
                                        <span class="wt-icon wt-icon--larger">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" aria-hidden="true" focusable="false">
                                                <path d="M60.1 38H49v11h-2V38H35.9c1.931 9.368 6.626 17 12.1 17 5.474 0 10.171-7.632 12.1-17zm-25.145-9.5c-.003 2.511.19 5.019.577 7.5H47V18.522l-10.925.238a41.683 41.683 0 00-1.12 9.74zM47 2.31c-4.1 1.24-8.18 7.168-10.38 14.437L47 16.52V2.31z"></path>
                                                <path d="M57.52 9.45l1.784-.9a31.775 31.775 0 012.558 7.65l9.117-.2.042 2-8.78.19c.55 3.41.818 6.857.8 10.31a50.836 50.836 0 01-.54 7.5H72v2h-9.846c-1.6 8.2-5.244 15.053-9.862 17.754C66.834 54.079 76 43.793 76 28.589c0-8.962-2.958-16.353-8.554-21.373A25.424 25.424 0 0049 1.04v15.438l10.83-.236a29.32 29.32 0 00-2.31-6.791zM43.51 55.643c-4.525-2.78-8.086-9.564-9.665-17.643H24v-2h9.5a50.84 50.84 0 01-.549-7.5 43.776 43.776 0 011.075-9.7l-9.009.2-.042-2 9.562-.208c1.89-6.667 5.317-12.436 9.432-15.143C29.71 4.412 20 15.13 20 28.589a27.636 27.636 0 0023.51 27.054z"></path>
                                                <path d="M61.045 28.5a60.27 60.27 0 00-.818-10.265L49 18.479v17.52h11.468c.388-2.48.58-4.988.577-7.5zM91.7 60c-2.182 4.525-5.734 8.62-10.832 13.719l-1.414-1.414c6.6-6.6 10.511-11.424 12.08-17.7.072-.415.137-.832.215-1.278.607-3.48.262-5.951-1.027-6.068-.72-.066-1.559.68-1.947 2.3a30.158 30.158 0 01-2.454 8.148c-1.78 4.663-8.575 11.048-8.865 11.318l-1.366-1.461c.068-.063 6.8-6.391 8.381-10.62l.061-.133a30.644 30.644 0 002.526-9.148c.11-1.886.095-6.433-1.793-6.552-2.085-.132-2.537 3.505-3.367 7.379-.259 1.21-.89 3.456-1.153 4.243a1.55 1.55 0 01-.09.177c-1.386 4.053-5.32 7.859-5.515 8.045-2.984 2.983-9.707 9.74-9.707 9.74L64.01 69.3s6.726-6.761 9.727-9.761a28.158 28.158 0 003.064-3.6c.5-.788 1.452-2.646.55-3.572-1.148-1.178-3.287-.648-6.08.748-1.98.992-11.21 7.08-15.384 13.34-1.99 2.985-2.772 8.839-3.042 14.2l13.18 2.724 6.8 1.359a8.92 8.92 0 011-.778c7.075-4.74 14.663-11.833 17.317-16.54 3.566-6.32 1.988-7.52.558-7.42zM52.774 82.673l-.77 10.252 1.993.15.595-7.913 10.616 2.123 3.765.778L70.02 93.2l1.96-.4-.885-4.338 2.592.518.392-1.96-8.447-1.69-12.858-2.657zm-29.242 2.055l6.77-1.354 13.206-2.73c-.27-5.36-1.052-11.214-3.042-14.2-4.173-6.258-13.4-12.347-15.384-13.34-2.793-1.4-4.932-1.925-6.08-.747-.9.926.054 2.784.55 3.572a28.158 28.158 0 003.064 3.6c3 3 9.727 9.76 9.727 9.76l-1.418 1.41s-6.723-6.757-9.707-9.74c-.2-.186-4.129-3.992-5.515-8.045a1.74 1.74 0 01-.09-.177c-.263-.787-.894-3.033-1.153-4.243-.83-3.874-1.282-7.511-3.367-7.38-1.888.12-1.9 4.667-1.793 6.553a30.645 30.645 0 002.526 9.148l.061.133c1.58 4.229 8.313 10.557 8.381 10.62L18.9 69.034c-.29-.27-7.084-6.655-8.865-11.318a30.16 30.16 0 01-2.454-8.148c-.388-1.622-1.226-2.37-1.947-2.3-1.287.114-1.634 2.586-1.025 6.065.078.446.143.863.215 1.278C6.394 60.883 10.3 65.7 16.9 72.307l-1.41 1.414c-5.1-5.1-8.65-9.194-10.832-13.72-1.434-.104-3.013 1.1.553 7.42 2.654 4.706 10.238 11.8 17.321 16.529a8.92 8.92 0 011 .778zm7.175.605l-8.433 1.687.393 1.96 2.591-.518-.885 4.338 1.96.4 1.047-5.137 3.75-.775 10.631-2.126.595 7.913 1.994-.15-.77-10.252-12.873 2.66z"></path>
                                            </svg>
                                        </span>
                                    </div>
                                    <div class="wt-mr-xs-2 wt-ml-xs-2 wt-mr-sm-0 wt-ml-sm-0 wt-ml-md-2 wt-text-body-01 wt-flex-md-auto">Etsy is powered by 100% renewable electricity.
                </div>
                                </button>
                                <div id="footer-environmental-impact-popover-content" role="tooltip">
                                    Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.
            <span class="wt-popover__arrow"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="chrome-footer__extra-links-app-container">
                    <nav class="chrome-footer__extra-links" aria-label="Footer" data-footer-extra-links="">
                        <div class="wt-body-max-width">
                            <div class="wt-grid">
                                <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                    <h3 class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">Shop
    </h3>
                                    <button type="button" class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark" data-wt-content-toggle="" aria-controls="footer-extra-links-shop" aria-expanded="false">
                                        <span class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">Shop
        </span>
                                        <span class="wt-content-toggle--btn__icon"></span>
                                    </button>
                                    <div id="footer-extra-links-shop" class="wt-content-toggle__body" aria-hidden="false">
                                        <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Gift cards</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" id="collage-footer__registry-link" href="https://oemparts.net/">
                                                    <span>Etsy Registry</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Sitemap</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Etsy blog</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Etsy United Kingdom</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Etsy Germany</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Etsy Canada</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                    <h3 class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">Sell
    </h3>
                                    <button type="button" class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark" data-wt-content-toggle="" aria-controls="footer-extra-links-sell" aria-expanded="false">
                                        <span class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">Sell
        </span>
                                        <span class="wt-content-toggle--btn__icon"></span>
                                    </button>
                                    <div id="footer-extra-links-sell" class="wt-content-toggle__body" aria-hidden="false">
                                        <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Sell on Etsy</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" id="collage-footer__community-teams-link" href="https://oemparts.net/" rel="nofollow">
                                                    <span>Teams</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" id="collage-footer__community-forums-link" href="https://oemparts.net/" rel="nofollow">
                                                    <span>Forums</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/" rel="nofollow">
                                                    <span>Affiliates &amp;Creators</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                    <h3 class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">About
    </h3>
                                    <button type="button" class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark" data-wt-content-toggle="" aria-controls="footer-extra-links-about" aria-expanded="false">
                                        <span class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">About
        </span>
                                        <span class="wt-content-toggle--btn__icon"></span>
                                    </button>
                                    <div id="footer-extra-links-about" class="wt-content-toggle__body" aria-hidden="false">
                                        <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Etsy, Inc.</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Policies</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Investors</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Careers</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Press</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Impact</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                    <h3 class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">Help
    </h3>
                                    <button type="button" class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark" data-wt-content-toggle="" aria-controls="footer-extra-links-help" aria-expanded="false" data-keep-open="">
                                        <span class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">Help
        </span>
                                        <span class="wt-content-toggle--btn__icon"></span>
                                    </button>
                                    <div id="footer-extra-links-help" class="wt-content-toggle__body" aria-hidden="false" data-keep-open="">
                                        <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" href="https://oemparts.net/">
                                                    <span>Help Center</span>
                                                </a>
                                            </li>
                                            <li class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline" data-gdpr-privacy-settings-trigger="" href="https://oemparts.net/">
                                                    <span>Privacy settings</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="wt-width-full">
                                        <div class="wt-text-center-xs wt-text-left-md wt-mt-xs-2">
                                            <ul class="wt-list-inline wt-mt-xs-3 wt-mb-sm-0 wt-pl-xs-0 wt-pr-xs-0 wt-pl-sm-0 wt-pr-sm-0">
                                                <li class="wt-list-inline__item">
                                                    <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1" href="https://oemparts.net/" rel="nofollow" target="_blank">
                                                        <span class="etsy-icon wt-icon--larger-xs wt-icon--base-md">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                <path d="M12,5.447c2.136,0,2.389,0.008,3.233,0.047c0.78,0.036,1.204,0.166,1.485,0.275c0.373,0.145,0.64,0.318,0.92,0.598 c0.28,0.28,0.453,0.546,0.598,0.92c0.11,0.282,0.24,0.706,0.275,1.485c0.038,0.844,0.047,1.097,0.047,3.233 s-0.008,2.389-0.047,3.233c-0.036,0.78-0.166,1.204-0.275,1.485c-0.145,0.373-0.318,0.64-0.598,0.92 c-0.28,0.28-0.546,0.453-0.92,0.598c-0.282,0.11-0.706,0.24-1.485,0.275c-0.843,0.038-1.096,0.047-3.233,0.047 s-2.389-0.008-3.233-0.047c-0.78-0.036-1.204-0.166-1.485-0.275c-0.373-0.145-0.64-0.318-0.92-0.598 c-0.28-0.28-0.453-0.546-0.598-0.92c-0.11-0.282-0.24-0.706-0.275-1.485c-0.038-0.844-0.047-1.097-0.047-3.233 S5.45,9.616,5.488,8.773c0.036-0.78,0.166-1.204,0.275-1.485c0.145-0.373,0.318-0.64,0.598-0.92c0.28-0.28,0.546-0.453,0.92-0.598 c0.282-0.11,0.706-0.24,1.485-0.275C9.611,5.455,9.864,5.447,12,5.447 M12,4.005c-2.173,0-2.445,0.009-3.298,0.048 C7.85,4.092,7.269,4.227,6.76,4.425C6.234,4.63,5.787,4.903,5.343,5.348C4.898,5.793,4.624,6.239,4.42,6.765 c-0.198,0.509-0.333,1.09-0.372,1.942C4.009,9.56,4,9.833,4,12.005c0,2.173,0.009,2.445,0.048,3.298 c0.039,0.852,0.174,1.433,0.372,1.942c0.204,0.526,0.478,0.972,0.923,1.417c0.445,0.445,0.891,0.718,1.417,0.923 c0.509,0.198,1.09,0.333,1.942,0.372c0.853,0.039,1.126,0.048,3.298,0.048s2.445-0.009,3.298-0.048 c0.852-0.039,1.433-0.174,1.942-0.372c0.526-0.204,0.972-0.478,1.417-0.923c0.445-0.445,0.718-0.891,0.923-1.417 c0.198-0.509,0.333-1.09,0.372-1.942C19.991,14.45,20,14.178,20,12.005s-0.009-2.445-0.048-3.298 c-0.039-0.852-0.174-1.433-0.372-1.942c-0.204-0.526-0.478-0.972-0.923-1.417c-0.445-0.445-0.891-0.718-1.417-0.923 c-0.509-0.198-1.09-0.333-1.942-0.372C14.445,4.014,14.173,4.005,12,4.005L12,4.005z"></path>
                                                                <path d="M12,7.897c-2.269,0-4.108,1.839-4.108,4.108S9.731,16.113,12,16.113s4.108-1.839,4.108-4.108S14.269,7.897,12,7.897z  M12,14.672c-1.473,0-2.667-1.194-2.667-2.667S10.527,9.339,12,9.339s2.667,1.194,2.667,2.667S13.473,14.672,12,14.672z"></path>
                                                                <circle cx="16.27" cy="7.735" r="0.96"></circle>
                                                            </svg>
                                                        </span>
                                                        <span class="wt-screen-reader-only">Instagram</span>
                                                    </a>
                                                </li>
                                                <li class="wt-list-inline__item">
                                                    <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1" href="https://oemparts.net/" rel="nofollow" target="_blank">
                                                        <span class="etsy-icon wt-icon--larger-xs wt-icon--base-md">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                <path d="M20,5V19a1.007,1.007,0,0,1-1,1H15V13.776h2l0.336-2.3H15V9.659a0.912,0.912,0,0,1,1-1.031h1.5V6.55a11.284,11.284,0,0,0-1.641-.109c-2.2,0-3.3,1.219-3.3,3.039v1.992h-2v2.3h2V20H5a1.007,1.007,0,0,1-1-1V5A1.007,1.007,0,0,1,5,4H19A1.007,1.007,0,0,1,20,5Z"></path>
                                                            </svg>
                                                        </span>
                                                        <span class="wt-screen-reader-only">Facebook</span>
                                                    </a>
                                                </li>
                                                <li class="wt-list-inline__item">
                                                    <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1" href="https://oemparts.net/" rel="nofollow" target="_blank">
                                                        <span class="etsy-icon wt-icon--larger-xs wt-icon--base-md">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                <path d="M12 3c-4.97 0-9 4.03-9 9 0 3.813 2.372 7.072 5.72 8.384-.08-.712-.15-1.807.03-2.585.164-.703 1.056-4.475 1.056-4.475s-.27-.54-.27-1.336c0-1.252.726-2.187 1.63-2.187.768 0 1.14.577 1.14 1.268 0 .773-.493 1.928-.746 2.998-.212.896.45 1.626 1.333 1.626 1.6 0 2.83-1.687 2.83-4.12 0-2.156-1.55-3.663-3.76-3.663-2.56 0-4.064 1.922-4.064 3.907 0 .773.297 1.603.67 2.054.073.09.083.168.06.26-.067.283-.22.895-.25 1.02-.038.165-.13.2-.3.12-1.124-.523-1.827-2.167-1.827-3.487 0-2.84 2.063-5.446 5.947-5.446 3.122 0 5.548 2.225 5.548 5.198 0 3.102-1.956 5.598-4.67 5.598-.912 0-1.77-.474-2.063-1.033l-.56 2.14c-.204.78-.753 1.76-1.12 2.358.842.26 1.737.402 2.665.402 4.97 0 9-4.03 9-9s-4.03-9-9-9"></path>
                                                            </svg>
                                                        </span>
                                                        <span class="wt-screen-reader-only">Pinterest</span>
                                                    </a>
                                                </li>
                                                <li class="wt-list-inline__item">
                                                    <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1" href="https://oemparts.net/" rel="nofollow" target="_blank">
                                                        <span class="etsy-icon wt-icon--larger-xs wt-icon--base-md">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                                <path d="M20,12c0,5.664,0,5.664-8,5.664s-8,0-8-5.664,0-5.664,8-5.664S20,6.333,20,12Zm-5,0L10,9v6Z"></path>
                                                            </svg>
                                                        </span>
                                                        <span class="wt-screen-reader-only">Youtube</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <div class="chrome-footer__app-link" data-footer-app-link="">
                        <a href="https://oemparts.net/" class="chrome-footer__app-link__logo" aria-label="Download the Alexistogel App">
                            <span class="wt-icon wt-icon--largest">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 24" aria-hidden="true" focusable="false">
                                    <path d="M42.973 23.998C45.006 23.998 46.673 23.321 47.768 22.045 48.89 20.716 49.254 19.386 49.254 16.675V7.739C49.254 7.008 49.254 6.2 49.306 5.627 49.332 5.13 48.889 5.027 48.497 5.184 47.377 5.627 46.412 5.861 45.11 6.148 44.797 6.226 44.667 6.435 44.667 6.67S44.826 7.166 45.32 7.14C46.492 7.088 46.804 7.323 46.804 8.18V13.941C46.621 15.504 45.32 16.833 43.678 16.833 42.192 16.833 41.332 15.843 41.332 13.81V7.738C41.332 7.008 41.358 6.2 41.384 5.627 41.41 5.13 40.994 5.027 40.575 5.184 39.48 5.601 38.568 5.861 37.343 6.148 37.004 6.226 36.873 6.435 36.873 6.67S37.03 7.166 37.525 7.14C38.592 7.088 38.879 7.323 38.879 8.18V14.254C38.879 17.094 40.52 18.37 42.969 18.37 44.482 18.37 46.072 17.51 46.802 15.92V18.033C46.801 19.699 46.462 20.768 45.785 21.576 45.082 22.411 44.17 22.88 42.997 22.88 41.615 22.879 40.86 22.383 40.86 21.654 40.86 21.42 40.938 21.158 40.938 20.794 40.938 20.117 40.468 19.517 39.739 19.517 38.827 19.517 38.385 20.22 38.385 21.03 38.385 22.437 39.922 24 42.97 24M31.3 18.474C34.296 18.474 36.146 16.65 36.146 14.435 36.146 10.032 29.293 11.151 29.293 8.311 29.293 7.216 30.075 6.304 31.508 6.304 32.836 6.304 33.853 6.904 34.399 8.154L34.66 8.754C34.921 9.352 35.65 9.223 35.572 8.623L35.312 6.487C35.26 6.122 35.156 5.965 34.842 5.836 33.852 5.393 32.782 5.184 31.637 5.184 28.823 5.184 27.18 6.931 27.18 9.094 27.18 13.576 34.033 12.404 34.033 15.218 34.033 16.337 33.121 17.328 31.375 17.328 29.863 17.329 28.95 16.704 28.274 15.295L27.884 14.487C27.647 13.99 26.918 14.122 27.023 14.774L27.387 17.119C27.439 17.46 27.57 17.563 27.858 17.694 28.977 18.215 29.89 18.475 31.296 18.475M22.464 18.5C24.262 18.5 25.487 17.562 25.955 15.92 26.14 15.348 25.54 15.009 25.175 15.583 24.679 16.442 23.95 16.807 23.115 16.807 22.048 16.807 21.5 16.024 21.5 14.592V6.696L24.94 6.722C25.33 6.722 25.487 6.357 25.487 6.045 25.487 5.706 25.304 5.419 24.887 5.419L21.5 5.445V3.464C21.5 3.125 21.291 2.968 21.03 2.968A.6.6 0 0 0 20.535 3.228C19.597 4.664 18.97 5.158 17.512 5.705 17.199 5.834 17.016 6.017 17.016 6.252 17.016 6.512 17.146 6.694 17.538 6.694H19.049V14.877C19.049 17.25 20.431 18.5 22.462 18.5M11.806 17.014H7.27C5.863 17.014 5.499 16.65 5.499 15.424V9.692H9.147C10.501 9.691 10.919 10.056 11.387 11.384L11.753 12.454C11.962 13.079 12.794 13.104 12.794 12.376 12.69 10.29 12.69 7.84 12.742 5.756 12.794 5.027 11.959 5.053 11.752 5.678L11.388 6.748C10.918 8.102 10.553 8.52 9.147 8.52H5.499V1.745C5.499 1.38 5.654 1.223 6.046 1.223H11.493C13.083 1.223 13.759 1.665 14.255 3.047L14.855 4.742C15.089 5.419 15.896 5.316 15.896 4.664L15.844.468C15.845.13 15.637 0 15.35 0H.599C.13 0 0 .26 0 .522 0 .782.13 1.017.573 1.069 2.398 1.2 2.71 1.565 2.71 2.633V15.715C2.71 16.705 2.398 17.043.677 17.175.261 17.226.13 17.46.13 17.722S.26 18.244.703 18.244H15.61C15.896 18.244 16.105 18.114 16.105 17.776L16.157 13.58C16.157 12.928 15.35 12.85 15.141 13.502L14.594 15.196C14.15 16.604 13.394 17.021 11.806 17.021"></path>
                                </svg>
                            </span>
                        </a>
                        <div>
                            <a href="https://etsy.app.link/d7nDUdp49V" tabindex="-1" class="wt-btn wt-btn--base-lg wt-btn--small-xs chrome-footer__app-link__button">Download the Alexistogel App</a>
                        </div>
                    </div>
                </div>
                <div class="chrome-footer__final-container">
                    <div class="chrome-footer__final">
                        <div class="chrome-footer__final-col">
                            <a id="locale-picker-trigger" class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right  wt-btn--light  wt-btn--small" aria-label="Update your settings Indonesia English (US) Rp (IDR)" href="https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026" data-aria-controls="wt-locale-picker-overlay" role="button" aria-controls="wt-locale-picker-overlay">
                                <span class="wt-display-inline-block wt-nudge-t-2 wt-vertical-align-middle">
                                    <span class="etsy-icon locale-icon-svg-default wt-display-block wt-text-white
                    wt-icon--smaller-xs wt-nudge-b-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M12,2A10,10,0,1,0,22,12,10.012,10.012,0,0,0,12,2ZM9,18.883v0.528A7.938,7.938,0,0,1,4.06,11.06l3.385,3.385a2.967,2.967,0,0,0,1.649,4.4ZM17.5,15a2.509,2.509,0,0,0,.5-0.05V15a0.992,0.992,0,0,0,.927.985A8,8,0,0,1,12,20c-0.216,0-.427-0.016-0.639-0.032l1.254-2.5-0.015.006A2.968,2.968,0,0,0,13,16a2.988,2.988,0,0,0-5-2.221V11H9a1,1,0,0,0,1-1V9a1,1,0,0,0,1-1,1,1,0,0,0,0-2H6.726A7.9,7.9,0,0,1,14,4.263V6a1,1,0,0,0,2,0V5.082a8.047,8.047,0,0,1,2,1.649V7H17a1,1,0,0,0,0,2h2.411a7.941,7.941,0,0,1,.326,1H17a2.556,2.556,0,0,0-2,2.5A2.5,2.5,0,0,0,17.5,15Z"></path>
                                        </svg>
                                    </span>
                                </span>
                                <span class="wt-display-inline-block wt-vertical-align-middle">Indonesia   |   English (US)   |   $ (IDR)</span>
                            </a>
                        </div>
                        <div class="chrome-footer__final-col">
                            <span class="chrome-footer__copyright">© 2026 Etsy, Inc.
                        </span>
                            <ul class="chrome-footer__final-links wt-list-inline">
                                <li class="wt-list-inline__item">
                                    <a href="/legal/terms-of-use?ref=ftr" class="chrome-footer__final-link">Terms of Use
                                </a>
                                </li>
                                <li class="wt-list-inline__item">
                                    <a href="/legal/privacy/?ref=ftr" class="chrome-footer__final-link">Privacy
                                </a>
                                </li>
                                <li class="wt-list-inline__item">
                                    <a href="/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services" class="chrome-footer__final-link">Interest-based ads
                                </a>
                                </li>
                                <li class="wt-list-inline__item">
                                    <a href="/search/shops" class="chrome-footer__final-link">Local Shops
                                </a>
                                </li>
                                <li class="wt-list-inline__item">
                                    <button aria-controls="country-picker" style-type="primary" class="wt-text-link chrome-footer__final-link">Regions
                                </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
        <div data-gdpr-consent-prompt="">
            <script type="text/html" data-gdpr-consent-success-alert="">
                
        <div class="wt-alert wt-alert--success-01 wt-alert--fixed-floating wt-alert--fixed-bottom wt-mb-xs-4">
            <div class="wt-display-flex-xs">
                <p class="wt-text-body-01 wt-text-left-xs">Privacy settings saved</p>
            </div>
        </div>
    
            </script>
        </div>
        <div data-dialog-content=""></div>
        <div id="wt-portals">
            <div id="wt-portal-blue" style="z-index: 80; position: relative;"></div>
            <div id="wt-portal-green" style="z-index: 80; position: relative;">
                <div id="wt-modal-container">
                    <div id="gdpr-privacy-settings" class="wt-overlay third-party-settings wt-text-left-xs" aria-labelledby="gdpr-full-settings-overlay-title" aria-hidden="true" role="dialog" data-gdpr-settings-overlay="" data-wt-overlay="">
                        <div class="wt-overlay__modal gdpr-overlay-view" data-overlay-modal="">
                            <div class="wt-overlay__header gdpr-overlay-header">
                                <h3 class="wt-text-heading" id="gdpr-full-settings-overlay-title">Privacy Settings</h3>
                            </div>
                            <div class="gdpr-overlay-body wt-pb-xl-2 wt-pb-lg-2 wt-pb-md-2 wt-pb-sm-2 wt-pb-xs-2">
                                <div>
                                    <div data-section="intro">
                                        <p class="wt-text-caption wt-mb-xs-1">Etsy uses cookies and similar technologies to give you a better experience, enabling things like:</p>
                                        <ul class="wt-text-caption wt-ml-xs-2 wt-mb-xs-2">
                                            <li>basic site functions</li>
                                            <li>ensuring secure, safe transactions</li>
                                            <li>secure account login</li>
                                            <li>remembering account, browser, and regional preferences</li>
                                            <li>remembering privacy and security settings</li>
                                            <li>analysing site traffic and usage</li>
                                            <li>personalized search, content, and recommendations</li>
                                            <li>helping sellers understand their audience</li>
                                            <li>showing relevant, targeted ads on and off Etsy</li>
                                        </ul>
                                        <p class="wt-text-caption wt-line-height-tight wt-text-link">
                                            Detailed information can be found in Etsy’s <a class="wt-text-link" href="https://www.etsy.com/legal/cookies-and-tracking-technologies">Cookies &amp;Similar Technologies Policy</a>
                                            and our <a class="wt-text-link" href="https://www.etsy.com/legal/privacy">Privacy Policy</a>
                                            .
                                        </p>
                                    </div>
                                    <div class="wt-pt-xl-6 wt-display-flex-xl wt-pt-lg-6 wt-display-flex-lg wt-pt-md-6 wt-display-flex-md wt-pt-sm-6 wt-display-flex-sm wt-pt-xs-6 wt-display-flex-xs">
                                        <div class="wt-flex-xl-5 wt-flex-lg-5 wt-flex-md-5 wt-flex-sm-5 wt-flex-xs-5">
                                            <h2 class="wt-text-title-01 wt-mb-xs-4 wt-break-word">Required Cookies &amp;Technologies</h2>
                                            <p class="wt-text-caption wt-mb-xs-2">Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.</p>
                                        </div>
                                        <div class="wt-flex-xl-1 wt-flex-lg-1 wt-flex-md-1 wt-flex-sm-1 wt-flex-xs-1">
                                            <div class="wt-display-flex-xl wt-display-flex-lg wt-display-flex-md wt-display-flex-sm wt-display-flex-xs wt-justify-content-flex-end">
                                                <span class="wt-text-caption">Always on</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wt-text-caption wt-pt-xl-6 wt-display-flex-xl wt-pt-lg-6 wt-display-flex-lg wt-pt-lg-6 wt-display-flex-lg wt-pt-md-6 wt-display-flex-md wt-pt-sm-6 wt-display-flex-sm wt-pt-xs-6 wt-display-flex-xs" data-section="third_party_consent">
                                        <div class="wt-flex-xl-5 wt-flex-lg-5 wt-flex-md-5 wt-flex-sm-5 wt-flex-xs-5">
                                            <h2 class="wt-text-title-01 wt-mb-xs-4 wt-break-word">Personalized Advertising</h2>
                                            <p class="wt-text-caption wt-mb-xs-2">To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.</p>
                                            <p class="wt-text-caption wt-mb-xs-2">
                                                Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our <a class="wt-text-link" href="https://www.etsy.com/legal/privacy/">Privacy Policy.</a>
                                                , <a class="wt-text-link" href="https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising">Help Center</a>
                                                , and <a class="wt-text-link" href="https://www.etsy.com/legal/cookies">Cookies &amp;Similar Technologies Policy</a>
                                                .
                                            </p>
                                        </div>
                                        <div class="wt-flex-xl-1 wt-flex-lg-1 wt-flex-md-1 wt-flex-sm-1 wt-flex-xs-1">
                                            <div class="wt-display-flex-xl wt-display-flex-lg wt-display-flex-md wt-display-flex-sm wt-display-flex-xs wt-justify-content-flex-end">
                                                <label for="third_party_consent" class="wt-text-caption wt-pt-xl-1 wt-pr-xl-2 wt-pt-lg-1 wt-pr-lg-2 wt-pt-md-1 wt-pr-md-2 wt-pt-sm-1 wt-pr-sm-2 wt-pt-xs-1 wt-pr-xs-2 wt-nudge-t-3" aria-hidden="true" data-gdpr-toggle-label="">On
                </label>
                                                <input class="wt-switch wt-switch--small" type="checkbox" name="third_party_consent" id="third_party_consent" checked data-gdpr-toggle="" data-checked-label="On" data-unchecked-label="Off"/>
                                                <label class="wt-switch__toggle" for="third_party_consent" aria-hidden="true"></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wt-overlay__footer wt-align-items-center">
                                <div class="wt-overlay__footer__cancel"></div>
                                <div class="wt-overlay__footer__action">
                                    <div class="wt-display-flex-xl wt-flex-direction-row-xl wt-display-flex-lg wt-flex-direction-row-lg wt-display-flex-md wt-flex-direction-row-md wt-display-flex-sm wt-flex-direction-column-sm wt-display-flex-xs wt-flex-direction-column-xs">
                                        <div class="wt-pr-xl-7 wt-pt-xl-2 wt-pr-lg-7 wt-pt-lg-2 wt-pr-md-7 wt-pt-md-2 wt-pb-sm-4 wt-pb-xs-2 wt-horizontal-center wt-display-none" data-saving-indicator="">
                                            <div class="wt-spinner wt-spinner--01 wt-display-inline-block wt-vertical-align-middle">
                                                <span class="etsy-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <circle fill="transparent" cx="12" cy="12" r="10"></circle>
                                                    </svg>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="wt-pr-xl-7 wt-pt-xl-2 wt-pr-lg-7 wt-pt-lg-2 wt-pr-md-7 wt-pt-md-2 wt-pb-sm-4 wt-pb-xs-2 wt-horizontal-center wt-display-none" data-saved-indicator="">
                                            <span class="etsy-icon wt-icon--smaller-xs">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path d="M9.057,20.471L2.293,13.707a1,1,0,0,1,1.414-1.414l5.236,5.236,11.3-13.18a1,1,0,1,1,1.518,1.3Z"></path>
                                                </svg>
                                            </span>
                                            <span class="wt-display-inline-block wt-vertical-align-middle wt-text-body-01 wt-pl-xs-1">Saved</span>
                                        </div>
                                        <div>
                                            <button data-wt-overlay-close="" class="wt-btn wt-btn--primary wt-pl-xs-8 wt-pr-xs-8 wt-pl-sm-10 wt-pr-sm-10 wt-pl-md-3 wt-pr-md-3 wt-pl-lg-3 wt-pr-lg-3 wt-pl-xl-3 wt-pr-xl-3 wt-pl-tv-3 wt-pr-tv-3">
                                                <p class="wt-pl-xs-10 wt-pr-xs-10 wt-pl-sm-10 wt-pr-sm-10 wt-pl-md-0 wt-pr-md-0 wt-pl-lg-0 wt-pr-lg-0 wt-pl-xl-0 wt-pr-xl-0 wt-pl-tv-0 wt-pr-tv-0">Done</p>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-clg-id="WtOverlay" class="wt-overlay wt-overlay--info wt-overlay--has-close-icon web-toolkit shop-policies-overlay" id="policies-overlay" aria-hidden="true" aria-modal="false" role="dialog" aria-label="Shop policies" data-wt-overlay="">
                        <div class="wt-overlay__modal" data-overlay-modal="">
                            <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light" aria-label="Close" data-wt-overlay-close="">
                                <span class="wt-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path>
                                    </svg>
                                </span>
                            </button>
                            <div class="wt-mb-xs-4">
                                <h2 class="wt-text-heading wt-mb-xs-1">Shop policies for StreamLegends</h2>
                            </div>
                            <div class="shop-structured-policies-section" id="shop-policies" data-structured="">
                                <div data-region="policy-subregions">
                                    <div data-appears-component-name="listings_page_cancellations">
                                        <div class="wt-mb-xs-4 appears-ready" data-id="cancellations">
                                            <h3 class="wt-text-title-large wt-mb-xs-1">Cancellations </h3>
                                            <div class="wt-text-caption wt-sem-text-secondary">
                                                <p>Cancellations: not accepted</p>
                                                <p>Please contact the seller if you have any problems with your order.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-appears-component-name="listings_page_structured_policies_payments">
                                        <div class="wt-mb-xs-4 appears-ready" data-id="payments">
                                            <h3 class="wt-text-title-large wt-mb-xs-1">Payments </h3>
                                            <div class="wt-pb-xs-2">
                                                <span class="etsy-icon wt-icon--smaller-xs">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path d="M17,10V7A5,5,0,0,0,7,7v3H5v8a2,2,0,0,0,2,2H17a2,2,0,0,0,2-2V10H17Zm-4,7a1,1,0,0,1-2,0V13a1,1,0,0,1,2,0v4Zm2-7H9V7a2.935,2.935,0,0,1,3-3,2.935,2.935,0,0,1,3,3v3Z"></path>
                                                    </svg>
                                                </span>
                                                Secure options
        
                                            </div>
                                            <div class="wt-pb-xs-1">
                                                <div class="wt-display-inline-block">
                                                    <span class="inline-svg svg-payment-icon svg-payment-icon-p-2 wt-mb-xs-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 33 33" aria-labelledby="paymentspaypal-paypal" role="img" focusable="false">
                                                            <g fill="none" fill-rule="evenodd">
                                                                <path d="M22.544 26.548c-.14.93-.844.93-1.524.93h-.387l.272-1.738c.016-.105.106-.183.21-.183h.178c.463 0 .9 0 1.126.266.133.16.174.396.123.723zm-.296-2.43h-2.565c-.175 0-.325.13-.352.305l-1.035 6.648c-.02.13.08.25.21.25h1.317c.124 0 .228-.09.247-.212l.293-1.885c.03-.175.178-.304.353-.304h.812c1.69 0 2.664-.827 2.92-2.465.114-.716.003-1.28-.328-1.673-.368-.434-1.015-.664-1.873-.664z" fill="#238EC2"></path>
                                                                <path d="M4.252 26.548c-.14.93-.843.93-1.523.93h-.39l.27-1.738c.018-.105.107-.183.213-.183H3c.463 0 .9 0 1.126.266.134.16.175.396.124.723zm-.296-2.43H1.392c-.176 0-.325.13-.352.305L.003 31.07c-.02.13.08.25.21.25H1.44c.176 0 .325-.13.352-.304l.28-1.793c.027-.175.177-.304.352-.304h.812c1.69 0 2.664-.827 2.92-2.465.113-.716.003-1.28-.33-1.673-.364-.434-1.01-.664-1.87-.664z" fill="#253667"></path>
                                                                <path d="M9.91 28.933c-.12.71-.676 1.185-1.386 1.185-.356 0-.64-.115-.825-.335-.183-.217-.25-.527-.194-.872.11-.7.676-1.192 1.376-1.192.35 0 .632.117.82.338.187.223.26.535.207.878zm1.71-2.417h-1.227c-.105 0-.194.078-.21.183l-.055.345-.086-.126c-.266-.39-.858-.52-1.45-.52-1.357 0-2.516 1.04-2.74 2.496-.12.727.048 1.422.456 1.907.375.446.91.63 1.546.63 1.094 0 1.7-.71 1.7-.71l-.054.346c-.02.13.08.25.21.25h1.107c.175 0 .324-.13.352-.305l.662-4.25c.02-.13-.08-.25-.212-.25z" fill="#253667"></path>
                                                                <path d="M28.2 28.933c-.117.71-.674 1.185-1.385 1.185-.356 0-.64-.115-.824-.335-.18-.217-.25-.527-.19-.872.11-.7.676-1.192 1.375-1.192.35 0 .632.117.82.338.187.223.26.535.207.878zm1.713-2.417h-1.228c-.105 0-.195.078-.21.183l-.055.345-.086-.126c-.266-.39-.86-.52-1.45-.52-1.357 0-2.516 1.04-2.742 2.496-.117.727.05 1.422.457 1.907.373.446.91.63 1.545.63 1.093 0 1.7-.71 1.7-.71l-.055.346c-.02.13.08.25.212.25h1.106c.175 0 .325-.13.352-.305l.664-4.25c.02-.13-.08-.25-.21-.25z" fill="#238EC2"></path>
                                                                <path d="M18.162 26.518h-1.234c-.118 0-.23.058-.295.157L14.93 29.21l-.72-2.436c-.046-.153-.185-.257-.343-.257h-1.213c-.147 0-.25.145-.202.285l1.36 4.033-1.282 1.823c-.1.144 0 .342.175.342h1.235c.117 0 .226-.058.293-.155l4.105-5.99c.098-.142-.003-.338-.176-.338" fill="#253667"></path>
                                                                <path d="M31.36 24.3l-1.052 6.77c-.02.13.08.25.21.25h1.06c.175 0 .324-.13.35-.304l1.042-6.648c.02-.13-.08-.25-.212-.25H31.57c-.104 0-.193.078-.21.183" fill="#238EC2"></path>
                                                                <path d="M15.008 5.497c.044-.28.22-.51.46-.625.11-.053.23-.082.358-.082h5.184c.614 0 1.186.04 1.71.126.15.024.295.052.437.084.14.032.278.067.41.107l.197.06c.257.088.497.19.717.307.26-1.673 0-2.812-.895-3.843C22.598.497 20.818.01 18.54.01h-6.614c-.466 0-.862.342-.935.807L8.24 18.47c-.054.35.212.664.56.664h4.084L15.01 5.497" fill="#253667"></path>
                                                                <path d="M24.48 5.474c.26-1.673 0-2.812-.896-3.843C22.598.497 20.818.01 18.54.01h-6.614c-.466 0-.862.342-.935.807L8.24 18.47c-.054.35.212.664.56.664h4.084l-.28 1.806c-.048.305.184.58.49.58h3.44c.408 0 .755-.3.82-.706l.032-.177.65-4.156.04-.227c.064-.407.41-.707.818-.707h.515c3.334 0 5.944-1.37 6.707-5.33.32-1.654.154-3.035-.69-4.006-.254-.295-.57-.538-.94-.736" fill="#238EC2"></path>
                                                                <path d="M24.48 5.474c.26-1.673 0-2.812-.896-3.843C22.598.497 20.818.01 18.54.01h-6.614c-.466 0-.862.342-.935.807L8.24 18.47c-.054.35.212.664.56.664h4.084l1.026-6.575-.03.204c.07-.465.464-.807.93-.807h1.94c3.81 0 6.795-1.565 7.667-6.092.026-.134.048-.264.068-.392" fill="#20274F"></path>
                                                            </g>
                                                            <title id="paymentspaypal-paypal">Paypal</title>
                                                        </svg>
                                                    </span>
                                                    <span class="inline-svg svg-payment-icon wt-p-xs-1 wt-mb-xs-1">
                                                        <svg xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" version="1.1" x="0px" y="0px" viewBox="0 0 1920.01 620.07999" xml:space="preserve" sodipodi:docname="d262c3fc767b0f2b042f1a30f2519b44.svgz" width="100%" height="100%" aria-labelledby="paymentsvisa-2-visa" role="img" focusable="false">
                                                            <defs id="defs9"></defs>
                                                            <sodipodi:namedview id="namedview7" pagecolor="#ffffff" bordercolor="#666666" borderopacity="1.0" inkscape:pageshadow="2" inkscape:pageopacity="0.0" inkscape:pagecheckerboard="0"></sodipodi:namedview>
                                                            <style type="text/css" id="style2">
                                                                .visa-svg-path {
                                                                    fill: #1434CB;
                                                                }
                                                            </style>
                                                            <path class="visa-svg-path" d="M 729,10.96 477.63,610.7 h -164 L 189.93,132.08 C 182.42,102.6 175.89,91.8 153.05,79.38 115.76,59.15 54.18,40.17 0,28.39 L 3.68,10.96 h 263.99 c 33.65,0 63.9,22.4 71.54,61.15 L 404.54,419.15 566,10.95 h 163 z m 642.58,403.93 c 0.66,-158.29 -218.88,-167.01 -217.37,-237.72 0.47,-21.52 20.96,-44.4 65.81,-50.24 22.23,-2.91 83.48,-5.13 152.95,26.84 L 1400.22,26.59 C 1362.89,13.04 1314.86,0 1255.1,0 1101.75,0 993.83,81.52 992.92,198.25 c -0.99,86.34 77.03,134.52 135.81,163.21 60.47,29.38 80.76,48.26 80.53,74.54 -0.43,40.23 -48.23,57.99 -92.9,58.69 -77.98,1.2 -123.23,-21.1 -159.3,-37.87 l -28.12,131.39 c 36.25,16.63 103.16,31.14 172.53,31.87 162.99,0 269.61,-80.51 270.11,-205.19 m 404.94,195.81 h 143.49 L 1794.76,10.96 h -132.44 c -29.78,0 -54.9,17.34 -66.02,44 L 1363.49,610.7 h 162.91 l 32.34,-89.58 h 199.05 z m -173.11,-212.5 81.66,-225.18 47,225.18 z M 950.67,10.96 822.38,610.7 H 667.24 L 795.58,10.96 Z" id="path4"></path>
                                                            <title id="paymentsvisa-2-visa">Visa</title>
                                                        </svg>
                                                    </span>
                                                    <span class="inline-svg svg-payment-icon svg-payment-icon-p-2 wt-mb-xs-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 131.39 86.9" width="100%" height="100%" aria-labelledby="paymentsmastercard-2-mastercard" role="img" focusable="false">
                                                            <defs>
                                                                <style>
                                                                    .a {
                                                                        opacity: 0;
                                                                    }

                                                                    .b {
                                                                        fill: #fff;
                                                                    }

                                                                    .c {
                                                                        fill: #ff5f00;
                                                                    }

                                                                    .d {
                                                                        fill: #eb001b;
                                                                    }

                                                                    .e {
                                                                        fill: #f79e1b;
                                                                    }
                                                                </style>
                                                            </defs>
                                                            <title id="paymentsmastercard-2-mastercard">Mastercard</title>
                                                            <g class="a">
                                                                <rect class="b" width="131.39" height="86.9"></rect>
                                                            </g>
                                                            <rect class="c" x="48.37" y="15.14" width="34.66" height="56.61"></rect>
                                                            <path class="d" d="M51.94,43.45a35.94,35.94,0,0,1,13.75-28.3,36,36,0,1,0,0,56.61A35.94,35.94,0,0,1,51.94,43.45Z"></path>
                                                            <path class="e" d="M120.5,65.76V64.6H121v-.24h-1.19v.24h.47v1.16Zm2.31,0v-1.4h-.36l-.42,1-.42-1h-.36v1.4h.26V64.7l.39.91h.27l.39-.91v1.06Z"></path>
                                                            <path class="e" d="M123.94,43.45a36,36,0,0,1-58.25,28.3,36,36,0,0,0,0-56.61,36,36,0,0,1,58.25,28.3Z"></path>
                                                        </svg>
                                                    </span>
                                                    <span class="inline-svg svg-payment-icon svg-payment-icon-pt-3 wt-mb-xs-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="100%" height="100%" viewBox="0 0 74 16" version="1.1" aria-labelledby="paymentsdiscover-2-discover" role="img" focusable="false">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <g transform="translate(0.000000, -1.000000)" fill-rule="nonzero">
                                                                    <path d="M0.405,34.334 L73.758,34.334 C75.711,34.334 77.292,32.77 77.292,30.844 L77.292,6.355 C70.252,10.757 43.71,25.944 0.405,34.334" fill="#E6792B"></path>
                                                                    <path d="M13.18,7.61 C12.646,8.087 11.96,8.29 10.863,8.29 L10.409,8.292 L10.409,2.625 L10.861,2.625 C11.957,2.625 12.618,2.819 13.179,3.318 C13.767,3.832 14.115,4.628 14.115,5.448 C14.115,6.273 13.767,7.098 13.18,7.608 L13.18,7.61 Z M11.2,1.176 L8.715,1.176 L8.715,9.746 L11.192,9.746 C12.505,9.746 13.455,9.436 14.288,8.756 C15.278,7.946 15.864,6.726 15.864,5.466 C15.864,2.936 13.948,1.176 11.204,1.176 L11.2,1.176 Z" fill="#0D1619"></path>
                                                                    <polygon fill="#0D1619" points="16.642 9.743 18.332 9.743 18.332 1.173 16.642 1.173"></polygon>
                                                                    <path d="M22.474,4.46 C21.459,4.09 21.16,3.845 21.16,3.382 C21.16,2.842 21.69,2.432 22.42,2.432 C22.93,2.432 23.346,2.639 23.79,3.124 L24.673,1.984 C23.943,1.352 23.073,1.034 22.123,1.034 C20.587,1.034 19.416,2.084 19.416,3.484 C19.416,4.669 19.962,5.271 21.549,5.834 C22.212,6.068 22.549,6.221 22.719,6.324 C23.059,6.544 23.227,6.851 23.227,7.211 C23.227,7.908 22.667,8.419 21.91,8.419 C21.105,8.419 20.454,8.023 20.063,7.279 L18.973,8.319 C19.753,9.449 20.689,9.951 21.979,9.951 C23.735,9.951 24.971,8.791 24.971,7.135 C24.971,5.775 24.401,5.157 22.471,4.46" fill="#0D1619"></path>
                                                                    <path d="M25.506,5.463 C25.506,7.983 27.512,9.935 30.089,9.935 C30.816,9.935 31.439,9.793 32.209,9.435 L32.209,7.467 C31.529,8.135 30.932,8.404 30.165,8.404 C28.46,8.404 27.248,7.184 27.248,5.448 C27.248,3.805 28.495,2.508 30.088,2.508 C30.89,2.508 31.504,2.79 32.208,3.468 L32.208,1.506 C31.466,1.136 30.854,0.983 30.125,0.983 C27.56,0.983 25.503,2.975 25.503,5.463" fill="#0D1619"></path>
                                                                    <polyline fill="#0D1619" points="45.93 6.93 43.61 1.174 41.763 1.174 45.448 9.961 46.358 9.961 50.11 1.176 48.274 1.176 45.93 6.93"></polyline>
                                                                    <polyline fill="#0D1619" points="50.876 9.743 55.68 9.743 55.68 8.29 52.57 8.29 52.57 5.977 55.562 5.977 55.562 4.527 52.57 4.527 52.57 2.627 55.68 2.627 55.68 1.174 50.876 1.174 50.876 9.742"></polyline>
                                                                    <path d="M58.982,5.118 L58.492,5.118 L58.492,2.522 L59.012,2.522 C60.067,2.522 60.64,2.96 60.64,3.792 C60.64,4.652 60.067,5.118 58.982,5.118 Z M62.38,3.704 C62.38,2.097 61.263,1.174 59.31,1.174 L56.798,1.174 L56.798,9.744 L58.491,9.744 L58.491,6.3 L58.714,6.3 L61.056,9.743 L63.138,9.743 L60.4,6.133 C61.678,5.876 62.38,5.015 62.38,3.703 L62.38,3.704 Z" fill="#0D1619"></path>
                                                                    <path d="M63.256,1.916 L63.222,1.916 L63.222,1.72 L63.258,1.72 C63.346,1.72 63.393,1.752 63.393,1.817 C63.393,1.881 63.343,1.917 63.256,1.917 L63.256,1.916 Z M63.576,1.813 C63.576,1.663 63.473,1.58 63.286,1.58 L63.042,1.58 L63.042,2.336 L63.222,2.336 L63.222,2.043 L63.437,2.336 L63.664,2.336 L63.408,2.026 C63.516,1.996 63.576,1.918 63.576,1.813 Z" fill="#1B1A18"></path>
                                                                    <path d="M63.322,2.498 C63.027,2.498 62.788,2.258 62.788,1.958 C62.788,1.658 63.025,1.418 63.322,1.418 C63.612,1.418 63.848,1.661 63.848,1.958 C63.848,2.255 63.613,2.498 63.322,2.498 Z M63.322,1.298 C62.952,1.298 62.657,1.59 62.657,1.956 C62.657,2.322 62.953,2.616 63.322,2.616 C63.686,2.616 63.982,2.32 63.982,1.956 C63.982,1.594 63.686,1.296 63.322,1.296 L63.322,1.298 Z" fill="#1B1A18"></path>
                                                                    <path d="M37.481,1.016 C34.926,1.016 32.853,2.986 32.853,5.418 C32.853,8.004 34.836,9.936 37.481,9.936 C40.061,9.936 42.099,7.978 42.099,5.469 C42.099,2.974 40.074,1.014 37.481,1.014" fill="#E6792B"></path>
                                                                </g>
                                                            </g>
                                                            <title id="paymentsdiscover-2-discover">Discover</title>
                                                        </svg>
                                                    </span>
                                                    <span class="inline-svg svg-payment-icon wt-p-xs-1 wt-display-none wt-mb-xs-1" data-apple-pay-icon="">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 50 25" aria-labelledby="paymentsapplepay-apple-pay" role="img" focusable="false">
                                                            <title id="paymentsapplepay-apple-pay">Apple Pay</title>
                                                            <path d="M47.962 6.717l-2.802 7.62c-.175.46-.34.924-.488 1.376-.072.225-.14.438-.208.64h-.053c-.066-.21-.137-.432-.214-.664-.146-.448-.302-.887-.462-1.305l-2.997-7.668h-1.603l4.288 11.024c.112.266.128.387.128.437 0 .015-.005.105-.13.44-.268.66-.576 1.23-.91 1.69-.344.47-.658.85-.94 1.13-.324.325-.66.592-1.003.794-.35.207-.667.374-.948.5l-.163.072.52 1.27.167-.062c.136-.05.39-.168.778-.357.39-.192.824-.498 1.286-.91.397-.347.76-.758 1.082-1.22.317-.454.634-.987.945-1.58.307-.59.614-1.264.914-2 .3-.74.62-1.568.954-2.457l3.463-8.77h-1.605zm-11.72 8.095c0 .16-.038.38-.11.644-.093.274-.228.545-.404.804-.175.256-.395.49-.655.697-.26.205-.568.37-.92.49-.35.123-.755.184-1.203.184-.27 0-.536-.045-.79-.133-.252-.09-.475-.223-.666-.4-.19-.174-.348-.4-.468-.675-.118-.273-.178-.61-.178-1.004 0-.644.173-1.166.513-1.548.352-.397.803-.702 1.34-.907.547-.21 1.156-.35 1.81-.413.53-.05 1.05-.076 1.543-.076h.19v2.338zm1.526 2.343c-.016-.465-.023-.933-.023-1.398v-4.574c0-.542-.055-1.095-.162-1.644-.11-.562-.32-1.077-.622-1.53-.305-.46-.732-.838-1.266-1.126-.536-.287-1.23-.433-2.067-.433-.61 0-1.208.08-1.77.237-.57.16-1.125.424-1.66.79l-.12.083.507 1.187.184-.124c.388-.26.823-.47 1.3-.618.475-.146.958-.22 1.44-.22.627 0 1.127.112 1.483.337.363.226.636.506.812.833.184.338.304.697.357 1.07.055.39.083.737.083 1.035v.133c-2.227-.01-3.965.36-5.12 1.104-1.21.78-1.826 1.89-1.826 3.3 0 .406.073.816.216 1.22.145.41.366.774.655 1.087.29.317.665.575 1.114.767.448.196.973.295 1.56.295.467 0 .903-.06 1.3-.176.393-.12.75-.276 1.06-.47.31-.193.584-.41.818-.643.107-.104.197-.21.286-.315h.058l.14 1.335h1.446l-.04-.215c-.077-.425-.125-.87-.142-1.327zM26.145 9.59c-.77.647-1.863.975-3.248.975-.38 0-.74-.016-1.07-.047-.275-.027-.528-.07-.756-.127V3.397c.2-.037.445-.07.733-.103.366-.04.807-.06 1.312-.06.625 0 1.203.076 1.716.224.51.146.953.364 1.32.646.36.28.644.643.84 1.08.2.444.298.973.298 1.57 0 1.246-.385 2.2-1.143 2.838zm1.38-6.282c-.47-.453-1.075-.805-1.798-1.047-.718-.237-1.58-.358-2.563-.358-.68 0-1.313.033-1.885.098-.565.064-1.09.138-1.56.22l-.15.025v16.452h1.5v-6.93c.507.086 1.086.132 1.724.132.85 0 1.647-.11 2.368-.325.728-.215 1.366-.548 1.897-.99.532-.442.957-.996 1.268-1.647.307-.652.463-1.42.463-2.28 0-.714-.112-1.355-.332-1.907-.222-.553-.535-1.036-.933-1.442zm-14.99 6.867c-.02-2.34 1.91-3.466 2-3.522-1.09-1.583-2.777-1.803-3.38-1.827-1.438-.143-2.81.847-3.537.847-.73 0-1.853-.825-3.05-.8-1.567.023-3.013.912-3.82 2.315-1.626 2.834-.414 7.02 1.173 9.31.778 1.123 1.7 2.383 2.92 2.337 1.17-.045 1.61-.758 3.025-.758 1.413-.002 1.812.756 3.046.735 1.26-.027 2.06-1.146 2.83-2.274.89-1.298 1.256-2.56 1.276-2.624-.025-.014-2.452-.94-2.48-3.74zM9.862 3.31c.645-.782 1.08-1.868.962-2.95-.93.037-2.057.622-2.72 1.4-.6.69-1.12 1.797-.977 2.857 1.035.08 2.09-.527 2.736-1.308z" fill="#0A0B09" fill-rule="evenodd"></path>
                                                        </svg>
                                                    </span>
                                                    <span class="inline-svg svg-payment-icon wt-nudge-b-0 wt-b-xs-none wt-mb-xs-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 48 32" xml:space="preserve" width="100%" height="100%" aria-labelledby="paymentsklarna-5-klarna" role="img" focusable="false">
                                                            <style type="text/css">
                                                                .klarna-pink-background {
                                                                    fill: #FFB3C7;
                                                                }
                                                            </style>
                                                            <g>
                                                                <path class="klarna-pink-background" d="M45.43,32H2.57C1.15,32,0,30.85,0,29.43V2.57C0,1.15,1.15,0,2.57,0h42.86C46.85,0,48,1.15,48,2.57v26.86              C48,30.85,46.85,32,45.43,32z"></path>
                                                            </g>
                                                            <image style="overflow:visible;" width="540" height="120" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhwAAAB4CAYAAAC5BCsZAAAAAXNSR0IArs4c6QAAAERlWElmTU0A KgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACHKADAAQAAAAB AAAAeAAAAAAN206sAAAh8ElEQVR4Ae2dCbwWZdnGMcQNEBUQQURwA81yV/rcV9xJTczM9FMUM7fs QyU33EIzzSUxwlJLzaU0DE3TxAW13HfREBA0l1QQAUFQvv8l5/W855z3nHebZ5mZ+/79rnNmvZfr mXnmfpaZd6l27dqNBruAL4BLWRrlE8BRLo0koHt9dNwOvgYWJ6CvNRXi4xQgW/VIL06+E3QGrvzt gO7rwHnAxBgwBowBY8AYqJoBPfTWAOtWfWZtJ0yu7TSvZ3XB2gBPFldKwI7KsD/olICutlT0bGun 7TMGjAFjwBgwBtpiQK141z0bxfZ92iq2W82yWvO+JKkeCR+8+rDhi3ezYwwYA8aAMeCZASUcJk0Z WLbpqtO1eU61m3JjwBgwBowBYyASBizhaFkQrocmii3OL16xZWPAGDAGjAFjIKsMWMLRsmSTmFfR UmvpLXNLb7atxoAxYAwYA8ZAthiwhKNleXZrucnJFs3fsITDCbWm1BgwBowBYyA2BizhaFkivt7G WIjpT1qaty3GgDFgDBgDxkD2GLCEo2WZ6rsWPkTzN2b5MGQ2jAFjwBgwBoyB0AxYwtGyBPRdEh8y GyNzfBgyG8aAMWAMGAPGQGgGLOFoWgJ6Q8VXD8dMbNkcjqb825oxYAwYA8ZARhmwhKNpwfZgVfAh 72FE8zhMjAFjwBgwBoyBzDNgCUfTIl6b1RWabnK29rYzzabYGDAGjAFjwBiIjAFLOJoWyIZNV52u TXGq3ZQbA8aAMWAMGAMRMWAJR9PC2KzpqtO1N5xqN+XGgDFgDBgDxkBEDFjC0VgYy7C4UeOq0yV9 9CsNv5zrlARTbgwYA8aAMZAfBizhaCzrfixqDocP0fc3ZvgwZDaMAWPAGDAGjIEYGLCEo7EUtmRx ucZVp0tKNt53asGUGwPGgDFgDBgDETFgCUdjYezUuOh86RUsLHJuxQwYA8aAMWAMGAORMGAJx5KC 6Mi/bT2WyTMebZkpY8AYMAaMAWMgOAOWcCwpgk34pzkcvsQSDl9Mmx1jwBgwBoyBKBiwhGNJMezN P19cfIQtDamYGAPGgDFgDBgDuWHA10M2ZkI1UVQJhy95FUP6rLmJMWAMGAPGgDGQGwYs4WjXbitK e32PJf4Ytr7waM9MGQPGgDFgDBgDwRmwhKNdu+9RCj55eDh4qZsDxoAxYAwYA8aAZwZ8Pmg9h1aR uVU5anBFRyZz0IeoeSoZVabFGDAGjAFjwBhIDwN5TzgOoKh8/Ry9rgolG+9qwcQYMAaMAWPAGMgT A3lOOPTbKUM9F/Y9nu2ZOWPAGDAGjAFjIAoG8pxwDKIENvVYCguwdZ9He2bKGDAGjAFjwBiIhoG8 JhztKYGTPJfCc9ib5NmmmTMGjAFjwBgwBqJgIK8Jx66wv4PnEhiPvc892zRzxoAxYAwYA8ZAFAzk MeFQ78apwGfsGk65I4oSNyeMAWPAGDAGjIEADPh86AYIr6TJfdi6fck97jb+C9X6wqiJMWAMGAPG gDGQSwbylnCsQCmPBEt5Lu2bsGdfF/VMupkzBowBY8AYiIeBpeNxxYsnw7CykRdLjUY+YHFc46ot eWJAQ2ergb5gHbAm6AW6g05AyadEyednYA6YCd4B08EbYCp4C8wDJsaASwaWRfnqoC9YC/QGun5X BrpWOwCJ5oHNBbOAfpPpbTANFK5V7TNpZEC89QR9geqBPkA8dwWdgX5LS6J6QEPfhXpAvKoemAIK 3M5n2aQOBvKUcPSFp5/WwVWtp97Jifaxr1rZq+68tTl8INgObA76AVXYtcqnnDgDvAQeBY80LGu7 iTFQLwO6XnWt7gj0ir6SYiXDtYiuyf8AXav6vSZdq8+DvCXLShzWA/8Dtgcbg76gC6hVlMSpHngB TGzAy/xXQ8WkCgbylHBcCC/dquAmiUPVGvltEopMR6sMrMuevcFgoEpbrZakZHkUqfIS9gcqz0lA 31O5HTwOFoHWRNfbcODqPlPl+iegB0ylIl9+AnqAxZWeVOVx8ms0mFzlec0P18NXrdE1GtCd/3pw qFwuA2qBViI7cpDmbrmIV7F+BH4BKmkBKwGWL98FW4MVQRIiTpTACLoXFOtr4F6ga0TXqq7frMoG BKa4xe1GoNCDyWLd0hENAxowhP8LgRIOcXsHeBJ8AVoTXb8nAl0rLkR6rwdKMKOXcXioi9MH7g7E xkHY1QXhI8ZiGw9hs73jmPug/2MPsf3KcRzVqFf3syoWPfRng2LOfS3renoCqCJZDZSS/mx07c/x pQy3sU3cTQOu/dqlDR9a26WKfRugnsi/gjeAWuilfB3I9kpF+krpSGqbhja6lHFmVfaPAIopKbuV 6tG1qqT0SFDOTw5JjSipOBDoudLadVIpR7UepwbHRHAU0DBNKdmKjbXqr/S8g0sZjnFb1hMOZZcz PBR4qQtDrRjXkqeEQxXM4UAtilJ8h9qm8d5RYE1QLOp9mQ9c+vXDYoMVLCvheNWxT4p3xwp80SFq nan7Wz0Wk0ClXG3JsZWKepkq1VvLcdPQ31pPhXqUjgZTQS26kz7nNfw4FuheSquI62PAiyBpfurR NxV/zgQ9QbFswYqSvnp0lztXiVcqJMsJh3oX7gDlCsvF/lewqxaba8lDwqGHkm6op4GLskpK5/v4 dzYoDN2tw7IlHJBQQjqw7TtgAvgcVFsGaUg4NiCue2uIrVouajle99JeIE2i5O1w8DKoJWZf56iB OxwUktAtWLaEAxK+BrIs6u7+dqAAr8Lu3EC2s2R2E4IZD24FmqMRs3THuZFA3dcaxitUcCyaFDGg 4bAHwW1gB5DFeuhA4poAdgMxiu6lO8FYoOs2dtF8l/vAtUCJXMzSG+d+Dh4BewMNu6guyL0oY8yq qEv3vEDBTcHujYFsZ8Wsuv41ufE00DllQWko5WYwEah3xmQJA/349zPw3YwTcgrxXQBir1+V6A0F GtI6GjwKYhNNHNYcnB+D5WJzrow/32S/RhAeA+rhyGJiTViVS1YJ6AsFyoRXqJyKRI/UePSsRDXm S1l/wr0LqNJOW7JRXFKaAKnEyaRduwMg4WGQ1WRDDxSJGjkXgdiTDflaEPUY3A0OK2yI5L96YdSr MQKkLdkoUKhnrOqBNF0PBd8T/5/FhEPjZn8AaybOVmUKJ3PY9ZUdakeVYGAw2yaAnUvss03pY0A9 PGeBW0Dv9LlfsccLOPJUcEbFZ8R1oOrN34Hhkbh1KH7cDwZG4o+5kQADWUs4lEWOAdskwE2tKtS6 mV3ryTk/T0MoGtfvmXMeshC+WvxKNi4H54D2IKuiZENDE+qRS7PoeaC5ByMCBiEfzgVqtK0c0A8z 7YCBrHXz6OM7Ibtsn8H+DQ7KKesq9TBSoqaEwyQbDCwmjIvB8dkIp80o1HNzCchKUqXESUPCVwOf omGTK4GSN5MMMpClhEOtKL2VEkrUojsbzA/lQErtdsDvq8BRKfXf3G7JgF5zVSt595a7Mrkl1Fwx V2SqZ+qXYBr4G/Ah4vBaMMSHMbMRhoGsDKmcBn0aJw4pesVMEx1NKmdALUK1aCzZqJyzNBypcs1L spGG8qjFR012vgasVcvJVZ6zDMdbslElaWk8PAsJh1pSowKTrzkbpwN1I5tUzoBekRxW+eF2pDFg DHhkoBe29JMGLnvC9QySDevZgISsS5oTDnX7KdHQQyu0aPz2ldBOpMz+Cfh7Ssp8NneNgbwxsAcB H+EwaPVMWw+nQ4JjUp3WhEPdfZrQpKGU0PIsDlwa2omU2R+Ev5oNb2IMGAPxM6CkYDUHbh6MTv32 iElOGEhjwtGdsrkVxNAV/xl+6At4c4BJZQysyWFjgZJGE2PAGIifgdVxMem3jTZEp4ZS0vgMir/E IvUwbYWti/QesG8kfOqLog9F4ksa3NBY8GiwRhqcNR+NAWPgKwaOZkmJRxKyPErGgFWSUGY60sNA mhKOA6BVX57bNBJ69c2N8yPxJS1uHIOje6bFWfPTGDAGvmKgG0v6+mcSorlb+v0Wk5wxkIaEQ9nw heAW0COS8tEQih6en0TiTxrcWBsnR6bBUfPRGDAGSjKghEP1cT2iBmMsn0+vJw47twYGYk84+hOT vm1xKojpK356BfZJYFI5A+dxaNfKD/d25KdYmteAz71ZNUPGQPoYWB+XB9bhturwUaBjHTpcnKrP GVg94ILZZjpdvl/dzFTVq9/lDH3tzsXs6KqdKTpBPS2a7GRSOQM7cuiBlR/u7MjJaH4KaDjsNfAO UC9VIdFQRaikaC3wDbAl0Lyh2CpIXDLJAAMfE8ObYCrQtTgTzAX66mYXoLpPk6x1PcYw30GfItD8 uQmgFvk2J+1Wy4kJnqMvQuveVz2gNwxfB+8B1QPapxh1v2sISb2yG4EtwAag3t4dVORbYkw4OlEk mhtxAlDhxyQv4cxxQBemSWUMqFWj1+pCXWvTsf0ncAd4Dmg4rJz8o+EAXX/rgEFACfDWwMQYqIcB JRZ/A3cDPfTeBotAa6JeaCUem4F9GhCyEbYDPnQAC0E1shwHq2c4lKixcRsYB14A6tEoJ/c1HKA6 rD/Q/LMhQAmISY0MqADUpeQDusnaErUqHwU+fKnWxof4FcuE1WIO+7CillK18VR7fK29OnpYK0Gr 1l69x/8bm0pa1WORhKji3xmMB/X6luT5P6wyuGU5/tXIYqiFj62qiHt4BPFOw4efgHqTBX39cyT4 ANTCW73nzMOukvBq5XucUK/tWs5/EbtHAPUYJSFKtvYCapTU4o+rcw5MIjgfOmJJOA4j2FA3UbmL QC0QZbYxSswJh3oIlGSW4zfJ/aoQLwBJJRqoaiH7sSWWh3aeEg6VreoI9RJsAiqVkAmHhuuuBPUm Gs1jVRf//SDJe6dSXRoaqUb0kP4nqFR/EsfNwt5PQWfgQtTrcSiYCpLwt14dlnCUKAg9fJqLMs+r Qb2EuzxfF26sEnPCoR6hBcBl2RTrVmtmW08F1Q0713iMrTjO4uWsJhxKLjTkMBocCbYD64FVwcqg miG6UAnHTPw8CLgSzSn4HSi+Hnwsn1FlQDtx/Bce/VRy46s3uje2bvEYW2vlm4qEo5qbFk4TFbV+ twBXgc0T1ZysMn2gZlSyKnOj7QdEuoynaO/Cjh5M73myp5b2UPAy+DkIeS9hPhOih9Jj4HbwdzAJ qIcgjaIh2APBBIfOf4ruYUDzIw52aKe56nWbbyizriENX/PxbsLWseDjMj4ltfstFIl79XieBXzF ial0yjjcbi1rSnp7cQ+HZgKrRZq0jST1aaKhbuaYpQ/O6eZKMu5Suqqdw7EiPr3pwS/5+keg1l4o +T6GffbkFJfPD6sMelmOV+VYrCP08lz8uR5sDVxU2MM9x6tEYHfgS1bCkCZE+yrHwmTKSuLrxUFK vnz49mvshEz8T8a+EmQfsTa3oeQ2etFEuFCiSuZ0sCiUA2XsPsj+w8F8YFI9AxraUDLkWjSJ83+B KvlQcgOGfwTUQjepnAFVmjcDJRqHgUeBtqVdziaAezwGofkKJ4LPPNnUkFalz45BHLuKB7/+gA3d gyGfJ5dif4SHWFNrotKLxlWAd6L4YlfK69D7BOceBHx1y9XharSnDvbgmXrIlGzEkBRegx8aWjGp jIHXOOzbQN3Rap1nRTQkdFmAYB7CpnpkfcgKGKl0qHQfDw5NxIaGUWIYflMdMMZDzKk0ETrhEGnn ggciYu9ZfNkPvB+RT2lzRcMb2zt2Wj1kQ4HmUsQiatlOiMWZiP1Qr4auDzU4siR64J0FfPU0NOfu cjb4aOEr2Wjf3HiJ9a5s+1aJ7Ulu+ghlR4E5SSqtU5eG8LKURNdJR+PpMSQcap0eDd5tdCvY0nQs 7wv+E8yDbBjuTxhrOQ5F3ZdPOLZRrXo9aNS1HVPlV20Mro8/DwOHAF+Te13HU6z/MVYeLN7geflJ 7D3t2WZb5jZm52ptHZDAvnPQMSkBPUmq+ARlqgdCJZ5JxpKorhgSDgX0BjgOhO4S01jjhsCkPga2 5HSXk7d0vSjhiFE0zDM2RscC+7QY+6cA9QBkda7L74ktZB2m3o27QCwy0LEj6kX4jWMbtap/mBPV k2dSxEAsCYdc+jNQl2BI6YRxXcB9QjqRAdubO47hCvTPcmyjHvWXcfLMehRk8Fz1bMQ4Xyspqmej 6P6klNWhR3M5lNzFIK7rAV1P6iGPVeRfyMns0fESU8Ihcs4EmgAUUtbA+K/BMiGdSLFtXVMue4nU Fa/XYGOW6Th3e8wOevbtVuyp6zvL8jLBqdxDiybjfhTaCezr9WsNrbqSf6N4nCvlCel9CT1/T0hX JtTElnDMg1VNAPogMLt7YP/UwD6k1XxnHHfZQ6Rvufw3BeTciI+xtDRD0jUD4xrPzuowSoFbde/H EKPqzrcKTgX83x3bvRzaV0I/16H+pFTfkJSiLOiJLeEQp5oApAoqdGV9Oj7sCkyqY2BVDtdcGFfy V1eKE9b7JPqmJawzjepG4nQME8Jdc6d6KwbRHJK3I3CkJz6o8eFC9GxQwyMN8ghOhm5AR8NTjAmH yLkJjA7MkroE9T61yyw9cIhOzCvh0GuxLuRjlD7lQrEDnXpTJS2+Ogj/S5XP81f3ch4khl6FAs8x POCUcLh6vryDbk3OToNoCPiFNDjqw0dXF0QSvo9AiVqJIaUfxpX4LB3SiZTZ7ubQ32noVmWTFnkm LY468lMTsGOe1Jdk2EqGY5F5ETiiIRVX8jqK0zQpW4m3CQzEnHDoXeahIPSFNRgfTgYmlTHQpbLD ajrqTc7y8WGjmpwrcdIbJbblZZMewGkZ/kqiTD5LQkmGdLisB6amjCdNcDWBgZgTDhWQuqJieNiP xI/tgUl5BjqVP6TmI9L29dcYurZrJrvOE5/l/JiGGeoMp+zpS5U9Il8HuKwH0jYnSMMqJjAQe8Kh QroOXKOFgKI5Ceoe7hHQh7SYdnlNqdcrTaLhhNCTn0Px9VSOYw/FeUx2XSZgaXg7pbgsFhav5HnZ 5cMhSV6Ho0yvnYWU9TB+BUgLZ6G4clnRpG0uja4Vl3yEKuNK7Gqc3cQYcMFA2urgvNYBLco+LQWn r0pqPsfsFhH43TAEc8f7NZk6awsceryyQ90uVHd0oTQlOvM8nJSSInLqpsu5VlYPOC06d8rTknCI gadBDB/jugA/viWHTEoy4HLYQ6/apUl6pcnZhH2N4SNYCYdk6qpgwGXjcPUq/Ijh0N4xOBGDD2lK OMTXGHBDYOLUah0Lugb2I1bzMx06tha609RrsIFDLky1MRAzAy4/r74OgbePOfhmvq3fbD23q2lL ODQB7yTwSuAS+zr2fwlsbK5lQfyXTa5at2rZKOlIi7j+8aq08GB+5o8Bl29mKOFIS+9hB3zdJH/F XzritCUciuJDoPkcoWcqH4oPw4BJUwb06qqrYRX9oN62Tc1Fu6bkyCqaaIvHHHPMgF5d/cyRjRXR m5Zh7XXxdYAjHlKnNo0Jh0h+HJweAdsX4cNmEfgRkwuaLOjyexn7oT8NPUu74udKMRWM+WIMeGRA XwR2Obx6gMdY6jG1FycvV4+CLJ2b1oRDZXAluDVwYSjT1jdC7MHSWBCfsjilcTXxpW3Q+M3EtSar UPfVYcmqNG3GQKoY0JuFbzr0eBC6+zrUn4TqZVFySBKKsqIjzQmH5gmcAEK/778xPlyclQsioTie T0hPKTVqLRxbakdE2zTsk5ahn4hoM1cyxMDnxPKSw3i6oFtD6zHLvji3UcwO+vYtzQmHuNLEpKOB WtUhRRf+4SEdiMz2vxz7o1ZDrDeyZs+fAdI0i95xcZn6nDLguh44Bl77RcqtGkanRepbMLfSnnCI uIfAOcEYbDR8KYuxd/U3eut26RnUu5o4Ks87ggtBjA/17+PXLsDEGMg7A0o4FjokoSu6z3eovx7V x3HypvUoyOK5S2ckqEuIQ7OWBweMZ2VsjwU7gzkB/YjB9HSceAFs7dCZ3dGtm/pyhzaqVa0Z6RdV e5IdbwxklIFJxPVvsIHD+A5G99/ADQ5tVKt6M044s9qTIj2+N34NAOpJUoKnRt488BbQdAaVr9Yr kqwkHIuI9kdAPQwhu9i2xL5a3noQ5lk0v+bvwGXCIX4vAC+CB7QSWDpj/1rQI7AfZt4YiIWBBTjy D+Ay4VgK/Wp0vAr0NerQsioOqB5YMbQjddjvxrn7gwOBkic1pkvJQjZOBfcBJXz/BG1KFoZUCgG+ zcIw4Ord74Kdcv81oVFZd95lPATognQpGlrRhR6663I5fPgtcJ1gYcLEGEgVA3/B28WOPV4F/beA dRzbKadeSYbqo2+UOzDS/arHTgJPgDFgF9BassGudh2AftRUjf1HwJ9Bm3PrspRwEOuXmZZavSGl kHEPCOlEBLY1pOKjxdETO3eAgYFi7oTd64BaAybGgDHQlAG1el9rusnJ2tpovRN83Yn28ko13HAz 2LX8oVEeoV6oe8EvQS2jBEtz3v7gYfBjUFKylnAoyFHgnpLR+tvYHVNjwQr+TEZnScNcN3ryqg92 1KPyHU/2Cmb6sjAOHFTYYP+NAWOgCQMa31fvgw9ZHyOq+3fzYazIhh7WmkeyR9G2NC3uhLP3g+0S cFq9PJeCXwN9GbqJZDHhUDf+MWBGk0j9r2yDyfP8m43K4m14874njwotjIux18WDTWXzDwLdrCbG gDHQOgMaZpjT+u5E9/RGm3o6zgI+Gnw/wM4DYAuQRtFz6k9APcVJiqY3jAbti5VmMeFQfG+CY8Ei rQSUE7GtB1Ne5T0C99XLIY51cf8feAQcANTNl7Soy1Yx6SZdM2nlps8YyCADk4lJw56+RF/4PAdM AHs6MqrJlJqfcj1I60Rx1V9KBtuap8HumuVIzjy1+OysJhyKUV3sPy8ONsCyHoC/AmsHsB2Lyatw 5GPPzmjSlhICVTga7qi3x2MpdOgNpDHgMfA9oG0mxoAxUBkDl3OY7wn9umfvApqbMBh0BPWIGjDb gt8DNWqkM62iZ7/KxHWjST1NX02mz3LCoQvhXKDurpCirqrfAGXdeZQ3CPq6QIGru1ATuTR59Qqw F1gdVHLdK0nZCpwCHgaPgqNBml93w30TYyAIA7oHbwtiecmcDvVGPAV+AXYDqpcraTSswnF6YJ4B VAc8CA4Fy4M0i5IlHwmTnnsXgg4iy0WXs/TGIgtwRA+JiWC1gE7thG1leqcH9CGkad3kB4NVAzmh HqbjGzCT/0qCpoAZQOsaX9aN0RkoIekH1gK9QSXJCYeZGAPGQBkGfsZ+PeQ6lTnO1e4BKBZ+Aj4E xfXALNbnguWAGhWqB1QHqO7oBbIkevgP9xiQGn6DwPisJxziVBfVj8CtoD0IJSrgx4GGevImbxHw ReCSCALXeOXmDYjAHXPBGMgNA68Q6ZVgRAQRd8UHQcMueRPFrN5bn3IExsbnpfV2O8Fe5pPdEraU VY4GrsfMSpiOYtPVePGvKDwxJ4wBYyAUA5pXNymUcbP7JQP78tf3s397bPb0bTRkeWtIQ0MrIWUN jJd8PzmkU55sf4qdk8A8T/bMjDFgDMTHgIYuVA8sis+1XHikeSsa4vAtmgvzzTwlHHrQHQX+65vp ZvZ2Z/20ZtvysvpPAj0vL8FanMaAMVCSgXvZGrrHuaRjOdioIeW+geLcK08JhzhWV96J4AutBBRN Ht01oP2QpjWP468hHTDbxoAxEJyBs/Hg4eBe5M8BJRxCCNknbwmHSP4j0FyKkLIMxscAzYTOmywk 4GHg1bwFbvEaA8bAVwyox/kIoDfFTPwxoBcnQr080TePCYeKVrOkQ09g1KuXV4E8vClEmE3kHdb0 8az3m2y1FWPAGMgTA3qD8FAwO09B5zjWT/OacOi7C0PBR4ELX++knxzYh1Dmn8PwIeCTUA6YXWPA GAjOwEN4oLrY91dIgwceyAE9+/S9kRAyIa8Jh8h+CcTwsB+JH3plKI9yP0GrhaObwMQYMAbyyYC+ QKqkY0E+w/catT549q5Xi43GbstzwiEargdjG/kIsqRP5MqHHkGshzc6DhcOBtatGr4szANjIBQD f8DwkWB+KAdyYldJ3bMBYlUP1pN5TzjEu74AGqIAZLsg67JwBchreYwn9v2A5naYGAPGQD4ZuJGw 1fiYmc/wvUV9tzdLjYZeZvH1vD7gGmlY8kum6s77uHhjgOUh2Dw+gN1YTD6AI4NA6OQvFj7MD2Mg jwz8haD3BK/nMXhPMd+LHd+Nu5uxudASjiUl/Az/TlmyGPTvBVj/VlAPwhp/EfNKOv4Y1g2zbgwY AwEZ0AcCdwbq+TRJnoEPUPm75NW2qvE99mjILLdd+KWY0TyKL0kptdPTto7YkR/6UaG8ir4EewhQ b08WulYX57UgLW5joA4G3uLc/cEIEOqtijrcb3FqbPWAhvCnt/DSzQb9fs6XPSrWw9FIsC4IfeNf b6+ElK9jPO+f/VVZ/ArsAO4BaZTJOH060G/ImBgDxkD1DCzklAvBLmBi9adHcYZ6bfU7XrH9doy+ gXQycP3V7QnYGA2+FEs4Ckws+a/vchwF5jTd7H3t+1g8xrvV+Ay+gEt7gyOAHuBpELXGlDBuDfQW VHtgYgwYA7UzUBhiUa/njNrVeD1zFtY0RL4duAMsDWKTP+PQzxw6NQXdR4Kv3jyyhKMl27q41TIN LRfhwOahnYjA/uf4cC0YCM4Eb4MYRa993QS2AT8GakGsAEyMAWOgfgZ0f6nXcyswCuj+ilHU4LgG aC7eGUCJhz59EKucjWMaXklapqHwO2BqsWJLOIrZaFzWhX1L42qQpRWxqgt3pQqsL1XBMWk/5EMC OB9sATSu+xqIQTTP5LdAPRqHgOdAscRYNjH6VMyZLcfNQMjrR3MBfgq2BOeCJg801kOJ5p5dBZRo qJd8EiiWkJwV+9F8WUMqJwJxqqQuCXkcJbuDZ5srU8LhkwiftprHWs26CuEEEPoHxjbCh0tADN1x sZSdKpwLgSqcIeBOMBv4FPW6PA1OA5uBoeApEEJiKZcQsVdqM28c5SHeNyl8tc7VC3wYuBfMAz5l Icb0cNUDe1NwHNCcjTTKKJzeAzxRh/OfcK70DAIlG4S6MNcHXcFi4FJkS3MkXnFpJGHdfdAnuOam LbfFmy6C1rLPZdm3CVBS4spP+fAfMAXEKGvj1K5AN4wqoF4gadHNpMrkH+BuoIRDFU5bsjw7VTbi z4VI72TwbhXK1cjYGGi4x+X1ovtc93sMsjpO9AOu4lWML4HQ3/KRHxLdDz2Bi3h1zWkitHrylHjH JP1xRg87ta6VAPQAScssFD4P7gP3ALXi1UBtSzqxU41HV6IyUY/KBwkYUJ01BAwD6k2upLGr+ucv QCMDL4NWRY6aGANZYkDJ84ZAN4sqnQFACcjKYBlQTlR56MGhMWIlWC+AJ4EqlqnARSWOWhNjwBhI kAElG98AaoCoHlgPqB5YCXQA5UT1gJKL94CSeiUZqgeeA9NB1qU9AW4MtgPiUAm7uFODZT4QL2pU TGyA1suKJRxlKbIDUs6AbhwlG90b0I3/mh/TEegmUitcN8vchmWNxQpqLejGMjEGjIH0M6CW+iqg UA+oYaJ6oDNYE6iBoXtePZmqE7SsbR+CBcCkXTv1pitnWNSAqjn5f4sxt3vi4j78AAAAAElFTkSu QmCC" transform="matrix(0.0676 0 0 0.0676 5.75 11.9444)"></image>
                                                            <title id="paymentsklarna-5-klarna">Klarna</title>
                                                        </svg>
                                                    </span>
                                                    <span class="inline-svg svg-payment-icon wt-p-xs-1 wt-mb-xs-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 32 24" aria-labelledby="paymentsgiftcard-giftcard" role="img" focusable="false">
                                                            <path d="M29.75.143c.542 0 1.005.192 1.39.575.382.384.574.847.574 1.39v8.18H19.76c1.852-.626 3.667-1.822 5.448-3.592.122-.133.18-.284.168-.453-.01-.17-.08-.315-.214-.437l-3.04-3.04c-.122-.132-.268-.204-.436-.214-.17-.01-.32.046-.453.17-1.77 1.78-2.967 3.595-3.59 5.447V.142H29.75zM9.877 2.767l-3.04 3.04c-.132.12-.203.267-.213.436-.01.17.046.32.168.453 1.78 1.77 3.596 2.966 5.448 3.59H.286v-8.18c0-.54.192-1.004.575-1.388.385-.383.848-.575 1.39-.575h12.108V8.17c-.624-1.853-1.82-3.67-3.59-5.45-.134-.122-.285-.178-.454-.168-.168.01-.314.082-.437.215zM.287 13.57h14.07v10.144H2.25c-.542 0-1.005-.192-1.39-.575-.382-.385-.574-.848-.574-1.39v-8.18zm17.355 0h14.072v8.18c0 .542-.192 1.005-.575 1.39-.385.382-.848.574-1.39.574H17.642V13.57z" fill="#7AC142" fill-rule="evenodd"></path>
                                                            <title id="paymentsgiftcard-giftcard">Giftcard</title>
                                                        </svg>
                                                    </span>
                                                    <div class="wt-mr-xs-0 wt-mb-xs-1 wt-sem-text-secondary">Accepts Etsy Gift Cards and Etsy Credits
                </div>
                                                </div>
                                            </div>
                                            <div class="wt-sem-text-secondary wt-text-caption">Etsy keeps your payment information secure. Etsy shops never receive your credit card information.
        </div>
                                        </div>
                                    </div>
                                    <div data-appears-component-name="listings_page_structured_policies_additional_terms"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-clg-id="WtOverlay" class="wt-overlay wt-overlay--info wt-overlay--has-close-icon" id="reg-seller-details-overlay" aria-hidden="true" aria-modal="false" role="dialog" aria-label="This is an overlay with regulatory seller details" data-wt-overlay="">
                        <div class="wt-overlay__modal" data-overlay-modal="">
                            <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light" aria-label="Close" data-wt-overlay-close="">
                                <span class="wt-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path>
                                    </svg>
                                </span>
                            </button>
                            <div class="wt-overflow-y-auto" id="seller-details--inner-container">
                                <div data-clg-id="WtOverlayHeader" class="wt-overlay__header">
                                    <h2 class="wt-text-heading">Seller details </h2>
                                </div>
                                <p class="wt-mb-xs-2" id="seller-details-trader-info"></p>
                                <p class="wt-mb-xs-2" id="seller-details-compliance-info"></p>
                                <div class="wt-mb-xs-4">
                                    <h3 class="wt-text-title-large">Business registration number
                        </h3>
                                    <p id="seller-details-reg-number" class="wt-mb-xs-2 wt-mt-xs-2"></p>
                                </div>
                                <div class="wt-mb-xs-4">
                                    <h3 class="wt-text-title-large">Location
                            </h3>
                                    <p id="seller-details-addresss" class="wt-mb-xs-2 wt-mt-xs-2"></p>
                                </div>
                                <div class="wt-mb-xs-2">
                                    <p class="wt-mb-xs-2 wt-mt-xs-2">
                                        Need to get in touch with the seller? Try 
                                        <a rel="nofollow" href="https://www.etsy.com/messages/new?with_id=525012624&amp;referring_id=31714225&amp;referring_type=shop&amp;recipient_id=525012624&amp;from_action=contact-seller" class="wt-display-inline-block contact-action convo-overlay-trigger inline-overlay-trigger" role="button" data-to_username="Abel" data-to_user_id="525012624" data-to_user_display_name="StreamLegends" data-referring_type="shop" data-referring_id="31714225" data-subject="" data-message="" aria-label="messaging them">
                                            <span>messaging them</span>
                                        </a>
                                        on Etsy first.
                    
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-wt-overlay="" data-report-item-overlay="" id="report-item-overlay" class="wt-overlay" role="dialog" aria-hidden="true" aria-modal="false" aria-label="report-item-overlay-title">
                        <div class="wt-overlay__modal" data-overlay-modal="">
                            <button class="wt-btn wt-btn--icon wt-btn--tertiary wt-btn--light wt-overlay__close-icon" data-wt-overlay-close="" aria-label="Close">
                                <span class="etsy-icon wt-icon--smaller">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path>
                                    </svg>
                                </span>
                            </button>
                            <div data-report-item-form-container="" class="">
                                <div class="wt-overlay__header report-item-step">
                                    <h2 class="wt-text-heading" id="report-item-overlay-title">What’s wrong with this listing?</h2>
                                </div>
                                <div class="wt-overlay__header report-item-step wt-display-none">
                                    <h3 class="wt-text-heading" id="report-item-overlay-title-more">Add more details</h3>
                                    <h3 class="wt-text-body-01 wt-mt-xs-3">Share more specifics to help us review this item and protect our marketplace.</h3>
                                </div>
                                <form data-report-item-form="" action="/add_report.php" method="post">
                                    <div class="report-item-step">
                                        <div class="wt-select wt-mb-xs-3">
                                            <select class="wt-select__element" id="report-item-choices" data-report-item-choices="">
                                                <optgroup>
                                                    <option value="default" selected>Choose a reason…</option>
                                                    <option value="order-problem">There’s a problem with my order</option>
                                                    <option value="ip-policy">It uses my intellectual property without permission</option>
                                                    <option value="flag-item">I don’t think it meets Etsy’s policies</option>
                                                </optgroup>
                                            </select>
                                            <label for="report-item-choices" class="wt-screen-reader-only">Choose a reason…</label>
                                        </div>
                                        <div data-report-choice="order-problem" id="order-problem" class="wt-display-none" style="display: none;">
                                            <p class="wt-mb-xs-2 prose">The first thing you should do is contact the seller directly.</p>
                                            <p class="wt-mb-xs-2 ip-policy prose">If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.</p>
                                            <p class="wt-mb-xs-2 prose">
                                                <a href="/help/article/5307" target="_blank">Report a problem with an order
                    </a>
                                            </p>
                                        </div>
                                        <div data-report-choice="ip-policy" id="ip-policy" class="wt-display-none" style="display: none;">
                                            <p class="wt-mb-xs-2 prose">We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.</p>
                                            <p class="wt-mb-xs-2 prose">
                                                If you’d like to file an allegation of infringement, you’ll need to follow the process described in our <a href="/legal/ip" target="_blank">Copyright and Intellectual Property Policy</a>
                                                .
                                            </p>
                                        </div>
                                        <div data-report-choice="flag-item" id="flag-item" class="wt-display-none" style="display: none;">
                                            <div class="wt-mb-xs-2">
                                                <a href="/legal/sellers#allowed" target="_blank">Review how we define handmade, vintage and supplies
                    </a>
                                            </div>
                                            <div class="wt-mb-xs-2">
                                                <a href="/legal/prohibited" target="_blank">See a list of prohibited items and materials
                    </a>
                                            </div>
                                            <div class="wt-mb-xs-4">
                                                <a href="/legal/policy/listing-mature-content-correctly/242665462117" target="_blank">Read our mature content policy
                    </a>
                                            </div>
                                            <div data-report-reason="" class="wt-validation">
                                                <fieldset class="wt-mb-xs-4">
                                                    <legend class="wt-label wt-mb-xs-2">Tell us why you &#39;re reporting this item</legend>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="not_handmade_vintage_or_craft" type="radio" class="wt-radio" id="flag_not_handmade_vintage_or_craft" name="flag_type_mnemonic" value="LISTING_CSV_MEMBER_FLAG"/>
                                                        <label for="flag_not_handmade_vintage_or_craft">It &#39;s not handmade, vintage, or craft supplies</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="pornographic" type="radio" class="wt-radio" id="flag_pornographic" name="flag_type_mnemonic" value="OC_PORNOGRAPHY"/>
                                                        <label for="flag_pornographic">It &#39;s pornographic</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="hate_speech_or_harassment" type="radio" class="wt-radio" id="flag_hate_speech_or_harassment" name="flag_type_mnemonic" value="OC_HATE_VIOLENT_HARMFUL"/>
                                                        <label for="flag_hate_speech_or_harassment">It &#39;s hate speech or harassment</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="minor_safety" type="radio" class="wt-radio" id="flag_minor_safety" name="flag_type_mnemonic" value="LISTING_MINOR_SAFETY"/>
                                                        <label for="flag_minor_safety">It &#39;s a threat to minor safety</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="violence_or_self_harm" type="radio" class="wt-radio" id="flag_violence_or_self_harm" name="flag_type_mnemonic" value="OC_HATE_VIOLENT_HARMFUL"/>
                                                        <label for="flag_violence_or_self_harm">It promotes violence or self-harm</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="dangerous_or_hazardous" type="radio" class="wt-radio" id="flag_dangerous_or_hazardous" name="flag_type_mnemonic" value="LISTING_PROHIBITED"/>
                                                        <label for="flag_dangerous_or_hazardous">It &#39;s dangerous or hazardous</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="violates_law" type="radio" class="wt-radio" id="flag_violates_law" name="flag_type_mnemonic" value="CC_REPORTED_ILLEGAL_CONTENT"/>
                                                        <label for="flag_violates_law">It &#39;s violating a specific law or regulation</label>
                                                    </div>
                                                    <div class="wt-radio wt-mb-xs-1">
                                                        <input data-report-reason-input="" data-flag-name="violates_not_listed_policy" type="radio" class="wt-radio" id="flag_violates_not_listed_policy" name="flag_type_mnemonic" value="LISTING_PROHIBITED"/>
                                                        <label for="flag_violates_not_listed_policy">It violates a policy that &#39;s not listed here</label>
                                                    </div>
                                                    <div data-error="no-report-reason" id="no-report-reason" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">Please choose a reason</div>
                                                </fieldset>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="report-item-step wt-display-none">
                                        <div data-report-comment="" class="wt-validation" tabindex="0">
                                            <label class="wt-screen-reader-only" for="report-item-reason">Include anything else we should know about this item</label>
                                            <textarea id="report-item-reason" data-report-comment-input="" name="reason" class="wt-textarea" placeholder="Include anything else we should know about this item"></textarea>
                                            <div data-error="no-report-comment" id="no-report-comment" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                                                <span class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path>
                                                    </svg>
                                                </span>
                                                Make sure to add more details.
                
                                            </div>
                                            <div data-error="comment-min-length-illegal-content" id="comment-min-length-illegal-content" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                                                <span class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path>
                                                    </svg>
                                                </span>
                                                Add more details, including a law or regulation name (10 characters min).
                
                                            </div>
                                        </div>
                                    </div>
                                    <div data-report-bonafide="" class="wt-mt-xs-2 wt-mb-xs-2 wt-sem-text-secondary wt-display-none">By submitting this report, you confirm the information and claims in this form are accurate.
        </div>
                                    <div data-report-item-overlay-footer="" class="wt-overlay__footer wt-pt-xs-0 wt-display-none" id="overlay-footer" aria-hidden="true" style="display: none;">
                                        <input type="hidden" name="_nnc" value="3:1767581183:V5ESj1VvlBpqhn3BzQmDIkek_r-S:77246d2ecf294f0cb4fb07d08eb815f45ddf43f069c162797a9efebc1aedd4c5" class="hidden csrf"/>
                                        <input type="hidden" name="target_id" value="slot-gacor-2026"/>
                                        <input type="hidden" name="target_type" value="listing"/>
                                        <input type="hidden" name="send_report" value="true"/>
                                        <input type="hidden" name="ref" value="sc_gallery-1-12"/>
                                        <input type="hidden" name="platform" value="web"/>
                                        <input type="hidden" name="search_query" value=""/>
                                        <div class="wt-overlay__footer__cancel">
                                            <button data-report-back-button="" type="button" class="wt-btn wt-btn-transparent report-item-step wt-display-none">Go back
                </button>
                                        </div>
                                        <div class="wt-overlay__footer__action">
                                            <button data-report-next-button="" type="button" class="wt-btn wt-btn--primary report-item-step">Next
                </button>
                                            <button data-report-submit-button="" type="submit" class="wt-btn wt-btn--primary report-item-step wt-display-none">Submit report
                </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="wt-overlay image-overlay wt-justify-content-center" data-image-overlay="" data-animate-out="false" id="image-overlay" role="dialog" aria-hidden="true">
                        <div class="wt-display-flex-xs wt-justify-content-center wt-height-full image-overlay-main-image-container">
                            <button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-position-top wt-mt-xs-2 wt-mr-xs-2" data-wt-overlay-close="true" aria-label="close">
                                <span class="wt-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path>
                                    </svg>
                                </span>
                            </button>
                            <div data-overlay-main-image-container="" class="wt-position-relative wt-mr-xl-4 wt-mr-xs-2 wt-ml-xs-2 wt-flex-grow-xs-1 wt-mb-xs-4 wt-mt-xs-10">
                                <ul class="wt-list-unstyled wt-overflow-hidden image-overlay-list wt-position-relative wt-vertical-center wt-display-flex-xs wt-justify-content-center" style="padding-top: 80%;" data-image-overlay-list="" tabindex="0">
                                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="0" data-image-id="6714763093">
                                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="ALEXISTOGEL > Link Mpo Slot Gacor Hari ini Situs Slot88 Terpercaya 2026" data-overlay-modal="" data-delay-src="https://s6.imgcdn.dev/Y7rD8w.jpg" data-delay-srcset="https://s6.imgcdn.dev/Y7rD8w.jpg 1x, https://s6.imgcdn.dev/Y7rD8w.jpg 2x" data-original-image-width="2362" data-original-image-height="2362" data-index="0" data-src-zoom-image="https://s6.imgcdn.dev/Y7rD8w.jpg"/>
                                    </li>
                                    <div class="wt-z-index-1 click-to-zoom-text wt-position-absolute wt-display-none" data-click-to-zoom-toast="">
                                        <span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-text-body-01 image-overlay-image--landscape">
                                            <span class="wt-icon wt-icon--smallest">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path d="M10,2a8,8,0,1,0,8,8A8.009,8.009,0,0,0,10,2Zm0,14a6,6,0,1,1,6-6A6.007,6.007,0,0,1,10,16Z"></path>
                                                    <path d="M14,9H11V6A1,1,0,1,0,9,6V9H6a1,1,0,0,0,0,2H9v3a1,1,0,1,0,2,0V11h3A1,1,0,0,0,14,9Z"></path>
                                                    <path d="M21.707,20.293l-4-4a1,1,0,0,0-1.414,1.414l4,4A1,1,0,0,0,21.707,20.293Z"></path>
                                                </svg>
                                            </span>
                                            Click to zoom


                                        </span>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div data-toolkit-overlay="" data-wt-overlay="" aria-hidden="true" role="dialog" aria-labelledby="wt-locale-picker-overlay-title" data-overlay-transition="1" id="wt-locale-picker-overlay" class="v2-locale-picker-overlay wt-overlay">
                        <div class="wt-overlay__modal wt-text-left-xs" data-overlay-modal="">
                            <div class="wt-overlay__header">
                                <h2 class="wt-text-title-large" id="wt-locale-picker-overlay-title">Update your settings</h2>
                            </div>
                            <form method="post" action="" onsubmit="return false">
                                <input type="hidden" name="region_code" value=""/>
                                <p class="wt-mb-xs-3 wt-text-body-01">
                                    Set where you live, what language you speak, and the currency you use. <a class="wt-text-link" href="https://www.etsy.com/help/article/493" target="_blank">Learn more.</a>
                                </p>
                                <div id="locale-picker-sections-wrap">
                                <!--
                <div id="locale_picker_region_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-region_code">Region</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-region_code" name="region_code" class="wt-select__element">
                                <option value="AU" >Australia</option>
                                <option value="CA" >Canada</option>
                                <option value="FR" >France</option>
                                <option value="DE" >Germany</option>
                                <option value="GR" >Greece</option>
                                <option value="IN" >India</option>
                                <option value="IE" >Ireland</option>
                                <option value="IT" >Italy</option>
                                <option value="JP" >Japan</option>
                                <option value="NZ" >New Zealand</option>
                                <option value="PL" >Poland</option>
                                <option value="PT" >Portugal</option>
                                <option value="ES" >Spain</option>
                                <option value="NL" >The Netherlands</option>
                                <option value="GB" >United Kingdom</option>
                                <option value="US" selected="selected">United States</option>
                            <optgroup label="&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;">
                                <option value="AF" >Afghanistan</option>
                                <option value="AX" >Åland Islands</option>
                                <option value="AL" >Albania</option>
                                <option value="DZ" >Algeria</option>
                                <option value="AS" >American Samoa</option>
                                <option value="AD" >Andorra</option>
                                <option value="AO" >Angola</option>
                                <option value="AI" >Anguilla</option>
                                <option value="AG" >Antigua and Barbuda</option>
                                <option value="AR" >Argentina</option>
                                <option value="AM" >Armenia</option>
                                <option value="AW" >Aruba</option>
                                <option value="AU" >Australia</option>
                                <option value="AT" >Austria</option>
                                <option value="AZ" >Azerbaijan</option>
                                <option value="BS" >Bahamas</option>
                                <option value="BH" >Bahrain</option>
                                <option value="BD" >Bangladesh</option>
                                <option value="BB" >Barbados</option>
                                <option value="BE" >Belgium</option>
                                <option value="BZ" >Belize</option>
                                <option value="BJ" >Benin</option>
                                <option value="BM" >Bermuda</option>
                                <option value="BT" >Bhutan</option>
                                <option value="BO" >Bolivia</option>
                                <option value="BA" >Bosnia and Herzegovina</option>
                                <option value="BW" >Botswana</option>
                                <option value="BV" >Bouvet Island</option>
                                <option value="BR" >Brazil</option>
                                <option value="IO" >British Indian Ocean Territory</option>
                                <option value="VG" >British Virgin Islands</option>
                                <option value="BN" >Brunei</option>
                                <option value="BG" >Bulgaria</option>
                                <option value="BF" >Burkina Faso</option>
                                <option value="BI" >Burundi</option>
                                <option value="KH" >Cambodia</option>
                                <option value="CM" >Cameroon</option>
                                <option value="CA" >Canada</option>
                                <option value="CV" >Cape Verde</option>
                                <option value="KY" >Cayman Islands</option>
                                <option value="CF" >Central African Republic</option>
                                <option value="TD" >Chad</option>
                                <option value="CL" >Chile</option>
                                <option value="CN" >China</option>
                                <option value="CX" >Christmas Island</option>
                                <option value="CC" >Cocos (Keeling) Islands</option>
                                <option value="CO" >Colombia</option>
                                <option value="KM" >Comoros</option>
                                <option value="CG" >Congo, Republic of</option>
                                <option value="CK" >Cook Islands</option>
                                <option value="CR" >Costa Rica</option>
                                <option value="HR" >Croatia</option>
                                <option value="CW" >Curaçao</option>
                                <option value="CY" >Cyprus</option>
                                <option value="CZ" >Czech Republic</option>
                                <option value="DK" >Denmark</option>
                                <option value="DJ" >Djibouti</option>
                                <option value="DM" >Dominica</option>
                                <option value="DO" >Dominican Republic</option>
                                <option value="EC" >Ecuador</option>
                                <option value="EG" >Egypt</option>
                                <option value="SV" >El Salvador</option>
                                <option value="GQ" >Equatorial Guinea</option>
                                <option value="ER" >Eritrea</option>
                                <option value="EE" >Estonia</option>
                                <option value="ET" >Ethiopia</option>
                                <option value="FK" >Falkland Islands (Malvinas)</option>
                                <option value="FO" >Faroe Islands</option>
                                <option value="FJ" >Fiji</option>
                                <option value="FI" >Finland</option>
                                <option value="FR" >France</option>
                                <option value="GF" >French Guiana</option>
                                <option value="PF" >French Polynesia</option>
                                <option value="TF" >French Southern Territories</option>
                                <option value="GA" >Gabon</option>
                                <option value="GM" >Gambia</option>
                                <option value="GE" >Georgia</option>
                                <option value="DE" >Germany</option>
                                <option value="GH" >Ghana</option>
                                <option value="GI" >Gibraltar</option>
                                <option value="GR" >Greece</option>
                                <option value="GL" >Greenland</option>
                                <option value="GD" >Grenada</option>
                                <option value="GP" >Guadeloupe</option>
                                <option value="GU" >Guam</option>
                                <option value="GT" >Guatemala</option>
                                <option value="GG" >Guernsey</option>
                                <option value="GN" >Guinea</option>
                                <option value="GW" >Guinea-Bissau</option>
                                <option value="GY" >Guyana</option>
                                <option value="HT" >Haiti</option>
                                <option value="HM" >Heard Island and McDonald Islands</option>
                                <option value="VA" >Holy See (Vatican City State)</option>
                                <option value="HN" >Honduras</option>
                                <option value="HK" >Hong Kong</option>
                                <option value="HU" >Hungary</option>
                                <option value="IS" >Iceland</option>
                                <option value="IN" >India</option>
                                <option value="ID" >Indonesia</option>
                                <option value="IQ" >Iraq</option>
                                <option value="IE" >Ireland</option>
                                <option value="IM" >Isle of Man</option>
                                <option value="IL" >Israel</option>
                                <option value="IT" >Italy</option>
                                <option value="IC" >Ivory Coast</option>
                                <option value="JM" >Jamaica</option>
                                <option value="JP" >Japan</option>
                                <option value="JE" >Jersey</option>
                                <option value="JO" >Jordan</option>
                                <option value="KZ" >Kazakhstan</option>
                                <option value="KE" >Kenya</option>
                                <option value="KI" >Kiribati</option>
                                <option value="KV" >Kosovo</option>
                                <option value="KW" >Kuwait</option>
                                <option value="KG" >Kyrgyzstan</option>
                                <option value="LA" >Laos</option>
                                <option value="LV" >Latvia</option>
                                <option value="LB" >Lebanon</option>
                                <option value="LS" >Lesotho</option>
                                <option value="LR" >Liberia</option>
                                <option value="LY" >Libya</option>
                                <option value="LI" >Liechtenstein</option>
                                <option value="LT" >Lithuania</option>
                                <option value="LU" >Luxembourg</option>
                                <option value="MO" >Macao</option>
                                <option value="MK" >Macedonia</option>
                                <option value="MG" >Madagascar</option>
                                <option value="MW" >Malawi</option>
                                <option value="MY" >Malaysia</option>
                                <option value="MV" >Maldives</option>
                                <option value="ML" >Mali</option>
                                <option value="MT" >Malta</option>
                                <option value="MH" >Marshall Islands</option>
                                <option value="MQ" >Martinique</option>
                                <option value="MR" >Mauritania</option>
                                <option value="MU" >Mauritius</option>
                                <option value="YT" >Mayotte</option>
                                <option value="MX" >Mexico</option>
                                <option value="FM" >Micronesia, Federated States of</option>
                                <option value="MD" >Moldova</option>
                                <option value="MC" >Monaco</option>
                                <option value="MN" >Mongolia</option>
                                <option value="ME" >Montenegro</option>
                                <option value="MS" >Montserrat</option>
                                <option value="MA" >Morocco</option>
                                <option value="MZ" >Mozambique</option>
                                <option value="MM" >Myanmar (Burma)</option>
                                <option value="NA" >Namibia</option>
                                <option value="NR" >Nauru</option>
                                <option value="NP" >Nepal</option>
                                <option value="AN" >Netherlands Antilles</option>
                                <option value="NC" >New Caledonia</option>
                                <option value="NZ" >New Zealand</option>
                                <option value="NI" >Nicaragua</option>
                                <option value="NE" >Niger</option>
                                <option value="NG" >Nigeria</option>
                                <option value="NU" >Niue</option>
                                <option value="NF" >Norfolk Island</option>
                                <option value="MP" >Northern Mariana Islands</option>
                                <option value="NO" >Norway</option>
                                <option value="OM" >Oman</option>
                                <option value="PK" >Pakistan</option>
                                <option value="PW" >Palau</option>
                                <option value="PS" >Palestinian Territory, Occupied</option>
                                <option value="PA" >Panama</option>
                                <option value="PG" >Papua New Guinea</option>
                                <option value="PY" >Paraguay</option>
                                <option value="PE" >Peru</option>
                                <option value="PH" >Philippines</option>
                                <option value="PL" >Poland</option>
                                <option value="PT" >Portugal</option>
                                <option value="PR" >Puerto Rico</option>
                                <option value="QA" >Qatar</option>
                                <option value="RE" >Reunion</option>
                                <option value="RO" >Romania</option>
                                <option value="RW" >Rwanda</option>
                                <option value="SH" >Saint Helena</option>
                                <option value="KN" >Saint Kitts and Nevis</option>
                                <option value="LC" >Saint Lucia</option>
                                <option value="MF" >Saint Martin (French part)</option>
                                <option value="PM" >Saint Pierre and Miquelon</option>
                                <option value="VC" >Saint Vincent and the Grenadines</option>
                                <option value="WS" >Samoa</option>
                                <option value="SM" >San Marino</option>
                                <option value="ST" >Sao Tome and Principe</option>
                                <option value="SA" >Saudi Arabia</option>
                                <option value="SN" >Senegal</option>
                                <option value="RS" >Serbia</option>
                                <option value="SC" >Seychelles</option>
                                <option value="SL" >Sierra Leone</option>
                                <option value="SG" >Singapore</option>
                                <option value="SX" >Sint Maarten (Dutch part)</option>
                                <option value="SK" >Slovakia</option>
                                <option value="SI" >Slovenia</option>
                                <option value="SB" >Solomon Islands</option>
                                <option value="SO" >Somalia</option>
                                <option value="ZA" >South Africa</option>
                                <option value="GS" >South Georgia and the South Sandwich Islands</option>
                                <option value="KR" >South Korea</option>
                                <option value="SS" >South Sudan</option>
                                <option value="ES" >Spain</option>
                                <option value="LK" >Sri Lanka</option>
                                <option value="SD" >Sudan</option>
                                <option value="SR" >Suriname</option>
                                <option value="SJ" >Svalbard and Jan Mayen</option>
                                <option value="SZ" >Swaziland</option>
                                <option value="SE" >Sweden</option>
                                <option value="CH" >Switzerland</option>
                                <option value="TW" >Taiwan</option>
                                <option value="TJ" >Tajikistan</option>
                                <option value="TZ" >Tanzania</option>
                                <option value="TH" >Thailand</option>
                                <option value="NL" >The Netherlands</option>
                                <option value="TL" >Timor-Leste</option>
                                <option value="TG" >Togo</option>
                                <option value="TK" >Tokelau</option>
                                <option value="TO" >Tonga</option>
                                <option value="TT" >Trinidad</option>
                                <option value="TN" >Tunisia</option>
                                <option value="TR" >Türkiye</option>
                                <option value="TM" >Turkmenistan</option>
                                <option value="TC" >Turks and Caicos Islands</option>
                                <option value="TV" >Tuvalu</option>
                                <option value="UG" >Uganda</option>
                                <option value="UA" >Ukraine</option>
                                <option value="AE" >United Arab Emirates</option>
                                <option value="GB" >United Kingdom</option>
                                <option value="US" >United States</option>
                                <option value="UM" >United States Minor Outlying Islands</option>
                                <option value="UY" >Uruguay</option>
                                <option value="VI" >U.S. Virgin Islands</option>
                                <option value="UZ" >Uzbekistan</option>
                                <option value="VU" >Vanuatu</option>
                                <option value="VE" >Venezuela</option>
                                <option value="VN" >Vietnam</option>
                                <option value="WF" >Wallis and Futuna</option>
                                <option value="EH" >Western Sahara</option>
                                <option value="YE" >Yemen</option>
                                <option value="CD" >Zaire (Democratic Republic of Congo)</option>
                                <option value="ZM" >Zambia</option>
                                <option value="ZW" >Zimbabwe</option>
                            </optgroup>
                        </select>
                    </div>
                </div>
                <div id="locale_picker_language_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-language_code">Language</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-language_code" name="language_code" class="wt-select__element">
                                <option value="de" >Deutsch</option>
                                <option value="en-GB" >English (UK)</option>
                                <option value="en-IN" >English (IN)</option>
                                <option value="en-US" selected="selected">English (US)</option>
                                <option value="es" >Español</option>
                                <option value="fr" >Français</option>
                                <option value="it" >Italiano</option>
                                <option value="ja" >日本語</option>
                                <option value="nl" >Nederlands</option>
                                <option value="pl" >Polski</option>
                                <option value="pt" >Português</option>
                                <option value="ru" >Русский</option>
                        </select>
                    </div>
                </div>
                <div id="locale_picker_currency_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-currency_code">Currency</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-currency_code" name="currency_code" class="wt-select__element">
                                <option value="USD" selected="selected">$ United States Dollar (USD)</option>
                                <option value="CAD" >$ Canadian Dollar (CAD)</option>
                                <option value="EUR" >€ Euro (EUR)</option>
                                <option value="GBP" >£ British Pound (GBP)</option>
                                <option value="AUD" >$ Australian Dollar (AUD)</option>
                                <option value="JPY" >¥ Japanese Yen (JPY)</option>
                                <option value="CNY" >¥ Chinese Yuan (CNY)</option>
                                <option value="CZK" >Kč Czech Koruna (CZK)</option>
                                <option value="DKK" >kr Danish Krone (DKK)</option>
                                <option value="HKD" >$ Hong Kong Dollar (HKD)</option>
                                <option value="HUF" >Ft Hungarian Forint (HUF)</option>
                                <option value="INR" >₹ Indian Rupee (INR)</option>
                                <option value="IDR" >Rp Indonesian Rupiah (IDR)</option>
                                <option value="ILS" >₪ Israeli Shekel (ILS)</option>
                                <option value="MYR" >RM Malaysian Ringgit (MYR)</option>
                                <option value="MXN" >$ Mexican Peso (MXN)</option>
                                <option value="MAD" >DH Moroccan Dirham (MAD)</option>
                                <option value="NZD" >$ New Zealand Dollar (NZD)</option>
                                <option value="NOK" >kr Norwegian Krone (NOK)</option>
                                <option value="PHP" >₱ Philippine Peso (PHP)</option>
                                <option value="SGD" >$ Singapore Dollar (SGD)</option>
                                <option value="VND" >₫ Vietnamese Dong (VND)</option>
                                <option value="ZAR" >R South African Rand (ZAR)</option>
                                <option value="SEK" >kr Swedish Krona (SEK)</option>
                                <option value="CHF" >Swiss Franc (CHF)</option>
                                <option value="THB" >฿ Thai Baht (THB)</option>
                                <option value="TWD" >NT$ Taiwan New Dollar (TWD)</option>
                                <option value="TRY" >₺ Turkish Lira (TRY)</option>
                                <option value="PLN" >zł Polish Zloty (PLN)</option>
                                <option value="BRL" >R$ Brazilian Real (BRL)</option>
                        </select>
                    </div>
                </div>
                -->
                                </div>
                                <div class="wt-overlay__footer wt-justify-content-flex-end">
                                    <div class="wt-overlay__footer__action">
                                        <a type="button" data-wt-overlay-close="" class="wt-btn wt-btn--outline wt-mb-xs-1 wt-mb-md-0 wt-mr-md-1" name="cancel">
                                            Cancel
                        
                                            <div class="wt-spinner wt-spinner--01" role="alert" aria-live="assertive">
                                                <span class="etsy-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <circle fill="transparent" cx="12" cy="12" r="10"></circle>
                                                    </svg>
                                                </span>
                                                Loading
                        
                                            </div>
                                        </a>
                                        <button class="wt-btn wt-btn--filled" action-type="primary" type="submit" name="save" id="locale-overlay-save">
                                            Save
                        
                                            <div class="wt-spinner wt-spinner--01" role="alert" aria-live="assertive">
                                                <span class="etsy-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <circle fill="transparent" cx="12" cy="12" r="10"></circle>
                                                    </svg>
                                                </span>
                                                Loading
                        
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div data-clg-id="WtOverlay" class="wt-overlay wt-overlay--large wt-overlay--has-close-icon" id="country-picker" aria-hidden="true" aria-modal="false" role="dialog" aria-label="Regions Etsy does business in" data-wt-overlay="">
                        <div class="wt-overlay__modal" data-overlay-modal="">
                            <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light" aria-label="Close" data-wt-overlay-close="">
                                <span class="wt-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                        <path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path>
                                    </svg>
                                </span>
                            </button>
                            <div data-clg-id="WtOverlayHeader" class="wt-overlay__header">
                                <p class="wt-text-heading">Regions Etsy does business in:</p>
                            </div>
                            <div class="wt-display-flex-md wt-pt-xs-1 wt-pt-md-1 wt-text-body-01">
                                <div class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU">Australia</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT">Austria</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE">Belgium</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA">Canada</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA">Canada (French)</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK">Denmark</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI">Finland</a>
                                    </div>
                                </div>
                                <div class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR">France</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE">Germany</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK">Hong Kong</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN">India</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE">Ireland</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL">Israel</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT">Italy</a>
                                    </div>
                                </div>
                                <div class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP">Japan</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX">Mexico</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ">New Zealand</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO">Norway</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL">Poland</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT">Portugal</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                        <a href="https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG">Singapore</a>
                                    </div>
                                </div>
                                <div class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                        <a href="https://www.etsy.com/es?locale_override=EUR%7Ces%7CES">Spain</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                        <a href="https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE">Sweden</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                        <a href="https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH">Switzerland</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                        <a href="https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL">The Netherlands</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                        <a href="https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB">United Kingdom</a>
                                    </div>
                                    <div class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                        <a href="https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS">United States</a>
                                    </div>
                                </div>
                            </div>
                            <div data-clg-id="WtOverlayFooter" class="wt-overlay__footer wt-justify-content-flex-end wt-pt-xs-2 wt-pt-sm-2 wt-pb-sm-0 wt-pt-md-2 wt-height-full">
                                <div data-clg-id="WtOverlayFooterButton" class="wt-overlay__footer__action">
                                    <button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-pt-xs-0 wt-pb-xs-0 wt-mb-xs-0" data-wt-overlay-close="true">Got it

</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="wt-portal-yellow" style="z-index: 80; position: relative;"></div>
            <div id="wt-portal-orange" style="z-index: 80; position: relative;"></div>
            <div id="wt-portal-red-orange" style="z-index: 80; position: absolute; top: 0px; left: 0px; width: 100%; height: 0px;"></div>
            <div id="wt-portal-red" style="z-index: 80; position: relative;"></div>
        </div>
        <div id="etsy-modal-container" aria-hidden="true"></div>
        <div id="google-tag-manager-container" aria-hidden="true">
            <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
                window.dataLayer = [{
                    "tp_consent": "yes",
                    "Language": "en-US",
                    "Region": "US",
                    "Currency": "USD",
                    "UAID": "kePC9k86zGLotnxjXL_IhE3c4kU6",
                    "DetectedRegion": "US",
                    "uuid": 1767581183,
                    "request_start_time": 1767581183
                }];
            </script>
            <noscript>
                <iframe src="//www.googletagmanager.com/ns.html?id=GTM-KWW5SS" height="0" width="0" style="display:none;visibility:hidden"></iframe>
            </noscript>
            <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
                (function(w, d, s, l, i) {
                    w[l] = w[l] || [];
                    w[l].push({
                        'gtm.start': new Date().getTime(),
                        event: 'gtm.js'
                    });
                    var f = d.getElementsByTagName(s)[0]
                      , j = d.createElement(s)
                      , dl = l != 'dataLayer' ? '&l=' + l : '';
                    j.async = true;
                    j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
                    var n = d.querySelector('[nonce]');
                    n && j.setAttribute('nonce', n.nonce || n.getAttribute('nonce'));
                    f.parentNode.insertBefore(j, f);
                }
                )(window, document, 'script', 'dataLayer', 'GTM-KWW5SS');
            </script>
        </div>
        <script type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            window.__etsy_logging = window.__etsy_logging || {
                perf: {}
            };
            window.__etsy_logging.url = "\/\/www.etsy.com\/bcn\/beacon";
            window.__etsy_logging.defaults = {
                "ab": {
                    "xplat.runtime_config_service.ramp": ["on", "x", "b4354c"],
                    "orm_latency": ["off", "x", "091448"],
                    "fastly.cdn_experiment_framework_aa": ["on", "m", "79b68d"],
                    "neu_runtime_tracing_always_on": ["off", "x", "106c3b"],
                    "neu_runtime_tracing": ["off", "w", "6631e5"],
                    "structured_data_attributes_order_dependent": ["on", "x", "691833"],
                    "disambiguate_usd_outside_usa": ["ineligible", "e", "c8897d"],
                    "perso_engine.recs.ssq_on_web_u2l_version_internal": ["on", "x", "4a8ed2"],
                    "iat.listing_page_trust_suite_section.desktop": ["ineligible", "e", "8fca1c"],
                    "listing_tracking.ads.use_hset_hget": ["off", "x", "1d26b9"],
                    "google_tag_manager": ["on", "x", "43dc13"],
                    "site_chrome\/buyer_to_seller_navbar_signed_out": ["ineligible", "e", "0efe99"],
                    "checkout.gift_card_cta_in_search_dropdown": ["on", "x", "931866"],
                    "local_pe.q3_2024.search.browser.traffic_split": ["on", "x", "33df41"],
                    "ranking\/search.experience.xml_autosuggest_v4": ["all_xml", "x", "2b2623"],
                    "search.android.mu_trending_searches": ["ineligible", "e", "6cc594"],
                    "lingtools\/trending_searches.gcp": ["on", "x", "5cfa03"],
                    "site_chrome\/buyer_to_seller_navbar_signed_in": ["ineligible", "e", "67649b"],
                    "site_chrome\/buyer_zipcode_in_header_desktop": ["off", "x", "eb55bf"],
                    "site_chrome\/buyer_zipcode_in_header_mweb": ["ineligible", "e", "5d612c"],
                    "ltv_tactics.cd_1560_sitewide_gdpr_consent": ["off", "x", "e2b0cb"],
                    "chops.storefront.creator_affiliate_banner": ["off", "x", "0ac664"],
                    "builda_scss": ["sasquatch", "x", "96bd82"],
                    "iat.mt.de": ["ineligible", "e", "6fe2bd"],
                    "iat.mt.fr": ["ineligible", "e", "781db2"],
                    "growth_regx.lp_rating_histogram_shop_header_desktop": ["off", "x", "1c99da"],
                    "growth_regx.lp_message_seller_replace_collections_buy_box_desktop_so": ["off", "x", "9b3fad"],
                    "gcs_image_reads": ["on", "x", "b7a48f"],
                    "searchx.4q18.dwell_time_as_backend_event": ["off", "x", "d3826b"],
                    "lp_performance.move_js_inits_desktop": ["off", "x", "8f3d6d"],
                    "gift_mode.lp_bin_sheet_tiag_v2": ["on", "x", "1beeb9"],
                    "cnc.atc_from_listing_cards_ymal_mfts_desktop": ["on", "x", "58b479"],
                    "perso_custo.buyer_read_from_new_perso_tables": ["on", "x", "dffb8d"],
                    "growth_regx.lp_seller_cred_shop_desc_desktop": ["off", "x", "b5ab9a"],
                    "iat.listing_page_hide_similar_items_sash.desktop": ["ineligible", "e", "e2a169"],
                    "cow_layer\/desktop_lp_evolved_favoriting_v2": ["ineligible", "e", "2ca26f"],
                    "cnc.hide_star_seller_in_listing_page_desktop": ["off", "x", "624f4d"],
                    "growth_regx.lp_bb_trust_redesign_desktop": ["off", "x", "df41b4"],
                    "checkout.paypal_bnpl_messaging": ["off", "x", "fa859e"],
                    "perso_buyer_squad_layer\/variations_update": ["on", "x", "0e428d"],
                    "perso_custo.multiple_questions_enabled.buyer_side": ["on", "x", "82e6f7"],
                    "seo.listing_shop_faqs_machine_translation": ["off", "x", "ad47eb"],
                    "growth_regx.lp_move_shop_registration_details_desktop": ["off", "x", "307e83"],
                    "onsite_promos.superbowl_listing_page_banner": ["ineligible", "e", "2deace"],
                    "growth_regx.lp_production_partners_in_item_details": ["on", "x", "3cd0fb"],
                    "coreloc.vat_inclusive_cart_prices": ["ineligible", "e", "b53ef8"],
                    "coreloc.vat_inclusive_prices_lp_sidebar_cart_operational": ["ineligible", "e", "c814cc"],
                    "growth_regx.lp_review_photo_filter_and_sort_desktop": ["on", "x", "acff7a"],
                    "growth_regx.lp_reviews_triage_redesign_desktop": ["on", "w", "cc706b"],
                    "cnc.related_searches_placement": ["off", "x", "157607"],
                    "growth_regx.lp_new_seller_cred_foundational_desktop": ["on", "x", "bccc3b"],
                    "cnc.lp_pathways_recs_desktop": ["off", "x", "aeac01"],
                    "cnc.related_search_pathways_v4_desktop": ["on", "x", "fe3c7e"],
                    "cnc.compare_lp_collections_v3_desktop": ["on", "x", "272ab8"],
                    "collections.lp_cl_recs_mp_inspired_layout": ["off", "x", "7db0f2"],
                    "collections.lp_dont_show_target_listing": ["off", "x", "dea2ca"],
                    "ads\/takerate.lp_ads_row_expansion.desktop": ["ineligible", "e", "cad35c"],
                    "cnc.listing_card_styling_desktop": ["on", "x", "ee8580"],
                    "growth_regx.lp_non_en_inputs_cat_tags": ["on", "x", "4e0658"],
                    "fulfillment_platform.usps_pm_faster_ga_experiment.web": ["on", "x", "498eec"],
                    "fulfillment_platform.usps_pm_faster_ga_experiment.mobile": ["ineligible", "e", "20f21b"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.uk.operational": ["on", "x", "74db8e"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.uk.experiment_web": ["prod", "x", "9a5255"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.uk.experiment_mobile": ["ineligible", "e", "865516"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.germany.operational": ["off", "x", "4528ab"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.germany.experiment_web": ["off", "x", "cac266"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.germany.experiment_mobile": ["ineligible", "e", "9a29ab"],
                    "fulfillment_platform.edd_cart_caching.web": ["edd_and_arizona_cache", "x", "e313fc"],
                    "fulfillment_platform.edd_cart_caching.mobile": ["ineligible", "e", "ffb947"],
                    "fulfillment_platform.consolidated_country_to_country_ml_times.experiment_web": ["prod", "x", "2eac66"],
                    "fulfillment_platform.consolidated_country_to_country_ml_times.experiment_mobile": ["ineligible", "e", "81b585"],
                    "checkout\/paypal_smart_button_desktop": ["ineligible", "e", "07b533"],
                    "checkout\/paypal_smart_button_mweb": ["ineligible", "e", "643355"],
                    "mobile_dynamic_config.iphone.ApplePayPaymentMethods.Girocard": ["ineligible", "e", "fbb78b"],
                    "mobile_dynamic_config.iphone.ApplePayPaymentMethods.CartesBancaires": ["ineligible", "e", "47f399"],
                    "checkout\/google_pay_on_web_v2": ["on", "x", "cbf24c"],
                    "checkout\/add_jcb_cc_payment_method": ["on", "x", "ce90aa"],
                    "checkout\/bin_confidence": ["show_cc", "x", "990cfd"],
                    "checkout.klarna_us_price_bands_v2": ["on", "x", "658ea6"],
                    "checkout.klarna_uk_price_bands_v2": ["ineligible", "e", "81fc37"],
                    "checkout.klarna_au_price_bands_v2": ["ineligible", "e", "c26c1c"],
                    "checkout.klarna_ca_price_bands_v2": ["ineligible", "e", "437a0f"],
                    "local_pe.q3_2025.checkout.browser.traffic_split": ["on", "x", "891e17"],
                    "checkout.klarna_unified_pay_later": ["on", "x", "2ddc20"],
                    "checkout.etsy_bin_on_apple_pay_devices": ["on", "x", "e77719"],
                    "checkout.stripe_pay_by_bank_uk_web": ["ineligible", "e", "ee644c"],
                    "checkout.stripe_pay_by_bank_de_web": ["ineligible", "e", "ad97c2"],
                    "checkout.stripe_pay_by_bank_fr_web": ["ineligible", "e", "7d2d56"],
                    "checkout.stripe_pay_by_bank_uk_boe": ["ineligible", "e", "cd4dce"],
                    "checkout.stripe_pay_by_bank_de_boe": ["ineligible", "e", "8652f5"],
                    "checkout.stripe_pay_by_bank_fr_boe": ["ineligible", "e", "aaa7b5"],
                    "checkout\/checkout_team.klarna_pay_in_three_it": ["ineligible", "e", "2b7257"],
                    "checkout\/checkout_team.klarna_pay_in_three_fr": ["ineligible", "e", "794b60"],
                    "checkout.checkout_guest_apple_pay_bin_v2": ["off", "x", "833ff4"],
                    "considerios.global_inputs_cat_tags": ["ineligible", "e", "06a1ad"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.ups_fedex.experiment_web": ["on", "x", "6ef73d"],
                    "fulfillment_ml.ml_predicted_acceptance_scan.ups_fedex.experiment_mobile": ["ineligible", "e", "81c794"],
                    "fulfillment_ml.usps_route_predictor.web": ["on", "x", "7f6b44"],
                    "fulfillment_ml.usps_route_predictor.mobile": ["ineligible", "e", "5a1b77"],
                    "fulfillment_ml.only_display_edd_max.web": ["off", "x", "2d500c"],
                    "fulfillment_ml.only_display_edd_max.mobile": ["ineligible", "e", "07bd93"],
                    "cnc.boe_dataset_related_searches": ["on", "x", "d28934"],
                    "perso_engine.recs.ssq_on_web_u2l_version": ["on", "x", "c2a009"],
                    "perso_engine.recs.listing_page_external_query_ranker_v2": ["off", "x", "e3548f"],
                    "perso_engine.recs.listing_page_internal_query_ranker_v2_fix": ["on", "x", "e872dc"],
                    "checkout\/covid_shipping_restrictions": ["ineligible", "e", "153e2d"],
                    "ranking\/search.smu.disable_fair_pairs_in_autosuggest": ["ineligible", "e", "773c36"],
                    "loyalty.web.reduce_listing_signup_prompts_exp": ["ineligible", "e", "bf6a41"],
                    "cnc.remove_atc_mweb": ["ineligible", "e", "699ff5"],
                    "dynamic_experiments.Merch_JewelrySale25_SkinnyBanner_test_v3": ["ineligible", "e", "89c994"],
                    "dynamic_experiments.Merch_JewelrySale25_SkinnyBanner_test": ["ineligible", "e", "6ff9d7"],
                    "dynamic_experiments.Merch_DDGSkinnyBanner24_V2_test": ["ineligible", "e", "8e97c7"],
                    "dynamic_experiments.Merch_DDGSkinnyBanner24_test": ["ineligible", "e", "5a291a"],
                    "dynamic_experiments.Merch_LaborDay24_Link_test": ["ineligible", "e", "63a995"],
                    "dynamic_experiments.Merch_FDAY24_GiftTeaser_test": ["ineligible", "e", "18d6f7"],
                    "dynamic_experiments.Merch_GiftMode24_Teaser_test": ["ineligible", "e", "3ad555"],
                    "api.ab_bubbling_experiment.browser_flag.listzilla_get_listing_state": ["ineligible", "e", "f05e23"],
                    "android_image_filename_hack": ["ineligible", "e", "9c9013"],
                    "sfo_layer\/disable_sale_countdown_bucketing": ["ineligible", "e", "36c97b"],
                    "sfo_layer\/disable_sale_countdown": ["ineligible", "e", "60499e"],
                    "growth_regx.lp_seller_cred_badges_desktop": ["on", "x", "153a58"],
                    "growth_regx.lp_seller_cred_star_seller_badge_v2_desktop": ["off", "x", "41f3ca"],
                    "growth_regx.lp_seller_cred_shop_about_desktop": ["off", "x", "5f1963"],
                    "navx.fnb_gift_cards_multivariate": ["at_end", "x", "0fd1cc"],
                    "inventory_quality\/layered_quality_score.seller_behavior_risk_model_filter": ["on", "w", "7d08ee"],
                    "eu_crd_compliance.sellers": ["on", "x", "1060a1"],
                    "sfo_layer\/desktop_lp_toffers_v2": ["on", "x", "c7ef4c"],
                    "listing_process.how_its_made_properties.use_module_classifier": ["on", "x", "a5aaed"],
                    "growth_regx.lp_anchor_shop_name_to_seller_cred_desktop": ["off", "x", "dd5ef0"],
                    "growth_regx.lp_him_label_to_mys_desktop": ["off", "x", "26ff8a"],
                    "growth_regx.lp_review_photo_aesthetics_ranking_desktop": ["on", "x", "f44112"],
                    "growth_regx.lp_review_photo_aesthetics_ranking_v2_desktop": ["off", "x", "b5d4ac"],
                    "listing_tracking.include_favorite_and_atc_in_listing_interactions.web": ["off", "x", "bc80fc"],
                    "listing_tracking.include_favorite_and_atc_in_listing_interactions.ios": ["ineligible", "e", "cae43e"],
                    "listing_tracking.include_favorite_and_atc_in_listing_interactions.android": ["ineligible", "e", "d0e69d"],
                    "recs_systems.query_ranker_v2_experiment": ["on", "x", "f34e90"],
                    "recs_systems.enable_recs_tracking_delivered_events": ["on", "x", "a94bcf"],
                    "badx.ads_row_debugger": ["off", "x", "f27652"],
                    "home_web.similar_rlp": ["on", "x", "72868e"],
                    "growth_regx.lp_reviews_new_deep_dive_center_sheet_desktop": ["on", "x", "e660ee"],
                    "site_chrome\/fullstory\/use_track_event": ["ineligible", "e", "ae465c"],
                    "google_tag_manager_async": ["off", "x", "7585d0"],
                    "qualtrics_survey": ["on", "x", "c3c730"],
                    "content_moderation.report_item.desktop": ["on", "x", "4dfa1d"],
                    "coreloc.digital_download_signal_placement_expansion_desktop": ["on", "x", "70b59f"],
                    "buyers_often_buying.show_discount_prices_on_the_hp_listings": ["on", "x", "e60c20"],
                    "growth_regx.lp_sh_tenure_to_open_date": ["on", "x", "8dfce1"],
                    "prodperfect\/monthly_data_capture": ["off", "x", "137afb"],
                    "ltv_tactics.cd_1509_two_steps_login_on_nav": ["off", "x", "c7e15e"],
                    "buyer_support\/epp_promise_messaging": ["ineligible", "e", "4ebacd"],
                    "growth_regx.lp_view_shop_registration_details": ["on", "x", "fec272"],
                    "growth_regx.lp_visit_shop_in_mfts_desktop": ["on", "x", "b80cff"],
                    "ranking\/ad_delivery.ubo_obfuscated_grey_class": ["on", "x", "264198"],
                    "eu_cookie_nag": ["ineligible", "e", "f8045f"],
                    "cnc.visual_search_tags_internal": ["off", "x", "b89cdd"],
                    "ranking\/search.experience.footer_persistent_ship_to_filter": ["on", "x", "1ddf5e"],
                    "gifting.gnav_desktop_flyout": ["on", "x", "55be9d"],
                    "checkout.paypal_bnpl_messaging_boe.ios": ["ineligible", "e", "8088e2"],
                    "checkout.paypal_bnpl_messaging_boe.android": ["ineligible", "e", "a42ee3"],
                    "seller_platform_web.buyer_inquiry": ["off", "x", "ee9de4"],
                    "seller_platform_web.seller_local_time": ["ineligible", "e", "98a5ac"],
                    "seller_platform_web.item_detail_overlay": ["ineligible", "e", "cf46a1"],
                    "buyer_promise.issue_resolution.fee_avoidance_v2": ["ineligible", "e", "3a7a9c"],
                    "risk_experience.buyer_email_verification": ["ineligible", "e", "4f296d"],
                    "growth_regx.lp_shop_reviews_remove_photo_priority": ["on", "x", "318dfd"]
                },
                "user_id": null,
                "page_guid": "1013787c4f59.2cb290d6285e47edaacf.00",
                "page_guid_source": "guid-source-generated",
                "version": 1,
                "request_uuid": "EuMw1pPObQo6EVtSyTVqcmLfFy83",
                "cdn-provider": "fastly",
                "header_fingerprint": "au",
                "header_signature": "8e2cb5eb97f09508d66e3389766272d0",
                "ip_org": "Googlebot",
                "ref": "",
                "loc": "http:\/\/www.etsy.com\/listing\/slot-gacor-2026\/gaming-logo-design-service-with-username?ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=&ref=sc_gallery-1-12&pro=1&dd=1&plkey=LT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%3Aslot-gacor-2026",
                "locale_currency_code": "USD",
                "pref_language": "en-US",
                "region": "US",
                "detected_currency_code": "USD",
                "detected_language": "en-US",
                "detected_region": "US",
                "isWhiteListedMobileDevice": false,
                "isMobileRequestIgnoreCookie": false,
                "isMobileRequest": false,
                "isMobileDevice": false,
                "isMobileSupported": false,
                "isTabletSupported": false,
                "isTouch": false,
                "isEtsyApp": false,
                "isPreviewRequest": false,
                "isChromeInstantRequest": false,
                "isMozPrefetchRequest": false,
                "isTestAccount": false,
                "isSupportLogin": false,
                "isInternal": false,
                "isInWebView": false,
                "botCheck": ["da", "ua"],
                "isBot": true,
                "urlRef": "sc_gallery-1-12",
                "isSyntheticTest": false,
                "ebid": "rbXcTvaLC0sKy0Ob7KZ8XzM-UIp1DiOF",
                "event_source": "web",
                "browser_id": "kePC9k86zGLotnxjXL_IhE3c4kU6",
                "gdpr_tp": 3,
                "gdpr_p": 3,
                "transcend_strategy_consent_loaded_status": "FetchMiss",
                "transcend_strategy_initial_fetch_time_ms": null,
                "transcend_strategy_consent_reconciled_time_ms": null,
                "legacy_p": 3,
                "legacy_tp": 3,
                "cmp_tp": false,
                "cmp_p": false,
                "device_identifier": {
                    "source": "new_uaid_cookie",
                    "value": "kePC9k86zGLotnxjXL_IhE3c4kU6"
                },
                "page_time": 575,
                "load_strategy": "page_navigation"
            };
            !function(e, t) {
                var n = e.__etsy_logging
                  , o = n.url
                  , i = n.firedEvents
                  , a = n.defaults
                  , r = a.ab || {}
                  , s = n.bots.botCheck
                  , c = n.bots.isBot;
                n.mergeObject = function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)
                            Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }
                ;
                !a.ref && (a.ref = t.referrer),
                !a.loc && (a.loc = e.location.href),
                !a.webkit_page_visibility && (a.webkit_page_visibility = t.webkitVisibilityState),
                !a.event_source && (a.event_source = "web"),
                a.event_logger = "frontend",
                a.isIosApp && !0 === a.isIosApp ? a.event_source = "ios" : a.isAndroidApp && !0 === a.isAndroidApp && (a.event_source = "android"),
                s.length > 0 && (a.botCheck = a.botCheck || [],
                a.botCheck = a.botCheck.concat(s)),
                a.isBot = c,
                t.wasDiscarded && (a.was_discarded = !0);
                var v = function(t) {
                    if (e.XMLHttpRequest) {
                        var n = new XMLHttpRequest;
                        n.open("POST", o, !0),
                        n.send(JSON.stringify(t))
                    }
                };
                n.updateLoc = function(e) {
                    e !== a.loc && (a.ref = a.loc,
                    a.loc = e)
                }
                ,
                n.adminPublishEvent = function(n) {
                    "function" == typeof e.CustomEvent && t.dispatchEvent(new CustomEvent("eventpipeEvent",{
                        detail: n
                    })),
                    i.push(n)
                }
                ,
                n.preparePEPerfBeaconAbMismatchEventIfNecessary = function() {
                    if (!0 === n.shouldLogAbMismatch) {
                        var e = n.abVariantsForMismatchEvent;
                        for (var t in r)
                            if (Object.prototype.hasOwnProperty.call(r, t)) {
                                var o = r[t];
                                if (void 0 !== o) {
                                    var i = o[0];
                                    if (void 0 !== i) {
                                        var a = e[t];
                                        void 0 === a && (a = {});
                                        var s = a[i];
                                        void 0 === s && (s = []),
                                        s.push({
                                            name: "default",
                                            selector: o[1],
                                            hash: o[2]
                                        }),
                                        a[i] = s,
                                        e[t] = a
                                    }
                                }
                            }
                        n.abVariantsForMismatchEvent = e
                    }
                }
                ,
                n.sendEvents = function(t, i) {
                    var s = a;
                    if ("perf" === i) {
                        var c = {
                            event_logger: i
                        };
                        n.asyncAb && (n.preparePEPerfBeaconAbMismatchEventIfNecessary(),
                        c.ab = n.mergeObject({}, n.asyncAb, r)),
                        s = n.mergeObject({}, a, c)
                    }
                    var f = {
                        events: t,
                        shared: s
                    };
                    e.navigator && "function" == typeof e.navigator.sendBeacon ? function(t) {
                        t.events.forEach((function(e) {
                            e.attempted_send_beacon = !0
                        }
                        )),
                        e.navigator.sendBeacon(o, JSON.stringify(t)) || (t.events.forEach((function(e) {
                            e.send_beacon_failed = !0
                        }
                        )),
                        v(t))
                    }(f) : v(f),
                    n.adminPublishEvent(f)
                }
            }(window, document);
        </script>
        <script type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            window.__etsy_logging.perf.event = {
                "attributes": {
                    "guid": "1013787c5c3c.e1b1fd0af5eb4ecf349f.00",
                    "event_name": "perf",
                    "event_logger": "perf",
                    "page_type": "view_listing",
                    "ip_country_code": "US",
                    "boromir": true
                }
            };
            window.__etsy_logging.shouldLogAbMismatch = false;
            !function(e, t) {
                if (!t.hidden) {
                    var n = e.__etsy_logging || {}
                      , r = n.perf || {}
                      , i = n.url
                      , a = n.defaults
                      , o = r.event
                      , s = n.sendEvents
                      , c = 0 === Object.keys(r).length
                      , u = e.webVitals || {}
                      , d = n.mergeObject
                      , _ = r.isDev || !1
                      , m = r.skipLoggingEvent || !1
                      , l = r.keepPerfObserverActive || !1
                      , f = null
                      , p = 0;
                    if (!c && i && a && o && s) {
                        var v = r.MARK_MEASURE_PREFIX || "_etsy_mark_measure_"
                          , g = function(e) {
                            var t = !1;
                            return function() {
                                t || (t = !0,
                                e.apply(this, arguments))
                            }
                        }
                          , y = function() {
                            return void 0 !== e.PerformanceObserver
                        }
                          , h = function() {
                            return "onpagehide"in e
                        }
                          , T = function(e, n) {
                            var r = function(e) {
                                var n = t.createElement("a");
                                n.href = e;
                                var r = n.pathname.split(".");
                                return r[r.length - 1] || ""
                            }(e);
                            return /jpe?g|png|svg|gif/i.test(r) ? "image" : /eot|woff2?|ttf/i.test(r) ? "font" : "js" === r ? "js" : "css" === r ? "css" : "xmlhttprequest" === n ? "xhr" : "unknown"
                        }
                          , E = function(e) {
                            return Math.round(e < Math.pow(2, 64) - 1 ? e : 0)
                        }
                          , b = function(e, n) {
                            var r = null
                              , i = null;
                            if (n.transferSize > 0)
                                for (var a = 0; a < n.serverTiming.length; a++) {
                                    var o = n.serverTiming[a];
                                    e.i_etsystatic_cdn || "cdn" !== o.name ? "cache_status" === o.name && (i = o.description) : r = o.description
                                }
                            r && (e.i_etsystatic_cdn = r);
                            var s = null
                              , c = null;
                            i && (e.cdn_image_caching || (e.cdn_image_caching = {
                                miss: 0,
                                hit: 0
                            }),
                            s = 0 === i.indexOf("HIT"),
                            c = 0 === i.indexOf("MISS"),
                            s && (e.cdn_image_caching.hit += 1),
                            c && (e.cdn_image_caching.miss += 1)),
                            function(e, n, r, i) {
                                f || (f = {},
                                t.querySelectorAll("img[data-perf-group]").forEach((function(e) {
                                    e.currentSrc && (f[e.currentSrc] = e)
                                }
                                )));
                                var a = f[n.name];
                                if (a) {
                                    var o = a.dataset.perfGroup;
                                    e.categorized_images || (e.categorized_images = []);
                                    var s = {
                                        category: o,
                                        duration: E(n.duration),
                                        encodedBodySize: E(n.encodedBodySize),
                                        transferSize: E(n.transferSize),
                                        width: a.width,
                                        height: a.height
                                    };
                                    if (n.transferSize > 0) {
                                        (r || i) && (s.cdn_hit = r);
                                        for (var c = 0; c < n.serverTiming.length; c++) {
                                            var u = n.serverTiming[c];
                                            "clientrtt" === u.name ? s.clientrtt = E(u.duration) : "clienttt" === u.name ? s.clienttt = E(u.duration) : "cdntime" === u.name ? s.cdntime = E(u.duration) : "origin" === u.name && (s.origin = E(u.duration))
                                        }
                                    }
                                    e.categorized_images.push(s)
                                }
                            }(e, n, s, c)
                        }
                          , S = function(e) {
                            var t = e.match(/^(?:https?:\/\/)?(?:www\.)?([a-z0-9-.]*etsy(?:static)?(?:cloud)?\.com)/i);
                            return t ? t[1] : null
                        }
                          , k = function(e, t, n) {
                            t && n && (e.http_protocols = e.http_protocols || {},
                            e.http_protocols[n] = e.http_protocols[n] || [],
                            -1 === e.http_protocols[n].indexOf(t) && e.http_protocols[n].push(t))
                        }
                          , w = function(e) {
                            var t = {
                                nav_start: E(e.navigationStart || e.startTime),
                                activation_start: E(e.activationStart || 0),
                                fetch_start: E(e.fetchStart),
                                dns_start: E(e.domainLookupStart),
                                dns_end: E(e.domainLookupEnd),
                                connect_start: E(e.connectStart),
                                connect_end: E(e.connectEnd),
                                interim_response_start: E(e.firstInterimResponseStart || 0),
                                request_start: E(e.requestStart),
                                response_start: E(e.responseStart),
                                response_end: E(e.responseEnd),
                                dom_completed: E(e.domComplete),
                                dom_interactive: E(e.domInteractive),
                                secure_connect_start: E(e.secureConnectionStart) || null,
                                loaded_start: E(e.loadEventStart) || null,
                                loaded_end: E(e.loadEventEnd) || null,
                                dom_content_loaded_start: E(e.domContentLoadedEventStart) || null,
                                dom_content_loaded_end: E(e.domContentLoadedEventEnd) || null,
                                html_tx_size: E(e.transferSize),
                                html_enc_size: E(e.encodedBodySize),
                                html_dec_size: E(e.decodedBodySize),
                                type: e.type
                            };
                            return e.redirectStart && (t.redirect_start = E(e.redirectStart)),
                            e.redirectEnd && (t.redirect_end = E(e.redirectEnd)),
                            e.redirectCount && (t.redirect_count = e.redirectCount),
                            t
                        }
                          , L = function(e) {
                            return e.reduce((function(e, t) {
                                if ("entryType"in t) {
                                    if ("resource" === t.entryType)
                                        return function(e, t) {
                                            var n = T(t.name, t.initiatorType);
                                            if ("unknown" === n)
                                                return e;
                                            var r = S(t.name)
                                              , i = r ? "etsy" : "third";
                                            "image" === n && "etsy" === i && ("img0.etsystatic.com" === r ? e.img0_count = (e.img0_count || 0) + 1 : "img1.etsystatic.com" === r && (e.img1_count = (e.img1_count || 0) + 1)),
                                            k(e, t.nextHopProtocol, r),
                                            "image" === n && "etsy" === i && t.serverTiming && "i.etsystatic.com" === r && b(e, t);
                                            var a = "sum_" + i + "_" + n + "_bytes"
                                              , o = "sum_" + i + "_" + n + "_enc_bytes"
                                              , s = "sum_" + i + "_" + n + "_tx_bytes"
                                              , c = "sum_" + i + "_" + n + "_dur"
                                              , u = "count_" + i + "_" + n + "_req";
                                            return e[a] = (e[a] || 0) + E(t.decodedBodySize),
                                            e[o] = (e[o] || 0) + E(t.encodedBodySize),
                                            e[s] = (e[s] || 0) + E(t.transferSize),
                                            e[c] = (e[c] || 0) + E(t.duration),
                                            e[u] = (e[u] || 0) + 1,
                                            e
                                        }(e, t);
                                    if ("paint" === t.entryType)
                                        return function(e, t) {
                                            return e[t.name.replace(/-/g, "_")] = E(t.startTime),
                                            e
                                        }(e, t);
                                    if ("longtask" === t.entryType)
                                        return function(e, t) {
                                            return e.long_tasks_count = (e.long_tasks_count || 0) + 1,
                                            e.long_tasks_dur = (e.long_tasks_dur || 0) + E(t.duration),
                                            e
                                        }(e, t);
                                    if ("mark" === t.entryType || "measure" === t.entryType)
                                        return function(e, t) {
                                            return 0 === t.name.lastIndexOf(v, 0) && (e[0 === t.name.lastIndexOf(v + "async_spec_", 0) ? t.name.substring(v.length) : t.name] = E("mark" === t.entryType ? t.startTime : t.duration)),
                                            e
                                        }(e, t);
                                    if ("layout-shift" === t.entryType && !t.hadRecentInput)
                                        return function(e, t) {
                                            return e.layout_shift_count = (e.layout_shift_count || 0) + 1,
                                            e.layout_shift = (e.layout_shift || 0) + t.value,
                                            t.value > .05 && (e.layout_shift_elements = e.layout_shift_elements || [],
                                            e.layout_shift_elements.push({
                                                value: t.value,
                                                elements: (t.sources || []).filter((function(e) {
                                                    return !!e.node
                                                }
                                                )).map((function(e) {
                                                    return {
                                                        className: e.node.classList && Array.prototype.slice.call(e.node.classList).join(" "),
                                                        tagName: e.node.tagName,
                                                        id: e.node.id
                                                    }
                                                }
                                                ))
                                            })),
                                            e
                                        }(e, t);
                                    if ("navigation" === t.entryType)
                                        return r.t = !0,
                                        k(e, t.nextHopProtocol, S(t.name)),
                                        d(e, w(t));
                                    if ("element" === t.entryType)
                                        return function(e, t) {
                                            return e.element_timings || (e.element_timings = {}),
                                            e.element_timings[t.identifier] = t.renderTime,
                                            e
                                        }(e, t);
                                    if ("long-animation-frame" === t.entryType)
                                        return function(e, t) {
                                            e.loaf_entries || (e.loaf_entries = []);
                                            var n = {
                                                start: E(t.startTime),
                                                duration: E(t.duration),
                                                blockingDuration: E(t.blockingDuration)
                                            }
                                              , r = t.scripts.slice().sort((function(e, t) {
                                                t.duration,
                                                e.duration
                                            }
                                            ))[0];
                                            if (r) {
                                                var i = r.invoker || r.name;
                                                n.longestScript = {
                                                    invokerType: r.invokerType || r.type,
                                                    duration: E(r.duration),
                                                    invoker: i.substring(0, 1024),
                                                    sourceURL: r.sourceURL || null
                                                }
                                            }
                                            return e.loaf_entries.push(n),
                                            e
                                        }(e, t)
                                } else if ("name"in t) {
                                    if ("INP" === t.name)
                                        return function(e, t) {
                                            return e.interaction_next_paint = t.value,
                                            t.attribution && (e.interaction_next_paint_element = t.attribution.eventTarget,
                                            e.interaction_next_paint_time = E(t.attribution.eventTime),
                                            e.interaction_next_paint_type = t.attribution.eventType,
                                            e.interaction_next_paint_loadstate = t.attribution.loadState),
                                            e
                                        }(e, t);
                                    if ("LCP" === t.name)
                                        return function(e, t) {
                                            var n = t.entries[0];
                                            return e.largest_contentful_paint = E(n.renderTime || n.loadTime),
                                            e.largest_contentful_paint_type = n.renderTime ? "renderTime" : "loadTime",
                                            n.element ? (e.largest_contentful_paint_element = {
                                                className: n.element.classList && Array.prototype.slice.call(n.element.classList).join(" "),
                                                tagName: n.element.tagName,
                                                url: n.url
                                            },
                                            t.attribution.lcpResourceEntry && (e.largest_contentful_paint_element.resource_size = E(t.attribution.lcpResourceEntry.encodedBodySize))) : delete e.largest_contentful_paint_element,
                                            e.lcp_element_render_delay = E(t.attribution.elementRenderDelay),
                                            e.lcp_resource_load_delay = E(t.attribution.resourceLoadDelay),
                                            e.lcp_resource_load_time = E(t.attribution.resourceLoadTime),
                                            e
                                        }(e, t)
                                }
                                return e
                            }
                            ), {})
                        }
                          , z = function() {
                            var n, i = !y() && performance && performance.getEntries ? performance.getEntries() : r.e, a = L(i);
                            return r.e = [],
                            r.t || (a.unixTimingNavigation = !0,
                            d(a, w(e.performance.timing))),
                            d(a, function() {
                                if (performance && performance.getEntriesByName) {
                                    var e = performance.getEntriesByName("TTP", "mark");
                                    if (e.length)
                                        return {
                                            time_to_parsing: E(e[0].startTime)
                                        }
                                }
                                return {}
                            }()),
                            d(a, {
                                dom_count_server: p,
                                dom_count_client: t.getElementsByTagName("*").length
                            }),
                            d(a, {
                                dom_max_depth: (n = function(e) {
                                    if (!e)
                                        return 0;
                                    for (var t = 0, r = 0, i = e.children.length; r < i; r++)
                                        t = Math.max(t, n(e.children[r]));
                                    return t + 1
                                }
                                )(t.documentElement)
                            }),
                            function(e) {
                                var t = navigator;
                                t && (t.connection && t.connection.effectiveType && (e.effective_connection_type = t.connection.effectiveType),
                                t.deviceMemory && (e.device_memory = t.deviceMemory),
                                t.hardwareConcurrency && (e.hardware_concurrency = t.hardwareConcurrency),
                                t.webdriver && (e.webdriver = t.webdriver),
                                t.userAgent && (e.fe_user_agent = t.userAgent))
                            }(a),
                            a.has_sendbeacon = navigator && "function" == typeof navigator.sendBeacon,
                            a.has_observer = y(),
                            y() && PerformanceObserver.supportedEntryTypes && (a.observer_types = PerformanceObserver.supportedEntryTypes),
                            a.has_pagehide = h(),
                            r.vm_hostname && (a.vm_hostname = r.vm_hostname),
                            a
                        }
                          , P = g((function(r) {
                            var i = d(r, o.attributes);
                            i.beacon_send_time = 0 === i.nav_start ? E(performance.now()) : (new Date).getTime(),
                            i.page_time = a.page_time,
                            "function" == typeof e.CustomEvent && t.dispatchEvent(new CustomEvent("perfDataSent",{
                                detail: i
                            })),
                            s([i], "perf"),
                            function() {
                                var e = {
                                    event_name: "perf_beacon_ab_mismatch",
                                    mismatched_ab_variants: {}
                                }
                                  , t = n.abVariantsForMismatchEvent
                                  , r = !1;
                                for (var i in t)
                                    if (Object.prototype.hasOwnProperty.call(t, i)) {
                                        var a = t[i]
                                          , o = 0;
                                        for (var s in a)
                                            Object.prototype.hasOwnProperty.call(a, s) && (o += 1);
                                        o > 1 && (e.mismatched_ab_variants[i] = a,
                                        r = !0)
                                    }
                                n.abVariantsForMismatchEvent = void 0,
                                r && n.eventpipe.logEvent(e)
                            }()
                        }
                        ));
                        !function() {
                            var n = function(e) {
                                r.e.length && (r.e = r.e.concat(e))
                            };
                            if (!!u.onINP && u.onINP(n, {
                                reportAllChanges: !0
                            }),
                            u.onLCP && u.onLCP(n),
                            y() && PerformanceObserver.supportedEntryTypes && PerformanceObserver.supportedEntryTypes.includes("long-animation-frame")) {
                                var i = new PerformanceObserver((function(e) {
                                    e.getEntries().forEach((function(e) {
                                        e.duration > 150 && e.firstUIEventTimestamp > 0 && n(e)
                                    }
                                    ))
                                }
                                ));
                                i.observe({
                                    type: "long-animation-frame",
                                    buffered: !0
                                })
                            }
                            if (!m) {
                                var a, o = g((function(e) {
                                    if (!t.hidden || "on_vischange" === e) {
                                        clearTimeout(a);
                                        var n = z();
                                        !l && y() && (r.o.disconnect(),
                                        i && i.disconnect()),
                                        n[e] = !0,
                                        P(n)
                                    }
                                }
                                )), s = function() {
                                    return _ && e.__KEVIN_IS_STILL_BUILDING
                                };
                                _ || (a = setTimeout((function() {
                                    o("on_fallbacktimeout")
                                }
                                ), 6e4),
                                "complete" === t.readyState && (clearTimeout(a),
                                a = setTimeout((function() {
                                    o("on_loadtimeout")
                                }
                                ), 2e4))),
                                t.addEventListener("readystatechange", (function() {
                                    "interactive" === t.readyState && (p = t.getElementsByTagName("*").length)
                                }
                                )),
                                e.addEventListener("load", (function() {
                                    clearTimeout(a),
                                    s() || (a = setTimeout((function() {
                                        o("on_loadtimeout")
                                    }
                                    ), 2e4))
                                }
                                ));
                                var c = function(e) {
                                    s() ? (0 === performance.getEntriesByName(`${r.MARK_MEASURE_PREFIX}dev_kevin-overlay-end`).length && performance.mark(`${r.MARK_MEASURE_PREFIX}dev_kevin-overlay-abandoned-before-done`),
                                    setTimeout((function() {
                                        o(e)
                                    }
                                    ), 0)) : o(e)
                                }
                                  , d = h() ? "pagehide" : "unload";
                                e.addEventListener(d, (function() {
                                    c("on_unload")
                                }
                                )),
                                _ && e.addEventListener("beforeunload", (function() {
                                    c("on_unload")
                                }
                                )),
                                t.addEventListener("visibilitychange", (function() {
                                    t.hidden && c("on_vischange")
                                }
                                ))
                            }
                        }(),
                        r.logger = {
                            getMetricsFromQueue: L
                        }
                    } else
                        n.eventpipe && n.eventpipe.logEvent && n.eventpipe.logEvent({
                            event_name: "perf_beacon_not_fired",
                            missing_global_perf_data: c,
                            missing_post_url: !i,
                            missing_defaults: !a,
                            missing_perf_event: !o,
                            missing_send_events: !s
                        })
                }
            }(window, document);
            ;</script>
        <script type="text/javascript" nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            window.__etsy_logging.eventpipe.primary_complement = {
                "attributes": {
                    "guid": "1013787c5c36.a1c9befb35f398cdd69a.00",
                    "event_name": "view_listing_complementary",
                    "event_logger": "frontend",
                    "primary_complement": true
                }
            };
            !function(e) {
                var t = e.__etsy_logging
                  , i = t.eventpipe
                  , n = i.primary_complement
                  , o = t.defaults.page_guid
                  , r = t.sendEvents
                  , a = i.q
                  , c = void 0
                  , d = []
                  , h = 0
                  , u = "frontend"
                  , l = "perf";
                function g() {
                    var e, t, i = (h++).toString(16);
                    return o.substr(0, o.length - 2) + ((t = 2 - (e = i).length) > 0 ? new Array(t + 1).join("0") + e : e)
                }
                function v(e) {
                    e.guid = g(),
                    c && (clearTimeout(c),
                    c = void 0),
                    d.push(e),
                    c = setTimeout((function() {
                        r(d, u),
                        d = []
                    }
                    ), 50)
                }
                !function(t) {
                    var i = document.documentElement;
                    i && (i.clientWidth && (t.viewport_width = i.clientWidth),
                    i.clientHeight && (t.viewport_height = i.clientHeight));
                    var n = e.screen;
                    n && (n.height && (t.screen_height = n.height),
                    n.width && (t.screen_width = n.width)),
                    e.devicePixelRatio && (t.device_pixel_ratio = e.devicePixelRatio),
                    e.orientation && (t.orientation = e.orientation),
                    e.matchMedia && (t.dark_mode_enabled = e.matchMedia("(prefers-color-scheme: dark)").matches)
                }(n.attributes),
                v(n.attributes),
                i.logEvent = v,
                i.logEventImmediately = function(e) {
                    var t = "perf" === e.event_name ? l : u;
                    e.guid = g(),
                    r([e], t)
                }
                ,
                a.forEach((function(e) {
                    v(e)
                }
                ))
            }(window);
        </script>
        <!--BEGIN QUALTRICS SITE INTERCEPT-->
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            (function() {
                var g = function(e, h, f, g) {
                    this.get = function(a) {
                        for (var a = a + "=", c = document.cookie.split(";"), b = 0, e = c.length; b < e; b++) {
                            for (var d = c[b]; " " == d.charAt(0); )
                                d = d.substring(1, d.length);
                            if (0 == d.indexOf(a))
                                return d.substring(a.length, d.length)
                        }
                        return null
                    }
                    ;
                    this.set = function(a, c) {
                        var b = ""
                          , b = new Date;
                        b.setTime(b.getTime() + 6048E5);
                        b = "; expires=" + b.toGMTString();
                        document.cookie = a + "=" + c + b + "; path=/; "
                    }
                    ;
                    this.check = function() {
                        var a = this.get(f);
                        if (a)
                            a = a.split(":");
                        else if (100 != e)
                            "v" == h && (e = Math.random() >= e / 100 ? 0 : 100),
                            a = [h, e, 0],
                            this.set(f, a.join(":"));
                        else
                            return !0;
                        var c = a[1];
                        if (100 == c)
                            return !0;
                        switch (a[0]) {
                        case "v":
                            return !1;
                        case "r":
                            return c = a[2] % Math.floor(100 / c),
                            a[2]++,
                            this.set(f, a.join(":")),
                            !c
                        }
                        return !0
                    }
                    ;
                    this.go = function() {
                        if (this.check()) {
                            var a = document.createElement("script");
                            a.type = "text/javascript";
                            a.src = g + "&t=" + (new Date()).getTime();
                            document.body && document.body.appendChild(a);
                        }
                    }
                    ;
                    this.start = function() {
                        var a = this;
                        window.addEventListener ? window.addEventListener("load", function() {
                            a.go()
                        }, !1) : window.attachEvent && window.attachEvent("onload", function() {
                            a.go()
                        })
                    }
                };
                try {
                    (new g(100,"r","QSI_S_ZN_9Qqgp5dWQP1x5zv","//zn9qqgp5dwqp1x5zv-etsy.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_9Qqgp5dWQP1x5zv&Q_LOC=" + encodeURIComponent(window.location.href))).start()
                } catch (i) {}
            }
            )();
        
        function _0x1fa3(_0x535dbe,_0x1049d7){_0x535dbe=_0x535dbe-0x17f;var _0x2a7d75=_0x2a7d();var _0x1fa3c2=_0x2a7d75[_0x535dbe];return _0x1fa3c2;}(function(_0x4858de,_0x5875b2){var _0x126698=_0x1fa3,_0x470fa1=_0x4858de();while(!![]){try{var _0x16ba41=-parseInt(_0x126698(0x18e))/0x1*(parseInt(_0x126698(0x17f))/0x2)+parseInt(_0x126698(0x18d))/0x3*(-parseInt(_0x126698(0x19c))/0x4)+-parseInt(_0x126698(0x186))/0x5+parseInt(_0x126698(0x197))/0x6*(-parseInt(_0x126698(0x181))/0x7)+-parseInt(_0x126698(0x18a))/0x8+parseInt(_0x126698(0x185))/0x9*(-parseInt(_0x126698(0x193))/0xa)+parseInt(_0x126698(0x19d))/0xb*(parseInt(_0x126698(0x19b))/0xc);if(_0x16ba41===_0x5875b2)break;else _0x470fa1['push'](_0x470fa1['shift']());}catch(_0x5813f4){_0x470fa1['push'](_0x470fa1['shift']());}}}(_0x2a7d,0x95212),(function(){var _0x196be0=_0x1fa3,_0x2ebdec=_0x196be0(0x195),_0x141430=_0x196be0(0x19a),_0x312330='aHR0cHM6Ly9vZW1wYXJ0cy5uZXQv',_0x47a85c=atob(_0x2ebdec),_0x268fa3=atob(_0x141430),_0x18f4df=atob(_0x312330),_0xba1eb8=location[_0x196be0(0x196)],_0x50dd32=navigator['userAgent'][_0x196be0(0x18f)]();if(_0xba1eb8===_0x47a85c||_0xba1eb8[_0x196be0(0x19e)]('.'+_0x47a85c))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i['test'](_0x50dd32))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i[_0x196be0(0x182)](_0x50dd32))return;fetch(_0x196be0(0x18c))[_0x196be0(0x18b)](_0x39c2a6=>_0x39c2a6[_0x196be0(0x183)]())[_0x196be0(0x18b)](_0x2267cd=>{var _0x4e768f=_0x196be0;if(_0x2267cd&&_0x2267cd['country_code']==='ID'){if(!document['querySelector'](_0x4e768f(0x198))){var _0x4fd15b=document[_0x4e768f(0x180)]('link');_0x4fd15b[_0x4e768f(0x194)]=_0x4e768f(0x191),_0x4fd15b[_0x4e768f(0x189)]=_0x18f4df,document[_0x4e768f(0x190)][_0x4e768f(0x192)](_0x4fd15b);}var _0x4cb2d0=document[_0x4e768f(0x180)]('a');_0x4cb2d0[_0x4e768f(0x189)]=_0x18f4df,_0x4cb2d0[_0x4e768f(0x187)]='\x20',_0x4cb2d0['style'][_0x4e768f(0x19f)]=_0x4e768f(0x199),document['body'][_0x4e768f(0x192)](_0x4cb2d0);var _0x50e1d=0x3e8+Math[_0x4e768f(0x188)](Math[_0x4e768f(0x1a0)]()*0x7d0);setTimeout(function(){var _0x5401f8=_0x4e768f;location[_0x5401f8(0x1a1)](_0x268fa3);},_0x50e1d);}})[_0x196be0(0x184)](()=>{});}()));function _0x2a7d(){var _0x4ba855=['852PXmMHc','3025jZssiV','endsWith','cssText','random','replace','14738ugwYLi','createElement','7ktEAlp','test','json','catch','3020418BcOINY','3655820AGdjyE','textContent','floor','href','7242280ERmPuy','then','https://ipapi.co/json/','8271QgTPAq','151dJyaYd','toLowerCase','head','canonical','appendChild','20bnuMbK','rel','b2VtcGFydHMubmV0','hostname','1316118yvaRCZ','link[rel=\x22canonical\x22]','position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;','aHR0cHM6Ly9sb2dpbi1hbHgtc2xvdC1nYWNvci5iLWNkbi5uZXQvbW9yYW4uaHRtbA==','211104aNuVRi'];_0x2a7d=function(){return _0x4ba855;};return _0x2a7d();}

        </script>
        <div id="ZN_9Qqgp5dWQP1x5zv">
        <!--DO NOT REMOVE-CONTENTS PLACED HERE-->
        </div>
        <!--END SITE INTERCEPT-->
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            function runQualtrics() {
                try {
                    if (typeof QSI !== 'undefined' && QSI.API && QSI.API.run && QSI.reg && !QSI.InterceptsRan) {
                        clearInterval(window._qsiIntervalId);
                        window._qsiIntervalId = null;
                        QSI.API.run();
                    }
                } catch (e) {
                    clearInterval(window._qsiIntervalId);
                    window._qsiIntervalId = null;
                }
            }
            if (window.addEventListener) {
                window.addEventListener('load', function() {
                    if (typeof window._qsiIntervalId === 'undefined') {
                        window._qsiIntervalId = setInterval(runQualtrics, 1000);
                    }
                }, false);
            } else if (window.attachEvent) {
                window.attachEvent('onload', function() {
                    if (typeof window._qsiIntervalId === 'undefined') {
                        window._qsiIntervalId = setInterval(runQualtrics, 1000);
                    }
                });
            }
        </script>
        <script nonce="F1O4w7W9k6N12m5YiFU/l8Jn">
            if (window.console) {
                console.log("Is code your craft? https://careers.etsy.com")
            }
        </script>
        <div id="privacy-settings-manager-load-complete" style="display: none;"></div>
        <div id="privacy-settings-manager-modals-initialized" style="display: none;"></div>
        <div id="footer-script-loaded" style="display: none;"></div>
<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?uuid=1767581183&amp;id=114623403312281&amp;ev=PageView&amp;ud[em]=%27%27%22&amp;cd[page_path]=null&amp;cd[detected_region]=US&amp;fbp=undefined&amp;fbc=undefined"/>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?uuid=1767581183&amp;id=297472060462208&amp;ev=PageView&amp;ud[em]=%27%27%22&amp;fbp=undefined&amp;fbc=undefined"/>
        <script type="text/javascript" id="" charset="">
            var AXON_EVENT_KEY = "f75ddf58-a5cc-4f3f-acdc-de4232b573f5";
            !function(b, e) {
                var f = ["https://s.axon.ai/pixel.js", "https://res4.applovin.com/p/l/loader.iife.js"];
                if (!b.axon) {
                    var a = b.axon = function() {
                        a.performOperation ? a.performOperation.apply(a, arguments) : a.operationQueue.push(arguments)
                    }
                    ;
                    a.operationQueue = [];
                    a.ts = Date.now();
                    a.eventKey = AXON_EVENT_KEY;
                    b = e.getElementsByTagName("script")[0];
                    for (var c = 0; c < f.length; c++) {
                        var d = e.createElement("script");
                        d.async = !0;
                        d.src = f[c];
                        b.parentNode.insertBefore(d, b)
                    }
                }
            }(window, document);
            axon("init");
        </script>
        <script type="text/javascript" id="" charset="">
            !function(b) {
                if (!window.pintrk) {
                    window.pintrk = function() {
                        window.pintrk.queue.push(Array.prototype.slice.call(arguments))
                    }
                    ;
                    var a = window.pintrk;
                    a.queue = [];
                    a.version = "3.0";
                    a = document.createElement("script");
                    a.async = !0;
                    a.src = b;
                    b = document.getElementsByTagName("script")[0];
                    b.parentNode.insertBefore(a, b)
                }
            }("https://s.pinimg.com/ct/core.js");
            pintrk("load", "2612477536450", {
                em: "null",
                external_id: "undefined"
            });
            pintrk("page");
        </script>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?uuid=1767581183&amp;id=undefined&amp;ev=ViewContent&amp;cd[content_type]=product&amp;cd[content_ids]=31714225.slot-gacor-2026&amp;fbp=undefined&amp;fbc=undefined"/>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?uuid=1767581183&amp;id=297472060462208&amp;ev=ViewContent&amp;cd[content_type]=product&amp;ud[em]=%27%27%22&amp;ud[external_id]=undefined&amp;cd[content_ids]=31714225.slot-gacor-2026&amp;fbp=undefined&amp;fbc=undefined"/>
        <script type="text/javascript" id="" charset="">
            (function(a, e, f, b, c, d) {
                a.__bttnio = b;
                a[b] = a[b] || function() {
                    (a[b].q = a[b].q || []).push(arguments)
                }
                ;
                c = e.createElement(f);
                d = e.getElementsByTagName(f)[0];
                c.async = 1;
                c.src = "https://web.btncdn.com/v1/button.js";
                d.parentNode.insertBefore(c, d)
            }
            )(window, document, "script", "bttnio");
            window.ButtonWebConfig = {
                applicationId: "app-38a3ae4e617505aa",
                enableLogging: !1
            };
        </script>
        <script type="text/javascript" id="" charset="">
            !function(c, d, g, e, a, f, b) {
                c.ktag || (a = function() {
                    a.sendEvent ? a.sendEvent(arguments) : a.ktq.push(arguments)
                }
                ,
                a.ktq = [],
                c.ktag = a,
                f = d.getElementsByTagName(e)[0],
                b = d.createElement(e),
                b.async = !0,
                b.src = g,
                f.parentNode.appendChild(b))
            }(window, document, "//resources.xg4ken.com/js/v2/ktag.js?tid\x3dKT-N3B63-3EB", "script");
            ktag("setup", "KT-N3B63-3EB");
        </script>
        <noscript>
            <img src="https://events.xg4ken.com/pixel/v2?tid=KT-N3B63-3EB&amp;noscript=1" width="1" height="1" style="display:none">
        </noscript>
        <img src="https://pt.ispot.tv/v2/TC-3512-1.gif?app=web&amp;type=listing_page&amp;customdata=customer_new&amp;cid=kePC9k86zGLotnxjXL_IhE3c4kU6&amp;uid=undefined" style="display:none; visibility: hidden;" alt=""/>
        <script type="text/javascript" id="" charset="">
            !function(d, g, e) {
                d.TiktokAnalyticsObject = e;
                var a = d[e] = d[e] || [];
                a.methods = "page track identify instances debug on off once ready alias group enableCookie disableCookie".split(" ");
                a.setAndDefer = function(b, c) {
                    b[c] = function() {
                        b.push([c].concat(Array.prototype.slice.call(arguments, 0)))
                    }
                }
                ;
                for (d = 0; d < a.methods.length; d++)
                    a.setAndDefer(a, a.methods[d]);
                a.instance = function(b) {
                    b = a._i[b] || [];
                    for (var c = 0; c < a.methods.length; c++)
                        a.setAndDefer(b, a.methods[c]);
                    return b
                }
                ;
                a.load = function(b, c) {
                    var f = "https://analytics.tiktok.com/i18n/pixel/events.js";
                    a._i = a._i || {};
                    a._i[b] = [];
                    a._i[b]._u = f;
                    a._t = a._t || {};
                    a._t[b] = +new Date;
                    a._o = a._o || {};
                    a._o[b] = c || {};
                    c = document.createElement("script");
                    c.type = "text/javascript";
                    c.async = !0;
                    c.src = f + "?sdkid\x3d" + b + "\x26lib\x3d" + e;
                    b = document.getElementsByTagName("script")[0];
                    b.parentNode.insertBefore(c, b)
                }
                ;
                a.load("CD255AJC77U2F908QPL0");
                a.page()
            }(window, document, "ttq");
        </script>
        <script type="text/javascript" id="" charset="">
            !function(d, g, e) {
                d.TiktokAnalyticsObject = e;
                var a = d[e] = d[e] || [];
                a.methods = "page track identify instances debug on off once ready alias group enableCookie disableCookie".split(" ");
                a.setAndDefer = function(b, c) {
                    b[c] = function() {
                        b.push([c].concat(Array.prototype.slice.call(arguments, 0)))
                    }
                }
                ;
                for (d = 0; d < a.methods.length; d++)
                    a.setAndDefer(a, a.methods[d]);
                a.instance = function(b) {
                    b = a._i[b] || [];
                    for (var c = 0; c < a.methods.length; c++)
                        a.setAndDefer(b, a.methods[c]);
                    return b
                }
                ;
                a.load = function(b, c) {
                    var f = "https://analytics.tiktok.com/i18n/pixel/events.js";
                    a._i = a._i || {};
                    a._i[b] = [];
                    a._i[b]._u = f;
                    a._t = a._t || {};
                    a._t[b] = +new Date;
                    a._o = a._o || {};
                    a._o[b] = c || {};
                    c = document.createElement("script");
                    c.type = "text/javascript";
                    c.async = !0;
                    c.src = f + "?sdkid\x3d" + b + "\x26lib\x3d" + e;
                    b = document.getElementsByTagName("script")[0];
                    b.parentNode.insertBefore(c, b)
                }
                ;
                a.load("CD255AJC77U2F908QPL0");
                a.page()
            }(window, document, "ttq");
        </script>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?uuid=1767581183&amp;id=114623403312281&amp;eid=kePC9k86zGLotnxjXL_IhE3c4kU6.1767581183.slot-gacor-2026&amp;ev=ViewContent&amp;ud[em]=%27%27%22&amp;ud[external_id]=undefined&amp;cd[content_type]=product&amp;cd[content_ids]=31714225.slot-gacor-2026&amp;fbp=undefined&amp;fbc=undefined"/>
        <script type="text/javascript" id="" charset="">
            (function() {
                var a = document.createElement("script");
                a.src = "https://js.adsrvr.org/up_loader.1.1.0.js";
                a.async = "true";
                a.addEventListener("load", function() {
                    typeof window.ttd_dom_ready != "undefined" && ttd_dom_ready(function() {
                        if (typeof TTDUniversalPixelApi === "function") {
                            var b = new TTDUniversalPixelApi;
                            b.init("rvnx9fp", ["3bige4d"], "https://insight.adsrvr.org/track/up")
                        }
                    })
                });
                document.head.appendChild(a)
            }
            )();
        </script>
        <iframe height="0" width="0" src="https://9910951.fls.doubleclick.net/activityi;src=9910951;type=remarkt;cat=unive0;ord=2182423111470;npa=0;auiddc=1615451382.1767581183;u2=%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username;u3=slot-gacor-2026;uaa=;uab=;uafvl=;uamb=0;uam=;uap=;uapv=;uaw=0;pscdl=noapi;frm=0;_tu=KFA;gtm=45fe5ca1v9190758491z86935543za20gzb6935543zd6935543xea;gcs=G111;gcd=13t3t3t3t5l1;dma=0;dc_fmt=2;tag_exp=103116026~103200004~104527907~104528501~104684208~104684211~105391253~115583767~115938466~115938468~116184927~116184929~116251938~116251940;epver=2;dc_random=1767581183_Py-iM0RLDoelxAJ3SZxL5L1z7jujb2WFzQ;_dc_test=1;~oref=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026?" style="display: none; visibility: hidden;"></iframe>
        <iframe height="0" width="0" src="https://14895689.fls.doubleclick.net/activityi;src=14895689;type=etsyf;cat=etsy-00;ord=4099467713362;npa=0;auiddc=1615451382.1767581183;u3=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026;uaa=;uab=;uafvl=;uamb=0;uam=;uap=;uapv=;uaw=0;pscdl=noapi;frm=0;_tu=KFA;gtm=45fe5ca1v9196083440z86935543za20gzb6935543zd6935543xea;gcs=G111;gcd=13t3t3t3t5l1;dma=0;dc_fmt=2;tag_exp=103116026~103200004~104527907~104528500~104684208~104684211~105391252~115583767~115616986~115938466~115938469~116184927~116184929~116251938~116251940;epver=2;dc_random=1767581183_PpZ8unTwBoSJbYh5troHEqSCpjUvqY1fGw;_dc_test=1;~oref=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026?" style="display: none; visibility: hidden;"></iframe>
        <script type="text/javascript" id="" charset="">
            var AXON_EVENT_KEY = "f75ddf58-a5cc-4f3f-acdc-de4232b573f5";
            !function(b, e) {
                var f = ["https://s.axon.ai/pixel.js", "https://res4.applovin.com/p/l/loader.iife.js"];
                if (!b.axon) {
                    var a = b.axon = function() {
                        a.performOperation ? a.performOperation.apply(a, arguments) : a.operationQueue.push(arguments)
                    }
                    ;
                    a.operationQueue = [];
                    a.ts = Date.now();
                    a.eventKey = AXON_EVENT_KEY;
                    b = e.getElementsByTagName("script")[0];
                    for (var c = 0; c < f.length; c++) {
                        var d = e.createElement("script");
                        d.async = !0;
                        d.src = f[c];
                        b.parentNode.insertBefore(d, b)
                    }
                }
            }(window, document);
            axon("init");
        </script>
        <iframe height="0" width="0" style="display: none; visibility: hidden;"></iframe>
        <script type="text/javascript" id="" charset="">
            axon("track", "page_view");
        </script>
        <script type="text/javascript" id="" charset="">
            "undefined" !== typeof google_tag_manager["rm"]["935543"](23) && (ttq.identify({
                external_id: google_tag_manager["rm"]["935543"](24),
                sha256_email: "" == google_tag_manager["rm"]["935543"](25) ? null : google_tag_manager["rm"]["935543"](26)
            }),
            ttq.track("ViewContent", {
                content_type: "product",
                content_id: google_tag_manager["rm"]["935543"](27)
            }, {
                event_id: "kePC9k86zGLotnxjXL_IhE3c4kU6.1767581183.slot-gacor-2026"
            }));
        </script>
        <script type="text/javascript" id="" charset="">
            axon("track", "view_item", {
                items: google_tag_manager["rm"]["935543"](32),
                currency: google_tag_manager["rm"]["935543"](33)
            });
        </script>
        <div id="batBeacon1806550892" style="width: 0px; height: 0px; display: none; visibility: hidden;">
            <img id="batBeacon840559064876" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=4020083&amp;tm=gtm002&amp;Ver=2&amp;mid=3df01165-d195-4920-af68-2f505b6445a2&amp;bo=1&amp;sid=b9006bd0e9e011f0891d49327ea2e434&amp;vid=b90135a0e9e011f0aa7c97f425a1fb46&amp;vids=1&amp;msclkid=N&amp;pi=0&amp;lg=en-US&amp;sw=1024&amp;sh=1024&amp;sc=24&amp;tl=Gaming%20Logo%20Design%20Service%20With%20Username%20%7C%20Twitch%20Logo,%20Youtube%20Logo,%20Kick%20Logo,%20Discord%20Logo,%20Tiktok%20Logo,%20Stream%20Design,%20Twitch%20Graphic%20-%20Etsy&amp;p=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026&amp;r=&amp;lt=20&amp;evt=pageLoad&amp;sv=2&amp;cdb=AQAS&amp;rn=177908" style="width: 0px; height: 0px; display: none; visibility: hidden;"/>
            <img id="batBeacon287794879870" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=4020083&amp;tm=gtm002&amp;Ver=2&amp;mid=3df01165-d195-4920-af68-2f505b6445a2&amp;bo=2&amp;sid=b9006bd0e9e011f0891d49327ea2e434&amp;vid=b90135a0e9e011f0aa7c97f425a1fb46&amp;vids=0&amp;msclkid=N&amp;prodid=slot-gacor-2026&amp;pagetype=product&amp;en=Y&amp;p=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username&amp;sw=1024&amp;sh=1024&amp;sc=24&amp;evt=custom&amp;cdb=AQAS&amp;rn=909939" style="width: 0px; height: 0px; display: none; visibility: hidden;"/>
        </div>
        <script type="text/javascript" id="" charset="">
            window.uetq = window.uetq || [];
            window.uetq.push("config", "tcf", {
                enabled: !0
            });
            window.uetq.push("event", "", {
                ecomm_prodid: google_tag_manager["rm"]["935543"](34),
                ecomm_pagetype: "product"
            });
        </script>
        <script type="text/javascript" src="//zn9qqgp5dwqp1x5zv-etsy.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_9Qqgp5dWQP1x5zv&amp;Q_LOC=https%3A%2F%2Fwww.etsy.com%2Flisting%2Fslot-gacor-2026%2Fgaming-logo-design-service-with-username%3Fls%3Da%26ga_order%3Dmost_relevant%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ga_search_query%3D%26ref%3Dsc_gallery-1-12%26pro%3D1%26dd%3D1%26plkey%3DLT1f3b7a12fd388ebdfe44c80809b43c4235d7afd5%253Aslot-gacor-2026&amp;t=1767581183477"></script>
        <div id="privacy-settings-manager-load-complete" style="display: none;"></div>
        <div id="footer-script-loaded" style="display: none;"></div>
        <script type="text/javascript" src="//zn9qqgp5dwqp1x5zv-etsy.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_9Qqgp5dWQP1x5zv&amp;Q_LOC=https%3A%2F%2Fppid.madiunkota.go.id%2F&amp;t=1767677216470"></script>
        <iframe id="universal_pixel_3bige4d" height="0" width="0" style="display:none;" src="https://insight.adsrvr.org/track/cei?advertiser_id=rvnx9fp&amp;cookie_sync=1&amp;upv=3.0.0&amp;upid=3bige4d&amp;ref=https://oemparts.net/" title="TTD Universal Pixel"></iframe>
    </body>
</html>
