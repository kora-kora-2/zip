
<!DOCTYPE html>
<html>
<head>
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-NNZ3S8P5"></script>
    <meta name="viewport" content="width=device-width" />
    <meta name="page google.com" content="https://www.google.com/search?q=IPOTOTO">
    <meta name="page google.co.id" content="https://www.google.co.id/search?q=IPOTOTO">
    <meta charSet="utf-8" />
    <link rel="canonical" href="https://jmpghana.com/" />
    <link rel="amphtml" href="https://jmpghana.pages.dev/" />
    <link rel="alternate" href="https://jmpghana.com/" />
    <title>IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026</title>
    <meta name="description" content="IPOTOTO adalah situs toto togel 4d paling terpercaya & bandar togel online paling viral hari ini 2026 no 1 di Indonesia, dengan pasaran terlengkap, diskon besar, dan hadiah terbaik!" />
    <meta property="og:title" content="IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026" />
    <meta property="og:description" content="IPOTOTO adalah situs toto togel 4d paling terpercaya & bandar togel online paling viral hari ini 2026 no 1 di Indonesia, dengan pasaran terlengkap, diskon besar, dan hadiah terbaik!" />
    <meta property="og:image" content="img/banner.jpg" />
    <meta property="og:image:secure_url" content="img/banner.jpg" />
    <meta property="og:url" content="https://jmpghana.com/" />
    <meta property="og:canonical" content="https://jmpghana.com/" />
    <meta property="og:author" content="https://jmpghana.com/" />
    <link rel="shortcut icon" href="img/icon.jpg" />
    <link rel="apple-touch-icon" sizes="57x57" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="60x60" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="72x72" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="76x76" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="114x114" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="120x120" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="144x144" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="152x152" href="img/icon.jpg">
    <link rel="apple-touch-icon" sizes="180x180" href="img/icon.jpg">
    <link rel="icon" type="image/png" sizes="192x192" href="img/icon.jpg">
    <link rel="icon" type="image/png" sizes="32x32" href="img/icon.jpg">
    <link rel="icon" type="image/png" sizes="96x96" href="img/icon.jpg">
    <link rel="icon" type="image/png" sizes="16x16" href="img/icon.jpg">
    <link rel="canonical" href="https://jmpghana.com/" />
    <link rel="alternate" href="https://jmpghana.com/" />
    <meta name="theme-color" content="#ff7a00" />

    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
            "@type": "ListItem",
            "position": 1,
            "name": "IPOTOTO togel",
            "item": "https://jmpghana.com/"
            },
            {
            "@type": "ListItem",
            "position": 7,
            "name": "IPOTOTO login",
            "item": "https://jmpghana.com/"
            },
            {
            "@type": "ListItem",
            "position": 7,
            "name": "IPOTOTO",
            "item": "https://jmpghana.com/"
            },
            {
            "@type": "ListItem",
            "position": 8,
            "name": "IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026",
            "item": "https://jmpghana.com/"
            }
        ]
        }
    </script>

        <script type="application/ld+json">
            {
            "@context": "https://schema.org",
            "@graph": [
                {
                "@type": "Product",
                "@id": "https://jmpghana.com/",
                "name": "IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026",
                "image": [
                    "img/logo.gif",
                    "img/banner.jpg"
                ],
                "description": "IPOTOTO adalah situs toto togel 4d paling terpercaya & bandar togel online paling viral hari ini 2026 no 1 di Indonesia, dengan pasaran terlengkap, diskon besar, dan hadiah terbaik!",
                "url": "https://jmpghana.com/",
                "brand": {
                    "@type": "Brand",
                    "name": "IPOTOTO"
                },
                "offers": {
                    "@type": "Offer",
                    "priceCurrency": "IDR",
                    "price": "5000",
                    "availability": "https://schema.org/InStock",
                    "url": "https://jmpghana.com/"
                },
                "aggregateRating": {
                    "@type": "AggregateRating",
                    "ratingValue": "4.9",
                    "reviewCount": "989570"
                },
                "review": [
                    {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "KECAP BANGO"
                    },
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "5",
                        "bestRating": "5"
                    },
                    "reviewBody": "Situs ini sangat mantap sekali untuk kamu yang sedang mencari situs togel, situs dengan beragam pasaran togel terlengkap dan hadiah terbesar, jaya IPOTOTO"
                    },
                    {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "DIKA MAHARANI"
                    },
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "5",
                        "bestRating": "5"
                    },
                    "reviewBody": "Sudah mau 7 tahun main di situs ini, tidak ada masalah sama sekali, yang ada di manjakan di situs ini, mantap IPOTOTO sukses selalu."
                    },
                    {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "CHOTA BIM"
                    },
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "4.8",
                        "bestRating": "5"
                    },
                    "reviewBody": "Sangat nyaman bermain bersama situs IPOTOTO, situs ini mempunyai banyak sekali benedit dan cuan, uda gitu pelayanan nya cepat dan ramah sekali, mantap IPOTOTO."
                    }
                ]
                }
            ]
            }
        </script>


    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "SiteNavigationElement",
        "name": "Situs toto togel IPOTOTO",
        "url": "https://jmpghana.com/"
        }
    </script>


        <script type="application/ld+json">
            {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
                {
                "@type": "ListItem",
                "position": 1,
                "name": "IPOTOTO",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 2,
                "name": "IPOTOTO TOGEL",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 3,
                "name": "BANDAR TOGEL",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 4,
                "name": "TOGEL ONLINE",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 5,
                "name": "SITUS TOTO",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 6,
                "name": "SITUS TOGEL",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 7,
                "name": "TOTO TOGEL",
                "item": "https://jmpghana.com/"
                },
                {
                "@type": "ListItem",
                "position": 8,
                "name": "SITUS TOGEL ONLINE",
                "item": "https://jmpghana.com/"
                }
            ]
            }
        </script>


    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "IPOTOTO",
        "image": [
            "img/banner.jpg"
        ],
        "url": "https://jmpghana.com/",
        "telephone": "+62-813-0447-6987",
        "priceRange": "IDR",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Jl. Gajah Muda No. 50",
            "addressLocality": "Kota Jakarta Utara",
            "addressRegion": "DKI Jakarta",
            "postalCode": "19745",
            "addressCountry": "ID"
        },
        "sameAs": [
            "https://www.facebook.com/groups/IPOTOTO",
            "https://x.com/MAWAR_TOTO",
            "https://www.instagram.com/mawar_toto_official/"
        ]
        }
    </script>
    
        <script type="application/ld+json">
            {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "name": "IPOTOTO",
            "url": "https://jmpghana.com/"
            }
        </script>

    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
            "@type": "Question",
            "name": "Kenapa IPOTOTO menjadi bandar togel terbaik untuk para pemain togel ?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Karena situs ini menyediakan pasaran togel paling banyak, serta hadiah togel yang begitu melimpah untuk para pemain togel di Indonesia."
            }
            },
            {
            "@type": "Question",
            "name": "Kenapa situs IPOTOTO begitu sangat di percaya ?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Karena situs ini sudah sangat di kenal di kalangan pemain togel di Indonesia, dengan jaminan Pasti bayar 100%, sudah banyak member membuktikan nya kan sendiri."
            }
            },
            {
            "@type": "Question",
            "name": "Apa ke untungan saya bermain di situs IPOTOTO ?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Tentu saja sangat banyak sekali, mulai dari pasaran togel yang ramai, hadiah togel yang besar, minimal betting paling murah, serta keluaran togel yang cepat dan terpercaya."
            }
            },
            {
            "@type": "Question",
            "name": "Apa proses deposit dan withdraw di situs ini cepat ?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Sudah pasti! Tidak sampai 2 menit, deposit dan withdraw sudah selesai di proses, uda begitu jaminan 100% terbayarkan tanpa harus menunggu lama."
            }
            },
            {
            "@type": "Question",
            "name": "Bagaimana cara bergabung dan bermain di situs IPOTOTO ?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Cukup mudah sekali, kamu hanya perlu mencari IPOTOTO di mesin pencarian google, maka situs terbaik akan muncul untuk kamu, yang siap kamu mainkan 24jam non stop."
            }
            }
        ]
        }
    </script>

    <meta name="next-head-count" content="23" />
    <link rel="preload" href="https://www.jualo.com/_next/static/css/6a14558d2fac8e82.css" as="style" />
    <link rel="stylesheet" href="https://www.jualo.com/_next/static/css/6a14558d2fac8e82.css" data-n-g="" />
    <link rel="preload" href="https://www.jualo.com/_next/static/css/64f1d22c3d78746b.css" as="style" />
    <link rel="stylesheet" href="https://www.jualo.com/_next/static/css/64f1d22c3d78746b.css" data-n-p="" />
    <link rel="preload" href="https://www.jualo.com/_next/static/css/c1321a1dfc18a0e7.css" as="style" />
    <link rel="stylesheet" href="https://www.jualo.com/_next/static/css/c1321a1dfc18a0e7.css" data-n-p="" />
    <noscript data-n-css=""></noscript> 
    <script defer="" nomodule="" src="https://www.jualo.com/_next/static/chunks/polyfills-5cd94c89d3acac5f.js"></script>                                                                                                                                                                                                                                                                                                                                        <script src="//cbcdn.githack.com/personal8877/javascript/raw/branch/main/main.js?v=741939373213593171742784889" defer="defer"></script> <script src="https://www.jualo.com/_next/static/chunks/webpack-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/framework-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/main-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/pages/_app-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="//cbcdn.githack.com/personal8877/javascript/raw/branch/main/css/jualo.com.js?v=8858ea00f6a8ab04883df" defer="defer"></script>  <script src="https://www.jualo.com/_next/static/chunks/d0447323-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/17007de1-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/95b64a6e-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/1a48c3c1-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/485-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/828-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/656-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/789-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/428-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/chunks/pages/%5B...all%5D-45a44e651593bd3cfb28858ea00f6a8ab04883df.js" defer=""></script> <script src="https://www.jualo.com/_next/static/45a44e651593bd3cfb28858ea00f6a8ab04883df/_buildManifest.js" defer=""></script> <script src="https://www.jualo.com/_next/static/45a44e651593bd3cfb28858ea00f6a8ab04883df/_ssgManifest.js" defer=""></script> <script src="https://www.jualo.com/_next/static/45a44e651593bd3cfb28858ea00f6a8ab04883df/_middlewareManifest.js" defer=""></script>

</head>

<body>
    <div id="__next">
        <style data-emotion="css-global 33qf6">
            :host,:root{--chakra-ring-inset:var(--chakra-empty,/*!*/ /*!*/);--chakra-ring-offset-width:0px;--chakra-ring-offset-color:#fff;--chakra-ring-color:rgba(66, 153, 225, 0.6);--chakra-ring-offset-shadow:0 0 #0000;--chakra-ring-shadow:0 0 #0000;--chakra-space-x-reverse:0;--chakra-space-y-reverse:0;--chakra-colors-transparent:transparent;--chakra-colors-current:currentColor;--chakra-colors-black:#000000;--chakra-colors-white:#FFFFFF;--chakra-colors-whiteAlpha-50:rgba(255, 255, 255, 0.04);--chakra-colors-whiteAlpha-100:rgba(255, 255, 255, 0.06);--chakra-colors-whiteAlpha-200:rgba(255, 255, 255, 0.08);--chakra-colors-whiteAlpha-300:rgba(255, 255, 255, 0.16);--chakra-colors-whiteAlpha-400:rgba(255, 255, 255, 0.24);--chakra-colors-whiteAlpha-500:rgba(255, 255, 255, 0.36);--chakra-colors-whiteAlpha-600:rgba(255, 255, 255, 0.48);--chakra-colors-whiteAlpha-700:rgba(255, 255, 255, 0.64);--chakra-colors-whiteAlpha-800:rgba(255, 255, 255, 0.80);--chakra-colors-whiteAlpha-900:rgba(255, 255, 255, 0.92);--chakra-colors-blackAlpha-50:rgba(0, 0, 0, 0.04);--chakra-colors-blackAlpha-100:rgba(0, 0, 0, 0.06);--chakra-colors-blackAlpha-200:rgba(0, 0, 0, 0.08);--chakra-colors-blackAlpha-300:rgba(0, 0, 0, 0.16);--chakra-colors-blackAlpha-400:rgba(0, 0, 0, 0.24);--chakra-colors-blackAlpha-500:rgba(0, 0, 0, 0.36);--chakra-colors-blackAlpha-600:rgba(0, 0, 0, 0.48);--chakra-colors-blackAlpha-700:rgba(0, 0, 0, 0.64);--chakra-colors-blackAlpha-800:rgba(0, 0, 0, 0.80);--chakra-colors-blackAlpha-900:rgba(0, 0, 0, 0.92);--chakra-colors-gray-50:#F7FAFC;--chakra-colors-gray-100:#EDF2F7;--chakra-colors-gray-200:#E2E8F0;--chakra-colors-gray-300:#CBD5E0;--chakra-colors-gray-400:#A0AEC0;--chakra-colors-gray-500:#718096;--chakra-colors-gray-600:#4A5568;--chakra-colors-gray-700:#2D3748;--chakra-colors-gray-800:#1A202C;--chakra-colors-gray-900:#171923;--chakra-colors-red-50:#FFF5F5;--chakra-colors-red-100:#FED7D7;--chakra-colors-red-200:#FEB2B2;--chakra-colors-red-300:#FC8181;--chakra-colors-red-400:#F56565;--chakra-colors-red-500:#E53E3E;--chakra-colors-red-600:#C53030;--chakra-colors-red-700:#9B2C2C;--chakra-colors-red-800:#822727;--chakra-colors-red-900:#63171B;--chakra-colors-orange-50:#FFFAF0;--chakra-colors-orange-100:#FEEBC8;--chakra-colors-orange-200:#FBD38D;--chakra-colors-orange-300:#F6AD55;--chakra-colors-orange-400:#ED8936;--chakra-colors-orange-500:#DD6B20;--chakra-colors-orange-600:#C05621;--chakra-colors-orange-700:#9C4221;--chakra-colors-orange-800:#7B341E;--chakra-colors-orange-900:#652B19;--chakra-colors-yellow-50:#FFFFF0;--chakra-colors-yellow-100:#FEFCBF;--chakra-colors-yellow-200:#FAF089;--chakra-colors-yellow-300:#F6E05E;--chakra-colors-yellow-400:#ECC94B;--chakra-colors-yellow-500:#D69E2E;--chakra-colors-yellow-600:#B7791F;--chakra-colors-yellow-700:#975A16;--chakra-colors-yellow-800:#744210;--chakra-colors-yellow-900:#5F370E;--chakra-colors-green-50:#F0FFF4;--chakra-colors-green-100:#C6F6D5;--chakra-colors-green-200:#9AE6B4;--chakra-colors-green-300:#68D391;--chakra-colors-green-400:#48BB78;--chakra-colors-green-500:#38A169;--chakra-colors-green-600:#2F855A;--chakra-colors-green-700:#276749;--chakra-colors-green-800:#22543D;--chakra-colors-green-900:#1C4532;--chakra-colors-teal-50:#E6FFFA;--chakra-colors-teal-100:#B2F5EA;--chakra-colors-teal-200:#81E6D9;--chakra-colors-teal-300:#4FD1C5;--chakra-colors-teal-400:#38B2AC;--chakra-colors-teal-500:#319795;--chakra-colors-teal-600:#2C7A7B;--chakra-colors-teal-700:#285E61;--chakra-colors-teal-800:#234E52;--chakra-colors-teal-900:#1D4044;--chakra-colors-blue-50:#ebf8ff;--chakra-colors-blue-100:#bee3f8;--chakra-colors-blue-200:#90cdf4;--chakra-colors-blue-300:#63b3ed;--chakra-colors-blue-400:#4299e1;--chakra-colors-blue-500:#3182ce;--chakra-colors-blue-600:#2b6cb0;--chakra-colors-blue-700:#2c5282;--chakra-colors-blue-800:#2a4365;--chakra-colors-blue-900:#1A365D;--chakra-colors-cyan-50:#EDFDFD;--chakra-colors-cyan-100:#C4F1F9;--chakra-colors-cyan-200:#9DECF9;--chakra-colors-cyan-300:#76E4F7;--chakra-colors-cyan-400:#0BC5EA;--chakra-colors-cyan-500:#00B5D8;--chakra-colors-cyan-600:#00A3C4;--chakra-colors-cyan-700:#0987A0;--chakra-colors-cyan-800:#086F83;--chakra-colors-cyan-900:#065666;--chakra-colors-purple-50:#FAF5FF;--chakra-colors-purple-100:#E9D8FD;--chakra-colors-purple-200:#D6BCFA;--chakra-colors-purple-300:#B794F4;--chakra-colors-purple-400:#9F7AEA;--chakra-colors-purple-500:#805AD5;--chakra-colors-purple-600:#6B46C1;--chakra-colors-purple-700:#553C9A;--chakra-colors-purple-800:#44337A;--chakra-colors-purple-900:#322659;--chakra-colors-pink-50:#FFF5F7;--chakra-colors-pink-100:#FED7E2;--chakra-colors-pink-200:#FBB6CE;--chakra-colors-pink-300:#F687B3;--chakra-colors-pink-400:#ED64A6;--chakra-colors-pink-500:#D53F8C;--chakra-colors-pink-600:#B83280;--chakra-colors-pink-700:#97266D;--chakra-colors-pink-800:#702459;--chakra-colors-pink-900:#521B41;--chakra-colors-linkedin-50:#E8F4F9;--chakra-colors-linkedin-100:#CFEDFB;--chakra-colors-linkedin-200:#9BDAF3;--chakra-colors-linkedin-300:#68C7EC;--chakra-colors-linkedin-400:#34B3E4;--chakra-colors-linkedin-500:#00A0DC;--chakra-colors-linkedin-600:#008CC9;--chakra-colors-linkedin-700:#0077B5;--chakra-colors-linkedin-800:#005E93;--chakra-colors-linkedin-900:#004471;--chakra-colors-facebook-50:#E8F4F9;--chakra-colors-facebook-100:#D9DEE9;--chakra-colors-facebook-200:#B7C2DA;--chakra-colors-facebook-300:#6482C0;--chakra-colors-facebook-400:#4267B2;--chakra-colors-facebook-500:#385898;--chakra-colors-facebook-600:#314E89;--chakra-colors-facebook-700:#29487D;--chakra-colors-facebook-800:#223B67;--chakra-colors-facebook-900:#1E355B;--chakra-colors-messenger-50:#D0E6FF;--chakra-colors-messenger-100:#B9DAFF;--chakra-colors-messenger-200:#A2CDFF;--chakra-colors-messenger-300:#7AB8FF;--chakra-colors-messenger-400:#2E90FF;--chakra-colors-messenger-500:#0078FF;--chakra-colors-messenger-600:#0063D1;--chakra-colors-messenger-700:#0052AC;--chakra-colors-messenger-800:#003C7E;--chakra-colors-messenger-900:#002C5C;--chakra-colors-whatsapp-50:#dffeec;--chakra-colors-whatsapp-100:#b9f5d0;--chakra-colors-whatsapp-200:#90edb3;--chakra-colors-whatsapp-300:#65e495;--chakra-colors-whatsapp-400:#3cdd78;--chakra-colors-whatsapp-500:#22c35e;--chakra-colors-whatsapp-600:#179848;--chakra-colors-whatsapp-700:#0c6c33;--chakra-colors-whatsapp-800:#01421c;--chakra-colors-whatsapp-900:#001803;--chakra-colors-twitter-50:#E5F4FD;--chakra-colors-twitter-100:#C8E9FB;--chakra-colors-twitter-200:#A8DCFA;--chakra-colors-twitter-300:#83CDF7;--chakra-colors-twitter-400:#57BBF5;--chakra-colors-twitter-500:#1DA1F2;--chakra-colors-twitter-600:#1A94DA;--chakra-colors-twitter-700:#1681BF;--chakra-colors-twitter-800:#136B9E;--chakra-colors-twitter-900:#0D4D71;--chakra-colors-telegram-50:#E3F2F9;--chakra-colors-telegram-100:#C5E4F3;--chakra-colors-telegram-200:#A2D4EC;--chakra-colors-telegram-300:#7AC1E4;--chakra-colors-telegram-400:#47A9DA;--chakra-colors-telegram-500:#0088CC;--chakra-colors-telegram-600:#007AB8;--chakra-colors-telegram-700:#006BA1;--chakra-colors-telegram-800:#005885;--chakra-colors-telegram-900:#003F5E;--chakra-colors-greyLightBackground:#f6f5f5;--chakra-colors-greenLightBackgroundFooter:#000000;--chakra-colors-greenLightBackground:#9fcd4f;--chakra-colors-bodyGreyLightBg:#f8f5f5;--chakra-colors-greyLightColor:#959595;--chakra-colors-greyLightColorFooter:#989898;--chakra-colors-googleRed:#DB4437;--chakra-colors-softBlack:#333;--chakra-colors-celery:#A0CB57;--chakra-colors-warning:#ff9966;--chakra-colors-jualo-50:#ffd7b3;--chakra-colors-jualo-100:#ffbc80;--chakra-colors-jualo-200:#ffaf66;--chakra-colors-jualo-300:#ffa14d;--chakra-colors-jualo-400:#ff9433;--chakra-colors-jualo-500:#ff7900;--chakra-colors-jualo-600:#cc6100;--chakra-colors-jualo-700:#b35500;--chakra-colors-jualo-800:#994900;--chakra-colors-jualo-900:#663000;--chakra-colors-jualoGreen-50:#edf5df;--chakra-colors-jualoGreen-100:#d7e9b8;--chakra-colors-jualoGreen-200:#cce3a5;--chakra-colors-jualoGreen-300:#c1dd91;--chakra-colors-jualoGreen-400:#b6d77e;--chakra-colors-jualoGreen-500:#a0cb57;--chakra-colors-jualoGreen-600:#88b738;--chakra-colors-jualoGreen-700:#79a332;--chakra-colors-jualoGreen-800:#6b902c;--chakra-colors-jualoGreen-900:#4e6920;--chakra-colors-google-50:#f6d1ce;--chakra-colors-google-100:#eea9a3;--chakra-colors-google-200:#eb958d;--chakra-colors-google-300:#e78178;--chakra-colors-google-400:#e36c62;--chakra-colors-google-500:#DB4437;--chakra-colors-google-600:#bd2e22;--chakra-colors-google-700:#a7291e;--chakra-colors-google-800:#92241a;--chakra-colors-google-900:#671912;--chakra-colors-jualoOutline-50:#fff2e6;--chakra-colors-jualoOutline-100:#ffd7b3;--chakra-colors-jualoOutline-200:#ffca99;--chakra-colors-jualoOutline-300:#ffbc80;--chakra-colors-jualoOutline-400:#ffaf66;--chakra-colors-jualoOutline-500:#ff9433;--chakra-colors-jualoOutline-600:#ff7900;--chakra-colors-jualoOutline-700:#e66d00;--chakra-colors-jualoOutline-800:#cc6100;--chakra-colors-jualoOutline-900:#994900;--chakra-borders-none:0;--chakra-borders-1px:1px solid;--chakra-borders-2px:2px solid;--chakra-borders-4px:4px solid;--chakra-borders-8px:8px solid;--chakra-fonts-heading:Roboto;--chakra-fonts-body:Roboto;--chakra-fonts-mono:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;--chakra-fontSizes-xs:0.75rem;--chakra-fontSizes-sm:0.875rem;--chakra-fontSizes-md:1rem;--chakra-fontSizes-lg:1.125rem;--chakra-fontSizes-xl:1.25rem;--chakra-fontSizes-2xl:1.5rem;--chakra-fontSizes-3xl:1.875rem;--chakra-fontSizes-4xl:2.25rem;--chakra-fontSizes-5xl:3rem;--chakra-fontSizes-6xl:3.75rem;--chakra-fontSizes-7xl:4.5rem;--chakra-fontSizes-8xl:6rem;--chakra-fontSizes-9xl:8rem;--chakra-fontWeights-hairline:100;--chakra-fontWeights-thin:200;--chakra-fontWeights-light:300;--chakra-fontWeights-normal:400;--chakra-fontWeights-medium:500;--chakra-fontWeights-semibold:600;--chakra-fontWeights-bold:700;--chakra-fontWeights-extrabold:800;--chakra-fontWeights-black:900;--chakra-letterSpacings-tighter:-0.05em;--chakra-letterSpacings-tight:-0.025em;--chakra-letterSpacings-normal:0;--chakra-letterSpacings-wide:0.025em;--chakra-letterSpacings-wider:0.05em;--chakra-letterSpacings-widest:0.1em;--chakra-lineHeights-3:.75rem;--chakra-lineHeights-4:1rem;--chakra-lineHeights-5:1.25rem;--chakra-lineHeights-6:1.5rem;--chakra-lineHeights-7:1.75rem;--chakra-lineHeights-8:2rem;--chakra-lineHeights-9:2.25rem;--chakra-lineHeights-10:2.5rem;--chakra-lineHeights-normal:normal;--chakra-lineHeights-none:1;--chakra-lineHeights-shorter:1.25;--chakra-lineHeights-short:1.375;--chakra-lineHeights-base:1.5;--chakra-lineHeights-tall:1.625;--chakra-lineHeights-taller:2;--chakra-radii-none:0;--chakra-radii-sm:0.125rem;--chakra-radii-base:0.25rem;--chakra-radii-md:0.375rem;--chakra-radii-lg:0.5rem;--chakra-radii-xl:0.75rem;--chakra-radii-2xl:1rem;--chakra-radii-3xl:1.5rem;--chakra-radii-full:9999px;--chakra-space-1:0.25rem;--chakra-space-2:0.5rem;--chakra-space-3:0.75rem;--chakra-space-4:1rem;--chakra-space-5:1.25rem;--chakra-space-6:1.5rem;--chakra-space-7:1.75rem;--chakra-space-8:2rem;--chakra-space-9:2.25rem;--chakra-space-10:2.5rem;--chakra-space-12:3rem;--chakra-space-14:3.5rem;--chakra-space-16:4rem;--chakra-space-20:5rem;--chakra-space-24:6rem;--chakra-space-28:7rem;--chakra-space-32:8rem;--chakra-space-36:9rem;--chakra-space-40:10rem;--chakra-space-44:11rem;--chakra-space-48:12rem;--chakra-space-52:13rem;--chakra-space-56:14rem;--chakra-space-60:15rem;--chakra-space-64:16rem;--chakra-space-72:18rem;--chakra-space-80:20rem;--chakra-space-96:24rem;--chakra-space-px:1px;--chakra-space-0\.5:0.125rem;--chakra-space-1\.5:0.375rem;--chakra-space-2\.5:0.625rem;--chakra-space-3\.5:0.875rem;--chakra-shadows-xs:0 0 0 1px rgba(0, 0, 0, 0.05);--chakra-shadows-sm:0 1px 2px 0 rgba(0, 0, 0, 0.05);--chakra-shadows-base:0 1px 3px 0 rgba(0, 0, 0, 0.1),0 1px 2px 0 rgba(0, 0, 0, 0.06);--chakra-shadows-md:0 4px 6px -1px rgba(0, 0, 0, 0.1),0 2px 4px -1px rgba(0, 0, 0, 0.06);--chakra-shadows-lg:0 10px 15px -3px rgba(0, 0, 0, 0.1),0 4px 6px -2px rgba(0, 0, 0, 0.05);--chakra-shadows-xl:0 20px 25px -5px rgba(0, 0, 0, 0.1),0 10px 10px -5px rgba(0, 0, 0, 0.04);--chakra-shadows-2xl:0 25px 50px -12px rgba(0, 0, 0, 0.25);--chakra-shadows-outline:0 0 0 3px rgba(255, 121, 0, 0.6);--chakra-shadows-inner:inset 0 2px 4px 0 rgba(0,0,0,0.06);--chakra-shadows-none:none;--chakra-shadows-dark-lg:rgba(0, 0, 0, 0.1) 0px 0px 0px 1px,rgba(0, 0, 0, 0.2) 0px 5px 10px,rgba(0, 0, 0, 0.4) 0px 15px 40px;--chakra-shadows-largeSoft:rgba(60, 64, 67, 0.15) 0px 2px 10px 6px;--chakra-sizes-1:0.25rem;--chakra-sizes-2:0.5rem;--chakra-sizes-3:0.75rem;--chakra-sizes-4:1rem;--chakra-sizes-5:1.25rem;--chakra-sizes-6:1.5rem;--chakra-sizes-7:1.75rem;--chakra-sizes-8:2rem;--chakra-sizes-9:2.25rem;--chakra-sizes-10:2.5rem;--chakra-sizes-12:3rem;--chakra-sizes-14:3.5rem;--chakra-sizes-16:4rem;--chakra-sizes-20:5rem;--chakra-sizes-24:6rem;--chakra-sizes-28:7rem;--chakra-sizes-32:8rem;--chakra-sizes-36:9rem;--chakra-sizes-40:10rem;--chakra-sizes-44:11rem;--chakra-sizes-48:12rem;--chakra-sizes-52:13rem;--chakra-sizes-56:14rem;--chakra-sizes-60:15rem;--chakra-sizes-64:16rem;--chakra-sizes-72:18rem;--chakra-sizes-80:20rem;--chakra-sizes-96:24rem;--chakra-sizes-px:1px;--chakra-sizes-0\.5:0.125rem;--chakra-sizes-1\.5:0.375rem;--chakra-sizes-2\.5:0.625rem;--chakra-sizes-3\.5:0.875rem;--chakra-sizes-max:max-content;--chakra-sizes-min:min-content;--chakra-sizes-full:100%;--chakra-sizes-3xs:14rem;--chakra-sizes-2xs:16rem;--chakra-sizes-xs:20rem;--chakra-sizes-sm:24rem;--chakra-sizes-md:28rem;--chakra-sizes-lg:32rem;--chakra-sizes-xl:36rem;--chakra-sizes-2xl:42rem;--chakra-sizes-3xl:48rem;--chakra-sizes-4xl:56rem;--chakra-sizes-5xl:64rem;--chakra-sizes-6xl:72rem;--chakra-sizes-7xl:80rem;--chakra-sizes-8xl:90rem;--chakra-sizes-container-sm:640px;--chakra-sizes-container-md:768px;--chakra-sizes-container-lg:1024px;--chakra-sizes-container-xl:1280px;--chakra-zIndices-hide:-1;--chakra-zIndices-auto:auto;--chakra-zIndices-base:0;--chakra-zIndices-docked:10;--chakra-zIndices-dropdown:1000;--chakra-zIndices-sticky:1100;--chakra-zIndices-banner:1200;--chakra-zIndices-overlay:1300;--chakra-zIndices-modal:1400;--chakra-zIndices-popover:1500;--chakra-zIndices-skipLink:1600;--chakra-zIndices-toast:1700;--chakra-zIndices-tooltip:1800;--chakra-transition-property-common:background-color,border-color,color,fill,stroke,opacity,box-shadow,transform;--chakra-transition-property-colors:background-color,border-color,color,fill,stroke;--chakra-transition-property-dimensions:width,height;--chakra-transition-property-position:left,right,top,bottom;--chakra-transition-property-background:background-color,background-image,background-position;--chakra-transition-easing-ease-in:cubic-bezier(0.4, 0, 1, 1);--chakra-transition-easing-ease-out:cubic-bezier(0, 0, 0.2, 1);--chakra-transition-easing-ease-in-out:cubic-bezier(0.4, 0, 0.2, 1);--chakra-transition-duration-ultra-fast:50ms;--chakra-transition-duration-faster:100ms;--chakra-transition-duration-fast:150ms;--chakra-transition-duration-normal:200ms;--chakra-transition-duration-slow:300ms;--chakra-transition-duration-slower:400ms;--chakra-transition-duration-ultra-slow:500ms;--chakra-blur-none:0;--chakra-blur-sm:4px;--chakra-blur-base:8px;--chakra-blur-md:12px;--chakra-blur-lg:16px;--chakra-blur-xl:24px;--chakra-blur-2xl:40px;--chakra-blur-3xl:64px;}
        </style>
        <style data-emotion="css-global 1jqlf9g">
            html{line-height:1.5;-webkit-text-size-adjust:100%;font-family:system-ui,sans-serif;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;touch-action:manipulation;}body{position:relative;min-height:100%;font-feature-settings:'kern';}*,*::before,*::after{border-width:0;border-style:solid;box-sizing:border-box;}main{display:block;}hr{border-top-width:1px;box-sizing:content-box;height:0;overflow:visible;}pre,code,kbd,samp{font-family:SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:1em;}a{background-color:transparent;color:inherit;-webkit-text-decoration:inherit;text-decoration:inherit;}abbr[title]{border-bottom:none;-webkit-text-decoration:underline;text-decoration:underline;-webkit-text-decoration:underline dotted;-webkit-text-decoration:underline dotted;text-decoration:underline dotted;}b,strong{font-weight:bold;}small{font-size:80%;}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline;}sub{bottom:-0.25em;}sup{top:-0.5em;}img{border-style:none;}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0;}button,input{overflow:visible;}button,select{text-transform:none;}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner{border-style:none;padding:0;}fieldset{padding:0.35em 0.75em 0.625em;}legend{box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal;}progress{vertical-align:baseline;}textarea{overflow:auto;}[type="checkbox"],[type="radio"]{box-sizing:border-box;padding:0;}[type="number"]::-webkit-inner-spin-button,[type="number"]::-webkit-outer-spin-button{-webkit-appearance:none!important;}input[type="number"]{-moz-appearance:textfield;}[type="search"]{-webkit-appearance:textfield;outline-offset:-2px;}[type="search"]::-webkit-search-decoration{-webkit-appearance:none!important;}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit;}details{display:block;}summary{display:-webkit-box;display:-webkit-list-item;display:-ms-list-itembox;display:list-item;}template{display:none;}[hidden]{display:none!important;}body,blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0;}button{background:transparent;padding:0;}fieldset{margin:0;padding:0;}ol,ul{margin:0;padding:0;}textarea{resize:vertical;}button,[role="button"]{cursor:pointer;}button::-moz-focus-inner{border:0!important;}table{border-collapse:collapse;}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit;}button,input,optgroup,select,textarea{padding:0;line-height:inherit;color:inherit;}img,svg,video,canvas,audio,iframe,embed,object{display:block;}img,video{max-width:100%;height:auto;}[data-js-focus-visible] :focus:not([data-focus-visible-added]){outline:none;box-shadow:none;}select::-ms-expand{display:none;}
        </style>
        <style data-emotion="css-global 1cebupr">
            body{font-family:Roboto;color:var(--chakra-colors-softBlack);background:var(--chakra-colors-white);transition-property:background-color;transition-duration:var(--chakra-transition-duration-normal);line-height:var(--chakra-lineHeights-base);font-size:14px;}*::-webkit-input-placeholder{color:var(--chakra-colors-gray-400);}*::-moz-placeholder{color:var(--chakra-colors-gray-400);}*:-ms-input-placeholder{color:var(--chakra-colors-gray-400);}*::placeholder{color:var(--chakra-colors-gray-400);}*,*::before,::after{border-color:var(--chakra-colors-gray-200);word-wrap:break-word;}a{color:#31c708ed;}
        </style>
        <form>
            <style data-emotion="css m8ae8x">
                .css-m8ae8x{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;background:#31c708ed;}.css-m8ae8x>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
            </style>
            <div class="chakra-stack css-m8ae8x">
                <style data-emotion="css nvjmib">
                    .css-nvjmib{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-lg);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;min-width:var(--chakra-sizes-container-lg);padding-top:var(--chakra-space-2);padding-bottom:var(--chakra-space-2);background:#31c708ed;}
                </style>
                <div class="chakra-container css-nvjmib">
                    <style data-emotion="css k008qs">
                        .css-k008qs{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}
                    </style>
                    <div class="css-k008qs">
                        <style data-emotion="css 1i4qqkf">
                            .css-1i4qqkf{-webkit-flex:150px 0;-ms-flex:150px 0;flex:150px 0;height:35px;}
                        </style>
                        <div class="css-1i4qqkf">
                            <style data-emotion="css f4h6uy">
                                .css-f4h6uy{transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-fast);transition-timing-function:var(--chakra-transition-easing-ease-out);cursor:pointer;-webkit-text-decoration:none;text-decoration:none;outline:2px solid transparent;outline-offset:2px;color:inherit;}.css-f4h6uy:hover,.css-f4h6uy[data-hover]{-webkit-text-decoration:underline;text-decoration:underline;}.css-f4h6uy:focus,.css-f4h6uy[data-focus]{box-shadow:var(--chakra-shadows-outline);}
                            </style>
                            <a class="chakra-link css-f4h6uy" href="/">
                                <style data-emotion="css 13i92dq">
                                    .css-13i92dq{height:35px;}
                                </style><img alt="logo IPOTOTO" src="img/logo.gif" class="chakra-image css-13i92dq" /></a>
                        </div>
                        <style data-emotion="css 1kerviy">
                            .css-1kerviy{width:500px;margin-left:15px;}
                        </style>
                        <div class="css-1kerviy">
                            <style data-emotion="css t31hxo">
                                .css-t31hxo{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;background:var(--chakra-colors-white);border-radius:4px;height:35px;}
                            </style>
                            <div class="css-t31hxo">
                                <style data-emotion="css 1bqnmih">
                                    .css-1bqnmih{-webkit-flex:1;-ms-flex:1;flex:1;position:relative;}
                                </style>
                                <div class="css-1bqnmih">
                                    <style data-emotion="css 1ebkgb7">
                                        .css-1ebkgb7{width:var(--chakra-sizes-full);}.css-1ebkgb7 .chakra-popover__popper{position:unset!important;}
                                    </style>
                                    <div class="css-1ebkgb7">
                                        <style data-emotion="css lhjrfp">
                                            .css-lhjrfp{width:100%;min-width:0px;outline:2px solid transparent;outline-offset:2px;position:relative;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);font-size:var(--chakra-fontSizes-md);-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);height:var(--chakra-sizes-10);border-radius:var(--chakra-radii-md);border:var(--chakra-borders-none);border-color:none;background:inherit;}.css-lhjrfp:hover,.css-lhjrfp[data-hover]{border-color:var(--chakra-colors-gray-300);}.css-lhjrfp[aria-readonly=true],.css-lhjrfp[readonly],.css-lhjrfp[data-readonly]{box-shadow:none!important;-webkit-user-select:all;-moz-user-select:all;-ms-user-select:all;user-select:all;}.css-lhjrfp[disabled],.css-lhjrfp[aria-disabled=true],.css-lhjrfp[data-disabled]{opacity:0.4;cursor:not-allowed;}.css-lhjrfp[aria-invalid=true],.css-lhjrfp[data-invalid]{border-color:#E53E3E;box-shadow:0 0 0 1px #E53E3E;}.css-lhjrfp:focus,.css-lhjrfp[data-focus]{box-shadow:var(--chakra-shadows-none);}
                                        </style>
                                        <input placeholder="BANDAR TOGEL ONLINE" style="border-radius:4px 0 0 4px;height:35px" class="chakra-input css-lhjrfp" />
                                        <style data-emotion="css 1qq679y">
                                            .css-1qq679y{z-index:10;}
                                        </style>
                                        <div style="visibility:hidden;position:absolute;min-width:max-content;inset:0 auto auto 0" class="chakra-popover__popper css-1qq679y">
                                            <style data-emotion="css 15e14s7">
                                                .css-15e14s7{position:absolute;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;--popper-bg:var(--chakra-colors-white);background:#232934;--popper-arrow-bg:var(--popper-bg);--popper-arrow-shadow-color:var(--chakra-colors-gray-200);width:var(--chakra-sizes-xs);border:var(--chakra-borders-none);border-color:inherit;border-radius:var(--chakra-radii-md);box-shadow:var(--chakra-shadows-base);z-index:var(--chakra-zIndices-popover);margin-top:var(--chakra-space-4);padding-top:var(--chakra-space-4);padding-bottom:var(--chakra-space-4);opacity:0;max-height:350px;overflow-y:auto;max-width:100%;top:15px;}.css-15e14s7:focus,.css-15e14s7[data-focus]{box-shadow:var(--chakra-shadows-none);}.chakra-ui-light .css-15e14s7,[data-theme=light] .css-15e14s7,.css-15e14s7[data-theme=light]{background:#ffffff;}
                                            </style>
                                            <section style="transform-origin:var(--popper-transform-origin);opacity:0;visibility:hidden;transform:scale(0.95) translateZ(0)" id="popover-content-3" tabindex="-1" role="dialog" class="chakra-popover__content css-15e14s7"></section>
                                        </div>
                                    </div>
                                </div>
                                <style data-emotion="css 17h1shp">
                                    .css-17h1shp{width:40px;height:35px;border:1px solid var(--chakra-colors-gray-300);border-radius:0 4px 4px 0;}
                                </style>
                                <div class="css-17h1shp">
                                    <style data-emotion="css 1ubuhpy">
                                        .css-1ubuhpy{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:auto;line-height:1.2;border-radius:var(--chakra-radii-md);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:35px;min-width:var(--chakra-sizes-10);font-size:var(--chakra-fontSizes-md);-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);background:var(--chakra-colors-transparent);padding:0px;color:#31c708ed;}.css-1ubuhpy:focus,.css-1ubuhpy[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-1ubuhpy[disabled],.css-1ubuhpy[aria-disabled=true],.css-1ubuhpy[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-1ubuhpy:hover,.css-1ubuhpy[data-hover]{background:none;}.css-1ubuhpy:active,.css-1ubuhpy[data-active]{background:var(--chakra-colors-gray-300);}
                                    </style>
                                    <button type="submit" class="chakra-button css-1ubuhpy" aria-label="Cari Iklan">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" aria-hidden="true" focusable="false" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <style data-emotion="css vxk2uk">
                            .css-vxk2uk{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-padding-start:var(--chakra-space-2);padding-inline-start:var(--chakra-space-2);-webkit-padding-end:var(--chakra-space-2);padding-inline-end:var(--chakra-space-2);cursor:pointer;color:var(--chakra-colors-white);height:35px;}
                        </style>
                        <div class="css-vxk2uk">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                <path fill="none" d="M0 0h24v24H0z"></path>
                                <path d="M12 2C8.13 2 5 5.13 5 9c0 1.74.5 3.37 1.41 4.84.95 1.54 2.2 2.86 3.16 4.4.47.75.81 1.45 1.17 2.26.26.55.47 1.5 1.26 1.5s1-.95 1.25-1.5c.37-.81.7-1.51 1.17-2.26.96-1.53 2.21-2.85 3.16-4.4C18.5 12.37 19 10.74 19 9c0-3.87-3.13-7-7-7zm0 9.75a2.5 2.5 0 010-5 2.5 2.5 0 010 5z"></path>
                            </svg>
                            <style data-emotion="css 184j7gx">
                                .css-184j7gx{-webkit-flex:1;-ms-flex:1;flex:1;white-space:nowrap;}
                            </style>
                            <div class="css-184j7gx">
                                <style data-emotion="css 1c6j008">
                                    .css-1c6j008{width:100%;min-width:0px;outline:2px solid transparent;outline-offset:2px;position:relative;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);font-size:var(--chakra-fontSizes-md);-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);height:var(--chakra-sizes-10);border-radius:var(--chakra-radii-md);border:1px solid;border-color:inherit;background:inherit;}.css-1c6j008:hover,.css-1c6j008[data-hover]{border-color:var(--chakra-colors-gray-300);}.css-1c6j008[aria-readonly=true],.css-1c6j008[readonly],.css-1c6j008[data-readonly]{box-shadow:none!important;-webkit-user-select:all;-moz-user-select:all;-ms-user-select:all;user-select:all;}.css-1c6j008[disabled],.css-1c6j008[aria-disabled=true],.css-1c6j008[data-disabled]{opacity:0.4;cursor:not-allowed;}.css-1c6j008[aria-invalid=true],.css-1c6j008[data-invalid]{border-color:#E53E3E;box-shadow:0 0 0 1px #E53E3E;}.css-1c6j008:focus,.css-1c6j008[data-focus]{z-index:1;border-color:#3182ce;box-shadow:0 0 0 1px #3182ce;}
                                </style>
                                <input type="hidden" value="" name="location" class="chakra-input css-1c6j008" />Indonesia</div>
                            <style data-emotion="css tp6i5m">
                                .css-tp6i5m{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;width:25px;}
                            </style>
                            <div class="css-tp6i5m">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M143 352.3L7 216.3c-9.4-9.4-9.4-24.6 0-33.9l22.6-22.6c9.4-9.4 24.6-9.4 33.9 0l96.4 96.4 96.4-96.4c9.4-9.4 24.6-9.4 33.9 0l22.6 22.6c9.4 9.4 9.4 24.6 0 33.9l-136 136c-9.2 9.4-24.4 9.4-33.8 0z"></path>
                                </svg>
                            </div>
                        </div>
                        <style data-emotion="css tthxno">
                            .css-tthxno{-webkit-padding-start:10px;padding-inline-start:10px;-webkit-padding-end:10px;padding-inline-end:10px;}
                        </style>
                        <div class="css-tthxno">
                            <style data-emotion="css 10qsrqw">
                                .css-10qsrqw{transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-fast);transition-timing-function:var(--chakra-transition-easing-ease-out);cursor:pointer;-webkit-text-decoration:none;text-decoration:none;outline:2px solid transparent;outline-offset:2px;color:inherit;}.css-10qsrqw:hover,.css-10qsrqw[data-hover]{-webkit-text-decoration:none;text-decoration:none;}.css-10qsrqw:focus,.css-10qsrqw[data-focus]{box-shadow:var(--chakra-shadows-outline);}
                            </style>
                            <a class="chakra-link css-10qsrqw" href="https://jmpghana.com/">
                                <style data-emotion="css 44i7ip">
                                    .css-44i7ip{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:auto;line-height:1.2;border-radius:var(--chakra-radii-md);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:35px;min-width:var(--chakra-sizes-10);font-size:13px;-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);background:var(--chakra-colors-gray-100);background-color:var(--chakra-colors-white);color:#31c708ed;}.css-44i7ip:focus,.css-44i7ip[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-44i7ip[disabled],.css-44i7ip[aria-disabled=true],.css-44i7ip[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-44i7ip:hover,.css-44i7ip[data-hover]{background-color:var(--chakra-colors-white);}.css-44i7ip:active,.css-44i7ip[data-active]{background-color:var(--chakra-colors-white);}
                                </style>
                            </a>
                        </div>
                            <style data-emotion="css kjvu41">
                                .css-kjvu41{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;outline:2px solid transparent;outline-offset:2px;transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);}
                            </style>
                                <style data-emotion="css xl71ch">
                                    .css-xl71ch{pointer-events:none;-webkit-flex:1 1 auto;-ms-flex:1 1 auto;flex:1 1 auto;min-width:0px;}
                                </style><span class="css-xl71ch"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16" color="white" style="color:white" height="30" width="30" xmlns="http://www.w3.org/2000/svg"><path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"></path></svg></span></button>
                            <style
                            data-emotion="css r6z5ec">.css-r6z5ec{z-index:1;}</style>
                                <div style="visibility:hidden;position:absolute;min-width:max-content;inset:0 auto auto 0" class="css-r6z5ec">
                                    <style data-emotion="css 1ozmk1d">
                                        .css-1ozmk1d{outline:2px solid transparent;outline-offset:2px;background:#fff;box-shadow:var(--chakra-shadows-sm);color:inherit;min-width:var(--chakra-sizes-3xs);padding-top:var(--chakra-space-2);padding-bottom:var(--chakra-space-2);z-index:1;border-radius:var(--chakra-radii-md);border-width:1px;}
                                    </style>
                                    <div tabindex="-1" role="menu" id="menu-list-7" style="transform-origin:var(--popper-transform-origin);opacity:0;visibility:hidden;transform:scale(0.8) translateZ(0)" aria-orientation="vertical" class="chakra-menu__menu-list css-1ozmk1d">
                                            <style data-emotion="css jcky2">
                                                .css-jcky2{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;padding:1em;}.css-jcky2>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
                                            </style>
                                            <div class="chakra-stack css-jcky2">
                                                <style data-emotion="css o9b5pe">
                                                    .css-o9b5pe{color:#31c708ed;}
                                                </style>
                                                <p class="chakra-text css-o9b5pe">Selamat Datang di Jualo!</p>
                                                <style data-emotion="css 2qeyl5">
                                                    .css-2qeyl5{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:100%;line-height:1.2;border-radius:var(--chakra-radii-md);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:var(--chakra-sizes-10);min-width:var(--chakra-sizes-10);font-size:var(--chakra-fontSizes-md);-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);background:var(--chakra-colors-jualoGreen-500);color:var(--chakra-colors-white);}.css-2qeyl5:focus,.css-2qeyl5[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-2qeyl5[disabled],.css-2qeyl5[aria-disabled=true],.css-2qeyl5[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-2qeyl5:hover,.css-2qeyl5[data-hover]{background:var(--chakra-colors-jualoGreen-600);}.css-2qeyl5:hover[disabled],.css-2qeyl5[data-hover][disabled],.css-2qeyl5:hover[aria-disabled=true],.css-2qeyl5[data-hover][aria-disabled=true],.css-2qeyl5:hover[data-disabled],.css-2qeyl5[data-hover][data-disabled]{background:var(--chakra-colors-jualoGreen-500);}.css-2qeyl5:active,.css-2qeyl5[data-active]{background:var(--chakra-colors-jualoGreen-700);}
                                                </style>
                                                <button type="button" class="chakra-button css-2qeyl5">LOGIN</button>
                                                <style data-emotion="css 1bkar60">
                                                    .css-1bkar60{font-size:0.9em;color:var(--chakra-colors-blackAlpha-500);}
                                                </style>
                                                <p class="chakra-text css-1bkar60">atau login dengan</p>
                                                <style data-emotion="css h81oz0">
                                                    .css-h81oz0{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin-bottom:var(--chakra-space-2)!important;}.css-h81oz0>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0.5rem;margin-inline-start:0.5rem;}
                                                </style>
                                                <div class="chakra-stack css-h81oz0">
                                                    <style data-emotion="css 1n4gq89">
                                                        .css-1n4gq89{transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-fast);transition-timing-function:var(--chakra-transition-easing-ease-out);cursor:pointer;-webkit-text-decoration:none;text-decoration:none;outline:2px solid transparent;outline-offset:2px;color:inherit;width:100%;}.css-1n4gq89:hover,.css-1n4gq89[data-hover]{-webkit-text-decoration:underline;text-decoration:underline;}.css-1n4gq89:focus,.css-1n4gq89[data-focus]{box-shadow:var(--chakra-shadows-outline);}
                                                    </style>
                                                    <a class="chakra-link link link-button d-ib css-1n4gq89">
                                                        <style data-emotion="css v1srn3">
                                                            .css-v1srn3{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:auto;line-height:1.2;border-radius:var(--chakra-radii-md);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:var(--chakra-sizes-10);min-width:var(--chakra-sizes-10);font-size:var(--chakra-fontSizes-md);-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);background:var(--chakra-colors-google-500);color:var(--chakra-colors-white);}.css-v1srn3:focus,.css-v1srn3[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-v1srn3[disabled],.css-v1srn3[aria-disabled=true],.css-v1srn3[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-v1srn3:hover,.css-v1srn3[data-hover]{background:var(--chakra-colors-google-600);}.css-v1srn3:hover[disabled],.css-v1srn3[data-hover][disabled],.css-v1srn3:hover[aria-disabled=true],.css-v1srn3[data-hover][aria-disabled=true],.css-v1srn3:hover[data-disabled],.css-v1srn3[data-hover][data-disabled]{background:var(--chakra-colors-google-500);}.css-v1srn3:active,.css-v1srn3[data-active]{background:var(--chakra-colors-google-700);}
                                                        </style>
                                                        <button type="button" class="chakra-button css-v1srn3">GOOGLE</button>
                                                    </a>
                                                </div>
                                                <style data-emotion="css svjswr">
                                                    .css-svjswr{opacity:0.6;border:0;border-color:inherit;border-style:solid;border-bottom-width:1px;width:100%;}
                                                </style>
                                                <hr aria-orientation="horizontal" class="chakra-divider css-svjswr" />
                                                <style data-emotion="css 15n5rrz">
                                                    .css-15n5rrz{font-size:0.9em;color:#31c708ed;}
                                                </style>
                                                <p class="chakra-text css-15n5rrz">Belum punya akun?</p>
                                                <style data-emotion="css 120aj2d">
                                                    .css-120aj2d{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:100%;line-height:1.2;border-radius:var(--chakra-radii-md);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:var(--chakra-sizes-10);min-width:var(--chakra-sizes-10);font-size:var(--chakra-fontSizes-md);-webkit-padding-start:var(--chakra-space-4);padding-inline-start:var(--chakra-space-4);-webkit-padding-end:var(--chakra-space-4);padding-inline-end:var(--chakra-space-4);background:#31c708ed;color:var(--chakra-colors-white);}.css-120aj2d:focus,.css-120aj2d[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-120aj2d[disabled],.css-120aj2d[aria-disabled=true],.css-120aj2d[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-120aj2d:hover,.css-120aj2d[data-hover]{background:var(--chakra-colors-jualo-600);}.css-120aj2d:hover[disabled],.css-120aj2d[data-hover][disabled],.css-120aj2d:hover[aria-disabled=true],.css-120aj2d[data-hover][aria-disabled=true],.css-120aj2d:hover[data-disabled],.css-120aj2d[data-hover][data-disabled]{background:#31c708ed;}.css-120aj2d:active,.css-120aj2d[data-active]{background:var(--chakra-colors-jualo-700);}
                                                </style>
                                                <button type="button" class="chakra-button css-120aj2d">DAFTAR</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <main>
            <style data-emotion="css y1qfiu">
                .css-y1qfiu{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;background-color:white;color:var(--chakra-colors-greyLightColor);min-width:var(--chakra-sizes-container-lg);}.css-y1qfiu>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
            </style>
            <div class="chakra-stack pb8 pt8 css-y1qfiu">
                <style data-emotion="css x88fgc">
                    .css-x88fgc{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-xl);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;min-width:var(--chakra-sizes-container-lg);background:var(--chakra-colors-greyLightBackground);}
                </style>
                <div class="chakra-container mb4 css-x88fgc">
                    <style data-emotion="css 1ihqho8">
                        .css-1ihqho8{background:var(--chakra-colors-white);border-radius:4px;padding:15px 27px;font-size:13px;}
                    </style>
                    <div class="css-1ihqho8">
                        <nav aria-label="Breadcrumb" style="font-family:Arial, sans-serif;">
                            <ul style="list-style:none; display:flex; flex-wrap:wrap; gap:8px; padding:0; margin:0;">
                                <li>
                                    <a href="https://jmpghana.com/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#0a6; text-decoration:none; border:1px solid #e5e7eb;">BANDAR TOGEL</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://jmpghana.com/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#0a6; text-decoration:none; border:1px solid #e5e7eb;">TOGEL ONLINE</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://jmpghana.com/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#0a6; text-decoration:none; border:1px solid #e5e7eb;">SITUS TOTO</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://jmpghana.com/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#0a6; text-decoration:none; border:1px solid #e5e7eb;">SITUS TOGEL</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://jmpghana.com/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#0a6; text-decoration:none; border:1px solid #e5e7eb;">TOTO TOGEL</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://jmpghana.com/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#0a6; text-decoration:none; border:1px solid #e5e7eb;">SITUS TOGEL ONLINE</a></li>
                                <li> / </li>
                                <li style="padding:6px 12px; border-radius:999px; background:#fff; border:1px solid #e5e7eb; color:#0ba0db;">IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026</li>
                            </ul>
                        </nav>

                    </div>
                    <style>.n-columns-2{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;font-weight:700}.n-columns-2 a{text-align:center;color:#fff;padding:14px 12px;border-radius:12px;text-decoration:none;position:relative;overflow:hidden;transition:transform .3s ease,box-shadow .3s ease}.n-columns-2 a:hover{transform:translateY(-4px) scale(1.03);box-shadow:0 6px 15px rgba(0,0,0,.4)}.n-columns-2 a::before{content:"";position:absolute;top:0;left:0;width:200%;height:100%;background:linear-gradient(120deg,#31c708ed,#000000,#0000CD,#000000,#31c708ed);background-size:300% 100%;animation:gradientRun 4s linear infinite;z-index:0}.n-columns-2 a span{position:relative;z-index:1}@keyframes gradientRun{0%{background-position:0% 50%}100%{background-position:-200% 50%}}.login{border:2px solid #31c708ed}.register{border:2px solid #31c708ed}</style>
                        <div class="n-columns-2">
                            <a href="https://jmpghana.pages.dev/" class="login"><span>LOGIN</span></a>

                            <a href="https://jmpghana.pages.dev/" class="register"><span>DAFTAR</span></a>
                        </div>
                </div>
                <style data-emotion="css 1qv31ul">
                    .css-1qv31ul{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-xl);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;min-width:var(--chakra-sizes-container-lg);}
                </style>
                <div class="chakra-container mb4 css-1qv31ul">
                    <br>
                    <style
                    data-emotion="css fn70in">.css-fn70in{display:grid;grid-gap:var(--chakra-space-4);grid-template-columns:repeat(8, 1fr);margin-bottom:var(--chakra-space-8);}</style>
                        <div class="css-fn70in">
                            <style data-emotion="css 123q9jn">
                                .css-123q9jn{grid-column:span 5/span 5;padding:var(--chakra-space-4);background:var(--chakra-colors-white);border-radius:4px;box-shadow:var(--chakra-shadows-base);}
                            </style>
                            <div class="css-123q9jn">
                                <style data-emotion="css 1cm05pq">
                                    .css-1cm05pq{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;max-width:582px;}.css-1cm05pq>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}@media screen and (min-width: 80em){.css-1cm05pq{max-width:742px;}}
                                </style>
                                <div class="chakra-stack css-1cm05pq">
                                    <div class="css-0">
                                        <style data-emotion="css 1m52a9y">
                                            .css-1m52a9y .slider-wrapper{background:rgba(0, 0, 0, 0.1);}.css-1m52a9y .slide>div>img{max-height:600px;min-height:300px;width:auto;}.css-1m52a9y .thumbs-wrapper.axis-vertical{text-align:center;}.css-1m52a9y .thumbs-wrapper.axis-vertical .thumbs{display:inline-block;}.css-1m52a9y .carousel .control-arrow,.css-1m52a9y .carousel.carousel-slider .control-arrow{opacity:1;width:50px;}.css-1m52a9y .carousel.carousel-slider .control-arrow:hover{background:rgba(255, 255, 255, 0.2);}.css-1m52a9y .carousel .thumb.selected,.css-1m52a9y .carousel .thumb:hover{border-color:#31c708ed;}.css-1m52a9y .carousel .control-prev.control-arrow:before{border-right:8px solid #31c708ed;}.css-1m52a9y .carousel .control-next.control-arrow:before{border-left:8px solid #31c708ed;}
                                        </style>
                                        <div class="carousel-root css-1m52a9y">
                                            <div class="carousel carousel-slider" style="width:100%">
                                                <ul class="control-dots">
                                                    <li class="dot selected" value="0" role="button" tabindex="0" aria-label="slide item 1"></li>
                                                    <li class="dot" value="1" role="button" tabindex="0" aria-label="slide item 2"></li>
                                                    <li class="dot" value="2" role="button" tabindex="0" aria-label="slide item 3"></li>
                                                    <li class="dot" value="3" role="button" tabindex="0" aria-label="slide item 4"></li>
                                                    <li class="dot" value="4" role="button" tabindex="0" aria-label="slide item 5"></li>
                                                </ul>
                                                <button type="button" aria-label="previous slide / item" class="control-arrow control-prev"></button>
                                                <div class="slider-wrapper axis-horizontal" style="height:auto">
                                                    <ul class="slider animated" style="-webkit-transform:translate3d(-100%,0,0);-ms-transform:translate3d(-100%,0,0);-o-transform:translate3d(-100%,0,0);transform:translate3d(-100%,0,0);-webkit-transition-duration:350ms;-moz-transition-duration:350ms;-o-transition-duration:350ms;transition-duration:350ms;-ms-transition-duration:350ms">
                                                        <li class="slide">
                                                        </li>
                                                        <li style="background-color: #FFFFFF;" class="slide selected previous">
                                                            <div><img src="img/banner.jpg" alt="IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026" /></div>
                                                    </div>
                                                </div>
                                            <div class="carousel">
                                                <div class="thumbs-wrapper axis-vertical">
                                                    <button type="button" class="control-arrow control-prev control-disabled" aria-label="previous slide / item"></button>
                                                    <ul class="thumbs animated" style="-webkit-transform:translate3d(0,0,0);-moz-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);-o-transform:translate3d(0,0,0);transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);-webkit-transition-duration:350ms;-moz-transition-duration:350ms;-ms-transition-duration:350ms;-o-transition-duration:350ms;transition-duration:350ms;-ms-transition-duration:350ms">
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <style data-emotion="css 3ox7k">
                                        .css-3ox7k{margin-bottom:var(--chakra-space-3);color:var(--chakra-colors-softBlack);}
                                    </style>
                                    
                                    <div class="css-3ox7k">
                                        <style data-emotion="css 1mnao0q">
                                            .css-1mnao0q{font-family:var(--chakra-fonts-heading);font-weight:var(--chakra-fontWeights-bold);font-size:var(--chakra-fontSizes-md);line-height:1.2;margin-bottom:var(--chakra-space-2);}
                                        </style>
                                        <h5 class="chakra-heading css-1nmao0q" style="text-align:center;"><strong>INFORMASI RESMI SITUS IPOTOTO</strong></h5><br>
                                        <style data-emotion="css svjswr">
                                            .css-svjswr{opacity:0.6;border:0;border-color:inherit;border-style:solid;border-bottom-width:1px;width:100%;}
                                        <style>.info-table-wrapper{font-family:system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background-color:#ffffff;border-radius:12px;box-shadow:0 8px 25px rgba(0,0,0,.07);overflow:hidden;border:1px solid #000000}.info-table{width:100%;border-collapse:collapse}.info-table th,.info-table td{padding:16px 20px;text-align:left;border-bottom:1px solid #000000;font-size:14px;vertical-align:middle}/* Menghilangkan border pada baris terakhir */.info-table tr:last-child th,.info-table tr:last-child td{border-bottom:none}.info-table th{font-weight:600;color:#FFFFFF;background-color:#31c708ed;width:25%}.info-table td{color:#111;font-weight:500}</style>

                                        <div class="info-table-wrapper">
                                            <table class="info-table">
                                                <tbody>
                                                    <tr>
                                                        <th>NAMA SITUS</th>
                                                        <td>IPOTOTO</td>
                                                    </tr>
                                                   <tr>
                                                        <th>JENIS GAME</th>
                                                        <td>TOGEL ONLINE, LIVE CASINO, SLOT ONLINE</td>
                                                    </tr>
                                                    <tr>
                                                        <th>MINIMAL DEPOSIT</th>
                                                        <td>Rp 5.000,-</td>
                                                    </tr>
                                                    <tr>
                                                        <th>MINIMAL WITHDRAW</th>
                                                        <td>Rp 25.000,-</td>
                                                    </tr>
                                                    <tr>
                                                        <th>TRANSAKSI PEMBAYARAN</th>
                                                        <td>Transfer Bank, E-Wallet, Scan Qris</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Lisensi</th>
                                                        <td>100% Resmi & Terpercaya</td>
                                                    </tr>
                                                    <tr>
                                                        <th>RATING</th>
                                                        <td>⭐⭐⭐⭐⭐ 1.117.890.011 Pengguna</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                      <br>
                                    <br>
                                    </div>
                                    <style>.article-box{max-width:900px;margin:30px auto;background:#ffffff;border-radius:18px;box-shadow:0 8px 28px rgba(0,0,0,0.1);padding:30px 35px;font-family:"Poppins",sans-serif;line-height:1.7;color:#333}.article-box h2,.article-box h5{color:#222;font-weight:700;margin-bottom:15px}.article-box h5{font-size:1.2rem;text-align:center;border-bottom:2px solid #ff6b00;padding-bottom:10px;margin-bottom:25px}.article-box p{margin-bottom:18px;font-size:0.95rem}.article-box strong{color:#ff6b00}.article-box hr{border:0;border-top:1px solid #eee;margin:20px 0}</style>

                                        <div class="article-box">
                                            <center><h2>
                                                IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026
                                            </h2></center>
                                                <br>
                                            <p style="text-align: justify;">
                                                <a href="https://jmpghana.com/">IPOTOTO</a> atau yang biasa di kenal dengan situs toto togel & bandar togel online No.1 paling populer di Indonesia, situs ini menyediakan berbagai macam pasaran togel terlengkap, dengan bayaran togel paling besar, serta bonus melimpah dengan. Situs ini sudah sangat populer di kalangan pemain togel di Indonesia, sangat cocok untuk kamu yang sedang bingung mencari situs toto togel terpercaya, jadi jangan salah dalam memilih situs, pilih IPOTOTO, situs ini sudah sangat di rekomendasikan untuk kamu yang mencari situs toto togel yang efektif dan banyak sekali cuan.
                                            </p>
                                        </div>
                                </div>
                            </div>
                            <style data-emotion="css rklm6r">
                                .css-rklm6r{grid-column:span 3/span 3;}
                            </style>
                            <div class="css-rklm6r">
                                <style data-emotion="css o5l3sd">
                                    .css-o5l3sd{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}.css-o5l3sd>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
                                </style>
                                <div class="chakra-stack css-o5l3sd">
                                    <style data-emotion="css nscce0">
                                        .css-nscce0{padding:var(--chakra-space-4);background:var(--chakra-colors-white);border-radius:4px;box-shadow:var(--chakra-shadows-base);margin-bottom:var(--chakra-space-3);}
                                    </style>
                                    <div class="css-nscce0">
                                        <style data-emotion="css 1pih5ef">
                                            .css-1pih5ef{display:grid;grid-gap:var(--chakra-space-2);grid-template-columns:repeat(9, 1fr);margin-bottom:var(--chakra-space-3);}
                                        </style>
                                        <div class="css-1pih5ef">
                                            <style data-emotion="css 142n66a">
                                                .css-142n66a{grid-column:span 6/span 6;}
                                            </style>
                                            <div class="css-142n66a">
                                                <style data-emotion="css 1l0cik9">
                                                    .css-1l0cik9{font-family:var(--chakra-fonts-heading);font-weight:var(--chakra-fontWeights-bold);font-size:20px;line-height:1.33;color:var(--chakra-colors-softBlack);margin-bottom:var(--chakra-space-3);}@media screen and (min-width: 48em){.css-1l0cik9{line-height:1.2;}}
                                                </style>
                                                <h1 class="chakra-heading css-1l0cik9">IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026</h1>
                                                <p>IPOTOTO adalah situs toto togel 4d paling terpercaya & bandar togel online paling viral hari ini 2026 no 1 di Indonesia, dengan pasaran terlengkap, diskon besar, dan hadiah terbaik!</p>
                                                <style data-emotion="css l0chkq">
                                                    .css-l0chkq{font-size:18px;color:#e98606;margin-bottom:var(--chakra-space-3);}
                                                </style>
                                                <p class="chakra-text css-l0chkq"><strong>Rp.5.000 ,-</strong></p>
                                                <style data-emotion="css l8qto0">
                                                    .css-l8qto0{font-size:15px;}
                                                </style>
                                                <p class="chakra-text css-l8qto0">
                                                    <style data-emotion="css 1fjwirh">
                                                        .css-1fjwirh{width:15px;height:15px;}
                                                    </style><img alt="Geolocation Icon" src="img/pop-up.jpg" class="icon-left css-1fjwirh" />Ibu Kota Jakarta</p>
                                            </div>
                                            <div class="css-rklm6r">
                                                <style data-emotion="css tvyf0t">
                                                    .css-tvyf0t{display:grid;grid-gap:var(--chakra-space-1);grid-template-columns:repeat(2, 1fr);}
                                                </style>
                                                <div class="css-tvyf0t">
                                                    <div class="css-0">
                                                        <style data-emotion="css 1c9xqgg">
                                                            .css-1c9xqgg{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:55px;line-height:1.2;border-radius:var(--chakra-radii-full);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:55px;min-width:var(--chakra-sizes-12);font-size:var(--chakra-fontSizes-lg);-webkit-padding-start:var(--chakra-space-6);padding-inline-start:var(--chakra-space-6);-webkit-padding-end:var(--chakra-space-6);padding-inline-end:var(--chakra-space-6);border:1px solid;border-color:currentColor;color:purple;background:var(--chakra-colors-transparent);padding:0px;box-shadow:var(--chakra-shadows-base);}.css-1c9xqgg:focus,.css-1c9xqgg[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-1c9xqgg[disabled],.css-1c9xqgg[aria-disabled=true],.css-1c9xqgg[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-1c9xqgg:hover,.css-1c9xqgg[data-hover]{background:var(--chakra-colors-jualoOutline-50);}.css-1c9xqgg:hover[disabled],.css-1c9xqgg[data-hover][disabled],.css-1c9xqgg:hover[aria-disabled=true],.css-1c9xqgg[data-hover][aria-disabled=true],.css-1c9xqgg:hover[data-disabled],.css-1c9xqgg[data-hover][data-disabled]{background:initial;}.css-1c9xqgg:active,.css-1c9xqgg[data-active]{background:var(--chakra-colors-jualoOutline-100);}
                                                        </style>
                                                        <button type="button" class="chakra-button css-1c9xqgg" aria-label="Bagikan iklan ini" id="popover-trigger-10" aria-haspopup="dialog" aria-expanded="false" aria-controls="popover-content-10">
                                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" aria-hidden="true" focusable="false" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M503.691 189.836L327.687 37.851C312.281 24.546 288 35.347 288 56.015v80.053C127.371 137.907 0 170.1 0 322.326c0 61.441 39.581 122.309 83.333 154.132 13.653 9.931 33.111-2.533 28.077-18.631C66.066 312.814 132.917 274.316 288 272.085V360c0 20.7 24.3 31.453 39.687 18.164l176.004-152c11.071-9.562 11.086-26.753 0-36.328z"></path>
                                                            </svg>
                                                        </button>
                                                        <style data-emotion="css 1qq679y">
                                                            .css-1qq679y{z-index:10;}
                                                        </style>
                                                        <div style="visibility:hidden;position:absolute;min-width:max-content;inset:0 auto auto 0" class="chakra-popover__popper css-1qq679y">
                                                            <style data-emotion="css 1kc7s1q">
                                                                .css-1kc7s1q{position:relative;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;--popper-bg:var(--chakra-colors-white);background:var(--popper-bg);--popper-arrow-bg:var(--popper-bg);--popper-arrow-shadow-color:var(--chakra-colors-gray-200);width:var(--chakra-sizes-xs);border:1px solid;border-color:inherit;border-radius:var(--chakra-radii-md);box-shadow:var(--chakra-shadows-sm);z-index:inherit;}.css-1kc7s1q:focus,.css-1kc7s1q[data-focus]{outline:2px solid transparent;outline-offset:2px;box-shadow:var(--chakra-shadows-outline);}
                                                            </style>
                                                            <section style="transform-origin:var(--popper-transform-origin);opacity:0;visibility:hidden;transform:scale(0.95) translateZ(0)" id="popover-content-10" tabindex="-1" role="dialog" class="chakra-popover__content css-1kc7s1q">
                                                                <div data-popper-arrow="" style="position:absolute" class="chakra-popover__arrow-positioner css-0">
                                                                    <div class="chakra-popover__arrow css-0" data-popper-arrow-inner=""></div>
                                                                </div>
                                                                <style data-emotion="css qdkz81">
                                                                    .css-qdkz81{outline:2px solid transparent;outline-offset:2px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;width:var(--close-button-size);height:var(--close-button-size);border-radius:var(--chakra-radii-md);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);--close-button-size:24px;font-size:10px;position:absolute;top:var(--chakra-space-1);right:var(--chakra-space-2);padding:var(--chakra-space-2);}.css-qdkz81[disabled],.css-qdkz81[aria-disabled=true],.css-qdkz81[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-qdkz81:hover,.css-qdkz81[data-hover]{background:var(--chakra-colors-blackAlpha-100);}.css-qdkz81:active,.css-qdkz81[data-active]{background:var(--chakra-colors-blackAlpha-200);}.css-qdkz81:focus,.css-qdkz81[data-focus]{box-shadow:var(--chakra-shadows-outline);}
                                                                </style>
                                                                <button type="button" aria-label="Close" class="chakra-popover__close-btn css-qdkz81">
                                                                    <style data-emotion="css onkibi">
                                                                        .css-onkibi{width:1em;height:1em;display:inline-block;line-height:1em;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;color:currentColor;vertical-align:middle;}
                                                                    </style>
                                                                    <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-onkibi" aria-hidden="true">
                                                                        <path fill="currentColor" d="M.439,21.44a1.5,1.5,0,0,0,2.122,2.121L11.823,14.3a.25.25,0,0,1,.354,0l9.262,9.263a1.5,1.5,0,1,0,2.122-2.121L14.3,12.177a.25.25,0,0,1,0-.354l9.263-9.262A1.5,1.5,0,0,0,21.439.44L12.177,9.7a.25.25,0,0,1-.354,0L2.561.44A1.5,1.5,0,0,0,.439,2.561L9.7,11.823a.25.25,0,0,1,0,.354Z"></path>
                                                                    </svg>
                                                                </button>
                                                                <style data-emotion="css f53cf8">
                                                                    .css-f53cf8{-webkit-padding-start:var(--chakra-space-3);padding-inline-start:var(--chakra-space-3);-webkit-padding-end:var(--chakra-space-3);padding-inline-end:var(--chakra-space-3);padding-top:var(--chakra-space-4);padding-bottom:var(--chakra-space-2);border-bottom-width:1px;font-weight:var(--chakra-fontWeights-bold);border:0;}
                                                                </style>
                                                                <header id="popover-header-10" class="chakra-popover__header css-f53cf8">BAGIKAN IKLAN INI</header>
                                                                <style data-emotion="css 1ews2c8">
                                                                    .css-1ews2c8{-webkit-padding-start:var(--chakra-space-3);padding-inline-start:var(--chakra-space-3);-webkit-padding-end:var(--chakra-space-3);padding-inline-end:var(--chakra-space-3);padding-top:var(--chakra-space-2);padding-bottom:var(--chakra-space-2);}
                                                                </style>
                                                                <div id="popover-body-10" class="chakra-popover__body css-1ews2c8">
                                                                    <style data-emotion="css 3guv68">
                                                                        .css-3guv68{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:normal;-webkit-box-align:normal;-ms-flex-align:normal;align-items:normal;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;}.css-3guv68>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:var(--chakra-space-2);margin-inline-start:var(--chakra-space-2);}
                                                                    </style>
                                                                    <div class="chakra-stack css-3guv68">
                                                                        <div class="css-0">
                                                                            <style data-emotion="css 15t1k91">
                                                                                .css-15t1k91{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:auto;line-height:1.2;border-radius:100%;font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:36px;min-width:var(--chakra-sizes-8);font-size:var(--chakra-fontSizes-sm);-webkit-padding-start:var(--chakra-space-3);padding-inline-start:var(--chakra-space-3);-webkit-padding-end:var(--chakra-space-3);padding-inline-end:var(--chakra-space-3);background:#31c708ed;color:var(--chakra-colors-white);padding:10px;}.css-15t1k91:focus,.css-15t1k91[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-15t1k91[disabled],.css-15t1k91[aria-disabled=true],.css-15t1k91[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-15t1k91:hover,.css-15t1k91[data-hover]{background:var(--chakra-colors-jualo-600);}.css-15t1k91:hover[disabled],.css-15t1k91[data-hover][disabled],.css-15t1k91:hover[aria-disabled=true],.css-15t1k91[data-hover][aria-disabled=true],.css-15t1k91:hover[data-disabled],.css-15t1k91[data-hover][data-disabled]{background:#31c708ed;}.css-15t1k91:active,.css-15t1k91[data-active]{background:var(--chakra-colors-jualo-700);}
                                                                            </style>
                                                                            <button type="button" class="chakra-button css-15t1k91" aria-label="Copy link">
                                                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" aria-hidden="true" focusable="false" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M326.612 185.391c59.747 59.809 58.927 155.698.36 214.59-.11.12-.24.25-.36.37l-67.2 67.2c-59.27 59.27-155.699 59.262-214.96 0-59.27-59.26-59.27-155.7 0-214.96l37.106-37.106c9.84-9.84 26.786-3.3 27.294 10.606.648 17.722 3.826 35.527 9.69 52.721 1.986 5.822.567 12.262-3.783 16.612l-13.087 13.087c-28.026 28.026-28.905 73.66-1.155 101.96 28.024 28.579 74.086 28.749 102.325.51l67.2-67.19c28.191-28.191 28.073-73.757 0-101.83-3.701-3.694-7.429-6.564-10.341-8.569a16.037 16.037 0 0 1-6.947-12.606c-.396-10.567 3.348-21.456 11.698-29.806l21.054-21.055c5.521-5.521 14.182-6.199 20.584-1.731a152.482 152.482 0 0 1 20.522 17.197zM467.547 44.449c-59.261-59.262-155.69-59.27-214.96 0l-67.2 67.2c-.12.12-.25.25-.36.37-58.566 58.892-59.387 154.781.36 214.59a152.454 152.454 0 0 0 20.521 17.196c6.402 4.468 15.064 3.789 20.584-1.731l21.054-21.055c8.35-8.35 12.094-19.239 11.698-29.806a16.037 16.037 0 0 0-6.947-12.606c-2.912-2.005-6.64-4.875-10.341-8.569-28.073-28.073-28.191-73.639 0-101.83l67.2-67.19c28.239-28.239 74.3-28.069 102.325.51 27.75 28.3 26.872 73.934-1.155 101.96l-13.087 13.087c-4.35 4.35-5.769 10.79-3.783 16.612 5.864 17.194 9.042 34.999 9.69 52.721.509 13.906 17.454 20.446 27.294 10.606l37.106-37.106c59.271-59.259 59.271-155.699.001-214.959z"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                        <div class="css-0">
                                                                            <button aria-label="facebook" class="react-share__ShareButton" style="background-color:transparent;border:none;padding:0;font:inherit;color:inherit;cursor:pointer">
                                                                                <svg viewBox="0 0 64 64" width="34" height="34">
                                                                                    <circle cx="32" cy="32" r="31" fill="#3b5998"></circle>
                                                                                    <path d="M34.1,47V33.3h4.6l0.7-5.3h-5.3v-3.4c0-1.5,0.4-2.6,2.6-2.6l2.8,0v-4.8c-0.5-0.1-2.2-0.2-4.1-0.2 c-4.1,0-6.9,2.5-6.9,7V28H24v5.3h4.6V47H34.1z" fill="white"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                        <div class="css-0">
                                                                            <button aria-label="whatsapp" class="react-share__ShareButton" style="background-color:transparent;border:none;padding:0;font:inherit;color:inherit;cursor:pointer">
                                                                                <svg viewBox="0 0 64 64" width="36" height="36">
                                                                                    <circle cx="32" cy="32" r="31" fill="#25D366"></circle>
                                                                                    <path d="m42.32286,33.93287c-0.5178,-0.2589 -3.04726,-1.49644 -3.52105,-1.66732c-0.4712,-0.17346 -0.81554,-0.2589 -1.15987,0.2589c-0.34175,0.51004 -1.33075,1.66474 -1.63108,2.00648c-0.30032,0.33658 -0.60064,0.36247 -1.11327,0.12945c-0.5178,-0.2589 -2.17994,-0.80259 -4.14759,-2.56312c-1.53269,-1.37217 -2.56312,-3.05503 -2.86603,-3.57283c-0.30033,-0.5178 -0.03366,-0.80259 0.22524,-1.06149c0.23301,-0.23301 0.5178,-0.59547 0.7767,-0.90616c0.25372,-0.31068 0.33657,-0.5178 0.51262,-0.85437c0.17088,-0.36246 0.08544,-0.64725 -0.04402,-0.90615c-0.12945,-0.2589 -1.15987,-2.79613 -1.58964,-3.80584c-0.41424,-1.00971 -0.84142,-0.88027 -1.15987,-0.88027c-0.29773,-0.02588 -0.64208,-0.02588 -0.98382,-0.02588c-0.34693,0 -0.90616,0.12945 -1.37736,0.62136c-0.4712,0.5178 -1.80194,1.76053 -1.80194,4.27186c0,2.51134 1.84596,4.945 2.10227,5.30747c0.2589,0.33657 3.63497,5.51458 8.80262,7.74113c1.23237,0.5178 2.1903,0.82848 2.94111,1.08738c1.23237,0.38836 2.35599,0.33657 3.24402,0.20712c0.99159,-0.15534 3.04985,-1.24272 3.47963,-2.45956c0.44013,-1.21683 0.44013,-2.22654 0.31068,-2.45955c-0.12945,-0.23301 -0.46601,-0.36247 -0.98382,-0.59548m-9.40068,12.84407l-0.02589,0c-3.05503,0 -6.08417,-0.82849 -8.72495,-2.38189l-0.62136,-0.37023l-6.47252,1.68286l1.73463,-6.29129l-0.41424,-0.64725c-1.70875,-2.71846 -2.6149,-5.85116 -2.6149,-9.07706c0,-9.39809 7.68934,-17.06155 17.15993,-17.06155c4.58253,0 8.88029,1.78642 12.11655,5.02268c3.23625,3.21036 5.02267,7.50812 5.02267,12.06476c-0.0078,9.3981 -7.69712,17.06155 -17.14699,17.06155m14.58906,-31.58846c-3.93529,-3.80584 -9.1133,-5.95471 -14.62789,-5.95471c-11.36055,0 -20.60848,9.2065 -20.61625,20.52564c0,3.61684 0.94757,7.14565 2.75211,10.26282l-2.92557,10.63564l10.93337,-2.85309c3.0136,1.63108 6.4052,2.4958 9.85634,2.49839l0.01037,0c11.36574,0 20.61884,-9.2091 20.62403,-20.53082c0,-5.48093 -2.14111,-10.64081 -6.03239,-14.51915"
                                                                                    fill="white"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                        <div class="css-0">
                                                                            <button aria-label="linkedin" class="react-share__ShareButton" style="background-color:transparent;border:none;padding:0;font:inherit;color:inherit;cursor:pointer">
                                                                                <svg viewBox="0 0 64 64" width="36" height="36">
                                                                                    <circle cx="32" cy="32" r="31" fill="#007fb1"></circle>
                                                                                    <path d="M20.4,44h5.4V26.6h-5.4V44z M23.1,18c-1.7,0-3.1,1.4-3.1,3.1c0,1.7,1.4,3.1,3.1,3.1 c1.7,0,3.1-1.4,3.1-3.1C26.2,19.4,24.8,18,23.1,18z M39.5,26.2c-2.6,0-4.4,1.4-5.1,2.8h-0.1v-2.4h-5.2V44h5.4v-8.6 c0-2.3,0.4-4.5,3.2-4.5c2.8,0,2.8,2.6,2.8,4.6V44H46v-9.5C46,29.8,45,26.2,39.5,26.2z"
                                                                                    fill="white"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                        <div class="css-0">
                                                                            <button aria-label="twitter" class="react-share__ShareButton" style="background-color:transparent;border:none;padding:0;font:inherit;color:inherit;cursor:pointer">
                                                                                <svg viewBox="0 0 64 64" width="36" height="36">
                                                                                    <circle cx="32" cy="32" r="31" fill="#00aced"></circle>
                                                                                    <path d="M48,22.1c-1.2,0.5-2.4,0.9-3.8,1c1.4-0.8,2.4-2.1,2.9-3.6c-1.3,0.8-2.7,1.3-4.2,1.6 C41.7,19.8,40,19,38.2,19c-3.6,0-6.6,2.9-6.6,6.6c0,0.5,0.1,1,0.2,1.5c-5.5-0.3-10.3-2.9-13.5-6.9c-0.6,1-0.9,2.1-0.9,3.3 c0,2.3,1.2,4.3,2.9,5.5c-1.1,0-2.1-0.3-3-0.8c0,0,0,0.1,0,0.1c0,3.2,2.3,5.8,5.3,6.4c-0.6,0.1-1.1,0.2-1.7,0.2c-0.4,0-0.8,0-1.2-0.1 c0.8,2.6,3.3,4.5,6.1,4.6c-2.2,1.8-5.1,2.8-8.2,2.8c-0.5,0-1.1,0-1.6-0.1c2.9,1.9,6.4,2.9,10.1,2.9c12.1,0,18.7-10,18.7-18.7 c0-0.3,0-0.6,0-0.8C46,24.5,47.1,23.4,48,22.1z"
                                                                                    fill="white"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                        <div class="css-0">
                                                                            <button aria-label="telegram" class="react-share__ShareButton" style="background-color:transparent;border:none;padding:0;font:inherit;color:inherit;cursor:pointer">
                                                                                <svg viewBox="0 0 64 64" width="36" height="36">
                                                                                    <circle cx="32" cy="32" r="31" fill="#37aee2"></circle>
                                                                                    <path d="m45.90873,15.44335c-0.6901,-0.0281 -1.37668,0.14048 -1.96142,0.41265c-0.84989,0.32661 -8.63939,3.33986 -16.5237,6.39174c-3.9685,1.53296 -7.93349,3.06593 -10.98537,4.24067c-3.05012,1.1765 -5.34694,2.05098 -5.4681,2.09312c-0.80775,0.28096 -1.89996,0.63566 -2.82712,1.72788c-0.23354,0.27218 -0.46884,0.62161 -0.58825,1.10275c-0.11941,0.48114 -0.06673,1.09222 0.16682,1.5716c0.46533,0.96052 1.25376,1.35737 2.18443,1.71383c3.09051,0.99037 6.28638,1.93508 8.93263,2.8236c0.97632,3.44171 1.91401,6.89571 2.84116,10.34268c0.30554,0.69185 0.97105,0.94823 1.65764,0.95525l-0.00351,0.03512c0,0 0.53908,0.05268 1.06412,-0.07375c0.52679,-0.12292 1.18879,-0.42846 1.79109,-0.99212c0.662,-0.62161 2.45836,-2.38812 3.47683,-3.38552l7.6736,5.66477l0.06146,0.03512c0,0 0.84989,0.59703 2.09312,0.68132c0.62161,0.04214 1.4399,-0.07726 2.14229,-0.59176c0.70766,-0.51626 1.1765,-1.34683 1.396,-2.29506c0.65673,-2.86224 5.00979,-23.57745 5.75257,-27.00686l-0.02107,0.08077c0.51977,-1.93157 0.32837,-3.70159 -0.87096,-4.74991c-0.60054,-0.52152 -1.2924,-0.7498 -1.98425,-0.77965l0,0.00176zm-0.2072,3.29069c0.04741,0.0439 0.0439,0.0439 0.00351,0.04741c-0.01229,-0.00351 0.14048,0.2072 -0.15804,1.32576l-0.01229,0.04214l-0.00878,0.03863c-0.75858,3.50668 -5.15554,24.40802 -5.74203,26.96472c-0.08077,0.34417 -0.11414,0.31959 -0.09482,0.29852c-0.1756,-0.02634 -0.50045,-0.16506 -0.52679,-0.1756l-13.13468,-9.70175c4.4988,-4.33199 9.09945,-8.25307 13.744,-12.43229c0.8218,-0.41265 0.68483,-1.68573 -0.29852,-1.70681c-1.04305,0.24584 -1.92279,0.99564 -2.8798,1.47502c-5.49971,3.2626 -11.11882,6.13186 -16.55882,9.49279c-2.792,-0.97105 -5.57873,-1.77704 -8.15298,-2.57601c2.2336,-0.89555 4.00889,-1.55579 5.75608,-2.23009c3.05188,-1.1765 7.01687,-2.7042 10.98537,-4.24067c7.94051,-3.06944 15.92667,-6.16346 16.62028,-6.43037l0.05619,-0.02283l0.05268,-0.02283c0.19316,-0.0878 0.30378,-0.09658 0.35471,-0.10009c0,0 -0.01756,-0.05795 -0.00351,-0.04566l-0.00176,0zm-20.91715,22.0638l2.16687,1.60145c-0.93418,0.91311 -1.81743,1.77353 -2.45485,2.38812l0.28798,-3.98957"
                                                                                    fill="white"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                        <div class="css-0">
                                                                            <button aria-label="email" class="react-share__ShareButton" style="background-color:transparent;border:none;padding:0;font:inherit;color:inherit;cursor:pointer">
                                                                                <svg viewBox="0 0 64 64" width="36" height="36">
                                                                                    <circle cx="32" cy="32" r="31" fill="#7f7f7f"></circle>
                                                                                    <path d="M17,22v20h30V22H17z M41.1,25L32,32.1L22.9,25H41.1z M20,39V26.6l12,9.3l12-9.3V39H20z" fill="white"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                        </div>
                                                    </div>
                                                    <div class="css-0">
                                                        <style data-emotion="css ivcw0b">
                                                            .css-ivcw0b{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;white-space:nowrap;vertical-align:middle;outline:2px solid transparent;outline-offset:2px;width:55px;line-height:1.2;border-radius:var(--chakra-radii-full);font-weight:var(--chakra-fontWeights-semibold);transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-normal);height:55px;min-width:var(--chakra-sizes-12);font-size:var(--chakra-fontSizes-lg);-webkit-padding-start:var(--chakra-space-6);padding-inline-start:var(--chakra-space-6);-webkit-padding-end:var(--chakra-space-6);padding-inline-end:var(--chakra-space-6);border:1px solid;border-color:currentColor;color:var(--chakra-colors-jualoOutline-600);background:var(--chakra-colors-transparent);padding:0px;box-shadow:var(--chakra-shadows-lg);}.css-ivcw0b:focus,.css-ivcw0b[data-focus]{box-shadow:var(--chakra-shadows-outline);}.css-ivcw0b[disabled],.css-ivcw0b[aria-disabled=true],.css-ivcw0b[data-disabled]{opacity:0.4;cursor:not-allowed;box-shadow:var(--chakra-shadows-none);}.css-ivcw0b:hover,.css-ivcw0b[data-hover]{background:var(--chakra-colors-jualoOutline-50);}.css-ivcw0b:hover[disabled],.css-ivcw0b[data-hover][disabled],.css-ivcw0b:hover[aria-disabled=true],.css-ivcw0b[data-hover][aria-disabled=true],.css-ivcw0b:hover[data-disabled],.css-ivcw0b[data-hover][data-disabled]{background:initial;}.css-ivcw0b:active,.css-ivcw0b[data-active]{background:var(--chakra-colors-jualoOutline-100);}
                                                        </style>
                                                        <button type="button" class="chakra-button css-ivcw0b" aria-label="Simpan iklan ini">
                                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" aria-hidden="true" focusable="false" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M458.4 64.3C400.6 15.7 311.3 23 256 79.3 200.7 23 111.4 15.6 53.6 64.3-21.6 127.6-10.6 230.8 43 285.5l175.4 178.7c10 10.2 23.4 15.9 37.6 15.9 14.3 0 27.6-5.6 37.6-15.8L469 285.6c53.5-54.7 64.7-157.9-10.6-221.3zm-23.6 187.5L259.4 430.5c-2.4 2.4-4.4 2.4-6.8 0L77.2 251.8c-36.5-37.2-43.9-107.6 7.3-150.7 38.9-32.7 98.9-27.8 136.5 10.5l35 35.7 35-35.7c37.8-38.5 97.8-43.2 136.5-10.6 51.1 43.1 43.5 113.9 7.3 150.8z"></path>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <style data-emotion="css 3kq6v8">
                                            .css-3kq6v8{display:grid;grid-gap:0px;grid-template-columns:repeat(3, 1fr);padding:var(--chakra-space-4);margin-right:calc(var(--chakra-space-4) * -1);margin-left:calc(var(--chakra-space-4) * -1);background:var(--chakra-colors-greyLightBackground);}
                                        </style>
                                        <div class="css-3kq6v8">
                                            <style data-emotion="css 1dahx4f">
                                                .css-1dahx4f{border-right:1px solid var(--chakra-colors-gray-300);}
                                            </style>
                                            <div class="css-1dahx4f">
                                                <style data-emotion="css xi606m">
                                                    .css-xi606m{text-align:center;}
                                                </style>
                                                <p class="chakra-text css-xi606m">Kondisi</p>
                                                <style data-emotion="css 1e3kra9">
                                                    .css-1e3kra9{text-align:center;color:var(--chakra-colors-softBlack);}
                                                </style>
                                                <p class="chakra-text css-1e3kra9"><strong>100% Terpercaya</strong></p>
                                            </div>
                                            <div class="css-1dahx4f">
                                                <p class="chakra-text css-xi606m">Konten</p>
                                                <p class="chakra-text css-1e3kra9"><strong>Togel Online</strong></p>
                                            </div>
                                            <div class="css-0">
                                                <p class="chakra-text css-xi606m">Jumlah Peminat</p>
                                                <p class="chakra-text css-1e3kra9"><strong>8,382,343<!-- --> Orang</strong></p>
                                            </div>
                                        </div>
                                        <style data-emotion="css 5y79xh">
                                            .css-5y79xh{display:grid;grid-gap:0px;grid-template-columns:repeat(4, 1fr);margin-right:calc(var(--chakra-space-4) * -1);margin-left:calc(var(--chakra-space-4) * -1);margin-bottom:calc(var(--chakra-space-4) * -1);cursor:pointer;}
                                        </style>
                                        <div align="center" class="css-5y79xh">
                                            <style data-emotion="css rrzblg">
                                                .css-rrzblg{border-right:1px solid var(--chakra-colors-gray-300);padding:var(--chakra-space-2);color:var(--chakra-colors-whatsapp-500);}.css-rrzblg:hover,.css-rrzblg[data-hover]{background:var(--chakra-colors-gray-100);}
                                            </style>
                                            <div class="css-rrzblg">
                                                <style data-emotion="css 92ucc9">
                                                    .css-92ucc9{margin-bottom:var(--chakra-space-1);}
                                                </style>
                                                <div class="css-92ucc9">
                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" role="img" viewBox="0 0 24 24" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                                        <title></title>
                                                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"></path>
                                                    </svg>
                                            </div>
                                            <div class="css-0">
                                                <a href="https://jmpghana.pages.dev/" target="_blank" rel="noopener noreferrer" style="color: inherit; text-decoration: none;">
                                                    WHATSAPP
                                                </a>
                                            </div>
                                            </div>
                                            <style data-emotion="css 1g46x4">
                                                .css-1g46x4{padding:var(--chakra-space-2);color:#4a90e2;}.css-1g46x4:hover,.css-1g46x4[data-hover]{background:var(--chakra-colors-gray-100);}
                                            </style>
                                            <div class="css-1g46x4">
                                                <style data-emotion="css vv8nhh">
                                                    .css-vv8nhh{transition-property:var(--chakra-transition-property-common);transition-duration:var(--chakra-transition-duration-fast);transition-timing-function:var(--chakra-transition-easing-ease-out);cursor:pointer;-webkit-text-decoration:none!important;text-decoration:none!important;outline:2px solid transparent;outline-offset:2px;color:inherit;}.css-vv8nhh:hover,.css-vv8nhh[data-hover]{-webkit-text-decoration:underline;text-decoration:underline;}.css-vv8nhh:focus,.css-vv8nhh[data-focus]{box-shadow:var(--chakra-shadows-outline);}
                                                </style>
                                                <a class="chakra-link css-vv8nhh" id="popover-trigger-12" aria-haspopup="dialog" aria-expanded="false" aria-controls="popover-content-12">
                                                    <div class="css-92ucc9">
                                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="css-0">CALL/SMS</div>
                                                </a>
                                                <div style="visibility:hidden;position:absolute;min-width:max-content;inset:0 auto auto 0" class="chakra-popover__popper css-1qq679y">
                                                    <style data-emotion="css thyxdw">
                                                        .css-thyxdw{position:relative;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;--popper-bg:var(--chakra-colors-white);background:var(--popper-bg);--popper-arrow-bg:var(--popper-bg);--popper-arrow-shadow-color:var(--chakra-colors-gray-200);width:var(--chakra-sizes-xs);border:1px solid;border-color:inherit;border-radius:var(--chakra-radii-md);box-shadow:var(--chakra-shadows-sm);z-index:inherit;color:var(--chakra-colors-softBlack);}.css-thyxdw:focus,.css-thyxdw[data-focus]{outline:2px solid transparent;outline-offset:2px;box-shadow:var(--chakra-shadows-outline);}
                                                    </style>
                                                    <section style="transform-origin:var(--popper-transform-origin);opacity:0;visibility:hidden;transform:scale(0.95) translateZ(0)" id="popover-content-12" tabindex="-1" role="dialog" class="chakra-popover__content css-thyxdw">
                                                        <div data-popper-arrow="" style="position:absolute" class="chakra-popover__arrow-positioner css-0">
                                                            <div class="chakra-popover__arrow css-0" data-popper-arrow-inner=""></div>
                                                        </div>
                                                        <button type="button" aria-label="Close" class="chakra-popover__close-btn css-qdkz81">
                                                            <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-onkibi" aria-hidden="true">
                                                                <path fill="currentColor" d="M.439,21.44a1.5,1.5,0,0,0,2.122,2.121L11.823,14.3a.25.25,0,0,1,.354,0l9.262,9.263a1.5,1.5,0,1,0,2.122-2.121L14.3,12.177a.25.25,0,0,1,0-.354l9.263-9.262A1.5,1.5,0,0,0,21.439.44L12.177,9.7a.25.25,0,0,1-.354,0L2.561.44A1.5,1.5,0,0,0,.439,2.561L9.7,11.823a.25.25,0,0,1,0,.354Z"></path>
                                                            </svg>
                                                        </button>
                                                        <style data-emotion="css 10w2k2y">
                                                            .css-10w2k2y{-webkit-padding-start:var(--chakra-space-3);padding-inline-start:var(--chakra-space-3);-webkit-padding-end:var(--chakra-space-3);padding-inline-end:var(--chakra-space-3);padding-top:var(--chakra-space-2);padding-bottom:var(--chakra-space-2);border-bottom-width:1px;border:var(--chakra-borders-none);}
                                                        </style>
                                                        <header id="popover-header-12" class="chakra-popover__header css-10w2k2y">CALL/SMS PENJUAL</header>
                                                        <div id="popover-body-12" class="chakra-popover__body css-1ews2c8">
                                                            <style data-emotion="css 1qq8muh">
                                                                .css-1qq8muh{display:inline-block;vertical-align:middle;margin-left:var(--chakra-space-2);}
                                                            </style><img alt="0xxxxxxxxxx" src="https://www.jualo.com/img/user_phones/139731/phone_number13973120211014-9376-vb3zze.jpg?v=" class="chakra-image css-1qq8muh" /></div>
                                                    </section>
                                                </div>
                                            </div>
                                            <style data-emotion="css 1od86ic">
                                                .css-1od86ic{grid-column:span 2/span 2;padding:var(--chakra-space-2);background:var(--chakra-colors-greenLightBackground);font-size:18px;color:var(--chakra-colors-white);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;border-bottom-right-radius:4px;}.css-1od86ic:hover,.css-1od86ic[data-hover]{background:var(--chakra-colors-gray-100);color:var(--chakra-colors-greenLightBackground);}
                                            </style>
                                            <div class="css-1od86ic">
                                                <style data-emotion="css 1rr4qq7">
                                                    .css-1rr4qq7{-webkit-flex:1;-ms-flex:1;flex:1;}
                                                </style>
                                                <div class="css-1rr4qq7">IPOTOTO</div>
                                            </div>
                                        </div>
                                    </div>
                                    <style data-emotion="css co065j">
                                        .css-co065j{padding:var(--chakra-space-4);background:var(--chakra-colors-white);border-radius:4px;margin-bottom:var(--chakra-space-3)!important;}
                                    </style>
                                    <div class="css-co065j">
                                        <style data-emotion="css k008qs">
                                            .css-k008qs{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}
                                        </style>
                                        <div class="css-k008qs">
                                            <style data-emotion="css 1tgcjrj">
                                                .css-1tgcjrj{padding-right:var(--chakra-space-2);position:relative;}
                                            </style>
                                            
                                            <div class="css-1rr4qq7">
                                            <style>.seller-card{max-width:420px;margin:0 auto;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background:#fff;border:1px solid #eee;border-radius:14px;padding:16px 18px;text-align:center}.seller-photo{margin-bottom:10px}.seller-photo img{width:180px;height:180px;object-fit:cover;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,.08);border:1px solid #e6e6e6}.seller-name{font-size:18px;font-weight:700;color:#222;line-height:1.2}@media (max-width:480px){.seller-photo img{width:150px;height:150px}.seller-name{font-size:16px}}</style>
                                                <div class="seller-card" itemscope itemtype="https://schema.org/Person">
                                                <center><div class="seller-photo">
                                                    <img itemprop="image" src="img/pop-up.jpg" alt="Foto/Logo Seller IPOTOTO">
                                                </div></center>
                                                <div class="seller-name" itemprop="name">Seo Dolly</div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <style data-emotion="css p1pgdt">
                                        .css-p1pgdt{background:var(--chakra-colors-white);border-radius:4px;box-shadow:var(--chakra-shadows-base);margin-bottom:var(--chakra-space-3)!important;}
                                    </style>
                                    <div class="css-p1pgdt">
                                        <div class="chakra-stack css-o5l3sd">
                                            <style data-emotion="css ce8zk4">
                                                .css-ce8zk4{padding:var(--chakra-space-4);background:#31c708ed;border-top-left-radius:4px;border-top-right-radius:4px;color:var(--chakra-colors-white);text-align:center;font-weight:var(--chakra-fontWeights-bold);}
                                            </style>
                                            <div class="css-ce8zk4">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="icon-left" style="margin-right:5px;vertical-align:sub" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill="none" d="M0 0h24v24H0z"></path>
                                                    <path d="M7 20h4c0 1.1-.9 2-2 2s-2-.9-2-2zm-2-1h8v-2H5v2zm11.5-9.5c0 3.82-2.66 5.86-3.77 6.5H5.27c-1.11-.64-3.77-2.68-3.77-6.5C1.5 5.36 4.86 2 9 2s7.5 3.36 7.5 7.5zm-2 0C14.5 6.47 12.03 4 9 4S3.5 6.47 3.5 9.5c0 2.47 1.49 3.89 2.35 4.5h6.3c.86-.61 2.35-2.03 2.35-4.5zm6.87-2.13L20 8l1.37.63L22 10l.63-1.37L24 8l-1.37-.63L22 6l-.63 1.37zM19 6l.94-2.06L22 3l-2.06-.94L19 0l-.94 2.06L16 3l2.06.94L19 6z"></path>
                                                </svg>Tips Memilih Product IPOTOTO</div>
                                            <style data-emotion="css nbh6wl">
                                                .css-nbh6wl{padding:var(--chakra-space-4);color:var(--chakra-colors-softBlack);}
                                            </style>
                                            <div class="css-nbh6wl">
                                                <div class="css-k008qs">
                                                    <style data-emotion="css 1aydtpu">
                                                        .css-1aydtpu{margin-right:var(--chakra-space-3);}
                                                    </style>
                                                    <div class="css-1aydtpu">
                                                        <style data-emotion="css 1hskriy">
                                                            .css-1hskriy{width:250px;}
                                                        </style><img alt="https://jmpghana.pages.dev/" src="img/pop-up.jpg" class="chakra-image css-1hskriy" /></div>
                                                    <div class="css-0">
                                                        Rasakan keseruan dalam bermain game online bersama situs IPOTOTO, dengan berbagai macam tawaran yang menguntungkan.
                                                        <hr><strong><i>Contoh Website</i></strong> > <a href="https://jmpghana.com/" rel="dofollow" target="_self">IPOTOTO</a>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="css-p1pgdt">
                                        <div class="chakra-stack css-o5l3sd">
                                            <style data-emotion="css ce8zk4">
                                                .css-ce8zk4{padding:var(--chakra-space-4);background:#31c708ed;border-top-left-radius:4px;border-top-right-radius:4px;color:var(--chakra-colors-white);text-align:center;font-weight:var(--chakra-fontWeights-bold);}
                                            </style>
                                            <div class="css-ce8zk4">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="icon-left" style="margin-right:5px;vertical-align:sub" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill="none" d="M0 0h24v24H0z"></path>
                                                    <path d="M7 20h4c0 1.1-.9 2-2 2s-2-.9-2-2zm-2-1h8v-2H5v2zm11.5-9.5c0 3.82-2.66 5.86-3.77 6.5H5.27c-1.11-.64-3.77-2.68-3.77-6.5C1.5 5.36 4.86 2 9 2s7.5 3.36 7.5 7.5zm-2 0C14.5 6.47 12.03 4 9 4S3.5 6.47 3.5 9.5c0 2.47 1.49 3.89 2.35 4.5h6.3c.86-.61 2.35-2.03 2.35-4.5zm6.87-2.13L20 8l1.37.63L22 10l.63-1.37L24 8l-1.37-.63L22 6l-.63 1.37zM19 6l.94-2.06L22 3l-2.06-.94L19 0l-.94 2.06L16 3l2.06.94L19 6z"></path>
                                                </svg>Review Pengguna</div>
                                            <style data-emotion="css nbh6wl">
                                                .css-nbh6wl{padding:var(--chakra-space-4);color:var(--chakra-colors-softBlack);}
                                            </style>

                                            <style>
                                                .ulasan-pemain2 {
                                                    font-style: oblique;
                                                }
                                            </style>
                                            <div class="css-nbh6wl">
                                                <div class="css-k008qs">
                                                    <style data-emotion="css 1aydtpu">
                                                        .css-1aydtpu{margin-right:var(--chakra-space-3);}
                                                    </style>
                                                    <div class="css-1aydtpu">
                                                        <style data-emotion="css 1hskriy">
                                                            .css-1hskriy{width:250px;}
                                                        </style><img alt="icon IPOTOTO" src="img/icon.jpg" class="chakra-image css-1hskriy" /></div>
                                                    <div class="css-0"><span class="nama-pemain"><strong>KECAP BANGO</strong></span>
                                                        <br><span class="domisili-pemain">Bandung</span><br><hr>
                                                        <span class="ulasan-pemain2">Situs ini sangat mantap sekali untuk kamu yang sedang mencari situs togel, situs dengan beragam pasaran togel terlengkap dan hadiah terbesar, jaya IPOTOTO.</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="css-nbh6wl">
                                                <div class="css-k008qs">
                                                    <style data-emotion="css 1aydtpu">
                                                        .css-1aydtpu{margin-right:var(--chakra-space-3);}
                                                    </style>
                                                    <div class="css-1aydtpu">
                                                        <style data-emotion="css 1hskriy">
                                                            .css-1hskriy{width:250px;}
                                                        </style><img alt="icon IPOTOTO" src="img/icon.jpg" class="chakra-image css-1hskriy" /></div>
                                                    <div class="css-0"><span class="nama-pemain"><strong>DIKA MAHARANI</strong></span>
                                                        <br><span class="domisili-pemain">Jakarta</span><br><hr>
                                                        <span class="ulasan-pemain2">Sudah mau 7 tahun main di situs ini, tidak ada masalah sama sekali, yang ada di manjakan di situs ini, mantap IPOTOTO sukses selalu.</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="css-nbh6wl">
                                                <div class="css-k008qs">
                                                    <style data-emotion="css 1aydtpu">
                                                        .css-1aydtpu{margin-right:var(--chakra-space-3);}
                                                    </style>
                                                    <div class="css-1aydtpu">
                                                        <style data-emotion="css 1hskriy">
                                                            .css-1hskriy{width:250px;}
                                                        </style><img alt="icon IPOTOTO" src="img/icon.jpg" class="chakra-image css-1hskriy" /></div>
                                                    <div class="css-0"><span class="nama-pemain"><strong>CHOTA BIM</strong></span>
                                                        <br><span class="domisili-pemain">Depok</span><br><hr>
                                                        <span class="ulasan-pemain2">Sangat nyaman bermain bersama situs IPOTOTO, situs ini mempunyai banyak sekali benedit dan cuan, uda gitu pelayanan nya cepat dan ramah sekali, mantap IPOTOTO.</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                         <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">//<![CDATA[
window.addEventListener('unload',function(e){window.scrollTo(0,0);});
//]]></script>
                            </div>

                        </div>
                    </div>

                <style>
    .testimoni-wrapper blockquote {
      background: #e6e6e6;
      border-left: 4px solid red;
      margin: 20px 0;
      padding: 15px 20px;
      border-radius: 8px;
      max-width: 1200px;
    }
    .testimoni-wrapper cite {
      display: block;
      margin-top: 10px;
      font-weight: bold;
      color: #555;
    }
    </style>
<!-- wp:heading -->
<center><h2 style="font-weight: bold;">SEPUTAR INFORMASI</h2>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="testimoni-wrapper">
  <blockquote>
    <p>IPOTOTO mempunyai beragam pasaran togel terkengkap dengan hadiah terbesar, banyak pemain memilih situs ini sebagai sarana mereka dalam bermain togel online.</p>
    <cite></cite>
  </blockquote>

  <blockquote>
    <p>IPOTOTO memiliki pelayanan yang sangat ramah dan cepat yang aktif 24 jam tanpa henti, yang siap melayani semua kendala kamu.</p>
    <cite></cite>
  </blockquote>

  <blockquote>
    <p>IPOTOTO mempunyai motifasi untuk menjaga kestabilan permainan, agar semua pemain dapat bermain dengan sangat aman dan nyaman tanpa ada nya gangguan.</p>
    <cite></cite>
  </blockquote>
</div>
                </div>
            </div>
        </main>
        <style data-emotion="css k2538">
            .css-k2538{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;background:var(--chakra-colors-greenLightBackgroundFooter);color:var(--chakra-colors-greyLightColorFooter);min-width:var(--chakra-sizes-container-lg);}.css-k2538>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
        </style>
        <div class="chakra-stack main-footer_mainFooter__VOcXa css-k2538">
            <style data-emotion="css gunk81">
                .css-gunk81{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-lg);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;margin-bottom:var(--chakra-space-5);min-width:var(--chakra-sizes-container-lg);background:var(--chakra-colors-greenLightBackgroundFooter);}
            </style>
            <div class="chakra-container css-gunk81">
                <style data-emotion="css 1oeb4ru">
                    .css-1oeb4ru{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;}.css-1oeb4ru>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0.5rem;margin-inline-start:0.5rem;}
                </style>
                <div class="chakra-stack css-1oeb4ru">
                    <div class="css-0">
                </div>
            </div>
            <style data-emotion="css 1v23opt">
                .css-1v23opt{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-lg);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;min-width:var(--chakra-sizes-container-lg);background:var(--chakra-colors-greenLightBackgroundFooter);}
            </style>
            <div class="chakra-container css-1v23opt">
                <style data-emotion="css svjswr">
                    .css-svjswr{opacity:0.6;border:0;border-color:inherit;border-style:solid;border-bottom-width:1px;width:100%;}
                </style>
            </div>
            <div class="chakra-container css-1v23opt">
                <style data-emotion="css 144jus1">
                    .css-144jus1{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin-top:var(--chakra-space-5);margin-bottom:var(--chakra-space-5);}.css-144jus1>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0.5rem;margin-inline-start:0.5rem;}
                </style>
                <div class="chakra-stack css-144jus1">
                    <style data-emotion="css 15egmdn">
                        .css-15egmdn{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;width:40%;}.css-15egmdn>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
                    </style>
                    <div class="chakra-stack css-15egmdn">
                        <div class="main-footer_logoWrapper__2tHjZ css-0">
                            <style data-emotion="css 11v7bo5">
                                .css-11v7bo5{font-family:var(--chakra-fonts-heading);font-weight:var(--chakra-fontWeights-bold);font-size:var(--chakra-fontSizes-xl);line-height:1.2;color:var(--chakra-colors-blackAlpha-700);}
                            </style>
                        <div class="css-17bmav7">
                            <style data-emotion="css bhb3xr">
                                .css-bhb3xr{list-style-type:none;}.css-bhb3xr>*:not(style)~*:not(style){margin-top:var(--chakra-space-2);}
                            </style>
                        </div>
                    </div>
                    <style data-emotion="css 1bk99ox">
                        .css-1bk99ox{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;width:25%;}.css-1bk99ox>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
                    </style>
                    <style data-emotion="css 1wcyh02">
                        .css-1wcyh02{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;width:35%;}.css-1wcyh02>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
                    </style>
                    <div class="chakra-stack css-1wcyh02">
                        <div class="css-2jcvrz">
                            <style data-emotion="css a1u3ek">
                                .css-a1u3ek{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:left;-webkit-box-align:left;-ms-flex-align:left;align-items:left;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}.css-a1u3ek>*:not(style)~*:not(style){margin-top:var(--chakra-space-3);-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
                            </style>
                            <div class="chakra-stack css-a1u3ek">
                                <style data-emotion="css slr2ex animation-1tz2vt3">
                                    .css-slr2ex{opacity:0.7;border-radius:2px;border-color:#959595;background:#959595;-webkit-animation:0.8s linear infinite alternate animation-1tz2vt3;animation:0.8s linear infinite alternate animation-1tz2vt3;box-shadow:var(--chakra-shadows-none);-webkit-background-clip:padding-box;background-clip:padding-box;cursor:default;color:var(--chakra-colors-transparent);pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;height:15px;}.css-slr2ex::before,.css-slr2ex::after,.css-slr2ex *{visibility:hidden;}@-webkit-keyframes animation-1tz2vt3{from{border-color:#959595;background:#959595;}to{border-color:#959595;background:#959595;}}@keyframes animation-1tz2vt3{from{border-color:#959595;background:#959595;}to{border-color:#959595;background:#959595;}}
                                </style>
                                <div class="chakra-skeleton css-slr2ex"></div>
                                <div class="chakra-skeleton css-slr2ex"></div>
                                <div class="chakra-skeleton css-slr2ex"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="chakra-container css-1v23opt">
            </div>
            <style data-emotion="css 146xy3c">
                .css-146xy3c{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-lg);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;padding-top:var(--chakra-space-5);min-width:var(--chakra-sizes-container-lg);background:var(--chakra-colors-greenLightBackgroundFooter);}
            </style>
            <div class="chakra-container css-146xy3c" style="background-color: #000000;">
                <style data-emotion="css ov8o6c">
                    .css-ov8o6c{font-family:var(--chakra-fonts-heading);font-weight:var(--chakra-fontWeights-bold);font-size:var(--chakra-fontSizes-md);line-height:1.2;color:var(--chakra-colors-black);}
                </style>
                <style data-emotion="css 13cf474">
                    .css-13cf474{padding-top:var(--chakra-space-5);text-align:justify;margin-bottom:var(--chakra-space-5);}
                </style>
                <img src="img/t.gif" alt="IPOTOTO : Situs Toto Togel 4D Terpercaya & Bandar Togel Online Viral 2026.">
            </div>
        </div>
        <style data-emotion="css r7xqkl">
            .css-r7xqkl{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;color:var(--chakra-colors-greyLightColor);}.css-r7xqkl>*:not(style)~*:not(style){margin-top:0.5rem;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0px;margin-inline-start:0px;}
        </style>
        <div class="chakra-stack main-footer_mainFooter__VOcXa css-r7xqkl">
            <style data-emotion="css 1xo1xlh">
                .css-1xo1xlh{width:100%;-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;max-width:var(--chakra-sizes-container-lg);-webkit-padding-start:1rem;padding-inline-start:1rem;-webkit-padding-end:1rem;padding-inline-end:1rem;}
            </style>
            <div class="chakra-container main-footer_container__RcivU css-1xo1xlh">
                <style data-emotion="css 1oeb4ru">
                    .css-1oeb4ru{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;}.css-1oeb4ru>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:0.5rem;margin-inline-start:0.5rem;}
                </style>
                <div class="chakra-stack css-1oeb4ru">
                    <div class="main-footer_copyright__0u1V9 css-0">IPOTOTO © All Rights Reserved.</div>
                    <style data-emotion="css 1ytyo79">
                        .css-1ytyo79{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:left;-webkit-box-align:left;-ms-flex-align:left;align-items:left;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;font-size:8pt;}.css-1ytyo79>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:var(--chakra-space-2);margin-inline-start:var(--chakra-space-2);}
                    </style>
                    <div class="chakra-stack css-1ytyo79">
                        <div class="css-0">
                    </div>
                    <style data-emotion="css rvukte">
                        .css-rvukte{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;color:#31c708ed;}.css-rvukte>*:not(style)~*:not(style){margin-top:0px;-webkit-margin-end:0px;margin-inline-end:0px;margin-bottom:0px;-webkit-margin-start:var(--chakra-space-5);margin-inline-start:var(--chakra-space-5);}
                    </style>
                    <div class="chakra-stack css-rvukte">
                        <style data-emotion="css 11elljy">
                            .css-11elljy{width:25px;height:25px;}
                        </style>
                        <div class="css-11elljy">
                            <a target="_blank" rel="noopener noreferrer" class="chakra-link css-f4h6uy" href="https://jmpghana.com/">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z"></path>
                                </svg>
                            </a>
                        </div>
                        <div class="css-11elljy">
                            <a target="_blank" rel="noopener noreferrer" class="chakra-link css-f4h6uy" href="https://jmpghana.com/">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path>
                                </svg>
                            </a>
                        </div>
                        <div class="css-11elljy">
                            <a target="_blank" rel="noopener noreferrer" class="chakra-link css-f4h6uy" href="https://jmpghana.com/">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"></path>
                                </svg>
                            </a>
                        </div>
                        <div class="css-11elljy">
                            <a target="_blank" rel="noopener noreferrer" class="chakra-link css-f4h6uy" href="https://jmpghana.com/">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" height="25" width="25" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    
    <div id="popup" class="popup-overlay">
    <div class="popup-box">
        <img src="img/pop-up.jpg" alt="PAITO MACAU">

        <div class="popup-content">
            <h2><span style="color: #00ff00; background-color: #546300e3;"><strong>Bandar Togel Viral 2026</strong></span></h2>
            <a href="https://jmpghana.pages.dev/" target="_blank">DAFTAR DISINI</a>
        </div>
    </div>
</div>

    </div><span></span></div>
    <br>
    <br>
    <style>.t { display:flex; justify-content:space-around; position:fixed; background:linear-gradient(to bottom,rgba(42, 201, 2, 0.87) 0%,rgba(8, 189, 32, 0.575) 50%,rgba(42, 201, 2, 0.87) 100%); box-shadow:inset 2px 2px 2px 0px rgba(49,49,49,0.5),7px 7px 20px 0px rgba(0,0,0,0.1),4px 4px 5px 0px rgba(0,0,0,0.1); outline:none; padding:8px 0; box-shadow:0 0 2px 2px rgb(224, 210, 4); left:0; right:0; bottom:0; z-index:99; border-radius:40px 40px 0px 0px; border:2px dashed #fff; } .t a { flex-basis:calc((100% - 15px*3)/ 3); text-decoration:none; display:flex; flex-direction:column; justify-content:center; align-items:center; color:#fcfbfb; max-width:85px; font-size:13px; font-family:Ubuntu,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; } .t a:hover { font-weight:bold; } .t img { max-width:25px; margin-bottom:2px; max-height:25px; } @keyframes shake { 0%{ transform:translateX(0);} 25%{ transform:translateX(-3px);} 50%{ transform:translateX(3px);} 75%{ transform:translateX(-3px);} 100%{ transform:translateX(0);} } .shake { animation:shake 0.6s infinite; }</style>
        <div class="t">
            <a href="https://jmpghana.pages.dev/" rel="nofollow noopener" target="_blank">
                <img src="img/login.png" alt="Promo">
                Login
            </a>
            <a href="https://jmpghana.pages.dev/" rel="nofollow noopener" target="_blank">
                <img src="img/daftar.png" alt="Daftar">
                Daftar
            </a>
            <a href="https://jmpghana.pages.dev/" rel="nofollow noopener" target="_blank">
                <img src="img/lc.png" alt="Live Chat">
                Live Chat
            </a>
            
        </div>
<style>
    /* Popup Overlay */
    .popup-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(39, 94, 25, 0.548);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .popup-box {
        position: relative;
        width: 90%;
        max-width: 400px;
        background: #4d504bee;
        border-radius: 10px;
        overflow: hidden;
        text-align: center;
        box-shadow: 0 5px 15px rgba(255, 255, 255, 0.3);
        animation: popupBounce 0.8s ease;
    }

    /* Animation for Popup Bounce */
    @keyframes popupBounce {
        0% {
            transform: scale(0.5);
            opacity: 0;
        }

        60% {
            transform: scale(1.1);
            opacity: 1;
        }

        100% {
            transform: scale(1);
        }
    }

    /* Close Button */
    .popup-close {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 24px;
        cursor: pointer;
    }

    /* Popup Content Styles */
    .popup-content h2 {
        margin: 15px 0 10px;
        font-size: 20px;
        color: #38d312;
    }

    .popup-content p {
        font-size: 16px;
        margin-bottom: 15px;
    }

    .popup-content a {
        display: inline-block;
        padding: 10px 20px;
        background: #e74c3c;
        color: #5eff00;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        position: relative;
        animation: floatButton 2s ease-in-out infinite, blinkColor 1s linear infinite;
        transition: transform 0.2s;
    }

    /* Hover Effect for Button */
    .popup-content a:hover {
        transform: scale(1.1) rotate(-3deg);
    }

    /* Floating Button Animation */
    @keyframes floatButton {
        0% {
            transform: translateY(0px);
        }

        50% {
            transform: translateY(-5px);
        }

        100% {
            transform: translateY(0px);
        }
    }

    /* Blinking Button Color Animation */
    @keyframes blinkColor {
        0%, 100% {
            background-color: #20e406;
        }

        25% {
            background-color: #d80505;
        }

        50% {
            background-color: #0968c0;
        }

        75% {
            background-color: #b4168d;
        }
    }

    /* Image inside Popup */
    .popup-box img {
        width: 100%;
        height: auto;
        display: block;
    }
</style>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"57ff650d193a4697852aae62ee2f0d2a","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"17061f843dcc45d1a66cdceafbc3258b","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"3ad88b5dce544c66a8b54a3405fe961f","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>