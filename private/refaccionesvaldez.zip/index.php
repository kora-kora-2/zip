



<!DOCTYPE html>
<html
    class="js audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a cors cssanimations backgroundblendmode flexbox inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color localstorage placeholder svg xhr2 audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a cors cssanimations backgroundblendmode flexbox inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color localstorage placeholder svg xhr2"
    lang="en">

<head>

    <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">

        //<![CDATA[
        window.DATADOG_CONFIG = {
            clientToken: 'puba7a42f353afa86efd9e11ee56e5fc8d9',
            applicationId: '8561f3f6-5252-482b-ba9f-2bbb1b009106',
            site: 'datadoghq.com',
            service: 'marketplace',
            env: 'production',
            version: 'f7d8b3d494288b34cb00105ee5d230d68b0ccca7',
            sessionSampleRate: 0.2,
            sessionReplaySampleRate: 5
        };

        //]]>
    </script>
    <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">
        //<![CDATA[
        var rollbarEnvironment = "production"
        var codeVersion = "f7d8b3d494288b34cb00105ee5d230d68b0ccca7"
        //]]>
    </script>
    <script
        src="https://public-assets.envato-static.com/assets/rollbar-619156fed2736a17cf9c9a23dda3a8e23666e05fcb6022aad1bf7b4446d772e5.js"
        nonce="TFNQUvYHwdi8uHoMheRs/Q==" defer></script>
    <meta content="origin-when-cross-origin" name="referrer">
    <link rel="dns-prefetch" href="//s3.envato.com">
    <link rel="preload"
        href="https://market-resized.envatousercontent.com/themeforest.net/files/344043819/MARKETICA_PREVIEW/00-marketica-preview-sale37.__large_preview.jpg?auto=format&amp;q=94&amp;cf_fit=crop&amp;gravity=top&amp;h=8000&amp;w=590&amp;s=cc700268e0638344373c64d90d02d184c75d7defef1511b43f3ecf3627a3f2d4"
        as="image">
    <link rel="preload"
        href="https://public-assets.envato-static.com/assets/generated_sprites/logos-20f56d7ae7a08da2c6698db678490c591ce302aedb1fcd05d3ad1e1484d3caf9.png"
        as="image">
    <link rel="preload"
        href="https://public-assets.envato-static.com/assets/generated_sprites/common-5af54247f3a645893af51456ee4c483f6530608e9c15ca4a8ac5a6e994d9a340.png"
        as="image">
    <title>IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!
    </title>
    <meta name="description"
        content="IPOTOTO merupakan tempat terbaik untuk bermain togel 4d, raih hoki maksimal di bandar toto macau yang penuh dengan keseruan dan peluang raih hadiah besar. ">
    <meta name="keywords"
        content="IPOTOTO, slot toto, situs slot, slot maxwin, BANDAR TOTO MACAU, slot terbaru, situs toto">
    <link rel="amphtml" href="https://refaccionesvaldez.pages.dev/" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="icon" type="image/x-icon" href="img/icon.jpg">
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="img/icon.jpg"
        sizes="72x72">
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="img/icon.jpg"
        sizes="114x114">
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="img/icon.jpg"
        sizes="120x120">
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="img/icon.jpg"
        sizes="144x144">
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="img/icon.jpg">
    <link rel="stylesheet"
        href="https://public-assets.envato-static.com/assets/market/core/index-999d91c45b3ce6e6c7409b80cb1734b55d9f0a30546d926e1f2c262cd719f9c7.css"
        media="all">
    <link rel="stylesheet"
        href="https://public-assets.envato-static.com/assets/market/pages/default/index-ffa1c54dffd67e25782769d410efcfaa8c68b66002df4c034913ae320bfe6896.css"
        media="all">
    <script
        src="https://public-assets.envato-static.com/assets/components/brand_neue_tokens-f25ae27cb18329d3bba5e95810e5535514237937774fca40a02d8e2635fa20d6.js"
        nonce="TFNQUvYHwdi8uHoMheRs/Q==" defer></script>
    <meta name="theme-color" content="#333333">
    <link rel="canonical" href="https://refaccionesvaldez.com.mx/">
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!",
  "image": "img/logo.gif",
  "description": "IPOTOTO merupakan tempat terbaik untuk bermain togel 4d, raih hoki maksimal di bandar toto macau yang penuh dengan keseruan dan peluang raih hadiah besar. ",
  "brand": {
    "@type": "Brand",
    "name": "SLOT TOTO GACOR"
  },
  "sku": "SLOT TOTO GACOR",
  "mpn": "77GCR-001",
  "url": "https://refaccionesvaldez.com.mx/",
  "offers": {
    "@type": "Offer",
    "url": "https://refaccionesvaldez.com.mx/",
    "priceCurrency": "IDR",
    "price": "0.00",
    "priceValidUntil": "2025-10-21",
    "itemCondition": "https://schema.org/NewCondition",
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": "SLOT TOTO GACOR"
    }
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "5.0",
    "reviewCount": 420
  },
  "review": [
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": "5",
        "bestRating": "5"
      },
      "author": {
        "@type": "Person",
        "name": "SITUS TOTO"
      }
    },
    {
      "@type": "Review",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": "5",
        "bestRating": "5"
      },
      "author": {
        "@type": "Person",
        "name": "User Verified"
      }
    }
  ]
}
</script>

    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "IPOTOTO",
      "item": "https://refaccionesvaldez.com.mx/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "SITUS TOTO",
      "item": "https://refaccionesvaldez.com.mx/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "TOTO TOGEL",
      "item": "https://refaccionesvaldez.com.mx/"
    },
    {
      "@type": "ListItem",
      "position": 4,
      "name": "BANDAR TOTO MACAU",
      "item": "https://refaccionesvaldez.com.mx/"
    },
    {
      "@type": "ListItem",
      "position": 5,
      "name": "SLOT TOTO GACOR",
      "item": "https://refaccionesvaldez.com.mx/"
    }
  ]
}
</script>

    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "SLOT TOTO GACOR",
  "url": "https://refaccionesvaldez.com.mx/",
  "logo": "img/logo.gif",
  "sameAs": [
    "https://www.facebook.com/SLOT-GACOR",
    "https://twitter.com/SLOT-GACOR",
    "https://www.instagram.com/SLOT-GACOR"
  ],
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+62-812-753-9901",
    "contactType": "customer support",
    "areaServed": "ID",
    "availableLanguage": ["Indonesian","English"]
  }
}
</script>

    <meta name="bingbot" content="nocache">
    <!-- Open Graph -->
    <meta property="og:title" content="IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!">
    <meta property="og:description" content="IPOTOTO hadir sebagai pusat akses login HK Pools resmi terbesar di Konoha yang menyediakan layanan toto togel online dengan sistem rapi, update data real-time, danperforma server yang konsisten. Platform ini dirancang untuk pemain yang mengutamakan kejelasan pasaran, ketepatan hasil, serta kenyamanan bermain tanpa gangguan.">
    <meta property="og:image" content="img/banner.jpg" />
    <meta property="og:image:alt" content="Login IPOTOTO dan akses link alternatif situs Slot Online Macau 4D terpercaya" />
    <meta property="og:url" content="https://refaccionesvaldez.com.mx/">
    <meta property="og:type" content="website">
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!" />
    <meta name="twitter:description" content="IPOTOTO merupakan tempat terbaik untuk bermain togel 4d, raih hoki maksimal di bandar toto macau yang penuh dengan keseruan dan peluang raih hadiah besar. " />
    <meta name="twitter:image" content="img/banner.jpg" />
    <meta name="twitter:image:alt" content="Login IPOTOTO dan akses link alternatif situs Slot Online Macau 4D terpercaya" />
    <meta property="og:title" content="IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://refaccionesvaldez.com.mx/">
    <meta property="og:image" content="img/banner.jpg" />
    <meta property="og:image:alt" content="Login IPOTOTO dan akses link alternatif situs Slot Online Macau 4D terpercaya" />
    <meta property="og:description" content="IPOTOTO merupakan tempat terbaik untuk bermain togel 4d, raih hoki maksimal di bandar toto macau yang penuh dengan keseruan dan peluang raih hadiah besar. ">
    <meta property="og:site_name" content="ThemeForest">
    <meta name="csrf-param" content="authenticity_token">
    <meta name="csrf-token" content="o7V7LGbBjnF9HgzqsCOek0VUbYNaqFcrL72zjeu3cGTv2_7pn5UklFm7XFtDaDCfkbbeD4zdIzwPzjrUhXtbHQ">
    <meta name="turbo-visit-control" content="reload">

    <script
        src="https://public-assets.envato-static.com/assets/market/core/head-d4f3da877553664cb1d5ed45cb42c6ec7e6b00d0c4d164be8747cfd5002a24eb.js"
        nonce="TFNQUvYHwdi8uHoMheRs/Q=="></script>
    <style type="text/css" id="CookieConsentStateDisplayStyles">
        .cookieconsent-optin,
        .cookieconsent-optin-preferences,
        .cookieconsent-optin-statistics,
        .cookieconsent-optin-marketing {
            display: block;
            display: initial;
        }

        .cookieconsent-optout-preferences,
        .cookieconsent-optout-statistics,
        .cookieconsent-optout-marketing,
        .cookieconsent-optout {
            display: none;
        }
    </style>
    <style>
        :root {
            --color-yellow-1000: #191919;
            --color-yellow-1000-mask: rgb(25 25 25 / 0.7);
            --color-yellow-700: #ffc400;
            --color-yellow-500: #ecc207;
            --color-yellow-300: #ecc207;
            --color-yellow-100: #cccccc;
            --color-yellow-50: #000000;
            --color-yellow-25: #f9f9fb;
            --color-white: #000000;
            --color-white-mask: rgb(255 255 255 / 0.7);
            --color-green-1000: #ffc400;
            --color-green-700: #2e7400;
            --color-green-500: #51a31d;
            --color-green-300: #6cc832;
            --color-green-100: #9cee69;
            --color-green-25: #eaffdc;
            --color-blue-1000: #ffc400;
            --color-blue-700: #ffc400;
            --color-blue-500: #ffc400;
            --color-blue-25: #f0f1ff;
            --color-veryberry-1000: #77012d;
            --color-veryberry-700: #b9004b;
            --color-veryberry-500: #f65286;
            --color-veryberry-25: #ffecf2;
            --color-bubblegum-700: #b037a6;
            --color-bubblegum-100: #e6afe1;
            --color-bubblegum-25: #feedfc;
            --color-jaffa-1000: #692400;
            --color-jaffa-700: #c24100;
            --color-jaffa-500: #ff6e28;
            --color-jaffa-25: #fff5ed;
            --color-yolk-1000: #452d0d;
            --color-yolk-700: #9e5f00;
            --color-yolk-500: #c28800;
            --color-yolk-300: #ffc800;
            --color-yolk-25: #fefaea;
            --color-transparent: transparent;
            --breakpoint-wide: 1024px;
            --breakpoint-extra-wide: 1440px;
            --breakpoint-2k-wide: 2560px;
            --spacing-8x: 128px;
            --spacing-7x: 64px;
            --spacing-6x: 40px;
            --spacing-5x: 32px;
            --spacing-4x: 24px;
            --spacing-3x: 16px;
            --spacing-2x: 8px;
            --spacing-1x: 4px;
            --spacing-none: 0px;
            --chunkiness-none: 0px;
            --chunkiness-thin: 1px;
            --chunkiness-thick: 2px;
            --roundness-square: 0px;
            --roundness-subtle: 4px;
            --roundness-extra-round: 16px;
            --roundness-circle: 48px;
            --shadow-500: 0px 2px 12px 0px rgba(0 0 0 / 15%);
            --elevation-medium: var(--shadow-500);
            /** @deprecated */
            --transition-base: 0.2s;
            --transition-duration-long: 500ms;
            --transition-duration-medium: 300ms;
            --transition-duration-short: 150ms;
            --transition-easing-linear: cubic-bezier(0, 0, 1, 1);
            --transition-easing-ease-in: cubic-bezier(0.42, 0, 1, 1);
            --transition-easing-ease-in-out: cubic-bezier(0.42, 0, 0.58, 1);
            --transition-easing-ease-out: cubic-bezier(0, 0, 0.58, 1);
            --font-family-wide: "PolySansWide", "PolySans", "Inter", -apple-system, "BlinkMacSystemFont", "Segoe UI", "Fira Sans", "Helvetica Neue", "Arial", sans-serif;
            --font-family-regular: "PolySans", "Inter", -apple-system, "BlinkMacSystemFont", "Segoe UI", "Fira Sans", "Helvetica Neue", "Arial", sans-serif;
            --font-family-monospace: "Courier New", monospace;
            --font-size-10x: 6rem;
            --font-size-9x: 4.5rem;
            --font-size-8x: 3rem;
            --font-size-7x: 2.25rem;
            --font-size-6x: 1.875rem;
            --font-size-5x: 1.5rem;
            --font-size-4x: 1.125rem;
            --font-size-3x: 1rem;
            --font-size-2x: 0.875rem;
            --font-size-1x: 0.75rem;
            --font-weight-bulky: 700;
            --font-weight-median: 600;
            --font-weight-neutral: 400;
            --font-spacing-tight: -0.02em;
            --font-spacing-normal: 0;
            --font-spacing-loose: 0.02em;
            --font-height-tight: 1;
            --font-height-normal: 1.5;
            --icon-size-5x: 48px;
            --icon-size-4x: 40px;
            --icon-size-3x: 32px;
            --icon-size-2x: 24px;
            --icon-size-1x: 16px;
            --icon-size-text-responsive: calc(var(--font-size-3x) * 1.5);
            --layer-depth-ceiling: 9999;
            --minimum-touch-area: 40px;
            /* component wiring? ------------------------------------------ */
            --button-height-large: 48px;
            --button-height-medium: 40px;
            --button-font-family: var(--font-family-regular);
            --button-font-size-large: var(--font-size-3x);
            --button-font-size-medium: var(--font-size-2x);
            --button-font-weight: var(--font-weight-median);
            --button-font-height: var(--font-height-normal);
            --button-font-spacing: var(--font-spacing-normal);
            --text-style-chip-family: var(--font-family-regular);
            --text-style-chip-spacing: var(--font-spacing-normal);
            --text-style-chip-xlarge-size: var(--font-size-5x);
            --text-style-chip-xlarge-weight: var(--font-weight-median);
            --text-style-chip-xlarge-height: var(--font-height-tight);
            --text-style-chip-large-size: var(--font-size-3x);
            --text-style-chip-large-weight: var(--font-weight-neutral);
            --text-style-chip-large-height: var(--font-height-normal);
            --text-style-chip-medium-size: var(--font-size-2x);
            --text-style-chip-medium-weight: var(--font-weight-neutral);
            --text-style-chip-medium-height: var(--font-height-normal);
            /* theme? ------------------------------------------------- */
            --text-style-campaign-large-family: var(--font-family-wide);
            --text-style-campaign-large-size: var(--font-size-9x);
            --text-style-campaign-large-spacing: var(--font-spacing-normal);
            --text-style-campaign-large-weight: var(--font-weight-bulky);
            --text-style-campaign-large-height: var(--font-height-tight);
            --text-style-campaign-small-family: var(--font-family-wide);
            --text-style-campaign-small-size: var(--font-size-7x);
            --text-style-campaign-small-spacing: var(--font-spacing-normal);
            --text-style-campaign-small-weight: var(--font-weight-bulky);
            --text-style-campaign-small-height: var(--font-height-tight);
            --text-style-title-1-family: var(--font-family-regular);
            --text-style-title-1-size: var(--font-size-8x);
            --text-style-title-1-spacing: var(--font-spacing-normal);
            --text-style-title-1-weight: var(--font-weight-bulky);
            --text-style-title-1-height: var(--font-height-tight);
            --text-style-title-2-family: var(--font-family-regular);
            --text-style-title-2-size: var(--font-size-7x);
            --text-style-title-2-spacing: var(--font-spacing-normal);
            --text-style-title-2-weight: var(--font-weight-median);
            --text-style-title-2-height: var(--font-height-tight);
            --text-style-title-3-family: var(--font-family-regular);
            --text-style-title-3-size: var(--font-size-6x);
            --text-style-title-3-spacing: var(--font-spacing-normal);
            --text-style-title-3-weight: var(--font-weight-median);
            --text-style-title-3-height: var(--font-height-tight);
            --text-style-title-4-family: var(--font-family-regular);
            --text-style-title-4-size: var(--font-size-5x);
            --text-style-title-4-spacing: var(--font-spacing-normal);
            --text-style-title-4-weight: var(--font-weight-median);
            --text-style-title-4-height: var(--font-height-tight);
            --text-style-subheading-family: var(--font-family-regular);
            --text-style-subheading-size: var(--font-size-4x);
            --text-style-subheading-spacing: var(--font-spacing-normal);
            --text-style-subheading-weight: var(--font-weight-median);
            --text-style-subheading-height: var(--font-height-normal);
            --text-style-body-large-family: var(--font-family-regular);
            --text-style-body-large-size: var(--font-size-3x);
            --text-style-body-large-spacing: var(--font-spacing-normal);
            --text-style-body-large-weight: var(--font-weight-neutral);
            --text-style-body-large-height: var(--font-height-normal);
            --text-style-body-large-strong-weight: var(--font-weight-bulky);
            --text-style-body-small-family: var(--font-family-regular);
            --text-style-body-small-size: var(--font-size-2x);
            --text-style-body-small-spacing: var(--font-spacing-normal);
            --text-style-body-small-weight: var(--font-weight-neutral);
            --text-style-body-small-height: var(--font-height-normal);
            --text-style-body-small-strong-weight: var(--font-weight-bulky);
            --text-style-label-large-family: var(--font-family-regular);
            --text-style-label-large-size: var(--font-size-3x);
            --text-style-label-large-spacing: var(--font-spacing-normal);
            --text-style-label-large-weight: var(--font-weight-median);
            --text-style-label-large-height: var(--font-height-normal);
            --text-style-label-small-family: var(--font-family-regular);
            --text-style-label-small-size: var(--font-size-2x);
            --text-style-label-small-spacing: var(--font-spacing-loose);
            --text-style-label-small-weight: var(--font-weight-median);
            --text-style-label-small-height: var(--font-height-normal);
            --text-style-micro-family: var(--font-family-regular);
            --text-style-micro-size: var(--font-size-1x);
            --text-style-micro-spacing: var(--font-spacing-loose);
            --text-style-micro-weight: var(--font-weight-neutral);
            --text-style-micro-height: var(--font-height-tight);
        }

        .color-scheme-light {
            --color-interactive-primary: var(--color-green-100);
            --color-interactive-primary-hover: var(--color-green-300);
            --color-interactive-secondary: var(--color-transparent);
            --color-interactive-secondary-hover: var(--color-yellow-1000);
            --color-interactive-tertiary: var(--color-transparent);
            --color-interactive-tertiary-hover: var(--color-yellow-25);
            --color-interactive-control: var(--color-yellow-1000);
            --color-interactive-control-hover: var(--color-yellow-700);
            --color-interactive-disabled: var(--color-yellow-100);
            --color-surface-primary: var(--color-white);
            --color-surface-accent: var(--color-yellow-50);
            --color-surface-inverse: var(--color-yellow-1000);
            --color-surface-brand-accent: var(--color-jaffa-25);
            --color-surface-elevated: var(--color-yellow-700);
            --color-surface-caution-default: var(--color-jaffa-25);
            --color-surface-caution-strong: var(--color-jaffa-700);
            --color-surface-critical-default: var(--color-veryberry-25);
            --color-surface-critical-strong: var(--color-veryberry-700);
            --color-surface-info-default: var(--color-blue-25);
            --color-surface-info-strong: var(--color-blue-700);
            --color-surface-neutral-default: var(--color-yellow-25);
            --color-surface-neutral-strong: var(--color-yellow-1000);
            --color-surface-positive-default: var(--color-green-25);
            --color-surface-positive-strong: var(--color-green-700);
            --color-overlay-light: var(--color-white-mask);
            --color-overlay-dark: var(--color-yellow-1000-mask);
            --color-content-brand: var(--color-green-1000);
            --color-content-brand-accent: var(--color-bubblegum-700);
            --color-content-primary: var(--color-yellow-1000);
            --color-content-inverse: var(--color-white);
            --color-content-secondary: var(--color-yellow-500);
            --color-content-disabled: var(--color-yellow-300);
            --color-content-caution-default: var(--color-jaffa-700);
            --color-content-caution-strong: var(--color-jaffa-25);
            --color-content-critical-default: var(--color-veryberry-700);
            --color-content-critical-strong: var(--color-veryberry-25);
            --color-content-info-default: var(--color-blue-700);
            --color-content-info-strong: var(--color-blue-25);
            --color-content-neutral-default: var(--color-yellow-1000);
            --color-content-neutral-strong: var(--color-white);
            --color-content-positive-default: var(--color-green-700);
            --color-content-positive-strong: var(--color-green-25);
            --color-border-primary: var(--color-yellow-1000);
            --color-border-secondary: var(--color-yellow-300);
            --color-border-tertiary: var(--color-yellow-100);
            --color-always-white: var(--color-white);
        }

        .color-scheme-dark {
            --color-interactive-primary: var(--color-green-100);
            --color-interactive-primary-hover: var(--color-green-300);
            --color-interactive-secondary: var(--color-transparent);
            --color-interactive-secondary-hover: var(--color-white);
            --color-interactive-tertiary: var(--color-transparent);
            --color-interactive-tertiary-hover: var(--color-yellow-700);
            --color-interactive-control: var(--color-white);
            --color-interactive-control-hover: var(--color-yellow-100);
            --color-interactive-disabled: var(--color-yellow-700);
            --color-surface-primary: var(--color-yellow-1000);
            --color-surface-accent: var(--color-yellow-700);
            --color-surface-inverse: var(--color-white);
            --color-surface-brand-accent: var(--color-yellow-700);
            --color-surface-elevated: var(--color-yellow-700);
            --color-surface-caution-default: var(--color-jaffa-1000);
            --color-surface-caution-strong: var(--color-jaffa-500);
            --color-surface-critical-default: var(--color-veryberry-1000);
            --color-surface-critical-strong: var(--color-veryberry-500);
            --color-surface-info-default: var(--color-blue-1000);
            --color-surface-info-strong: var(--color-blue-500);
            --color-surface-neutral-default: var(--color-yellow-700);
            --color-surface-neutral-strong: var(--color-white);
            --color-surface-positive-default: var(--color-green-1000);
            --color-surface-positive-strong: var(--color-green-500);
            --color-overlay-light: var(--color-white-mask);
            --color-overlay-dark: var(--color-yellow-1000-mask);
            --color-content-brand: var(--color-green-1000);
            --color-content-brand-accent: var(--color-bubblegum-100);
            --color-content-primary: var(--color-white);
            --color-content-inverse: var(--color-yellow-1000);
            --color-content-secondary: var(--color-yellow-100);
            --color-content-disabled: var(--color-yellow-500);
            --color-content-caution-default: var(--color-jaffa-500);
            --color-content-caution-strong: var(--color-jaffa-1000);
            --color-content-critical-default: var(--color-veryberry-500);
            --color-content-critical-strong: var(--color-veryberry-1000);
            --color-content-info-default: var(--color-blue-500);
            --color-content-info-strong: var(--color-blue-1000);
            --color-content-neutral-default: var(--color-white);
            --color-content-neutral-strong: var(--color-yellow-1000);
            --color-content-positive-default: var(--color-green-500);
            --color-content-positive-strong: var(--color-green-1000);
            --color-border-primary: var(--color-white);
            --color-border-secondary: var(--color-yellow-500);
            --color-border-tertiary: var(--color-yellow-700);
            --color-always-white: var(--color-white);
        }

        /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvYmFzZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMENBQUE7RUFFQSwyQkFBQTtFQUNBLDBCQUFBO0VBQ0EsMEJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3QkFBQTtFQUVBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsMkJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBRUEsZ0NBQUE7RUFFQSx5QkFBQTtFQUNBLCtCQUFBO0VBQ0EsNEJBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFFQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFFQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsNkJBQUE7RUFDQSx3QkFBQTtFQUVBLGdEQUFBO0VBQ0EscUNBQUE7RUFFQSxpQkFBQTtFQUNBLHVCQUFBO0VBRUEsaUNBQUE7RUFDQSxtQ0FBQTtFQUNBLGtDQUFBO0VBRUEsb0RBQUE7RUFDQSx3REFBQTtFQUNBLCtEQUFBO0VBQ0EseURBQUE7RUFFQTtrRUFBQTtFQUVBO3NEQUFBO0VBRUEsaURBQUE7RUFFQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtFQUVBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtFQUVBLDZCQUFBO0VBQ0Esd0JBQUE7RUFDQSw0QkFBQTtFQUVBLHNCQUFBO0VBQ0EseUJBQUE7RUFFQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EsNERBQUE7RUFFQSwyQkFBQTtFQUVBLDBCQUFBO0VBRUEsaUVBQUE7RUFFQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsK0NBQUE7RUFDQSwrQ0FBQTtFQUNBLGlEQUFBO0VBRUEsb0RBQUE7RUFDQSxxREFBQTtFQUNBLGtEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGlEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUVBLDZEQUFBO0VBRUEsMkRBQUE7RUFDQSxxREFBQTtFQUNBLCtEQUFBO0VBQ0EsNERBQUE7RUFDQSw0REFBQTtFQUVBLDJEQUFBO0VBQ0EscURBQUE7RUFDQSwrREFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxxREFBQTtFQUNBLHFEQUFBO0VBRUEsdURBQUE7RUFDQSw4Q0FBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFDQSxxREFBQTtFQUVBLHVEQUFBO0VBQ0EsOENBQUE7RUFDQSx3REFBQTtFQUNBLHNEQUFBO0VBQ0EscURBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLHFEQUFBO0VBRUEsMERBQUE7RUFDQSxpREFBQTtFQUNBLDJEQUFBO0VBQ0EseURBQUE7RUFDQSx5REFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDJEQUFBO0VBQ0Esa0RBQUE7RUFDQSw0REFBQTtFQUNBLDBEQUFBO0VBQ0EsMERBQUE7RUFFQSwyREFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUNBLDBEQUFBO0VBRUEscURBQUE7RUFDQSw0Q0FBQTtFQUNBLHFEQUFBO0VBQ0EscURBQUE7RUFDQSxtREFBQTtBQXhDRjs7QUEyQ0E7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwyREFBQTtFQUNBLHNEQUFBO0VBQ0Esd0RBQUE7RUFDQSxtREFBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwyQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsK0NBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esc0RBQUE7RUFDQSxzREFBQTtFQUNBLDJEQUFBO0VBQ0EsMkRBQUE7RUFDQSxrREFBQTtFQUNBLGtEQUFBO0VBQ0EscURBQUE7RUFDQSxzREFBQTtFQUNBLHVEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLCtDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSxxREFBQTtFQUNBLDREQUFBO0VBQ0EsMERBQUE7RUFDQSxtREFBQTtFQUNBLGlEQUFBO0VBQ0EsdURBQUE7RUFDQSxrREFBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFFQSw4Q0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQTdDRjs7QUFnREE7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLHNEQUFBO0VBQ0EseURBQUE7RUFDQSwrQ0FBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwrQ0FBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLDZEQUFBO0VBQ0EsMkRBQUE7RUFDQSxvREFBQTtFQUNBLGtEQUFBO0VBQ0Esc0RBQUE7RUFDQSxrREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLDJDQUFBO0VBQ0EsK0NBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSxzREFBQTtFQUNBLHdEQUFBO0VBQ0Esd0RBQUE7RUFFQSwwQ0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQWxERiIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcGllZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9lbnZhdG8vZW52YXRvLWRlc2lnbi10b2tlbnMvYmxvYi9tYWluL3Rva2Vucy5jc3NcblxuOnJvb3Qge1xuICAtLWNvbG9yLWdyZXktMTAwMDogIzE5MTkxOTtcbiAgLS1jb2xvci1ncmV5LTEwMDAtbWFzazogcmdiKDI1IDI1IDI1IC8gMC43KTtcbiAgLS1jb2xvci1ncmV5LTcwMDogIzM4MzgzODtcbiAgLS1jb2xvci1ncmV5LTUwMDogIzcwNzA3MDtcbiAgLS1jb2xvci1ncmV5LTMwMDogIzk0OTQ5NDtcbiAgLS1jb2xvci1ncmV5LTEwMDogI2NjY2NjYztcbiAgLS1jb2xvci1ncmV5LTUwOiAjZWNlY2VlO1xuICAtLWNvbG9yLWdyZXktMjU6ICNmOWY5ZmI7XG4gIC0tY29sb3Itd2hpdGU6ICNmZmZmZmY7XG4gIC0tY29sb3Itd2hpdGUtbWFzazogcmdiKDI1NSAyNTUgMjU1IC8gMC43KTtcblxuICAtLWNvbG9yLWdyZWVuLTEwMDA6ICMxYTQyMDA7XG4gIC0tY29sb3ItZ3JlZW4tNzAwOiAjMmU3NDAwO1xuICAtLWNvbG9yLWdyZWVuLTUwMDogIzUxYTMxZDtcbiAgLS1jb2xvci1ncmVlbi0zMDA6ICM2Y2M4MzI7XG4gIC0tY29sb3ItZ3JlZW4tMTAwOiAjOWNlZTY5O1xuICAtLWNvbG9yLWdyZWVuLTI1OiAjZWFmZmRjO1xuXG4gIC0tY29sb3ItYmx1ZS0xMDAwOiAjMTYzNTdiO1xuICAtLWNvbG9yLWJsdWUtNzAwOiAjNGY1Y2U4O1xuICAtLWNvbG9yLWJsdWUtNTAwOiAjNzU4NWZmO1xuICAtLWNvbG9yLWJsdWUtMjU6ICNmMGYxZmY7XG5cbiAgLS1jb2xvci12ZXJ5YmVycnktMTAwMDogIzc3MDEyZDtcbiAgLS1jb2xvci12ZXJ5YmVycnktNzAwOiAjYjkwMDRiO1xuICAtLWNvbG9yLXZlcnliZXJyeS01MDA6ICNmNjUyODY7XG4gIC0tY29sb3ItdmVyeWJlcnJ5LTI1OiAjZmZlY2YyO1xuXG4gIC0tY29sb3ItYnViYmxlZ3VtLTcwMDogI2IwMzdhNjtcbiAgLS1jb2xvci1idWJibGVndW0tMTAwOiAjZTZhZmUxO1xuICAtLWNvbG9yLWJ1YmJsZWd1bS0yNTogI2ZlZWRmYztcblxuICAtLWNvbG9yLWphZmZhLTEwMDA6ICM2OTI0MDA7XG4gIC0tY29sb3ItamFmZmEtNzAwOiAjYzI0MTAwO1xuICAtLWNvbG9yLWphZmZhLTUwMDogI2ZmNmUyODtcbiAgLS1jb2xvci1qYWZmYS0yNTogI2ZmZjVlZDtcblxuICAtLWNvbG9yLXlvbGstMTAwMDogIzQ1MmQwZDtcbiAgLS1jb2xvci15b2xrLTcwMDogIzllNWYwMDtcbiAgLS1jb2xvci15b2xrLTUwMDogI2MyODgwMDtcbiAgLS1jb2xvci15b2xrLTMwMDogI2ZmYzgwMDtcbiAgLS1jb2xvci15b2xrLTI1OiAjZmVmYWVhO1xuXG4gIC0tY29sb3ItdHJhbnNwYXJlbnQ6IHRyYW5zcGFyZW50O1xuXG4gIC0tYnJlYWtwb2ludC13aWRlOiAxMDI0cHg7XG4gIC0tYnJlYWtwb2ludC1leHRyYS13aWRlOiAxNDQwcHg7XG4gIC0tYnJlYWtwb2ludC0yay13aWRlOiAyNTYwcHg7XG5cbiAgLS1zcGFjaW5nLTh4OiAxMjhweDtcbiAgLS1zcGFjaW5nLTd4OiA2NHB4O1xuICAtLXNwYWNpbmctNng6IDQwcHg7XG4gIC0tc3BhY2luZy01eDogMzJweDtcbiAgLS1zcGFjaW5nLTR4OiAyNHB4O1xuICAtLXNwYWNpbmctM3g6IDE2cHg7XG4gIC0tc3BhY2luZy0yeDogOHB4O1xuICAtLXNwYWNpbmctMXg6IDRweDtcbiAgLS1zcGFjaW5nLW5vbmU6IDBweDtcblxuICAtLWNodW5raW5lc3Mtbm9uZTogMHB4O1xuICAtLWNodW5raW5lc3MtdGhpbjogMXB4O1xuICAtLWNodW5raW5lc3MtdGhpY2s6IDJweDtcblxuICAtLXJvdW5kbmVzcy1zcXVhcmU6IDBweDtcbiAgLS1yb3VuZG5lc3Mtc3VidGxlOiA0cHg7XG4gIC0tcm91bmRuZXNzLWV4dHJhLXJvdW5kOiAxNnB4O1xuICAtLXJvdW5kbmVzcy1jaXJjbGU6IDQ4cHg7XG5cbiAgLS1zaGFkb3ctNTAwOiAwcHggMnB4IDEycHggMHB4IHJnYmEoMCAwIDAgLyAxNSUpO1xuICAtLWVsZXZhdGlvbi1tZWRpdW06IHZhcigtLXNoYWRvdy01MDApO1xuXG4gIC8qKiBAZGVwcmVjYXRlZCAqL1xuICAtLXRyYW5zaXRpb24tYmFzZTogMC4ycztcblxuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tbG9uZzogNTAwbXM7XG4gIC0tdHJhbnNpdGlvbi1kdXJhdGlvbi1tZWRpdW06IDMwMG1zO1xuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tc2hvcnQ6IDE1MG1zO1xuXG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctbGluZWFyOiBjdWJpYy1iZXppZXIoMCwgMCwgMSwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1pbjogY3ViaWMtYmV6aWVyKDAuNDIsIDAsIDEsIDEpO1xuICAtLXRyYW5zaXRpb24tZWFzaW5nLWVhc2UtaW4tb3V0OiBjdWJpYy1iZXppZXIoMC40MiwgMCwgMC41OCwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1vdXQ6IGN1YmljLWJlemllcigwLCAwLCAwLjU4LCAxKTtcblxuICAtLWZvbnQtZmFtaWx5LXdpZGU6IFwiUG9seVNhbnNXaWRlXCIsIFwiUG9seVNhbnNcIiwgXCJJbnRlclwiLCAtYXBwbGUtc3lzdGVtLCBcIkJsaW5rTWFjU3lzdGVtRm9udFwiLFxuICAgIFwiU2Vnb2UgVUlcIiwgXCJGaXJhIFNhbnNcIiwgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIkFyaWFsXCIsIHNhbnMtc2VyaWY7XG4gIC0tZm9udC1mYW1pbHktcmVndWxhcjogXCJQb2x5U2Fuc1wiLCBcIkludGVyXCIsIC1hcHBsZS1zeXN0ZW0sIFwiQmxpbmtNYWNTeXN0ZW1Gb250XCIsIFwiU2Vnb2UgVUlcIixcbiAgICBcIkZpcmEgU2Fuc1wiLCBcIkhlbHZldGljYSBOZXVlXCIsIFwiQXJpYWxcIiwgc2Fucy1zZXJpZjtcbiAgLS1mb250LWZhbWlseS1tb25vc3BhY2U6IFwiQ291cmllciBOZXdcIiwgbW9ub3NwYWNlO1xuXG4gIC0tZm9udC1zaXplLTEweDogNnJlbTtcbiAgLS1mb250LXNpemUtOXg6IDQuNXJlbTtcbiAgLS1mb250LXNpemUtOHg6IDNyZW07XG4gIC0tZm9udC1zaXplLTd4OiAyLjI1cmVtO1xuICAtLWZvbnQtc2l6ZS02eDogMS44NzVyZW07XG4gIC0tZm9udC1zaXplLTV4OiAxLjVyZW07XG4gIC0tZm9udC1zaXplLTR4OiAxLjEyNXJlbTtcbiAgLS1mb250LXNpemUtM3g6IDFyZW07XG4gIC0tZm9udC1zaXplLTJ4OiAwLjg3NXJlbTtcbiAgLS1mb250LXNpemUtMXg6IDAuNzVyZW07XG5cbiAgLS1mb250LXdlaWdodC1idWxreTogNzAwO1xuICAtLWZvbnQtd2VpZ2h0LW1lZGlhbjogNjAwO1xuICAtLWZvbnQtd2VpZ2h0LW5ldXRyYWw6IDQwMDtcblxuICAtLWZvbnQtc3BhY2luZy10aWdodDogLTAuMDJlbTtcbiAgLS1mb250LXNwYWNpbmctbm9ybWFsOiAwO1xuICAtLWZvbnQtc3BhY2luZy1sb29zZTogMC4wMmVtO1xuXG4gIC0tZm9udC1oZWlnaHQtdGlnaHQ6IDE7XG4gIC0tZm9udC1oZWlnaHQtbm9ybWFsOiAxLjU7XG5cbiAgLS1pY29uLXNpemUtNXg6IDQ4cHg7XG4gIC0taWNvbi1zaXplLTR4OiA0MHB4O1xuICAtLWljb24tc2l6ZS0zeDogMzJweDtcbiAgLS1pY29uLXNpemUtMng6IDI0cHg7XG4gIC0taWNvbi1zaXplLTF4OiAxNnB4O1xuICAtLWljb24tc2l6ZS10ZXh0LXJlc3BvbnNpdmU6IGNhbGModmFyKC0tZm9udC1zaXplLTN4KSAqIDEuNSk7XG5cbiAgLS1sYXllci1kZXB0aC1jZWlsaW5nOiA5OTk5O1xuXG4gIC0tbWluaW11bS10b3VjaC1hcmVhOiA0MHB4O1xuXG4gIC8qIGNvbXBvbmVudCB3aXJpbmc/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4gIC0tYnV0dG9uLWhlaWdodC1sYXJnZTogNDhweDtcbiAgLS1idXR0b24taGVpZ2h0LW1lZGl1bTogNDBweDtcbiAgLS1idXR0b24tZm9udC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLWJ1dHRvbi1mb250LXNpemUtbGFyZ2U6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tYnV0dG9uLWZvbnQtc2l6ZS1tZWRpdW06IHZhcigtLWZvbnQtc2l6ZS0yeCk7XG4gIC0tYnV0dG9uLWZvbnQtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1tZWRpYW4pO1xuICAtLWJ1dHRvbi1mb250LWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcbiAgLS1idXR0b24tZm9udC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtY2hpcC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAteGxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS01eCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LXRpZ2h0KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utc2l6ZTogdmFyKC0tZm9udC1zaXplLTN4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1tZWRpdW0tc2l6ZTogdmFyKC0tZm9udC1zaXplLTJ4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbWVkaXVtLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbmV1dHJhbCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLW1lZGl1bS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLyogdGhlbWU/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS13aWRlKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS05eCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1sYXJnZS1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtYnVsa3kpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktd2lkZSk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtN3gpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xuXG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNpemU6IHZhcigtLWZvbnQtc2l6ZS04eCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtdGl0bGUtMS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTEtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc2l6ZTogdmFyKC0tZm9udC1zaXplLTd4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0yLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc2l6ZTogdmFyKC0tZm9udC1zaXplLTZ4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0zLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc2l6ZTogdmFyKC0tZm9udC1zaXplLTV4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS00LXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc2l6ZTogdmFyKC0tZm9udC1zaXplLTR4KTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1zdWJoZWFkaW5nLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuXG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW5ldXRyYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXN0cm9uZy13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcblxuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zdHJvbmctd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1idWxreSk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1zaXplOiB2YXIoLS1mb250LXNpemUtM3gpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtbGFyZ2Utc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLWxvb3NlKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtbWljcm8tZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0xeCk7XG4gIC0tdGV4dC1zdHlsZS1taWNyby1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbG9vc2UpO1xuICAtLXRleHQtc3R5bGUtbWljcm8td2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xufVxuXG4uY29sb3Itc2NoZW1lLWxpZ2h0IHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtY29udHJvbC1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1zdXJmYWNlLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS01MCk7XG4gIC0tY29sb3Itc3VyZmFjZS1pbnZlcnNlOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW5mby1kZWZhdWx0OiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLXN1cmZhY2UtbmV1dHJhbC1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTcwMCk7XG5cbiAgLS1jb2xvci1vdmVybGF5LWxpZ2h0OiB2YXIoLS1jb2xvci13aGl0ZS1tYXNrKTtcbiAgLS1jb2xvci1vdmVybGF5LWRhcms6IHZhcigtLWNvbG9yLWdyZXktMTAwMC1tYXNrKTtcblxuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQ6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1idWJibGVndW0tNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LXByaW1hcnk6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbnZlcnNlOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1zZWNvbmRhcnk6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWphZmZhLTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtMjUpO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi03MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcG9zaXRpdmUtc3Ryb25nOiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG5cbiAgLS1jb2xvci1ib3JkZXItcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cblxuLmNvbG9yLXNjaGVtZS1kYXJrIHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnk6IHZhcigtLWNvbG9yLXRyYW5zcGFyZW50KTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS10ZXJ0aWFyeS1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1jb250cm9sLWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcblxuICAtLWNvbG9yLXN1cmZhY2UtcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW52ZXJzZTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS01MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktNTAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tZGVmYXVsdDogdmFyKC0tY29sb3ItYmx1ZS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTUwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLXBvc2l0aXZlLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JlZW4tNTAwKTtcblxuICAtLWNvbG9yLW92ZXJsYXktbGlnaHQ6IHZhcigtLWNvbG9yLXdoaXRlLW1hc2spO1xuICAtLWNvbG9yLW92ZXJsYXktZGFyazogdmFyKC0tY29sb3ItZ3JleS0xMDAwLW1hc2spO1xuXG4gIC0tY29sb3ItY29udGVudC1icmFuZDogdmFyKC0tY29sb3ItZ3JlZW4tMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1icmFuZC1hY2NlbnQ6IHZhcigtLWNvbG9yLWJ1YmJsZWd1bS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcHJpbWFyeTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLWNvbnRlbnQtaW52ZXJzZTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXNlY29uZGFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tZGVmYXVsdDogdmFyKC0tY29sb3ItamFmZmEtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS01MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtbmV1dHJhbC1kZWZhdWx0OiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1uZXV0cmFsLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXBvc2l0aXZlLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZWVuLTUwMCk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuXG4gIC0tY29sb3ItYm9yZGVyLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTUwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */
    </style>
    <style>
        .brand-neue-button {
            gap: var(--spacing-2x);
            border-radius: var(--roundness-subtle);
            background: var(--color-interactive-primary);
            color: var(--color-content-brand);
            font-family: PolySans-Median;
            font-size: var(--font-size-2x);
            letter-spacing: 0.02em;
            text-align: center;
            padding: 0 20px;
        }

        .brand-neue-button:hover,
        .brand-neue-button:active,
        .brand-neue-button:focus {
            background: var(--color-interactive-primary-hover);
        }

        .brand-neue-button__open-in-new::after {
            font-size: 0;
            margin-left: 5px;
            vertical-align: sub;
            content: url("data:image/svg+xml,<svg width=\"14\" height=\"14\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><g id=\"ico-/-24-/-actions-/-open_in_new\"><path id=\"Icon-color\" d=\"M17.5 12.0833V15.8333C17.5 16.7538 16.7538 17.5 15.8333 17.5H4.16667C3.24619 17.5 2.5 16.7538 2.5 15.8333V4.16667C2.5 3.24619 3.24619 2.5 4.16667 2.5H7.91667C8.14679 2.5 8.33333 2.68655 8.33333 2.91667V3.75C8.33333 3.98012 8.14679 4.16667 7.91667 4.16667H4.16667V15.8333H15.8333V12.0833C15.8333 11.8532 16.0199 11.6667 16.25 11.6667H17.0833C17.3135 11.6667 17.5 11.8532 17.5 12.0833ZM17.3167 2.91667L17.0917 2.69167C16.98 2.57535 16.8278 2.50668 16.6667 2.5H11.25C11.0199 2.5 10.8333 2.68655 10.8333 2.91667V3.75C10.8333 3.98012 11.0199 4.16667 11.25 4.16667H14.6583L7.625 11.2C7.54612 11.2782 7.50175 11.3847 7.50175 11.4958C7.50175 11.6069 7.54612 11.7134 7.625 11.7917L8.20833 12.375C8.28657 12.4539 8.39307 12.4982 8.50417 12.4982C8.61527 12.4982 8.72176 12.4539 8.8 12.375L15.8333 5.35V8.75C15.8333 8.98012 16.0199 9.16667 16.25 9.16667H17.0833C17.3135 9.16667 17.5 8.98012 17.5 8.75V3.33333C17.4955 3.17342 17.4299 3.02132 17.3167 2.90833V2.91667Z\" fill=\"%231A4200\"/></g></svg>");
        }

        /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */
    </style>
    <style type="text/css">
        .fancybox-margin {
            margin-right: 15px;
        }

        .box--no-padding {
            background-color: #000000;
            color: #000000;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 10px solid rgb(16, 204, 10);
        }
    </style>
    <script src="https://bat.bing.com/p/action/16005611.js" type="text/javascript" async=""
        data-ueto="ueto_8c931ec7a9"></script>
    <meta http-equiv="origin-trial"
        content="A7JYkbIvWKmS8mWYjXO12SIIsfPdI7twY91Y3LWOV/YbZmN1ZhYv8O+Zs6/IPCfBE99aV9tIC8sWZSCN09vf7gkAAACWeyJvcmlnaW4iOiJodHRwczovL2N0LnBpbnRlcmVzdC5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZzIiLCJleHBpcnkiOjE3NDIzNDIzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
    <style>
        :root {
            --color-grey-1000: #191919;
            --color-grey-1000-mask: rgb(25 25 25 / 0.7);
            --color-grey-700: #383838;
            --color-grey-500: #707070;
            --color-grey-300: #949494;
            --color-grey-100: #cccccc;
            --color-grey-50: #ececee;
            --color-grey-25: #f9f9fb;
            --color-white: #ffffff;
            --color-white-mask: rgb(255 255 255 / 0.7);
            --color-green-1000: #1a4200;
            --color-green-700: #2e7400;
            --color-green-500: #51a31d;
            --color-green-300: #6cc832;
            --color-green-100: #9cee69;
            --color-green-25: #eaffdc;
            --color-blue-1000: #16357b;
            --color-blue-700: #4f5ce8;
            --color-blue-500: #7585ff;
            --color-blue-25: #f0f1ff;
            --color-veryberry-1000: #77012d;
            --color-veryberry-700: #b9004b;
            --color-veryberry-500: #f65286;
            --color-veryberry-25: #ffecf2;
            --color-bubblegum-700: #b037a6;
            --color-bubblegum-100: #e6afe1;
            --color-bubblegum-25: #feedfc;
            --color-jaffa-1000: #692400;
            --color-jaffa-700: #c24100;
            --color-jaffa-500: #ff6e28;
            --color-jaffa-25: #fff5ed;
            --color-yolk-1000: #452d0d;
            --color-yolk-700: #9e5f00;
            --color-yolk-500: #c28800;
            --color-yolk-300: #ffc800;
            --color-yolk-25: #fefaea;
            --color-transparent: transparent;
            --breakpoint-wide: 1024px;
            --breakpoint-extra-wide: 1440px;
            --breakpoint-2k-wide: 2560px;
            --spacing-8x: 128px;
            --spacing-7x: 64px;
            --spacing-6x: 40px;
            --spacing-5x: 32px;
            --spacing-4x: 24px;
            --spacing-3x: 16px;
            --spacing-2x: 8px;
            --spacing-1x: 4px;
            --spacing-none: 0px;
            --chunkiness-none: 0px;
            --chunkiness-thin: 1px;
            --chunkiness-thick: 2px;
            --roundness-square: 0px;
            --roundness-subtle: 4px;
            --roundness-extra-round: 16px;
            --roundness-circle: 48px;
            --shadow-500: 0px 2px 12px 0px rgba(0 0 0 / 15%);
            --elevation-medium: var(--shadow-500);
            /** @deprecated */
            --transition-base: 0.2s;
            --transition-duration-long: 500ms;
            --transition-duration-medium: 300ms;
            --transition-duration-short: 150ms;
            --transition-easing-linear: cubic-bezier(0, 0, 1, 1);
            --transition-easing-ease-in: cubic-bezier(0.42, 0, 1, 1);
            --transition-easing-ease-in-out: cubic-bezier(0.42, 0, 0.58, 1);
            --transition-easing-ease-out: cubic-bezier(0, 0, 0.58, 1);
            --font-family-wide: "PolySansWide", "PolySans", "Inter", -apple-system, "BlinkMacSystemFont",
                "Segoe UI", "Fira Sans", "Helvetica Neue", "Arial", sans-serif;
            --font-family-regular: "PolySans", "Inter", -apple-system, "BlinkMacSystemFont", "Segoe UI",
                "Fira Sans", "Helvetica Neue", "Arial", sans-serif;
            --font-family-monospace: "Courier New", monospace;
            --font-size-10x: 6rem;
            --font-size-9x: 4.5rem;
            --font-size-8x: 3rem;
            --font-size-7x: 2.25rem;
            --font-size-6x: 1.875rem;
            --font-size-5x: 1.5rem;
            --font-size-4x: 1.125rem;
            --font-size-3x: 1rem;
            --font-size-2x: 0.875rem;
            --font-size-1x: 0.75rem;
            --font-weight-bulky: 700;
            --font-weight-median: 600;
            --font-weight-neutral: 400;
            --font-spacing-tight: -0.02em;
            --font-spacing-normal: 0;
            --font-spacing-loose: 0.02em;
            --font-height-tight: 1;
            --font-height-normal: 1.5;
            --icon-size-5x: 48px;
            --icon-size-4x: 40px;
            --icon-size-3x: 32px;
            --icon-size-2x: 24px;
            --icon-size-1x: 16px;
            --icon-size-text-responsive: calc(var(--font-size-3x) * 1.5);
            --layer-depth-ceiling: 9999;
            --minimum-touch-area: 40px;
            /* component wiring? ------------------------------------------ */
            --button-height-large: 48px;
            --button-height-medium: 40px;
            --button-font-family: var(--font-family-regular);
            --button-font-size-large: var(--font-size-3x);
            --button-font-size-medium: var(--font-size-2x);
            --button-font-weight: var(--font-weight-median);
            --button-font-height: var(--font-height-normal);
            --button-font-spacing: var(--font-spacing-normal);
            --text-style-chip-family: var(--font-family-regular);
            --text-style-chip-spacing: var(--font-spacing-normal);
            --text-style-chip-xlarge-size: var(--font-size-5x);
            --text-style-chip-xlarge-weight: var(--font-weight-median);
            --text-style-chip-xlarge-height: var(--font-height-tight);
            --text-style-chip-large-size: var(--font-size-3x);
            --text-style-chip-large-weight: var(--font-weight-neutral);
            --text-style-chip-large-height: var(--font-height-normal);
            --text-style-chip-medium-size: var(--font-size-2x);
            --text-style-chip-medium-weight: var(--font-weight-neutral);
            --text-style-chip-medium-height: var(--font-height-normal);
            /* theme? ------------------------------------------------- */
            --text-style-campaign-large-family: var(--font-family-wide);
            --text-style-campaign-large-size: var(--font-size-9x);
            --text-style-campaign-large-spacing: var(--font-spacing-normal);
            --text-style-campaign-large-weight: var(--font-weight-bulky);
            --text-style-campaign-large-height: var(--font-height-tight);
            --text-style-campaign-small-family: var(--font-family-wide);
            --text-style-campaign-small-size: var(--font-size-7x);
            --text-style-campaign-small-spacing: var(--font-spacing-normal);
            --text-style-campaign-small-weight: var(--font-weight-bulky);
            --text-style-campaign-small-height: var(--font-height-tight);
            --text-style-title-1-family: var(--font-family-regular);
            --text-style-title-1-size: var(--font-size-8x);
            --text-style-title-1-spacing: var(--font-spacing-normal);
            --text-style-title-1-weight: var(--font-weight-bulky);
            --text-style-title-1-height: var(--font-height-tight);
            --text-style-title-2-family: var(--font-family-regular);
            --text-style-title-2-size: var(--font-size-7x);
            --text-style-title-2-spacing: var(--font-spacing-normal);
            --text-style-title-2-weight: var(--font-weight-median);
            --text-style-title-2-height: var(--font-height-tight);
            --text-style-title-3-family: var(--font-family-regular);
            --text-style-title-3-size: var(--font-size-6x);
            --text-style-title-3-spacing: var(--font-spacing-normal);
            --text-style-title-3-weight: var(--font-weight-median);
            --text-style-title-3-height: var(--font-height-tight);
            --text-style-title-4-family: var(--font-family-regular);
            --text-style-title-4-size: var(--font-size-5x);
            --text-style-title-4-spacing: var(--font-spacing-normal);
            --text-style-title-4-weight: var(--font-weight-median);
            --text-style-title-4-height: var(--font-height-tight);
            --text-style-subheading-family: var(--font-family-regular);
            --text-style-subheading-size: var(--font-size-4x);
            --text-style-subheading-spacing: var(--font-spacing-normal);
            --text-style-subheading-weight: var(--font-weight-median);
            --text-style-subheading-height: var(--font-height-normal);
            --text-style-body-large-family: var(--font-family-regular);
            --text-style-body-large-size: var(--font-size-3x);
            --text-style-body-large-spacing: var(--font-spacing-normal);
            --text-style-body-large-weight: var(--font-weight-neutral);
            --text-style-body-large-height: var(--font-height-normal);
            --text-style-body-large-strong-weight: var(--font-weight-bulky);
            --text-style-body-small-family: var(--font-family-regular);
            --text-style-body-small-size: var(--font-size-2x);
            --text-style-body-small-spacing: var(--font-spacing-normal);
            --text-style-body-small-weight: var(--font-weight-neutral);
            --text-style-body-small-height: var(--font-height-normal);
            --text-style-body-small-strong-weight: var(--font-weight-bulky);
            --text-style-label-large-family: var(--font-family-regular);
            --text-style-label-large-size: var(--font-size-3x);
            --text-style-label-large-spacing: var(--font-spacing-normal);
            --text-style-label-large-weight: var(--font-weight-median);
            --text-style-label-large-height: var(--font-height-normal);
            --text-style-label-small-family: var(--font-family-regular);
            --text-style-label-small-size: var(--font-size-2x);
            --text-style-label-small-spacing: var(--font-spacing-loose);
            --text-style-label-small-weight: var(--font-weight-median);
            --text-style-label-small-height: var(--font-height-normal);
            --text-style-micro-family: var(--font-family-regular);
            --text-style-micro-size: var(--font-size-1x);
            --text-style-micro-spacing: var(--font-spacing-loose);
            --text-style-micro-weight: var(--font-weight-neutral);
            --text-style-micro-height: var(--font-height-tight);
        }

        .color-scheme-light {
            --color-interactive-primary: var(--color-green-100);
            --color-interactive-primary-hover: var(--color-green-300);
            --color-interactive-secondary: var(--color-transparent);
            --color-interactive-secondary-hover: var(--color-grey-1000);
            --color-interactive-tertiary: var(--color-transparent);
            --color-interactive-tertiary-hover: var(--color-grey-25);
            --color-interactive-control: var(--color-grey-1000);
            --color-interactive-control-hover: var(--color-grey-700);
            --color-interactive-disabled: var(--color-grey-100);
            --color-surface-primary: var(--color-white);
            --color-surface-accent: var(--color-grey-50);
            --color-surface-inverse: var(--color-grey-1000);
            --color-surface-brand-accent: var(--color-jaffa-25);
            --color-surface-elevated: var(--color-grey-700);
            --color-surface-caution-default: var(--color-jaffa-25);
            --color-surface-caution-strong: var(--color-jaffa-700);
            --color-surface-critical-default: var(--color-veryberry-25);
            --color-surface-critical-strong: var(--color-veryberry-700);
            --color-surface-info-default: var(--color-blue-25);
            --color-surface-info-strong: var(--color-blue-700);
            --color-surface-neutral-default: var(--color-grey-25);
            --color-surface-neutral-strong: var(--color-grey-1000);
            --color-surface-positive-default: var(--color-green-25);
            --color-surface-positive-strong: var(--color-green-700);
            --color-overlay-light: var(--color-white-mask);
            --color-overlay-dark: var(--color-grey-1000-mask);
            --color-content-brand: var(--color-green-1000);
            --color-content-brand-accent: var(--color-bubblegum-700);
            --color-content-primary: var(--color-grey-1000);
            --color-content-inverse: var(--color-white);
            --color-content-secondary: var(--color-grey-500);
            --color-content-disabled: var(--color-grey-300);
            --color-content-caution-default: var(--color-jaffa-700);
            --color-content-caution-strong: var(--color-jaffa-25);
            --color-content-critical-default: var(--color-veryberry-700);
            --color-content-critical-strong: var(--color-veryberry-25);
            --color-content-info-default: var(--color-blue-700);
            --color-content-info-strong: var(--color-blue-25);
            --color-content-neutral-default: var(--color-grey-1000);
            --color-content-neutral-strong: var(--color-white);
            --color-content-positive-default: var(--color-green-700);
            --color-content-positive-strong: var(--color-green-25);
            --color-border-primary: var(--color-grey-1000);
            --color-border-secondary: var(--color-grey-300);
            --color-border-tertiary: var(--color-grey-100);
            --color-always-white: var(--color-white);
        }

        .color-scheme-dark {
            --color-interactive-primary: var(--color-green-100);
            --color-interactive-primary-hover: var(--color-green-300);
            --color-interactive-secondary: var(--color-transparent);
            --color-interactive-secondary-hover: var(--color-white);
            --color-interactive-tertiary: var(--color-transparent);
            --color-interactive-tertiary-hover: var(--color-grey-700);
            --color-interactive-control: var(--color-white);
            --color-interactive-control-hover: var(--color-grey-100);
            --color-interactive-disabled: var(--color-grey-700);
            --color-surface-primary: var(--color-grey-1000);
            --color-surface-accent: var(--color-grey-700);
            --color-surface-inverse: var(--color-white);
            --color-surface-brand-accent: var(--color-grey-700);
            --color-surface-elevated: var(--color-grey-700);
            --color-surface-caution-default: var(--color-jaffa-1000);
            --color-surface-caution-strong: var(--color-jaffa-500);
            --color-surface-critical-default: var(--color-veryberry-1000);
            --color-surface-critical-strong: var(--color-veryberry-500);
            --color-surface-info-default: var(--color-blue-1000);
            --color-surface-info-strong: var(--color-blue-500);
            --color-surface-neutral-default: var(--color-grey-700);
            --color-surface-neutral-strong: var(--color-white);
            --color-surface-positive-default: var(--color-green-1000);
            --color-surface-positive-strong: var(--color-green-500);
            --color-overlay-light: var(--color-white-mask);
            --color-overlay-dark: var(--color-grey-1000-mask);
            --color-content-brand: var(--color-green-1000);
            --color-content-brand-accent: var(--color-bubblegum-100);
            --color-content-primary: var(--color-white);
            --color-content-inverse: var(--color-grey-1000);
            --color-content-secondary: var(--color-grey-100);
            --color-content-disabled: var(--color-grey-500);
            --color-content-caution-default: var(--color-jaffa-500);
            --color-content-caution-strong: var(--color-jaffa-1000);
            --color-content-critical-default: var(--color-veryberry-500);
            --color-content-critical-strong: var(--color-veryberry-1000);
            --color-content-info-default: var(--color-blue-500);
            --color-content-info-strong: var(--color-blue-1000);
            --color-content-neutral-default: var(--color-white);
            --color-content-neutral-strong: var(--color-grey-1000);
            --color-content-positive-default: var(--color-green-500);
            --color-content-positive-strong: var(--color-green-1000);
            --color-border-primary: var(--color-white);
            --color-border-secondary: var(--color-grey-500);
            --color-border-tertiary: var(--color-grey-700);
            --color-always-white: var(--color-white);
        }

        /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvYmFzZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMENBQUE7RUFFQSwyQkFBQTtFQUNBLDBCQUFBO0VBQ0EsMEJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3QkFBQTtFQUVBLCtCQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBRUEsMkJBQUE7RUFDQSwwQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFFQSwwQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBRUEsZ0NBQUE7RUFFQSx5QkFBQTtFQUNBLCtCQUFBO0VBQ0EsNEJBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFFQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFFQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsNkJBQUE7RUFDQSx3QkFBQTtFQUVBLGdEQUFBO0VBQ0EscUNBQUE7RUFFQSxpQkFBQTtFQUNBLHVCQUFBO0VBRUEsaUNBQUE7RUFDQSxtQ0FBQTtFQUNBLGtDQUFBO0VBRUEsb0RBQUE7RUFDQSx3REFBQTtFQUNBLCtEQUFBO0VBQ0EseURBQUE7RUFFQTtrRUFBQTtFQUVBO3NEQUFBO0VBRUEsaURBQUE7RUFFQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtFQUVBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtFQUVBLDZCQUFBO0VBQ0Esd0JBQUE7RUFDQSw0QkFBQTtFQUVBLHNCQUFBO0VBQ0EseUJBQUE7RUFFQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0EsNERBQUE7RUFFQSwyQkFBQTtFQUVBLDBCQUFBO0VBRUEsaUVBQUE7RUFFQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsK0NBQUE7RUFDQSwrQ0FBQTtFQUNBLGlEQUFBO0VBRUEsb0RBQUE7RUFDQSxxREFBQTtFQUNBLGtEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGlEQUFBO0VBQ0EsMERBQUE7RUFDQSx5REFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUVBLDZEQUFBO0VBRUEsMkRBQUE7RUFDQSxxREFBQTtFQUNBLCtEQUFBO0VBQ0EsNERBQUE7RUFDQSw0REFBQTtFQUVBLDJEQUFBO0VBQ0EscURBQUE7RUFDQSwrREFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxxREFBQTtFQUNBLHFEQUFBO0VBRUEsdURBQUE7RUFDQSw4Q0FBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFDQSxxREFBQTtFQUVBLHVEQUFBO0VBQ0EsOENBQUE7RUFDQSx3REFBQTtFQUNBLHNEQUFBO0VBQ0EscURBQUE7RUFFQSx1REFBQTtFQUNBLDhDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLHFEQUFBO0VBRUEsMERBQUE7RUFDQSxpREFBQTtFQUNBLDJEQUFBO0VBQ0EseURBQUE7RUFDQSx5REFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDBEQUFBO0VBQ0EsaURBQUE7RUFDQSwyREFBQTtFQUNBLDBEQUFBO0VBQ0EseURBQUE7RUFDQSwrREFBQTtFQUVBLDJEQUFBO0VBQ0Esa0RBQUE7RUFDQSw0REFBQTtFQUNBLDBEQUFBO0VBQ0EsMERBQUE7RUFFQSwyREFBQTtFQUNBLGtEQUFBO0VBQ0EsMkRBQUE7RUFDQSwwREFBQTtFQUNBLDBEQUFBO0VBRUEscURBQUE7RUFDQSw0Q0FBQTtFQUNBLHFEQUFBO0VBQ0EscURBQUE7RUFDQSxtREFBQTtBQXhDRjs7QUEyQ0E7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwyREFBQTtFQUNBLHNEQUFBO0VBQ0Esd0RBQUE7RUFDQSxtREFBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwyQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsK0NBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esc0RBQUE7RUFDQSxzREFBQTtFQUNBLDJEQUFBO0VBQ0EsMkRBQUE7RUFDQSxrREFBQTtFQUNBLGtEQUFBO0VBQ0EscURBQUE7RUFDQSxzREFBQTtFQUNBLHVEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLCtDQUFBO0VBQ0EsMkNBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSxxREFBQTtFQUNBLDREQUFBO0VBQ0EsMERBQUE7RUFDQSxtREFBQTtFQUNBLGlEQUFBO0VBQ0EsdURBQUE7RUFDQSxrREFBQTtFQUNBLHdEQUFBO0VBQ0Esc0RBQUE7RUFFQSw4Q0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQTdDRjs7QUFnREE7RUFDRSxtREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLHNEQUFBO0VBQ0EseURBQUE7RUFDQSwrQ0FBQTtFQUNBLHdEQUFBO0VBQ0EsbURBQUE7RUFFQSwrQ0FBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7RUFDQSxtREFBQTtFQUNBLCtDQUFBO0VBQ0Esd0RBQUE7RUFDQSxzREFBQTtFQUNBLDZEQUFBO0VBQ0EsMkRBQUE7RUFDQSxvREFBQTtFQUNBLGtEQUFBO0VBQ0Esc0RBQUE7RUFDQSxrREFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFFQSw4Q0FBQTtFQUNBLGlEQUFBO0VBRUEsOENBQUE7RUFDQSx3REFBQTtFQUNBLDJDQUFBO0VBQ0EsK0NBQUE7RUFDQSxnREFBQTtFQUNBLCtDQUFBO0VBQ0EsdURBQUE7RUFDQSx1REFBQTtFQUNBLDREQUFBO0VBQ0EsNERBQUE7RUFDQSxtREFBQTtFQUNBLG1EQUFBO0VBQ0EsbURBQUE7RUFDQSxzREFBQTtFQUNBLHdEQUFBO0VBQ0Esd0RBQUE7RUFFQSwwQ0FBQTtFQUNBLCtDQUFBO0VBQ0EsOENBQUE7RUFFQSx3Q0FBQTtBQWxERiIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcGllZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9lbnZhdG8vZW52YXRvLWRlc2lnbi10b2tlbnMvYmxvYi9tYWluL3Rva2Vucy5jc3NcblxuOnJvb3Qge1xuICAtLWNvbG9yLWdyZXktMTAwMDogIzE5MTkxOTtcbiAgLS1jb2xvci1ncmV5LTEwMDAtbWFzazogcmdiKDI1IDI1IDI1IC8gMC43KTtcbiAgLS1jb2xvci1ncmV5LTcwMDogIzM4MzgzODtcbiAgLS1jb2xvci1ncmV5LTUwMDogIzcwNzA3MDtcbiAgLS1jb2xvci1ncmV5LTMwMDogIzk0OTQ5NDtcbiAgLS1jb2xvci1ncmV5LTEwMDogI2NjY2NjYztcbiAgLS1jb2xvci1ncmV5LTUwOiAjZWNlY2VlO1xuICAtLWNvbG9yLWdyZXktMjU6ICNmOWY5ZmI7XG4gIC0tY29sb3Itd2hpdGU6ICNmZmZmZmY7XG4gIC0tY29sb3Itd2hpdGUtbWFzazogcmdiKDI1NSAyNTUgMjU1IC8gMC43KTtcblxuICAtLWNvbG9yLWdyZWVuLTEwMDA6ICMxYTQyMDA7XG4gIC0tY29sb3ItZ3JlZW4tNzAwOiAjMmU3NDAwO1xuICAtLWNvbG9yLWdyZWVuLTUwMDogIzUxYTMxZDtcbiAgLS1jb2xvci1ncmVlbi0zMDA6ICM2Y2M4MzI7XG4gIC0tY29sb3ItZ3JlZW4tMTAwOiAjOWNlZTY5O1xuICAtLWNvbG9yLWdyZWVuLTI1OiAjZWFmZmRjO1xuXG4gIC0tY29sb3ItYmx1ZS0xMDAwOiAjMTYzNTdiO1xuICAtLWNvbG9yLWJsdWUtNzAwOiAjNGY1Y2U4O1xuICAtLWNvbG9yLWJsdWUtNTAwOiAjNzU4NWZmO1xuICAtLWNvbG9yLWJsdWUtMjU6ICNmMGYxZmY7XG5cbiAgLS1jb2xvci12ZXJ5YmVycnktMTAwMDogIzc3MDEyZDtcbiAgLS1jb2xvci12ZXJ5YmVycnktNzAwOiAjYjkwMDRiO1xuICAtLWNvbG9yLXZlcnliZXJyeS01MDA6ICNmNjUyODY7XG4gIC0tY29sb3ItdmVyeWJlcnJ5LTI1OiAjZmZlY2YyO1xuXG4gIC0tY29sb3ItYnViYmxlZ3VtLTcwMDogI2IwMzdhNjtcbiAgLS1jb2xvci1idWJibGVndW0tMTAwOiAjZTZhZmUxO1xuICAtLWNvbG9yLWJ1YmJsZWd1bS0yNTogI2ZlZWRmYztcblxuICAtLWNvbG9yLWphZmZhLTEwMDA6ICM2OTI0MDA7XG4gIC0tY29sb3ItamFmZmEtNzAwOiAjYzI0MTAwO1xuICAtLWNvbG9yLWphZmZhLTUwMDogI2ZmNmUyODtcbiAgLS1jb2xvci1qYWZmYS0yNTogI2ZmZjVlZDtcblxuICAtLWNvbG9yLXlvbGstMTAwMDogIzQ1MmQwZDtcbiAgLS1jb2xvci15b2xrLTcwMDogIzllNWYwMDtcbiAgLS1jb2xvci15b2xrLTUwMDogI2MyODgwMDtcbiAgLS1jb2xvci15b2xrLTMwMDogI2ZmYzgwMDtcbiAgLS1jb2xvci15b2xrLTI1OiAjZmVmYWVhO1xuXG4gIC0tY29sb3ItdHJhbnNwYXJlbnQ6IHRyYW5zcGFyZW50O1xuXG4gIC0tYnJlYWtwb2ludC13aWRlOiAxMDI0cHg7XG4gIC0tYnJlYWtwb2ludC1leHRyYS13aWRlOiAxNDQwcHg7XG4gIC0tYnJlYWtwb2ludC0yay13aWRlOiAyNTYwcHg7XG5cbiAgLS1zcGFjaW5nLTh4OiAxMjhweDtcbiAgLS1zcGFjaW5nLTd4OiA2NHB4O1xuICAtLXNwYWNpbmctNng6IDQwcHg7XG4gIC0tc3BhY2luZy01eDogMzJweDtcbiAgLS1zcGFjaW5nLTR4OiAyNHB4O1xuICAtLXNwYWNpbmctM3g6IDE2cHg7XG4gIC0tc3BhY2luZy0yeDogOHB4O1xuICAtLXNwYWNpbmctMXg6IDRweDtcbiAgLS1zcGFjaW5nLW5vbmU6IDBweDtcblxuICAtLWNodW5raW5lc3Mtbm9uZTogMHB4O1xuICAtLWNodW5raW5lc3MtdGhpbjogMXB4O1xuICAtLWNodW5raW5lc3MtdGhpY2s6IDJweDtcblxuICAtLXJvdW5kbmVzcy1zcXVhcmU6IDBweDtcbiAgLS1yb3VuZG5lc3Mtc3VidGxlOiA0cHg7XG4gIC0tcm91bmRuZXNzLWV4dHJhLXJvdW5kOiAxNnB4O1xuICAtLXJvdW5kbmVzcy1jaXJjbGU6IDQ4cHg7XG5cbiAgLS1zaGFkb3ctNTAwOiAwcHggMnB4IDEycHggMHB4IHJnYmEoMCAwIDAgLyAxNSUpO1xuICAtLWVsZXZhdGlvbi1tZWRpdW06IHZhcigtLXNoYWRvdy01MDApO1xuXG4gIC8qKiBAZGVwcmVjYXRlZCAqL1xuICAtLXRyYW5zaXRpb24tYmFzZTogMC4ycztcblxuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tbG9uZzogNTAwbXM7XG4gIC0tdHJhbnNpdGlvbi1kdXJhdGlvbi1tZWRpdW06IDMwMG1zO1xuICAtLXRyYW5zaXRpb24tZHVyYXRpb24tc2hvcnQ6IDE1MG1zO1xuXG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctbGluZWFyOiBjdWJpYy1iZXppZXIoMCwgMCwgMSwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1pbjogY3ViaWMtYmV6aWVyKDAuNDIsIDAsIDEsIDEpO1xuICAtLXRyYW5zaXRpb24tZWFzaW5nLWVhc2UtaW4tb3V0OiBjdWJpYy1iZXppZXIoMC40MiwgMCwgMC41OCwgMSk7XG4gIC0tdHJhbnNpdGlvbi1lYXNpbmctZWFzZS1vdXQ6IGN1YmljLWJlemllcigwLCAwLCAwLjU4LCAxKTtcblxuICAtLWZvbnQtZmFtaWx5LXdpZGU6IFwiUG9seVNhbnNXaWRlXCIsIFwiUG9seVNhbnNcIiwgXCJJbnRlclwiLCAtYXBwbGUtc3lzdGVtLCBcIkJsaW5rTWFjU3lzdGVtRm9udFwiLFxuICAgIFwiU2Vnb2UgVUlcIiwgXCJGaXJhIFNhbnNcIiwgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIkFyaWFsXCIsIHNhbnMtc2VyaWY7XG4gIC0tZm9udC1mYW1pbHktcmVndWxhcjogXCJQb2x5U2Fuc1wiLCBcIkludGVyXCIsIC1hcHBsZS1zeXN0ZW0sIFwiQmxpbmtNYWNTeXN0ZW1Gb250XCIsIFwiU2Vnb2UgVUlcIixcbiAgICBcIkZpcmEgU2Fuc1wiLCBcIkhlbHZldGljYSBOZXVlXCIsIFwiQXJpYWxcIiwgc2Fucy1zZXJpZjtcbiAgLS1mb250LWZhbWlseS1tb25vc3BhY2U6IFwiQ291cmllciBOZXdcIiwgbW9ub3NwYWNlO1xuXG4gIC0tZm9udC1zaXplLTEweDogNnJlbTtcbiAgLS1mb250LXNpemUtOXg6IDQuNXJlbTtcbiAgLS1mb250LXNpemUtOHg6IDNyZW07XG4gIC0tZm9udC1zaXplLTd4OiAyLjI1cmVtO1xuICAtLWZvbnQtc2l6ZS02eDogMS44NzVyZW07XG4gIC0tZm9udC1zaXplLTV4OiAxLjVyZW07XG4gIC0tZm9udC1zaXplLTR4OiAxLjEyNXJlbTtcbiAgLS1mb250LXNpemUtM3g6IDFyZW07XG4gIC0tZm9udC1zaXplLTJ4OiAwLjg3NXJlbTtcbiAgLS1mb250LXNpemUtMXg6IDAuNzVyZW07XG5cbiAgLS1mb250LXdlaWdodC1idWxreTogNzAwO1xuICAtLWZvbnQtd2VpZ2h0LW1lZGlhbjogNjAwO1xuICAtLWZvbnQtd2VpZ2h0LW5ldXRyYWw6IDQwMDtcblxuICAtLWZvbnQtc3BhY2luZy10aWdodDogLTAuMDJlbTtcbiAgLS1mb250LXNwYWNpbmctbm9ybWFsOiAwO1xuICAtLWZvbnQtc3BhY2luZy1sb29zZTogMC4wMmVtO1xuXG4gIC0tZm9udC1oZWlnaHQtdGlnaHQ6IDE7XG4gIC0tZm9udC1oZWlnaHQtbm9ybWFsOiAxLjU7XG5cbiAgLS1pY29uLXNpemUtNXg6IDQ4cHg7XG4gIC0taWNvbi1zaXplLTR4OiA0MHB4O1xuICAtLWljb24tc2l6ZS0zeDogMzJweDtcbiAgLS1pY29uLXNpemUtMng6IDI0cHg7XG4gIC0taWNvbi1zaXplLTF4OiAxNnB4O1xuICAtLWljb24tc2l6ZS10ZXh0LXJlc3BvbnNpdmU6IGNhbGModmFyKC0tZm9udC1zaXplLTN4KSAqIDEuNSk7XG5cbiAgLS1sYXllci1kZXB0aC1jZWlsaW5nOiA5OTk5O1xuXG4gIC0tbWluaW11bS10b3VjaC1hcmVhOiA0MHB4O1xuXG4gIC8qIGNvbXBvbmVudCB3aXJpbmc/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4gIC0tYnV0dG9uLWhlaWdodC1sYXJnZTogNDhweDtcbiAgLS1idXR0b24taGVpZ2h0LW1lZGl1bTogNDBweDtcbiAgLS1idXR0b24tZm9udC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLWJ1dHRvbi1mb250LXNpemUtbGFyZ2U6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tYnV0dG9uLWZvbnQtc2l6ZS1tZWRpdW06IHZhcigtLWZvbnQtc2l6ZS0yeCk7XG4gIC0tYnV0dG9uLWZvbnQtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1tZWRpYW4pO1xuICAtLWJ1dHRvbi1mb250LWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcbiAgLS1idXR0b24tZm9udC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtY2hpcC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAteGxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS01eCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLXhsYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LXRpZ2h0KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utc2l6ZTogdmFyKC0tZm9udC1zaXplLTN4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2Utd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtY2hpcC1tZWRpdW0tc2l6ZTogdmFyKC0tZm9udC1zaXplLTJ4KTtcbiAgLS10ZXh0LXN0eWxlLWNoaXAtbWVkaXVtLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbmV1dHJhbCk7XG4gIC0tdGV4dC1zdHlsZS1jaGlwLW1lZGl1bS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLyogdGhlbWU/IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS13aWRlKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS05eCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1sYXJnZS1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLWxhcmdlLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtYnVsa3kpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tbGFyZ2UtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktd2lkZSk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtN3gpO1xuICAtLXRleHQtc3R5bGUtY2FtcGFpZ24tc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1jYW1wYWlnbi1zbWFsbC13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLWNhbXBhaWduLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xuXG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNpemU6IHZhcigtLWZvbnQtc2l6ZS04eCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0xLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtdGl0bGUtMS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTEtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc2l6ZTogdmFyKC0tZm9udC1zaXplLTd4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0yLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTItaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc2l6ZTogdmFyKC0tZm9udC1zaXplLTZ4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS0zLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTMtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc2l6ZTogdmFyKC0tZm9udC1zaXplLTV4KTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS10aXRsZS00LXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXRpdGxlLTQtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC10aWdodCk7XG5cbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc2l6ZTogdmFyKC0tZm9udC1zaXplLTR4KTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1zdWJoZWFkaW5nLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLXN1YmhlYWRpbmctaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuXG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0zeCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXNwYWNpbmc6IHZhcigtLWZvbnQtc3BhY2luZy1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW5ldXRyYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1ib2R5LWxhcmdlLXN0cm9uZy13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LWJ1bGt5KTtcblxuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1mYW1pbHk6IHZhcigtLWZvbnQtZmFtaWx5LXJlZ3VsYXIpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbm9ybWFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLWJvZHktc21hbGwtaGVpZ2h0OiB2YXIoLS1mb250LWhlaWdodC1ub3JtYWwpO1xuICAtLXRleHQtc3R5bGUtYm9keS1zbWFsbC1zdHJvbmctd2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1idWxreSk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLWxhcmdlLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1zaXplOiB2YXIoLS1mb250LXNpemUtM3gpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtbGFyZ2Utc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLW5vcm1hbCk7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS13ZWlnaHQ6IHZhcigtLWZvbnQtd2VpZ2h0LW1lZGlhbik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1sYXJnZS1oZWlnaHQ6IHZhcigtLWZvbnQtaGVpZ2h0LW5vcm1hbCk7XG5cbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWZhbWlseTogdmFyKC0tZm9udC1mYW1pbHktcmVndWxhcik7XG4gIC0tdGV4dC1zdHlsZS1sYWJlbC1zbWFsbC1zaXplOiB2YXIoLS1mb250LXNpemUtMngpO1xuICAtLXRleHQtc3R5bGUtbGFiZWwtc21hbGwtc3BhY2luZzogdmFyKC0tZm9udC1zcGFjaW5nLWxvb3NlKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLXdlaWdodDogdmFyKC0tZm9udC13ZWlnaHQtbWVkaWFuKTtcbiAgLS10ZXh0LXN0eWxlLWxhYmVsLXNtYWxsLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtbm9ybWFsKTtcblxuICAtLXRleHQtc3R5bGUtbWljcm8tZmFtaWx5OiB2YXIoLS1mb250LWZhbWlseS1yZWd1bGFyKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLXNpemU6IHZhcigtLWZvbnQtc2l6ZS0xeCk7XG4gIC0tdGV4dC1zdHlsZS1taWNyby1zcGFjaW5nOiB2YXIoLS1mb250LXNwYWNpbmctbG9vc2UpO1xuICAtLXRleHQtc3R5bGUtbWljcm8td2VpZ2h0OiB2YXIoLS1mb250LXdlaWdodC1uZXV0cmFsKTtcbiAgLS10ZXh0LXN0eWxlLW1pY3JvLWhlaWdodDogdmFyKC0tZm9udC1oZWlnaHQtdGlnaHQpO1xufVxuXG4uY29sb3Itc2NoZW1lLWxpZ2h0IHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtY29udHJvbC1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1zdXJmYWNlLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS01MCk7XG4gIC0tY29sb3Itc3VyZmFjZS1pbnZlcnNlOiB2YXIoLS1jb2xvci1ncmV5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW5mby1kZWZhdWx0OiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktMjUpO1xuICAtLWNvbG9yLXN1cmZhY2UtbmV1dHJhbC1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTcwMCk7XG5cbiAgLS1jb2xvci1vdmVybGF5LWxpZ2h0OiB2YXIoLS1jb2xvci13aGl0ZS1tYXNrKTtcbiAgLS1jb2xvci1vdmVybGF5LWRhcms6IHZhcigtLWNvbG9yLWdyZXktMTAwMC1tYXNrKTtcblxuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQ6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1idWJibGVndW0tNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LXByaW1hcnk6IHZhcigtLWNvbG9yLWdyZXktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbnZlcnNlOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1zZWNvbmRhcnk6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWRpc2FibGVkOiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWphZmZhLTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jYXV0aW9uLXN0cm9uZzogdmFyKC0tY29sb3ItamFmZmEtMjUpO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTcwMCk7XG4gIC0tY29sb3ItY29udGVudC1jcml0aWNhbC1zdHJvbmc6IHZhcigtLWNvbG9yLXZlcnliZXJyeS0yNSk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNzAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTI1KTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi03MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcG9zaXRpdmUtc3Ryb25nOiB2YXIoLS1jb2xvci1ncmVlbi0yNSk7XG5cbiAgLS1jb2xvci1ib3JkZXItcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTMwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cblxuLmNvbG9yLXNjaGVtZS1kYXJrIHtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5OiB2YXIoLS1jb2xvci1ncmVlbi0xMDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLXByaW1hcnktaG92ZXI6IHZhcigtLWNvbG9yLWdyZWVuLTMwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci10cmFuc3BhcmVudCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtc2Vjb25kYXJ5LWhvdmVyOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtdGVydGlhcnk6IHZhcigtLWNvbG9yLXRyYW5zcGFyZW50KTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS10ZXJ0aWFyeS1ob3ZlcjogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLWludGVyYWN0aXZlLWNvbnRyb2w6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1pbnRlcmFjdGl2ZS1jb250cm9sLWhvdmVyOiB2YXIoLS1jb2xvci1ncmV5LTEwMCk7XG4gIC0tY29sb3ItaW50ZXJhY3RpdmUtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcblxuICAtLWNvbG9yLXN1cmZhY2UtcHJpbWFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWFjY2VudDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtaW52ZXJzZTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLXN1cmZhY2UtYnJhbmQtYWNjZW50OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1lbGV2YXRlZDogdmFyKC0tY29sb3ItZ3JleS03MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY2F1dGlvbi1kZWZhdWx0OiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS01MDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtZGVmYXVsdDogdmFyKC0tY29sb3ItdmVyeWJlcnJ5LTEwMDApO1xuICAtLWNvbG9yLXN1cmZhY2UtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktNTAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tZGVmYXVsdDogdmFyKC0tY29sb3ItYmx1ZS0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTUwMCk7XG4gIC0tY29sb3Itc3VyZmFjZS1uZXV0cmFsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZXktNzAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLW5ldXRyYWwtc3Ryb25nOiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3Itc3VyZmFjZS1wb3NpdGl2ZS1kZWZhdWx0OiB2YXIoLS1jb2xvci1ncmVlbi0xMDAwKTtcbiAgLS1jb2xvci1zdXJmYWNlLXBvc2l0aXZlLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JlZW4tNTAwKTtcblxuICAtLWNvbG9yLW92ZXJsYXktbGlnaHQ6IHZhcigtLWNvbG9yLXdoaXRlLW1hc2spO1xuICAtLWNvbG9yLW92ZXJsYXktZGFyazogdmFyKC0tY29sb3ItZ3JleS0xMDAwLW1hc2spO1xuXG4gIC0tY29sb3ItY29udGVudC1icmFuZDogdmFyKC0tY29sb3ItZ3JlZW4tMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1icmFuZC1hY2NlbnQ6IHZhcigtLWNvbG9yLWJ1YmJsZWd1bS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtcHJpbWFyeTogdmFyKC0tY29sb3Itd2hpdGUpO1xuICAtLWNvbG9yLWNvbnRlbnQtaW52ZXJzZTogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXNlY29uZGFyeTogdmFyKC0tY29sb3ItZ3JleS0xMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtZGlzYWJsZWQ6IHZhcigtLWNvbG9yLWdyZXktNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tZGVmYXVsdDogdmFyKC0tY29sb3ItamFmZmEtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNhdXRpb24tc3Ryb25nOiB2YXIoLS1jb2xvci1qYWZmYS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LWNyaXRpY2FsLWRlZmF1bHQ6IHZhcigtLWNvbG9yLXZlcnliZXJyeS01MDApO1xuICAtLWNvbG9yLWNvbnRlbnQtY3JpdGljYWwtc3Ryb25nOiB2YXIoLS1jb2xvci12ZXJ5YmVycnktMTAwMCk7XG4gIC0tY29sb3ItY29udGVudC1pbmZvLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWJsdWUtNTAwKTtcbiAgLS1jb2xvci1jb250ZW50LWluZm8tc3Ryb25nOiB2YXIoLS1jb2xvci1ibHVlLTEwMDApO1xuICAtLWNvbG9yLWNvbnRlbnQtbmV1dHJhbC1kZWZhdWx0OiB2YXIoLS1jb2xvci13aGl0ZSk7XG4gIC0tY29sb3ItY29udGVudC1uZXV0cmFsLXN0cm9uZzogdmFyKC0tY29sb3ItZ3JleS0xMDAwKTtcbiAgLS1jb2xvci1jb250ZW50LXBvc2l0aXZlLWRlZmF1bHQ6IHZhcigtLWNvbG9yLWdyZWVuLTUwMCk7XG4gIC0tY29sb3ItY29udGVudC1wb3NpdGl2ZS1zdHJvbmc6IHZhcigtLWNvbG9yLWdyZWVuLTEwMDApO1xuXG4gIC0tY29sb3ItYm9yZGVyLXByaW1hcnk6IHZhcigtLWNvbG9yLXdoaXRlKTtcbiAgLS1jb2xvci1ib3JkZXItc2Vjb25kYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTUwMCk7XG4gIC0tY29sb3ItYm9yZGVyLXRlcnRpYXJ5OiB2YXIoLS1jb2xvci1ncmV5LTcwMCk7XG5cbiAgLS1jb2xvci1hbHdheXMtd2hpdGU6IHZhcigtLWNvbG9yLXdoaXRlKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */
    </style>
    <style>
        .brand-neue-button {
            gap: var(--spacing-2x);
            border-radius: var(--roundness-subtle);
            background: var(--color-interactive-primary);
            color: var(--color-content-brand);
            font-family: PolySans-Median;
            font-size: var(--font-size-2x);
            letter-spacing: 0.02em;
            text-align: center;
            padding: 0 20px;
        }

        .brand-neue-button:hover,
        .brand-neue-button:active,
        .brand-neue-button:focus {
            background: var(--color-interactive-primary-hover);
        }

        .brand-neue-button__open-in-new::after {
            font-size: 0;
            margin-left: 5px;
            vertical-align: sub;
            content: url("data:image/svg+xml,<svg width=\"14\" height=\"14\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><g id=\"ico-/-24-/-actions-/-open_in_new\"><path id=\"Icon-color\" d=\"M17.5 12.0833V15.8333C17.5 16.7538 16.7538 17.5 15.8333 17.5H4.16667C3.24619 17.5 2.5 16.7538 2.5 15.8333V4.16667C2.5 3.24619 3.24619 2.5 4.16667 2.5H7.91667C8.14679 2.5 8.33333 2.68655 8.33333 2.91667V3.75C8.33333 3.98012 8.14679 4.16667 7.91667 4.16667H4.16667V15.8333H15.8333V12.0833C15.8333 11.8532 16.0199 11.6667 16.25 11.6667H17.0833C17.3135 11.6667 17.5 11.8532 17.5 12.0833ZM17.3167 2.91667L17.0917 2.69167C16.98 2.57535 16.8278 2.50668 16.6667 2.5H11.25C11.0199 2.5 10.8333 2.68655 10.8333 2.91667V3.75C10.8333 3.98012 11.0199 4.16667 11.25 4.16667H14.6583L7.625 11.2C7.54612 11.2782 7.50175 11.3847 7.50175 11.4958C7.50175 11.6069 7.54612 11.7134 7.625 11.7917L8.20833 12.375C8.28657 12.4539 8.39307 12.4982 8.50417 12.4982C8.61527 12.4982 8.72176 12.4539 8.8 12.375L15.8333 5.35V8.75C15.8333 8.98012 16.0199 9.16667 16.25 9.16667H17.0833C17.3135 9.16667 17.5 8.98012 17.5 8.75V3.33333C17.4955 3.17342 17.4299 3.02132 17.3167 2.90833V2.91667Z\" fill=\"%231A4200\"/></g></svg>");
        }

        /*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9qYXZhc2NyaXB0L2NvbXBvbmVudHMvYnJhbmRfbmV1ZV90b2tlbnMvY29tcG9uZW50cy9idXR0b24uc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNCQUFBO0VBQ0Esc0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGlDQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGtEQUFBO0FBRUo7O0FBQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdEQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIuYnJhbmQtbmV1ZS1idXR0b25cbiAgZ2FwOiB2YXIoLS1zcGFjaW5nLTJ4KVxuICBib3JkZXItcmFkaXVzOiB2YXIoLS1yb3VuZG5lc3Mtc3VidGxlKVxuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb2xvci1pbnRlcmFjdGl2ZS1wcmltYXJ5KVxuICBjb2xvcjogdmFyKC0tY29sb3ItY29udGVudC1icmFuZClcbiAgZm9udC1mYW1pbHk6IFBvbHlTYW5zLU1lZGlhblxuICBmb250LXNpemU6IHZhcigtLWZvbnQtc2l6ZS0yeClcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDJlbVxuICB0ZXh0LWFsaWduOiBjZW50ZXJcbiAgcGFkZGluZzogMCAyMHB4XG4gICY6aG92ZXIsICY6YWN0aXZlLCAmOmZvY3VzXG4gICAgYmFja2dyb3VuZDogdmFyKC0tY29sb3ItaW50ZXJhY3RpdmUtcHJpbWFyeS1ob3ZlcilcblxuLmJyYW5kLW5ldWUtYnV0dG9uX19vcGVuLWluLW5ld1xuICAmOjphZnRlclxuICAgIGZvbnQtc2l6ZTogMFxuICAgIG1hcmdpbi1sZWZ0OiA1cHhcbiAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViXG4gICAgY29udGVudDogdXJsKCdkYXRhOmltYWdlL3N2Zyt4bWwsPHN2ZyB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTRcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PGcgaWQ9XCJpY28tLy0yNC0vLWFjdGlvbnMtLy1vcGVuX2luX25ld1wiPjxwYXRoIGlkPVwiSWNvbi1jb2xvclwiIGQ9XCJNMTcuNSAxMi4wODMzVjE1LjgzMzNDMTcuNSAxNi43NTM4IDE2Ljc1MzggMTcuNSAxNS44MzMzIDE3LjVINC4xNjY2N0MzLjI0NjE5IDE3LjUgMi41IDE2Ljc1MzggMi41IDE1LjgzMzNWNC4xNjY2N0MyLjUgMy4yNDYxOSAzLjI0NjE5IDIuNSA0LjE2NjY3IDIuNUg3LjkxNjY3QzguMTQ2NzkgMi41IDguMzMzMzMgMi42ODY1NSA4LjMzMzMzIDIuOTE2NjdWMy43NUM4LjMzMzMzIDMuOTgwMTIgOC4xNDY3OSA0LjE2NjY3IDcuOTE2NjcgNC4xNjY2N0g0LjE2NjY3VjE1LjgzMzNIMTUuODMzM1YxMi4wODMzQzE1LjgzMzMgMTEuODUzMiAxNi4wMTk5IDExLjY2NjcgMTYuMjUgMTEuNjY2N0gxNy4wODMzQzE3LjMxMzUgMTEuNjY2NyAxNy41IDExLjg1MzIgMTcuNSAxMi4wODMzWk0xNy4zMTY3IDIuOTE2NjdMMTcuMDkxNyAyLjY5MTY3QzE2Ljk4IDIuNTc1MzUgMTYuODI3OCAyLjUwNjY4IDE2LjY2NjcgMi41SDExLjI1QzExLjAxOTkgMi41IDEwLjgzMzMgMi42ODY1NSAxMC44MzMzIDIuOTE2NjdWMy43NUMxMC44MzMzIDMuOTgwMTIgMTEuMDE5OSA0LjE2NjY3IDExLjI1IDQuMTY2NjdIMTQuNjU4M0w3LjYyNSAxMS4yQzcuNTQ2MTIgMTEuMjc4MiA3LjUwMTc1IDExLjM4NDcgNy41MDE3NSAxMS40OTU4QzcuNTAxNzUgMTEuNjA2OSA3LjU0NjEyIDExLjcxMzQgNy42MjUgMTEuNzkxN0w4LjIwODMzIDEyLjM3NUM4LjI4NjU3IDEyLjQ1MzkgOC4zOTMwNyAxMi40OTgyIDguNTA0MTcgMTIuNDk4MkM4LjYxNTI3IDEyLjQ5ODIgOC43MjE3NiAxMi40NTM5IDguOCAxMi4zNzVMMTUuODMzMyA1LjM1VjguNzVDMTUuODMzMyA4Ljk4MDEyIDE2LjAxOTkgOS4xNjY2NyAxNi4yNSA5LjE2NjY3SDE3LjA4MzNDMTcuMzEzNSA5LjE2NjY3IDE3LjUgOC45ODAxMiAxNy41IDguNzVWMy4zMzMzM0MxNy40OTU1IDMuMTczNDIgMTcuNDI5OSAzLjAyMTMyIDE3LjMxNjcgMi45MDgzM1YyLjkxNjY3WlwiIGZpbGw9XCIlMjMxQTQyMDBcIi8+PC9nPjwvc3ZnPicpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */
    </style>
</head>

<body class="color-scheme-light" data-view="app impressionTracker" data-responsive="true" data-user-signed-in="false"
    __processed_046ac43c-cdf6-4311-9a75-3ea1775342f5__="true"
    bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZW5hYmxlZCIsIklOU1RBR1JBTSI6ImVuYWJsZWQiLCJUSUtUT0siOiJkaXNhYmxlZCIsIkxJTktFRElOIjoiZW5hYmxlZCIsIkNPTkZJRyI6ImRpc2FibGVkIn0sInZlcnNpb24iOiIyLjAuMjYiLCJzY29yZSI6MjAwMjYwfV0=">
<div style="display:none" data-nosnippet="true">
<p><a href="https://iposlot.uk.com/" >slot</a></p>
<p><a href="https://amandascottauthor.com/" >agen slot</a></p>
<p><a href="https://kerudung.id/" >bandar slot gacor terpercaya</a></p>
<p><a href="https://kerudung.id/kategori-produk/khimar/" >situs bandar slot</a></p>
<p><a href="https://paganibygibellini.com/" >situs bandar slot gacor terpercaya</a></p>
<p><a href="https://invoicetemplatehub.com/" >situs slot</a></p>
<p><a href="https://iposlot.pro/" >agen slot gacor</a></p>
<p><a href="https://ipototo.wiki/" >situs bandar slot gacor</a></p>
<p><a href="https://ipototo.ink/" >situs slot online gacor</a></p>
<p><a href="https://ipototo.info/" >bandar slot gacor</a></p>
<p><a href="https://repmasser.com/" >slot77</a></p>
<p><a href="https://situsipototo.com/" >slot777</a></p>
<p><a href="https://ipototo.click/" >slot</a></p>
<p><a href="https://bfrpro.com/" >slot online</a></p>
<p><a href="https://brooklynunderground.org/" >slot online terpercaya</a></p>
<p><a href="https://redcrossvarna.org/" >slot gacor</a></p>
<p><a href="https://dabrye.com/" >agen slot</a></p>
<p><a href="https://overtheboards.net/" >bandar slot</a></p>
<p><a href="https://docs.bicyclefi.io/" >slot gacor terpercaya</a></p>
<p><a href="https://terasana.com/" >bandar slot gacor</a></p>
<p><a href="https://situsbang188.com/" >slot online</a></p>
<p><a href="https://inceskotatua.com/" >slot online gacor</a></p>
<p><a href="https://www.buahcuan.com/" >daftar slot gacor resmi</a></p>
<p><a href="https://www.umaginechennai.com/" >situs slot online gacor</a></p>
<p><a href="https://ipototo96.com" >daftar situs slot gacor</a></p>
<p><a href="https://idxpragma.com/" >daftar demo slot gacor</a></p>
<p><a href="https://ipototoslot.com/" >demo slot pgsoft online gacor</a></p>
<p><a href="https://ipototologin.com/" >slot online pgsoft gacor</a></p>
<p><a href="https://www.sterisanimalhealth.com/" >pg soft slot online</a></p>
<p><a href="https://www.sterisanimalhealth.com/media/" >slot pgsoft online demo</a></p>
<p><a href="https://ipototomacau.com/" >live draw macau 4d</a></p>
<p><a href="https://liftvirginia.com/" >bandar toto macau</a></p>
<p><a href="https://madphotoanddesign.com/" >situs toto macau</a></p>
<p><a href="https://togelipototo.com/" >live toto macau</a></p>
<p><a href="https://www.petitmontparnasse.com/" >live draw macau</a></p>
<p><a href="https://agenipototo.com/" >situs toto macau</a></p>
<p><a href="https://www.cfhracing.com/" >situs toto 4d</a></p>
<p><a href="https://www.stefanikscontracting.com/services/" >togel toto 4d</a></p>
<p><a href="https://terramysterium.com/" >situs bandar toto macau</a></p>
<p><a href="https://blog.terramysterium.com/" >togel toto macau</a></p>
<p><a href="https://bandaripototo.com/" >togel</a></p>
<p><a href="https://forcediagnostics.com/" >togel 4d</a></p>
<p><a href="https://news.forcediagnostics.com/" >bandar togel</a></p>
<p><a href="https://dwifh.com/" >bandar togel terpercaya</a></p>
<p><a href="https://neurocat.ai/" >bandar togel resmi</a></p>
<p><a href="https://ipototoder.com/" >situs bandar togel</a></p>
<p><a href="https://ipototoplus.com/" >bandar togel 4d</a></p>
<p><a href="https://carnavaldebielsa.com/" >bandar togel 4d terpercaya</a></p>
<p><a href="https://ipotogel.org/" >situs togel</a></p>
<p><a href="https://www.ekolojikanayasa.org/" >bandar togel toto</a></p>
<p><a href="https://bandofdoodlers.com/" >bandar togel resmi terpercaya</a></p>
<p><a href="https://corvettec6collection.com/" >situs bandar togel 4d terpercaya</a></p>
<p><a href="https://grasslamp.com/" >bandar togel online</a></p>
<p><a href="https://containerbaryyc.com/" >bandar togel online terpercaya</a></p>
<p><a href="https://envormation.org/" >bandar togel online resmi</a></p>
<p><a href="https://ipototo.vip/" >bandar toto macau</a></p>
<p><a href="https://ipototo.us.com/" >toto macau</a></p>
<p><a href="https://quantumtictactoe.com/" >situs toto macau</a></p>
<p><a href="https://quantumtictactoe.com/play/" >toto macau 4d</a></p>
<p><a href="https://www.birminghamballet.com/" >situs bandar toto macau</a></p>
<p><a href="https://www.birminghamballet.com/nutcrackerauditions/" >bandar toto macau terpercaya</a></p>
<p><a href="https://ipomount.com/" >situs toto 4d</a></p>
<p><a href="https://ipomount.com/ipototo/" >situs toto macau 4d terpercaya</a></p>
<p><a href="https://usaseendurance.rocks/" >situs toto macau 4d</a></p>
<p><a href="https://creditar.io/" >bandar toto macau resmi</a></p>
<p><a href="https://blog.creditar.io/" >bandar toto macau terpercaya</a></p>
<p><a href="https://modelqualityintroductions.com/" >bandar toto macau resmi terpercaya</a></p>
<p><a href="https://ipototo.id/" >bandar toto</a></p>
<p><a href="https://ipototo.us/" >bandar toto macau</a></p>
<p><a href="https://ipototo.us/toto-macau/" >situs bandar toto macau</a></p>
<p><a href="https://www.shadowrise.nl/" >bandar macau</a></p>
<p><a href="https://chuckaburger.com/" >toto macau</a></p>
<p><a href="https://www.finkdifferent.io/" >situs toto macau terpercaya</a></p>
<p><a href="https://ipototo.uk.com/" >bandar toto macau resmi terpercaya</a></p>
<p><a href="https://townkingstonny.us/" >situs toto macau terpercaya</a></p>
<p><a href="https://petergabrielbacktofront.com/" >bandar toto macau terpercaya</a></p>
<p><a href="https://tindertalespod.com/" >situs bandar toto macau</a></p>
<p><a href="https://tindertalespod.com/contact/" >bandar toto macau</a></p>
<p><a href="https://tempesttradingbaja.com/" >slot 777</a></p>
<p><a href="https://www.optikbirmingham.com/gallery/" >bandar togel toto terpercaya</a></p>
<p><a href="https://securityworldtech.com/about-us/" >live draw macau</a></p>
<p><a href="https://broadway-pro.com/" >bandar slot gacor</a></p>
<p><a href="https://quyala.com/myuday-lupin-login/" >toto togel macau</a></p>
<p><a href="https://lifehacksstory.com/" >bandar slot gacor</a></p>
<p><a href="https://tambstechnics.com/basket.php/" >situs bandar toto macau terpercaya</a></p>
</div>

    <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">
        //<![CDATA[
        var gtmConfig = {}

        //]]>
    </script>

    <!--[if lte IE 8]>
  <div style="color:#fff;background:#f00;padding:20px;text-align:center;">
    ThemeForest no longeractively supports this version of Internet Explorer. We suggest that you <a href="https://windows.microsoft.com/en-us/internet-explorer/download-ie" style="color:#fff;text-decoration:underline;">upgrade to a newer version</a> or <a href="https://browsehappy.com/" style="color:#fff;text-decoration:underline;">try a different browser</a>.
  </div>
<![endif]-->

    <script
        src="https://public-assets.envato-static.com/assets/gtm_measurements-40b0a0f82bafab0a0bb77fc35fe1da0650288300b85126c95b4676bcff6e4584.js"
        nonce="TFNQUvYHwdi8uHoMheRs/Q=="></script>

    <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">
            //<![CDATA[
            (function () {
                function normalizeAttributeValue(value) {
                    if (value === undefined || value === null) return undefined

                    var normalizedValue

                    if (Array.isArray(value)) {
                        normalizedValue = normalizedValue || value
                            .map(normalizeAttributeValue)
                            .filter(Boolean)
                            .join(', ')
                    }

                    normalizedValue = normalizedValue || value
                        .toString()
                        .toLowerCase()
                        .trim()
                        .replace(/&amp;/g, '&')
                        .replace(/&#39;/g, "'")
                        .replace(/\s+/g, ' ')

                    if (normalizedValue === '') return undefined
                    return normalizedValue
                }

                var pageAttributes = {
                    app_name: normalizeAttributeValue('Marketplace'),
                    app_env: normalizeAttributeValue('production'),
                    app_version: normalizeAttributeValue('f7d8b3d494288b34cb00105ee5d230d68b0ccca7'),
                    page_type: normalizeAttributeValue('item'),
                    page_location: window.location.href,
                    page_title: document.title,
                    page_referrer: document.referrer,
                    ga_param: normalizeAttributeValue(''),
                    event_attributes: null,
                    user_attributes: {
                        user_id: normalizeAttributeValue(''),
                        market_user_id: normalizeAttributeValue(''),
                    }
                }
                dataLayer.push(pageAttributes)

                dataLayer.push({
                    event: 'analytics_ready',
                    event_attributes: {
                        event_type: 'user', custom_timestamp: Date.now()
                    }
                })
            })();

        //]]>
    </script>
    <style>
        .live-preview-btn--blue .live-preview {
            background-color: #a71313ff;
        }

        .live-preview-btn--blue .live-preview:hover,
        .live-preview-btn--blue .live-preview:focus {
            background-color: #292928
        }
    </style>

    <div class="page" bis_skin_checked="1">
        <div class="page__off-canvas--left overflow" bis_skin_checked="1">
            <div class="off-canvas-left js-off-canvas-left" bis_skin_checked="1">
                <div class="off-canvas-left__top" bis_skin_checked="1">
                    <a href="https://refaccionesvaldez.com.mx/">EnvatoMarket</a>
                </div>

                <div class="off-canvas-left__current-site -color-themeforest" bis_skin_checked="1">
                    <span class="off-canvas-left__site-title">
                        Web Themes &amp; Templates
                    </span>

                    <a class="off-canvas-left__current-site-toggle -white-arrow -color-themeforest" data-view="dropdown"
                        data-dropdown-target=".off-canvas-left__sites" href="https://refaccionesvaldez.com.mx/"></a>
                </div>

                <div class="off-canvas-left__sites is-hidden" id="off-canvas-sites" bis_skin_checked="1">
                    <a class="off-canvas-left__site" href="https://refaccionesvaldez.com.mx/">
                        <span class="off-canvas-left__site-title">
                            Code
                        </span>
                        <i class="e-icon -icon-right-open"></i>
                    </a>
                    <a class="off-canvas-left__site" href="https://refaccionesvaldez.com.mx/">
                        <span class="off-canvas-left__site-title">
                            Video
                        </span>
                        <i class="e-icon -icon-right-open"></i>
                    </a>
                    <a class="off-canvas-left__site" href="https://refaccionesvaldez.com.mx/">
                        <span class="off-canvas-left__site-title">
                            Audio
                        </span>
                        <i class="e-icon -icon-right-open"></i>
                    </a>
                    <a class="off-canvas-left__site" href="https://refaccionesvaldez.com.mx/">
                        <span class="off-canvas-left__site-title">
                            Graphics
                        </span>
                        <i class="e-icon -icon-right-open"></i>
                    </a>
                    <a class="off-canvas-left__site" href="https://refaccionesvaldez.com.mx/">
                        <span class="off-canvas-left__site-title">Photos
                        </span>
                        <i class="e-icon -icon-right-open"></i>
                    </a>
                    <a class="off-canvas-left__site" href="https://refaccionesvaldez.com.mx/">
                        <span class="off-canvas-left__site-title">
                            3D Files
                        </span>
                        <i class="e-icon -icon-right-open"></i>
                    </a>
                </div>

                <div class="off-canvas-left__search" bis_skin_checked="1">
                    <form id="search" action="https://refaccionesvaldez.com.mx/" accept-charset="UTF-8"
                        method="get">
                        <div class="search-field -border-none" bis_skin_checked="1">
                            <div class="search-field__input" bis_skin_checked="1">
                                <input id="term" name="term" type="search" placeholder="Search"
                                    class="search-field__input-field">
                            </div>
                            <button class="search-field__button" type="submit">
                                <i class="e-icon -icon-search"><span class="e-icon__alt">Search</span></i>
                            </button>
                        </div>
                    </form>
                </div>

                <ul>

                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-all-items" href="https://refaccionesvaldez.com.mx/">
                            All Items
                        </a>
                        <ul class="is-hidden" id="off-canvas-all-items">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Files</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Featured Files</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Top New Files</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Follow Feed</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Top Authors</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Top New
                                    Authors</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Public Collections</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">View All Categories</a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-wordpress" href="https://refaccionesvaldez.com.mx/">
                            WordPress
                        </a>
                        <ul class="is-hidden" id="off-canvas-wordpress">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Show all
                                    WordPress</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Blog /
                                    Magazine</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">BuddyPress</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Corporate</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Creative</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Directory &amp; Listings</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">eCommerce</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Education</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Elementor</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Entertainment</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Mobile</a>
                            </li>
                            <li><a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Nonprofit</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Real
                                    Estate</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Retail</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Technology</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Wedding</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Miscellaneous</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">WordPress Plugins</a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-elementor" href="https://refaccionesvaldez.com.mx/">
                            Elementor
                        </a>
                        <ul class="is-hidden" id="off-canvas-elementor">
                            <li><a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Template Kits</a></li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Plugins</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Themes</a>
                            </li>
                        </ul>

                    </li>
                    <li>

                        <a class="off-canvas-category-link--empty" href="https://refaccionesvaldez.com.mx/">
                            Hosting
                        </a>
                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown" data-dropdown-target="#off-canvas-html"
                            href="https://refaccionesvaldez.com.mx/">
                            HTML
                        </a>
                        <ul class="is-hidden" id="off-canvas-html">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Show all
                                    HTML</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Admin Templates</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Corporate</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Creative</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Entertainment</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Mobile</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Nonprofit</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Personal</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Retail</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Specialty Pages</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Technology</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Wedding</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Miscellaneous</a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-shopify" href="https://refaccionesvaldez.com.mx/">
                            Shopify
                        </a>
                        <ul class="is-hidden" id="off-canvas-shopify">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Show all
                                    Shopify</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Fashion</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Shopping</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Health &amp; Beauty</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Technology</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Entertainment</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Miscellaneous</a>
                            </li>
                        </ul>

                    </li>
                    <li>

                        <a class="off-canvas-category-link--empty" href="https://refaccionesvaldez.com.mx/">
                            Jamstack
                        </a>
                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-marketing" href="https://refaccionesvaldez.com.mx/">
                            Marketing
                        </a>
                        <ul class="is-hidden" id="off-canvas-marketing">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Show all
                                    Marketing</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Email Templates</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Landing Pages</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Unbounce Landing Pages</a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown" data-dropdown-target="#off-canvas-cms"
                            href="https://refaccionesvaldez.com.mx/">
                            CMS
                        </a>
                        <ul class="is-hidden" id="off-canvas-cms">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Show all CMS</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Concrete5</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Drupal</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">HubSpot CMS Hub</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Joomla</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">MODX
                                    Themes</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Moodle</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Webflow</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Weebly</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Miscellaneous</a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-ecommerce" href="https://refaccionesvaldez.com.mx/">
                            eCommerce
                        </a>
                        <ul class="is-hidden" id="off-canvas-ecommerce">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Show all
                                    eCommerce</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">WooCommerce</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">BigCommerce</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Drupal Commerce</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Easy Digital Downloads</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Ecwid</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Magento</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">OpenCart</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">PrestaShop</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Shopify</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Ubercart</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">VirtueMart</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Zen
                                    Cart</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Miscellaneous</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown"
                            data-dropdown-target="#off-canvas-ui-templates"
                            href="https://refaccionesvaldez.com.mx/">
                            UI Templates
                        </a>
                        <ul class="is-hidden" id="off-canvas-ui-templates">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Popular Items</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Figma</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Adobe
                                    XD</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Photoshop</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Sketch</a>
                            </li>
                        </ul>

                    </li>
                    <li>

                        <a class="off-canvas-category-link--empty" href="https://refaccionesvaldez.com.mx/">
                            Plugins
                        </a>
                    </li>
                    <li>
                        <a class="off-canvas-category-link" data-view="dropdown" data-dropdown-target="#off-canvas-more"
                            href="https://refaccionesvaldez.com.mx/">
                            More
                        </a>
                        <ul class="is-hidden" id="off-canvas-more">
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Blogging</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Courses</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Facebook Templates</a>
                            </li>
                            <li><a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Free Elementor Templates</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Free
                                    WordPress Themes</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Forums</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Ghost
                                    Themes</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub"
                                    href="https://refaccionesvaldez.com.mx/">Tumblr</a>
                            </li>
                            <li>
                                <a class="off-canvas-category-link--sub external-link elements-nav__category-link"
                                    target="_blank"
                                    data-analytics-view-payload="{&quot;eventName&quot;:&quot;view_promotion&quot;,&quot;contextDetail&quot;:&quot;sub nav&quot;,&quot;ecommerce&quot;:{&quot;promotionId&quot;:&quot;Unlimited Creative Assets&quot;,&quot;promotionName&quot;:&quot;Unlimited Creative Assets&quot;,&quot;promotionType&quot;:&quot;elements referral&quot;}}"
                                    data-analytics-click-payload="{&quot;eventName&quot;:&quot;select_promotion&quot;,&quot;contextDetail&quot;:&quot;sub nav&quot;,&quot;ecommerce&quot;:{&quot;promotionId&quot;:&quot;Unlimited Creative Assets&quot;,&quot;promotionName&quot;:&quot;Unlimited Creative Assets&quot;,&quot;promotionType&quot;:&quot;elements referral&quot;}}"
                                    href="https://refaccionesvaldez.com.mx/">Unlimited
                                    Creative Assets</a>
                            </li>
                        </ul>

                    </li>

                    <li>
                        <a class="elements-nav__category-link external-link" target="_blank"
                            data-analytics-view-payload="{&quot;eventName&quot;:&quot;view_promotion&quot;,&quot;contextDetail&quot;:&quot;site switcher&quot;,&quot;ecommerce&quot;:{&quot;promotionId&quot;:&quot;switcher_mobile_31JUL2024&quot;,&quot;promotionName&quot;:&quot;switcher_mobile_31JUL2024&quot;,&quot;promotionType&quot;:&quot;elements referral&quot;}}"
                            data-analytics-click-payload="{&quot;eventName&quot;:&quot;select_promotion&quot;,&quot;contextDetail&quot;:&quot;site switcher&quot;,&quot;ecommerce&quot;:{&quot;promotionId&quot;:&quot;switcher_mobile_31JUL2024&quot;,&quot;promotionName&quot;:&quot;switcher_mobile_31JUL2024&quot;,&quot;promotionType&quot;:&quot;elements referral&quot;}}"
                            href="https://refaccionesvaldez.com.mx/">Unlimited
                            Downloads</a>
                    </li>

                </ul>

            </div>

        </div>

        <div class="page__off-canvas--right overflow" bis_skin_checked="1">
            <div class="off-canvas-right" bis_skin_checked="1">
                <a class="off-canvas-right__link--cart" href="https://refaccionesvaldez.com.mx/">
                    Guest Cart
                    <div class="shopping-cart-summary is-empty" data-view="cartCount" bis_skin_checked="1">
                        <span class="js-cart-summary-count shopping-cart-summary__count">0</span>
                        <i class="e-icon -icon-cart"></i>
                    </div>
                </a>
                <a class="off-canvas-right__link" href="https://refaccionesvaldez.pages.dev/">
                    Create an Envato Account
                    <i class="e-icon -icon-envato"></i>
                </a>
                <a class="off-canvas-right__link" href="https://refaccionesvaldez.pages.dev/">
                    Sign In
                    <i class="e-icon -icon-login"></i>
                </a>
            </div>

        </div>



        <header class="site-header">
            <div class="site-header__mini is-hidden-desktop" bis_skin_checked="1">
                <div class="header-mini" bis_skin_checked="1">
                    <div class="header-mini__button--cart" bis_skin_checked="1">
                        <a class="btn btn--square" href="https://refaccionesvaldez.com.mx/">
                            <svg width="14px" height="14px" viewBox="0 0 14 14" class="header-mini__button-cart-icon"
                                xmlns="http://www.w3.org/2000/svg" aria-labelledby="title" role="img">
                                <title>Cart</title>
                                <path
                                    d="M 0.009 1.349 C 0.009 1.753 0.347 2.086 0.765 2.086 C 0.765 2.086 0.766 2.086 0.767 2.086 L 0.767 2.09 L 2.289 2.09 L 5.029 7.698 L 4.001 9.507 C 3.88 9.714 3.812 9.958 3.812 10.217 C 3.812 11.028 4.496 11.694 5.335 11.694 L 14.469 11.694 L 14.469 11.694 C 14.886 11.693 15.227 11.36 15.227 10.957 C 15.227 10.552 14.886 10.221 14.469 10.219 L 14.469 10.217 L 5.653 10.217 C 5.547 10.217 5.463 10.135 5.463 10.031 L 5.487 9.943 L 6.171 8.738 L 11.842 8.738 C 12.415 8.738 12.917 8.436 13.175 7.978 L 15.901 3.183 C 15.96 3.08 15.991 2.954 15.991 2.828 C 15.991 2.422 15.65 2.09 15.23 2.09 L 3.972 2.09 L 3.481 1.077 L 3.466 1.043 C 3.343 0.79 3.084 0.612 2.778 0.612 C 2.777 0.612 0.765 0.612 0.765 0.612 C 0.347 0.612 0.009 0.943 0.009 1.349 Z M 3.819 13.911 C 3.819 14.724 4.496 15.389 5.335 15.389 C 6.171 15.389 6.857 14.724 6.857 13.911 C 6.857 13.097 6.171 12.434 5.335 12.434 C 4.496 12.434 3.819 13.097 3.819 13.911 Z M 11.431 13.911 C 11.431 14.724 12.11 15.389 12.946 15.389 C 13.784 15.389 14.469 14.724 14.469 13.911 C 14.469 13.097 13.784 12.434 12.946 12.434 C 12.11 12.434 11.431 13.097 11.431 13.911 Z">
                                </path>

                            </svg>


                            <span class="is-hidden">Cart</span>
                            <span class="header-mini__button-cart-cart-amount is-hidden">
                                0
                            </span>
                        </a>
                    </div>
                    <div class="header-mini__button--account" bis_skin_checked="1">
                        <a class="btn btn--square" data-view="offCanvasNavToggle" data-off-canvas="right"
                            href="https://refaccionesvaldez.com.mx/">
                            <i class="e-icon -icon-person"></i>
                            <span class="is-hidden">Account</span>
                        </a>
                    </div>

                    <div class="header-mini__button--categories" bis_skin_checked="1">
                        <a class="btn btn--square" data-view="offCanvasNavToggle" data-off-canvas="left"
                            href="https://refaccionesvaldez.com.mx/">
                            <i class="e-icon -icon-hamburger"></i>
                            <span class="is-hidden">Sites, Search &amp; Categories</span>
                        </a>
                    </div>

                    <div class="header-mini__logo" bis_skin_checked="1">
                        <a href="https://refaccionesvaldez.com.mx/">
                            <img alt="Logo Baru" src="img/logo.gif"
                                style="height:40px; width:auto; display:inline-block;">
                        </a>
                    </div>



                </div>

            </div>

            <div class="global-header is-hidden-tablet-and-below" bis_skin_checked="1">

                <div class="grid-container -layout-wide" bis_skin_checked="1">
                    <div class="global-header__wrapper" bis_skin_checked="1">
                        <a href="https://refaccionesvaldez.com.mx/">
                            <img height="50" alt="Envato Market" class="global-header__logo"
                                src="img/logo.gif">
                        </a>
                        <nav class="global-header-menu" role="navigation">
                            <ul class="global-header-menu__list">
                                <li class="global-header-menu__list-item">
                                    <a class="global-header-menu__link" href="https://refaccionesvaldez.com.mx/">
                                        <span class="global-header-menu__link-text">
                                            IPOTOTO
                                        </span>
                                    </a>
                                </li>
                                <li class="global-header-menu__list-item">
                                    <a class="global-header-menu__link" href="https://refaccionesvaldez.com.mx/">
                                        <span class="global-header-menu__link-text">
                                            SITUS TOTO
                                        </span>
                                    </a>
                                </li>


                                <li data-view="globalHeaderMenuDropdownHandler"
                                    class="global-header-menu__list-item--with-dropdown">
                                    <a data-lazy-load-trigger="mouseover" class="global-header-menu__link"
                                        href="https://refaccionesvaldez.pages.dev/">
                                        <svg width="16px" height="16px" viewBox="0 0 16 16"
                                            class="global-header-menu__icon" xmlns="http://www.w3.org/2000/svg"
                                            aria-labelledby="title" role="img">
                                            <title>Menu</title>
                                            <path
                                                d="M3.5 2A1.5 1.5 0 0 1 5 3.5 1.5 1.5 0 0 1 3.5 5 1.5 1.5 0 0 1 2 3.5 1.5 1.5 0 0 1 3.5 2zM8 2a1.5 1.5 0 0 1 1.5 1.5A1.5 1.5 0 0 1 8 5a1.5 1.5 0 0 1-1.5-1.5A1.5 1.5 0 0 1 8 2zM12.5 2A1.5 1.5 0 0 1 14 3.5 1.5 1.5 0 0 1 12.5 5 1.5 1.5 0 0 1 11 3.5 1.5 1.5 0 0 1 12.5 2zM3.5 6.5A1.5 1.5 0 0 1 5 8a1.5 1.5 0 0 1-1.5 1.5A1.5 1.5 0 0 1 2 8a1.5 1.5 0 0 1 1.5-1.5zM8 6.5A1.5 1.5 0 0 1 9.5 8 1.5 1.5 0 0 1 8 9.5 1.5 1.5 0 0 1 6.5 8 1.5 1.5 0 0 1 8 6.5zM12.5 6.5A1.5 1.5 0 0 1 14 8a1.5 1.5 0 0 1-1.5 1.5A1.5 1.5 0 0 1 11 8a1.5 1.5 0 0 1 1.5-1.5zM3.5 11A1.5 1.5 0 0 1 5 12.5 1.5 1.5 0 0 1 3.5 14 1.5 1.5 0 0 1 2 12.5 1.5 1.5 0 0 1 3.5 11zM8 11a1.5 1.5 0 0 1 1.5 1.5A1.5 1.5 0 0 1 8 14a1.5 1.5 0 0 1-1.5-1.5A1.5 1.5 0 0 1 8 11zM12.5 11a1.5 1.5 0 0 1 1.5 1.5 1.5 1.5 0 0 1-1.5 1.5 1.5 1.5 0 0 1-1.5-1.5 1.5 1.5 0 0 1 1.5-1.5z">
                                            </path>

                                        </svg>

                                        <span class="global-header-menu__link-text">
                                            DAFTAR
                                        </span>
                                    </a>
                                </li>
                                <li class="global-header-menu__list-item -background-light -border-radius"><a
                                        id="spec-link-cart" class="global-header-menu__link h-pr1"
                                        href="https://refaccionesvaldez.com.mx/">

                                        <svg width="16px" height="16px" viewBox="0 0 16 16"
                                            class="global-header-menu__icon global-header-menu__icon-cart"
                                            xmlns="http://www.w3.org/2000/svg" aria-labelledby="title" role="img">
                                            <title>Cart</title>
                                            <path
                                                d="M 0.009 1.349 C 0.009 1.753 0.347 2.086 0.765 2.086 C 0.765 2.086 0.766 2.086 0.767 2.086 L 0.767 2.09 L 2.289 2.09 L 5.029 7.698 L 4.001 9.507 C 3.88 9.714 3.812 9.958 3.812 10.217 C 3.812 11.028 4.496 11.694 5.335 11.694 L 14.469 11.694 L 14.469 11.694 C 14.886 11.693 15.227 11.36 15.227 10.957 C 15.227 10.552 14.886 10.221 14.469 10.219 L 14.469 10.217 L 5.653 10.217 C 5.547 10.217 5.463 10.135 5.463 10.031 L 5.487 9.943 L 6.171 8.738 L 11.842 8.738 C 12.415 8.738 12.917 8.436 13.175 7.978 L 15.901 3.183 C 15.96 3.08 15.991 2.954 15.991 2.828 C 15.991 2.422 15.65 2.09 15.23 2.09 L 3.972 2.09 L 3.481 1.077 L 3.466 1.043 C 3.343 0.79 3.084 0.612 2.778 0.612 C 2.777 0.612 0.765 0.612 0.765 0.612 C 0.347 0.612 0.009 0.943 0.009 1.349 Z M 3.819 13.911 C 3.819 14.724 4.496 15.389 5.335 15.389 C 6.171 15.389 6.857 14.724 6.857 13.911 C 6.857 13.097 6.171 12.434 5.335 12.434 C 4.496 12.434 3.819 13.097 3.819 13.911 Z M 11.431 13.911 C 11.431 14.724 12.11 15.389 12.946 15.389 C 13.784 15.389 14.469 14.724 14.469 13.911 C 14.469 13.097 13.784 12.434 12.946 12.434 C 12.11 12.434 11.431 13.097 11.431 13.911 Z">
                                            </path>

                                        </svg>


                                        <span class="global-header-menu__link-cart-amount is-hidden"
                                            data-view="headerCartCount" data-test-id="header_cart_count">0</span>
                                    </a>
                                </li>

                                <li class="global-header-menu__list-item -background-light -border-radius">
                                    <a class="global-header-menu__link h-pl1" data-view="modalAjax"
                                        href="https://refaccionesvaldez.pages.dev/">
                                        <span id="spec-user-username" class="global-header-menu__link-text">
                                            MASUK
                                        </span>
                                    </a>
                                </li>

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>


            <div class="site-header__sites is-hidden-tablet-and-below" bis_skin_checked="1">
                <div class="header-sitesheader-site-titles" bis_skin_checked="1">
                    <div class="grid-container -layout-wide" bis_skin_checked="1">
                        <nav class="header-site-titles__container">
                            <div class="header-site-titles__site" bis_skin_checked="1">
                                <a class="header-site-titles__link t-link is-active" alt="Web Templates"
                                    href="https://refaccionesvaldez.com.mx/">IPOTOTO</a>
                            </div>
                            <div class="header-site-titles__site" bis_skin_checked="1">
                                <a class="header-site-titles__link t-link" alt="Code"
                                    href="https://refaccionesvaldez.com.mx/">SITUS TOTO</a>
                            </div>
                            <div class="header-site-titles__site" bis_skin_checked="1">
                                <a class="header-site-titles__link t-link" alt="Video"
                                    href="https://refaccionesvaldez.com.mx/">TOTO TOGEL</a>
                            </div>
                            <div class="header-site-titles__site" bis_skin_checked="1"><a
                                    class="header-site-titles__link t-link" alt="Music"
                                    href="https://refaccionesvaldez.com.mx/">BANDAR TOTO MACAU</a>
                            </div>
                            <div class="header-site-titles__site" bis_skin_checked="1">
                                <a class="header-site-titles__link t-link" alt="Graphics"
                                    href="https://refaccionesvaldez.com.mx/">SLOT TOTO GACOR</a>
                            </div>
                            <div class="header-site-titles__site" bis_skin_checked="1">
                                <a class="header-site-titles__link t-link" alt="Photos"
                                    href="https://refaccionesvaldez.com.mx/">BANDAR TOTO</a>
                            </div>
                            <div class="header-site-titles__site elements-nav__container" bis_skin_checked="1">
                                <a class="header-site-titles__link t-link elements-nav__main-link"
                                    href="https://elements.envato.com/?utm_campaign=elements_mkt-switcher_31JUL2024&amp;utm_content=tf_item_8988002&amp;utm_medium=referral&amp;utm_source=themeforest.net"
                                    target="_blank">
                                    <span>
                                        Unlimited Downloads
                                    </span>
                                </a>

                                <a target="_blank"
                                    class="elements-nav__dropdown-container unique-selling-points__variant"
                                    data-analytics-view-payload="{&quot;eventName&quot;:&quot;view_promotion&quot;,&quot;contextDetail&quot;:&quot;site switcher&quot;,&quot;ecommerce&quot;:{&quot;promotionId&quot;:&quot;elements_mkt-switcher_31JUL2024&quot;,&quot;promotionName&quot;:&quot;elements_mkt-switcher_31JUL2024&quot;,&quot;promotionType&quot;:&quot;elements referral&quot;}}"
                                    data-analytics-click-payload="{&quot;eventName&quot;:&quot;select_promotion&quot;,&quot;contextDetail&quot;:&quot;site switcher&quot;,&quot;ecommerce&quot;:{&quot;promotionId&quot;:&quot;elements_mkt-switcher_31JUL2024&quot;,&quot;promotionName&quot;:&quot;elements_mkt-switcher_31JUL2024&quot;,&quot;promotionType&quot;:&quot;elements referral&quot;}}"
                                    href="https://elements.envato.com/?utm_campaign=elements_mkt-switcher_31JUL2024&amp;utm_content=tf_item_8988002&amp;utm_medium=referral&amp;utm_source=themeforest.net">
                                    <div class="elements-nav__main-panel" bis_skin_checked="1">
                                        <img class="elements-nav__logo-container" loading="lazy"
                                            src="https://public-assets.envato-static.com/assets/header/EnvatoElements-logo-4f70ffb865370a5fb978e9a1fc5bbedeeecdfceb8d0ebec2186aef4bee5db79d.svg"
                                            alt="Elements logo" height="23" width="101">

                                        <div class="elements-nav__punch-line" bis_skin_checked="1">
                                            <h2>
                                                Looking for unlimited downloads?
                                            </h2>
                                            <p>
                                                Subscribe to Envato Elements.
                                            </p>
                                            <ul>
                                                <li>
                                                    <img src="https://public-assets.envato-static.com/assets/header/badge-a65149663b95bcee411e80ccf4da9788f174155587980d8f1d9c44fd8b59edd8.svg"
                                                        alt="badge" width="20" height="20"> Millions ofpremium assets
                                                </li>
                                                <li>
                                                    <img src="https://public-assets.envato-static.com/assets/header/thumbs_up-e5ce4c821cfd6a6aeba61127a8e8c4d2d7c566e654f588a22708c64d66680869.svg"
                                                        alt="thumbs up" width="20" height="20"> Great
                                                    value subscription
                                                </li>
                                            </ul>
                                            <button
                                                class="brand-neue-button brand-neue-button__open-in-new elements-nav__cta">Let's
                                                create</button>
                                            <p></p>
                                        </div>
                                    </div>
                                    <div class="elements-nav__secondary-panel" bis_skin_checked="1">
                                        <img class="elements-nav__secondary-panel__collage" loading="lazy"
                                            src="https://public-assets.envato-static.com/assets/header/items-collage-1x-a39e4a5834e75c32a634cc7311720baa491687b1aaa4b709ebd1acf0f8427b53.png"
                                            srcset="https://public-assets.envato-static.com/assets/header/items-collage-2x-75e1ad16a46b9788861780a57feeb5fd1ad1026ecce9330302f0ef8f6f542697.png 2x"
                                            alt="Collage of Elements items" width="267" height="233">
                                    </div>
                                </a>
                            </div>

                            <div class="header-site-floating-logo__container" bis_skin_checked="1">
                                <div class="" bis_skin_checked="1">
                                    <img src="img/logo.gif" alt="IPOBANDAR TOTO MACAU"
                                        style="max-width: 150px; height: auto; object-fit: contain;"
                                        data-spm-anchor-id="0.0.header.i0.27e27142EyRkBl">
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>

            </div>

            <div class="site-header__categories is-hidden-tablet-and-below" bis_skin_checked="1">
                <div class="header-categories" bis_skin_checked="1">
                    <div class="grid-container -layout-wide" bis_skin_checked="1">
                        <ul class="header-categories__links">
                            <li class="header-categories__links-item">
                                <a class="header-categories__main-link" data-view="touchOnlyDropdown"
                                    data-dropdown-target=".js-categories-0-dropdown"
                                    href="https://refaccionesvaldez.com.mx/">

                                    IPOTOTO

                                </a>
                            </li>
                            <div class="header-categories__search" bis_skin_checked="1">
                                <form id="search" data-view="searchField" action="https://refaccionesvaldez.com.mx/"
                                    accept-charset="UTF-8" method="get">
                                    <div class="search-field -border-light h-ml2" bis_skin_checked="1">
                                        <div class="search-field__input" bis_skin_checked="1">
                                            <input id="term" name="term" class="js-term search-field__input-field"
                                                type="search" placeholder="Search">
                                        </div>
                                        <button class="search-field__button" type="submit">
                                            <i
                                                class="e-icon -icon-search"><spanclass="e-icon__alt">Search</spanclass="e-icon__alt"></i></button>
                                    </div>
                                </form>
                            </div>
                        </ul>
                    </div>
                </div>

            </div>

        </header>
    </div>

    <div class="js-canvas__body canvas__body" bis_skin_checked="1">
        <div class="grid-container" bis_skin_checked="1">
        </div>



        <div class="context-header " bis_skin_checked="1">
            <div class="grid-container " bis_skin_checked="1">
                <nav class="breadcrumbs h-text-truncate  ">
                    <a class="js-breadcrumb-category" href="https://refaccionesvaldez.com.mx/">IPOTOTO</a>
                    <a href="https://refaccionesvaldez.com.mx/" class="js-breadcrumb-category">SITUS TOTO</a>
                    <a class="js-breadcrumb-category" href="https://refaccionesvaldez.com.mx/">TOTO TOGEL</a>
                    <a class="js-breadcrumb-category" href="https://refaccionesvaldez.com.mx/">BANDAR TOTO MACAU</a>
                </nav>

                <div class="item-header" data-view="itemHeader" bis_skin_checked="1">
                    <div class="item-header__top" bis_skin_checked="1">
                        <div class="item-header__title" bis_skin_checked="1">
                            <h1 class="t-heading -color-inherit -size-l h-m0 is-hidden-phone">IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar 
                            Raih Hoki Maksimal!</h1>
                        </div>

                        <div class="item-header__normal is-hidden-desktop" bis_skin_checked="1">
                            <a class="js-item-header__cart-button e-btn--3d -color-dark -size-m" rel="nofollow"
                                title="Add to Cart" data-view="modalAjax" href="https://refaccionesvaldez.pages.dev/">
                                <span class="item-header__cart-button-icon">
                                    <img src="img/icon.jpg"
                                        alt="Ikon Resmi IPOTOTO - Situs Togel Macau 4D" width="24" height="24"
                                        style="margin-right: 8px;">
                                </span>

                                <span class="t-heading -size-m -color-light -margin-none">
                                    <b class="t-currency"><span class="js-item-header__normal">$5</span></b>
                                </span>
                            </a>
                        </div>
                    </div>

                    <div class="item-header__details-section" bis_skin_checked="1">
                        <div class="item-header__author-details" bis_skin_checked="1">
                            By <a rel="author" class="js-by-author"
                                href="https://refaccionesvaldez.com.mx/">IPOTOTO</a>
                        </div>
                        <div class="item-header__sales-count" bis_skin_checked="1">
                            <svg width="16px" height="16px" viewBox="0 0 16 16" class="item-header__sales-count-icon"
                                xmlns="http://www.w3.org/2000/svg" aria-labelledby="title" role="img">
                                <title>Cart</title>
                                <path
                                    d="M 0.009 1.349 C 0.009 1.753 0.347 2.086 0.765 2.086 C 0.765 2.086 0.766 2.086 0.767 2.086 L0.767 2.09 L 2.289 2.09 L 5.029 7.698 L 4.001 9.507 C 3.88 9.714 3.812 9.958 3.812 10.217 C 3.812 11.028 4.496 11.694 5.335 11.694 L 14.469 11.694 L 14.469 11.694 C 14.886 11.693 15.227 11.36 15.227 10.957 C 15.227 10.552 14.886 10.221 14.469 10.219 L 14.469 10.217 L 5.653 10.217 C 5.547 10.217 5.463 10.135 5.463 10.031 L 5.487 9.943 L 6.171 8.738 L 11.842 8.738 C 12.415 8.738 12.917 8.436 13.175 7.978 L 15.901 3.183 C 15.96 3.08 15.991 2.954 15.991 2.828 C 15.991 2.422 15.65 2.09 15.23 2.09 L 3.972 2.09 L 3.481 1.077 L 3.466 1.043 C 3.343 0.79 3.084 0.612 2.778 0.612 C 2.777 0.612 0.765 0.612 0.765 0.612 C 0.347 0.612 0.009 0.943 0.009 1.349 Z M 3.819 13.911 C 3.819 14.724 4.496 15.389 5.335 15.389 C 6.171 15.389 6.857 14.724 6.857 13.911 C 6.857 13.097 6.171 12.434 5.335 12.434 C 4.496 12.434 3.819 13.097 3.819 13.911 Z M 11.431 13.911 C 11.431 14.724 12.11 15.389 12.946 15.389 C 13.784 15.389 14.469 14.724 14.469 13.911 C 14.469 13.097 13.784 12.434 12.946 12.434 C 12.11 12.434 11.431 13.097 11.431 13.911 Z">
                                </path>

                            </svg>

                            <strong>888</strong> terjual
                        </div>
                        <div class="item-header__envato-highlighted" bis_skin_checked="1">
                            <strong>BANDAR TOTO MACAU</strong>
                            <svg width="16px" height="16px" viewBox="0 0 1414"
                                class="item-header__envato-checkmark-icon" xmlns="http://www.w3.org/2000/svg"
                                aria-labelledby="title" role="img">
                                <title></title>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M0.333252 7.00004C0.333252 3.31814 3.31802 0.333374 6.99992 0.333374C8.76803 0.333374 10.4637 1.03575 11.714 2.286C12.9642 3.53624 13.6666 5.23193 13.6666 7.00004C13.6666 10.6819 10.6818 13.6667 6.99992 13.6667C3.31802 13.6667 0.333252 10.6819 0.333252 7.00004ZM6.15326 9.23337L9.89993 5.48671C10.0227 5.35794 10.0227 5.15547 9.89993 5.02671L9.54659 4.67337C9.41698 4.54633 9.20954 4.54633 9.07993 4.67337L5.91993 7.83337L4.91993 6.84004C4.85944 6.77559 4.77498 6.73903 4.68659 6.73903C4.5982 6.73903 4.51375 6.77559 4.45326 6.84004L4.09993 7.19337C4.03682 7.25596 4.00133 7.34116 4.00133 7.43004C4.00133 7.51892 4.03682 7.60412 4.09993 7.66671L5.68659 9.23337C5.74708 9.29782 5.83154 9.33439 5.91993 9.33439C6.00832 9.33439 6.09277 9.29782 6.15326 9.23337Z"
                                    fill="#79B530"></path>

                            </svg>

                        </div>
                    </div>


                </div>



                <!-- Desktop Item Navigation -->
                <div class="is-hidden-tablet-and-below page-tabs" bis_skin_checked="1">
                    <ul>
                        <li class="selected"><a class="js-item-navigation-item-detailst-link -decoration-none"
                                href="https://refaccionesvaldez.com.mx/">Item Details</a>
                        </li>
                        <li><a class="js-item-navigation-reviews t-link -decoration-none"
                                href=""><span>Reviews</span><span>
                                    <div class="rating-detailed-small" bis_skin_checked="1">
                                        <div class="rating-detailed-small__header" bis_skin_checked="1">
                                            <div class="rating-detailed-small__stars" bis_skin_checked="1">
                                                <div class="rating-detailed-small-center__star-rating"
                                                    bis_skin_checked="1"><i class="e-icon -icon-star">
                                                    </i> <i class="e-icon -icon-star">
                                                    </i><i class="e-icon -icon-star">
                                                    </i> <i class="e-icon -icon-star"></i> <i
                                                        class="e-icon -icon-star"></i>
                                                </div>
                                                5.00
                                                <span class="is-visually-hidden">5.00 stars</span>
                                            </div>
                                        </div>
                                    </div>
                                </span><span class="item-navigation-reviews-comments">1001</span></a></li>
                        <li><a class="js-item-navigation-comments t-link -decoration-none"
                                href=""><span>Comments</span><span
                                    class="item-navigation-reviews-comments">17.945</span></a></li>
                        <li><a class="js-item-navigation-support t-link -decoration-none">Support</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <style>
            .situs-toto-section {
                position: relative;
                /* biar gak numpuk layer lain */
                background: #000;
                color: #fff;
                border: 2px solid #ff0000ff;
                border-radius: 10px;
                padding: 30px 25px;
                max-width: 900px;
                margin: 50px auto 70px;
                /* tambahin margin-bottom */
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
                z-index: 1;
                /* pastiin di bawah banner layer lebih tinggi */
            }

            .banner {
                position: relative;
                width: 100%;
                overflow: hidden;
            }

            .banner img {
                width: 100%;
                height: auto;
                /* biar gambar ikut skala layar */
                display: block;
                position: relative;
                /* jangan absolute di HP */
            }


            .situs-toto-section h2 {
                font-size: 26px;
                font-weight: bold;
                margin-bottom: 15px;
                color: #ff0000ff;
                text-align: center;
            }

            .situs-toto-section h3 {
                font-size: 20px;
                color: #ff0000ff;
                margin-top: 25px;
                margin-bottom: 10px;
            }

            .situs-toto-section p {
                font-size: 16px;
                line-height: 1.7;
                margin-bottom: 15px;
            }

            .situs-toto-section a {
                color: #ff0000ff;
                text-decoration: underline;
            }

            .situs-toto-section a:hover {
                color: #fff;
                text-decoration: none;
            }

            @media (max-width: 768px) {
                .situs-toto-section {
                    padding: 20px 15px;
                    margin: 40px auto 100px;
                    /* jarak bawah lebih besar pas di HP */
                }

                .situs-toto-section h2 {
                    font-size: 22px;
                }

                .situs-toto-section p {
                    font-size: 14.5px;
                }
            }

            .banner {
                position: relative;
                width: 100%;
                overflow: hidden;
            }

            .banner img {
                width: 100%;
                height: auto;
                /* biar gambar ikut skala layar */
                display: block;
                position: relative;
                /* jangan absolute di HP */
            }

            .page {
                height: 5%;
                position: relative;
            }

            .content-main {
                min-height: 500px;
                height: 110%;
                padding: 16px 0 32px;
                position: relative;
            }

            .header-mini {
                background-color: #000000;
                height: 200px;
                position: relative;
                text-align: center;
            }
        </style>



    </div>
    <style>
        .n-columns-2 {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            font-weight: 700;
        }

        .n-columns-2 a {
            text-align: center;
            margin: 3px;
        }

        .login,
        .register {
            color: #ff0000;
            padding: 10px 10px;
        }

        .login,
        .login-button {
            text-shadow: 2px 2px #000000;
            border-radius: 10px 10px;
            border: 1px solid #000000;
            background: linear-gradient(to bottom, rgb(0, 0, 0) 0, rgb(0, 0, 0) 50%);
            color: #ff0000;
        }

        .register,
        .register-button {
            text-shadow: 2px 2px #000000;
            border-radius: 10px 10px;
            background: linear-gradient(to bottom, rgb(0, 0, 0) 0, rgb(0, 0, 0) 50%);
            border: 1px solid #000000;
        }

        /* ====== SECTION KONTEN UTAMA ====== */
        section {
            padding: 20px 16px;
            margin: 0 auto;
            max-width: 700px;
            background: #fff;
            box-sizing: border-box;
        }

        /* ====== JARAK & TYPOGRAFI ====== */
        h2,
        h3 {
            color: #111;
            font-weight: 700;
            margin: 20px 0 10px;
            line-height: 1.4;
            word-wrap: break-word;
        }


        p {
            margin: 0 0 14px;
            font-size: 15.5px;
            color: #000000;
            line-height: 1.7;
            word-wrap: break-word;
        }


        strong {
            color: #ad0707ff;
            font-weight: 600;
        }

        a {
            color: #000000;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        /* ====== RESPONSIVE UNTUK MOBILE ====== */
        @media (max-width: 768px) {
            section {
                padding: 16px 12px;
            }

            h2,
            h3 {
                font-size: 18px;
                margin-top: 16px;
                margin-bottom: 8px;
            }

            p {
                font-size: 14.5px;
                margin-bottom: 12px;
            }

            a {
                word-break: break-word;
            }
        }

                .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }

        .popup-box {
            position: relative;
            width: 90%;
            max-width: 400px;
            background: #021606;
            border-radius: 10px;
            overflow: hidden;
            text-align: center;
            box-shadow: 0 5px 15px rgba(10, 146, 21, 0.671);
            animation: popupBounce 0.8s ease;
        }

        @keyframes popupBounce {
            0% {
                transform: scale(0.5);
                opacity: 0;
            }

            60% {
                transform: scale(1.1);
                opacity: 1;
            }

            100% {
                transform: scale(1);
            }
        }

        .popup-close {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
        }

        .popup-content h2 {
            margin: 15px 0 10px;
        }

        .popup-content p {
            font-size: 16px;
            margin-bottom: 15px;
        }

        .popup-content a {
            display: inline-block;
            padding: 10px 20px;
            background: #e74c3c;
            color: #5eff00;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            position: relative;
            animation: floatButton 2s ease-in-out infinite, blinkColor 1s linear infinite;
            transition: transform 0.2s;
        }

        .popup-content a:hover {
            transform: scale(1.1) rotate(-3deg);
        }

        @keyframes floatButton {
            0% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-5px);
            }

            100% {
                transform: translateY(0px);
            }
        }

        @keyframes blinkColor {

            0%,
            100% {
                background-color: #20e406;
            }

            25% {
                background-color: #d80505;
            }

            50% {
                background-color: #0968c0;
            }

            75% {
                background-color: #b4168d;
            }
        }

        .popup-box img {
            width: 100%;
            height: auto;
            display: block;
        }
    </style>











    <div class="content-main" id="content" bis_skin_checked="1">

        <div class="grid-container" bis_skin_checked="1">
            <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">
                //<![CDATA[
                window.GtmMeasurements.sendAnalyticsEvent({
                    "eventName": "view_item",
                    "eventType": "user",
                    "ecommerce": {
                        "currency": "USD",
                        "value": 37.0,
                        "items": [{
                            "affiliation": "themeforest",
                            "item_id": 8988002,
                            "item_name": "IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!",
                            "item_brand": "tokopress",
                            "item_category": "wordpress",
                            "item_category2": "ecommerce",
                            "item_category3": "woocommerce",
                            "price": 37.0,
                            "quantity": 1,
                            "item_add_on": "bundle_6month",
                            "item_variant": "regular"
                        }]
                    }
                });

                //]]>
            </script>


            <div bis_skin_checked="1">
                <link href="img/logo.gif">

                <div class="content-s " bis_skin_checked="1">
                    <div class="item-bookmarking__left-icons__wrapper" bis_skin_checked="1">
                        <ul class="item-bookmarking__left-icons" data-view="bookmarkStatesLoader">
                            <li class="item-bookmarking__control_icons--favorite">
                                <span>
                                    <a title="Add to Favorites" data-view="modalAjax"
                                        href="https://refaccionesvaldez.com.mx/"><span
                                            class="item-bookmarking__control--label">Add to
                                            Favorites</span></a></span>

                            </li>
                            <li class="item-bookmarking__control_icons--collection">
                                <span><a title="Add to Collection" data-view="modalAjax"
                                        href="https://refaccionesvaldez.com.mx/">
                                        <span class="item-bookmarking__control--label">Add to
                                            Collection</span></a>
                                </span>

                            </li>
                        </ul>
                    </div>


                    <div class="box--no-padding" bis_skin_checked="1">
                        <div class="item-preview live-preview-btn--blue -preview-live" bis_skin_checked="1">



                            <a target="_blank" href="https://refaccionesvaldez.pages.dev/"
                                rel="noopener noreferrer"><img src="img/banner.jpg"
                                    alt="Login IPOTOTO link alternatif toto macau 4d 2026"
                                    width="500" height="500" srcset="img/banner.jpg 1x"
                                    sizes="(min-width: 1024px) 590px, (min-width: 1px) 100vw, 600px"></a>
                            <div class="js- item-preview-image__gallery"
                                data-title="IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal! - WooCommerce eCommerce Screenshots Gallery"
                                data-url="marketica-marketplace-wordpress-theme/screenshots/modal/8988002"
                                bis_skin_checked="1">
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/00-marketica-preview-sale37.jpg">MARKETICA_PREVIEW/00-marketica-preview-sale37.jpg</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/01_marketica2_homepage.png">MARKETICA_PREVIEW/01_marketica2_homepage.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/02_marketica2_shop_page.png">MARKETICA_PREVIEW/02_marketica2_shop_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/03_marketica2_single_product_page.png">MARKETICA_PREVIEW/03_marketica2_single_product_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/04_marketica2_cart_page.png">MARKETICA_PREVIEW/04_marketica2_cart_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/05_marketica2_checkout_page.png">MARKETICA_PREVIEW/05_marketica2_checkout_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/06_marketica2_myaccount_login_page.png">MARKETICA_PREVIEW/06_marketica2_myaccount_login_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/07_marketica2_plan_and_pricing_page.png">MARKETICA_PREVIEW/07_marketica2_plan_and_pricing_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/08_marketica2_team_members_page.png">MARKETICA_PREVIEW/08_marketica2_team_members_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/09_marketica2_contact_page_template.png">MARKETICA_PREVIEW/09_marketica2_contact_page_template.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/10_marketica2_blog_page.png">MARKETICA_PREVIEW/10_marketica2_blog_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/11_marketica2_blog_post_formats.png">MARKETICA_PREVIEW/11_marketica2_blog_post_formats.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/12_marketica2_single_product_page.png">MARKETICA_PREVIEW/12_marketica2_single_product_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/13_marketica2_theme_customizer.png">MARKETICA_PREVIEW/13_marketica2_theme_customizer.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/14_marketica2_visualcomposer_templates.png">MARKETICA_PREVIEW/14_marketica2_visualcomposer_templates.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/15_marketica2_tablet_view.png">MARKETICA_PREVIEW/15_marketica2_tablet_view.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/16_marketica2_tablet_view_offcanvas_menu.png">MARKETICA_PREVIEW/16_marketica2_tablet_view_offcanvas_menu.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/17_marketica2_themeoptions_header.png">MARKETICA_PREVIEW/17_marketica2_themeoptions_header.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/18_marketica2_themeoptions_footer.png">MARKETICA_PREVIEW/18_marketica2_themeoptions_footer.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/19_marketica2_themeoptions_contact.png">MARKETICA_PREVIEW/19_marketica2_themeoptions_contact.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/20_marketica2_themeoptions_woocommerce.png">MARKETICA_PREVIEW/20_marketica2_themeoptions_woocommerce.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/21_marketica2_wcvendors_user_page.png">MARKETICA_PREVIEW/21_marketica2_wcvendors_user_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/22_marketica2_wcvendors_vendor_page.png">MARKETICA_PREVIEW/22_marketica2_wcvendors_vendor_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/23_marketica2_wcvendors_vendor_dashboard.png">MARKETICA_PREVIEW/23_marketica2_wcvendors_vendor_dashboard.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/24_marketica2_wcvendors_shop_settings.png">MARKETICA_PREVIEW/24_marketica2_wcvendors_shop_settings.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/25_marketica2_dokan_vendor_store_page.png">MARKETICA_PREVIEW/25_marketica2_dokan_vendor_store_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/26_marketica2_dokan_vendor_review_page.png">MARKETICA_PREVIEW/26_marketica2_dokan_vendor_review_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/27_marketica2_dokan_vendor_dashboard_page.png">MARKETICA_PREVIEW/27_marketica2_dokan_vendor_dashboard_page.png</a><a
                                    class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/28_marketica2_dokan_vendor_dashboard_products_page.png">MARKETICA_PREVIEW/28_marketica2_dokan_vendor_dashboard_products_page.png</a>
                                <a class="is-hidden"
                                    href="https://s3.envato.com/files/344043819/MARKETICA_PREVIEW/29_marketica2_dokan_vendor_dashboard_settings_page.png">MARKETICA_PREVIEW/29_marketica2_dokan_vendor_dashboard_settings_page.png</a>
                            </div>

                            <div class="item-preview__actions" bis_skin_checked="1">
                                <div id="fullscreen" class="item-preview__preview-buttons" bis_skin_checked="1">

                                    <a href="https://refaccionesvaldez.pages.dev/" role="button"
                                        class="btn-icon live-preview" target="_blank" rel="noopener nofollow">LOGIN
                                    </a>

                                    <a data-view="screenshotGallery" href="https://refaccionesvaldez.pages.dev/"
                                        role="button" class="btn-icon screenshots" target="_blank" rel="noopener">
                                        DAFTAR
                                    </a>

                                </div>
                            </div>


                        </div>
                    </div>

                    <div data-view="toggleItemDescription" bis_skin_checked="1">
                        <div class="js-item-togglable-content has-toggle" bis_skin_checked="1">

                            <div class="js-item-description-toggle item-description-toggle" bis_skin_checked="1">
                                <a class="item-description-toggle__link" href="https://refaccionesvaldez.com.mx/">
                                    <span>Show More <i class="e-icon -icon-chevron-down"></i></span>
                                    <span class="item-description-toggle__less">Show Less <i
                                            class="e-icon -icon-chevron-down -rotate-180"></i></span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <section data-view="recommendedItems"
                        data-url="/item/marketica-marketplace-wordpress-theme/8988002/recommended_items"
                        id="recommended_items">
                        <div class="author-recommended-collection" bis_skin_checked="1">

                            <ul class="author-recommended-collection__list"
                                data-analytics-view-payload="{&quot;eventName&quot;:&quot;view_item_list&quot;,&quot;eventType&quot;:&quot;user&quot;,&quot;ecommerce&quot;:{&quot;currency&quot;:&quot;USD&quot;,&quot;item_list_name&quot;:&quot;Author Recommended tokopress&quot;,&quot;items&quot;:[{&quot;affiliation&quot;:&quot;themeforest&quot;,&quot;item_id&quot;:26116208,&quot;item_name&quot;:&quot;Retrave | Travel \u0026 Tour Agency Elementor Template Kit&quot;,&quot;item_brand&quot;:&quot;tokopress&quot;,&quot;item_category&quot;:&quot;template-kits&quot;,&quot;item_category2&quot;:&quot;elementor&quot;,&quot;item_category3&quot;:&quot;travel-accomodation&quot;,&quot;price&quot;:&quot;24&quot;,&quot;quantity&quot;:1,&quot;index&quot;:1},{&quot;affiliation&quot;:&quot;themeforest&quot;,&quot;item_id&quot;:26126773,&quot;item_name&quot;:&quot;Coursly | Education \u0026 Offline Course Elementor Template Kit&quot;,&quot;item_brand&quot;:&quot;tokopress&quot;,&quot;item_category&quot;:&quot;template-kits&quot;,&quot;item_category2&quot;:&quot;elementor&quot;,&quot;item_category3&quot;:&quot;education&quot;,&quot;price&quot;:&quot;24&quot;,&quot;quantity&quot;:1,&quot;index&quot;:2},{&quot;affiliation&quot;:&quot;themeforest&quot;,&quot;item_id&quot;:26416085,&quot;item_name&quot;:&quot;Sweeding | Wedding Event Invitation Elementor Template Kit&quot;,&quot;item_brand&quot;:&quot;tokopress&quot;,&quot;item_category&quot;:&quot;template-kits&quot;,&quot;item_category2&quot;:&quot;elementor&quot;,&quot;item_category3&quot;:&quot;weddings&quot;,&quot;price&quot;:&quot;24&quot;,&quot;quantity&quot;:1,&quot;index&quot;:3}]},&quot;item_list_id&quot;:8435762}">




                            </ul>
                        </div>
                        <div bis_skin_checked="1">

                        </div>







                        <div data-view="itemPageScrollEvents" bis_skin_checked="1"></div>
                    </section>
                </div>

                <div class="sidebar-l sidebar-right" bis_skin_checked="1">


                    <div class="pricebox-container" bis_skin_checked="1">
                        <div class="purchase-panel" bis_skin_checked="1">
                            <div id="purchase-form" class="purchase-form" bis_skin_checked="1">
                                <form data-view="purchaseForm" data-analytics-has-custom-click="true"
                                    data-analytics-click-payload="{&quot;eventName&quot;:&quot;add_to_cart&quot;,&quot;eventType&quot;:&quot;user&quot;,&quot;quantityUpdate&quot;:false,&quot;ecommerce&quot;:{&quot;currency&quot;:&quot;USD&quot;,&quot;value&quot;:37.0,&quot;items&quot;:[{&quot;affiliation&quot;:&quot;themeforest&quot;,&quot;item_id&quot;:8988002,&quot;item_name&quot;:&quot;IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!&quot;,&quot;item_brand&quot;:&quot;tokopress&quot;,&quot;item_category&quot;:&quot;wordpress&quot;,&quot;item_category2&quot;:&quot;ecommerce&quot;,&quot;item_category3&quot;:&quot;woocommerce&quot;,&quot;price&quot;:&quot;37&quot;,&quot;quantity&quot;:1}]}}"
                                    action="https://refaccionesvaldez.com.mx/" accept-charset="UTF-8" method="post">
                                    <input type="hidden" name="authenticity_token"
                                        value="o7V7LGbBjnF9HgzqsCOek0VUbYNaqFcrL72zjeu3cGTv2_7pn5UklFm7XFtDaDCfkbbeD4zdIzwPzjrUhXtbHQ"
                                        autocomplete="off">
                                    <div bis_skin_checked="1">
                                        <div data-view="itemVariantSelector" data-id="8988002"
                                            data-cookiebot-enabled="true" bis_skin_checked="1">
                                            <div class="purchase-form__selection" bis_skin_checked="1">
                                                <span class="purchase-form__license-type">
                                                    <span data-view="flyout" class="flyout">
                                                        <span
                                                            class="js-license-selector__chosen-license purchase-form__license-dropdown">Regular
                                                            License</span>
                                                        <div class="js-flyout__body flyout__body -padding-side-removed"
                                                            bis_skin_checked="1">
                                                            <span class="js-flyout__triangle flyout__triangle"></span>
                                                            <div class="license-selector" data-view="licenseSelector"
                                                                bis_skin_checked="1">
                                                                <div class="js-license-selector__item license-selector__item"
                                                                    data-license="regular" data-name="Regular License"
                                                                    bis_skin_checked="1">

                                                                    <div class="license-selector__license-type"
                                                                        bis_skin_checked="1">
                                                                        <span class="t-heading -size-xxs">Regular
                                                                            License</span>
                                                                        <span
                                                                            class="js-license-selector__selected-label e-text-label -color-green -size-s "
                                                                            data-license="regular">Selected</span>
                                                                    </div>
                                                                    <div class="license-selector__price"
                                                                        bis_skin_checked="1"><span
                                                                            class="t-heading -size-m h-m0">
                                                                            <b class="t-currency"><span
                                                                                    class="">$88</span></b>
                                                                        </span>
                                                                    </div>
                                                                    <div class="license-selector__description"
                                                                        bis_skin_checked="1">
                                                                        <p class="t-body -size-m h-m0">
                                                                            IPOTOTO merupakan media situs Toto Macau
                                                                            yang mudah dimainkan dan anti rungkad,
                                                                            dipadukan dengan BANDAR TOTO MACAU depo 5K bonus
                                                                            member baru serta beragam permainan menarik
                                                                            yang bisa dinikmati setiap hari.</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="flyout__link" bis_skin_checked="1">
                                                                <p class="t-body -size-m h-m0">
                                                                    <a class="t-link -decoration-reversed"
                                                                        target="_blank"
                                                                        href="https://refaccionesvaldez.com.mx//licenses/standard">View
                                                                        license details</a>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </span>


                                                    <input type="hidden" name="license" id="license" value="regular"
                                                        class="js-purchase-default-license" data-license="regular"
                                                        autocomplete="off">
                                                </span>

                                                <div class="js-purchase-heading purchase-form__price t-heading -size-xxl"
                                                    bis_skin_checked="1">
                                                    <b class="t-currency"><span class="js-purchase-price">$5</span></b>
                                                </div>
                                            </div>


                                            <div class="purchase-form__license js-purchase-license is-active"
                                                data-license="regular" bis_skin_checked="1">
                                                <price class="js-purchase-license-prices" data-price-prepaid="$37"
                                                    data-license="regular" data-price-prepaid-upgrade="$46.38"
                                                    data-support-upgrade-price="$9.38" data-support-upgrade-saving="$12"
                                                    data-support-extension-price="$15.63"
                                                    data-support-extension-saving="$6.25"
                                                    data-support-renewal-price="$5.00">
                                                </price>
                                            </div>

                                            <div class="purchase-form__support" bis_skin_checked="1">
                                                <ul class="t-icon-list -font-size-s -icon-size-s -offset-flush">
                                                    <li class="t-icon-list__item -icon-ok">
                                                        <span class="is-visually-hidden">Included:</span> IPOTOTO
                                                    </li>
                                                    <li class="t-icon-list__item -icon-ok">
                                                        <span class="is-visually-hidden">Included:</span> Situs slot
                                                        terpercaya 2025
                                                    </li>
                                                    <li class="t-icon-list__item -icon-ok">
                                                        <span class="is-visually-hidden">Included:</span>Slot online
                                                        gampang menang<span class="purchase-form__author-name"></span>
                                                        <a class="t-link -decoration-reversed js-support__inclusion-link"
                                                            data-view="modalAjax"
                                                            href="/item_support/what_is_item_support/8988002">
                                                            <svg width="12px" height="13px" viewBox="0 0 12 13" class=""
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                aria-labelledby="title" role="img">
                                                                <title>More Info</title>
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M0 6.5a6 6 0 1 0 12 0 6 6 0 0 0-12 0zm7.739-3.17a.849.849 0 01-.307.664.949.949 0 0 1-.716.273c-.273 0-.529-.102-.716-.272a.906.906 0 0 1-.307-.665c0-.256.102-.512.307-.682.187-.17.443-.273.716-.273.273 0 .528.102.716.273a.908.908 0 0 1 .307.682zm-.103 6.34-.119.46c-.34.137-.613.24-.818.307a2.5 2.5 0 0 1-.716.103c-.409 0-.733-.103-.954-.307a.953.953 0 0 1-.341-.767c0-.12 0-.256.017-.375.017-.12.05-.273.085-.426l.426-1.517a7.14 7.14 0 0 1 .103-.41c.017-.119.034-.238.034-.357a.582.582 0 0 0-.12-.41c-.085-.068-.238-.119-.46-.119-.12 0-.239.017-.34.051-.069.03-.132.047-.189.064-.042.012-.082.024-.119.038l.12-.46c.234-.102.468-.18.69-.253l.11-.037c.24-.085.478-.119.734-.119.409 0 .733.102.954.307.222.187.341.477.341.784 0 .068 0 .187-.017.34v.003a2.173 2.173 0 0 1-.085.458l-.427 1.534-.102.41v.002c-.017.119-.034.237-.034.356 0 .204.051.34.136.409.137.085.307.119.46.102a1.3 1.3 0 0 0 .359-.051c.085-.051.17-.085.272-.12z"
                                                                    fill="#ff9204"></path>

                                                            </svg>
                                                        </a>
                                                    </li>
                                                </ul>

                                                <div class="purchase-form__upgrade purchase-form__upgrade--before-after-price"
                                                    bis_skin_checked="1">
                                                    <div class="purchase-form__upgrade-checkbox purchase-form__upgrade-checkbox--before-after-price"
                                                        bis_skin_checked="1">
                                                        <input type="hidden" name="support" id="support_default"
                                                            value="bundle_6month" class="js-support__default"
                                                            autocomplete="off">
                                                        <input type="checkbox" name="support" id="support"
                                                            value="bundle_12month" class="js-support__option">
                                                    </div>
                                                    <div class="purchase-form__upgrade-info" bis_skin_checked="1">
                                                        <label
                                                            class="purchase-form__label purchase-form__label--before-after-price"
                                                            for="support">
                                                            Extend support to 12 months
                                                            <span
                                                                class="purchase-form__price purchase-form__price--before-after-price t-heading -size-xs h-pull-right">
                                                                <span
                                                                    class="js-renewal__price t-currency purchase-form__renewal-price purchase-form__renewal-price--strikethrough">$100.00</span>

                                                                <b class="t-currency"><span
                                                                        class="js-support__price">$5.00</span>
                                                                </b>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <p class="t-body -size-m"><i>This item is licensed 100% GPL.</i>
                                        </p>
                                        <p>IPOTOTO hadir sebagai akses terpercaya untuk permainan BANDAR TOTO MACAU 4D dan
                                            togel Macau dengan lisensi resmi tahun 2026. Platform ini dikenal luas
                                            karena konsistensi sistem, keakuratan data pasaran, serta dukungan layanan
                                            yang memudahkan pemain dalam memantau hasil dan melakukan transaksi dengan
                                            aman. Tidak heran jika IPOTOTO menjadi salah satu rujukan utama bagi
                                            pemain yang mengutamakan stabilitas dan kejelasan sistem permainan.</p>
                                        <div class="purchase-form__cta-buttons" bis_skin_checked="1">
                                            <div class="purchase-form__button" bis_skin_checked="1">
                                            </div>

                                        </div>
                                        <div class="purchase-form__us-dollars-notice-container" bis_skin_checked="1">
                                            <p class="purchase-form__us-dollars-notice"><i></i>
                                            </p>
                                        </div>

                                    </div>
                                </form>
                            </div>

                        </div>

                    </div>

                </div>
                <script nonce="TFNQUvYHwdi8uHoMheRs/Q==">
                    //<![CDATA[
                    // HACK: Google Chrome always scroll the previous page's position on hitting Back button
                    // This causes issue with responsive version in which unexpanded item description obscure
                    // the scroll position and Chrome will jump to the outer border of bottom
                    window.addEventListener('unload', function (e) {
                        window.scrollTo(0, 0);
                    });//]]>
                </script>
            </div>

        </div>
    </div>

    <style>



    </style>

    <!-- wp:heading -->
    <!-- ====== TESTIMONI SLIDER IPOTOTO ====== -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

    <center>
        <h2 style="font-weight: bold;">Testimoni Member IPOTOTO</h2>
    </center>

    <!-- Slider Wrapper -->
    <div class="testimoni-wrapper swiper swiper-initialized swiper-horizontal swiper-android swiper-backface-hidden">
        <div class="swiper-wrapper" id="swiper-wrapper-aa16f61081dd721075" aria-live="off"
            style="cursor: grab; transition-duration: 0ms; transform: translate3d(-402px, 0px, 0px); transition-delay: 0ms;">
            <!-- Slide 1 -->
            <div class="swiper-slide swiper-slide-prev" role="group" aria-label="1 / 3" data-swiper-slide-index="0"
                style="width: 382px; margin-right: 20px;">
                <blockquote>
                    <p style="color: white;">
                        Saya pilih IPOTOTO karena aksesnya jelas dan data togel Macau-nya selalu update. Main slot
                        4D juga lebih tenang karena sistemnya stabil dan transparan.
                    </p>
                    <cite>Arman, Tangerang</cite>
                </blockquote>
            </div>

            <div class="swiper-slide swiper-slide-active" role="group" aria-label="2 / 3" data-swiper-slide-index="1"
                style="width: 382px; margin-right: 20px;">
                <blockquote>
                    <p style="color: white;">
                        Dari sekian situs yang saya coba, IPOTOTO paling rapi soal pasaran dan hasil. Cocok buat
                        yang serius main togel tanpa ribet.
                    </p>
                    <cite>Lina, Pontianak</cite>
                </blockquote>
            </div>

            <div class="swiper-slide swiper-slide-next" role="group" aria-label="3 / 3" data-swiper-slide-index="2"
                style="width: 382px; margin-right: 20px;">
                <blockquote>
                    <p style="color: white;">
                        Login cepat, hasil Macau akurat, dan tampilan gampang dipahami. IPOTOTO terasa seperti
                        platform resmi, bukan sekadar situs biasa.
                    </p>
                    <cite>Robby, Manado</cite>
                </blockquote>
            </div>
        </div>
        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
    </div>


    <!-- Pagination & Navigation -->
    <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal">
        <span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span
            class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button"
            aria-label="Go to slide 2" aria-current="true"></span><span class="swiper-pagination-bullet" tabindex="0"
            role="button" aria-label="Go to slide 3"></span></div>


    <!-- ===== CSS STYLING ===== -->
    <style>
        /* ===== Wrapper Utama ===== */
        h2 {
            margin-top: 100px;
        }

        .testimoni-wrapper {
            max-width: 800px;
            margin: 80px auto 60px;
            /* tambahin margin-top biar stabil di semua layar */
            padding: 20px;
            box-sizing: border-box;
            position: relative;
            z-index: 1;
        }

        /* ===== Swiper Slide Styling ===== */
        .swiper-slide blockquote {
            background: #000000;
            color: #fff;
            padding: 25px;
            margin: 0 10px;
            border-left: 5px solid #ff0000ff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            min-height: 180px;
            /* tambahkan tinggi minimum agar stabil */
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .swiper-slide blockquote p {
            margin: 0;
            font-size: 15.5px;
            line-height: 1.6;
        }

        .swiper-slideblockquote cite {
            display: block;
            margin-top: 12px;
            font-style: normal;
            font-weight: bold;
            color: #ff0000ff;
        }

        /* ===== Pagination & Nav Buttons ===== */
        .swiper-pagination-bullet {
            background: #ff0000ff;
            opacity: 0.7;
        }

        .swiper-pagination-bullet-active {
            opacity: 1;
        }

        .swiper-button-prev,
        .swiper-button-next {
            color: #ff0000ff;
            transition: 0.3s;
        }

        .swiper-button-prev:hover,
        .swiper-button-next:hover {
            color: #fff;
        }

        /* ===== Responsif untuk HP ===== */
        @media (max-width: 768px) {
            .testimoni-wrapper {
                margin: 70px auto 50px;
                /* jaga jarak tetap stabil */
                padding: 20px 15px;
            }

            .swiper-slide blockquote {
                padding: 20px;
                min-height: 200px;
                /* fix tinggi agar gak naik-turun di HP */
            }

            .swiper-slide blockquote p {
                font-size: 14.5px;
            }
        }

        @media (max-width: 768px) {
            .purchase-form__selection {
                position: relative;
                z-index: 5;
                /* biar gak ketimpa testimoni */
                margin-bottom: 120px;
                /* kasih jarak dari menu bawah */
            }

            .purchase-form__us-dollars-notice-container {
                padding-bottom: 20px;
                /* tambahan spacing */
            }

            .testimonial-slider,
            .testimoni-wrapper {
                z-index: 3;
                /* lebih rendah biar form-nya di atas */
            }

            .bottom-nav,
            .mobile-menu {
                position: fixed;
                bottom: 0;
                width: 100%;
                z-index: 9999;
                /* tetap paling atas untuk menu bawah */
            }
        }
    </style>

    <!-- ===== JS SWIPER CONFIG ===== -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script>
        const swiper = new Swiper('.swiper', {
            loop: true,
            autoplay: {
                delay: 3000, // 3 detik per slide
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            slidesPerView: 1,
            spaceBetween: 20,
            grabCursor: true,
        });
    </script>
    <!-- ====== END TESTIMONI SLIDER ====== -->








    <style>
        .IPOTOTO-fixed-footer {
            display: flex;
            justify-content: space-around;
            position: fixed;
            background: linear-gradient(to bottom, rgb(0, 0, 0) 0%, rgb(0, 0, 0) 50%, rgb(0, 0, 0) 100%);
            box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.5), 7px 7px 20px 0px rgba(0, 0, 0, 0.1), 4px 4px 5px 0px rgba(0, 0, 0, 0.1);
            outline: none;
            padding: 5px 0;
            box-shadow: 0 0 2px 2px rgb(0, 0, 0);
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 99;
            border-radius: 40px 40px 0px 0px;
            border-style: dashed;

        }

        .IPOTOTO-fixed-footer a {
            flex-basis: calc((100% - 15px*6)/ 5);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #ff0000ff;
            max-width: 75px;
            font-size: 12px;
            font-family: Ubuntu, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
        }

        .IPOTOTO-fixed-footer a:hover {
            font-weight: bold;
        }

        .IPOTOTO-fixed-footer .center {
            transform: scale(1.5) translateY(-5px);
            background: center no-repeat;
            background-size: contain;
            background-color: inherit;
            border-radius: 50%;
        }

        .agolxtotoenolx-fixed-footer img {
            max-width: 20px;
            margin-bottom: 0;
            max-height: 20px;
        }
    </style>
    <div class="IPOTOTO-fixed-footer">
        <a href="https://refaccionesvaldez.pages.dev/" rel="nofollow noopener" target="_blank">
            <img layout="intrinsic" height="20px" width="20px" src="img/promo.png"
                alt="BONUS IPOTOTO">
            Promo
        </a>
        <a href="https://refaccionesvaldez.pages.dev/" rel="nofollow noopener" target="_blank">
            <img layout="intrinsic" height="20px" width="20px" src="img/login.png"
                alt="LOGIN IPOTOTO">
            Login
        </a>
        <a href="https://refaccionesvaldez.pages.dev/" rel="nofollow noopener" target="_blank" class="tada">
            <img layout="intrinsic" height="20px" width="20px" src="img/daftar.png"
                alt="DAFTAR IPOTOTO">
            Daftar
        </a>
        <a href="https://refaccionesvaldez.pages.dev/" rel="nofollow noopener" target="_blank">
            <img layout="intrinsic" height="20px" width="20px" src="img/wa.gif"
                alt="WHATSAPP IPOTOTO">
            Whatsapp
        </a>
        <a href="https://refaccionesvaldez.pages.dev/" rel="nofollow noopener" target="_blank"
            class="js_live_chat_link live-chat-link">
            <img class="live-chat-icon" layout="intrinsic" height="20px" width="20px"
                src="img/lc.png" alt="LIVE CHAT IPOTOTO">
            Live Chat
        </a>
    </div>
    <style>
        #artikel-IPOTOTO {
            background-color: #ffffff;
            padding: 50px 20px;
            font-family: 'Arial', sans-serif;
            color: #000000;
            margin-top: -50px;
        }

        #artikel-IPOTOTO .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            /* Tambah padding biar nggak mepet border */
            border: 2px solid #000000;
            /* Border abu-abu lembut */
            border-radius: 10px;
            /* Efek melengkung */
        }

        #artikel-IPOTOTO h2 {
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 20px;
            color: #59d108;
            text-align: center;
        }

        #artikel-IPOTOTO h3 {
            font-size: 1.4em;
            margin-top: 30px;
            margin-bottom: 15px;
            color: #000000;
        }

        #artikel-IPOTOTO p {
            line-height: 1.7;
            margin-bottom: 15px;
            font-size: 1em;
        }

        #artikel-IPOTOTO ul,
        #artikel-IPOTOTO ol {
            margin-left: 20px;
            margin-bottom: 20px;
        }

        #artikel-IPOTOTO li {
            margin-bottom: 10px;
            font-size: 1em;
        }

        #artikel-IPOTOTO li::marker {
            color: green;
            /* tanda checklist hijau di list */
        }

        #artikel-IPOTOTO .cta {
            margin-top: 30px;
            padding: 10px 15px;
            background-color: #bb0606ff;
            border-radius: 8px;
            font-weight: bold;
            font-size: 14px;
            text-align: center;
            color: #111;
            display: inline-block;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        #artikel-IPOTOTO .cta:hover {
            background-color: #c01010ff;
            transform: scale(1.03);
            cursor: pointer;
        }

        /* Style untuk tren-toto-togel (biar konsisten dengan border) */
        #tren-toto-togel {
            margin-top: 30px;
            /* Jarak dari section sebelumnya */
        }

        #tren-toto-togel table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }

        #tren-toto-togel th,
        #tren-toto-togel td {
            border: 1px solid #000000;
            padding: 8px;
            text-align: left;
        }

        #tren-toto-togel th {
            background-color: #000000;
            color: #ffffff;
            /* Teks putih biar kontras */
        }

        @media (max-width: 768px) {
            #artikel-IPOTOTO {
                padding: 30px 15px;
            }

            #artikel-IPOTOTO .container {
                padding: 15px;
                /* Kurangin padding di mobile */
            }

            #artikel-IPOTOTO h2 {
                font-size: 1.6em;
            }

            #artikel-IPOTOTOh3 {
                font-size: 1.2em;
            }
        }
    </style>
    <section id="artikel-IPOTOTO">
        <div class="container">
            <h1>IPOTOTO: Bandar TOTO Macau Tempat Main Togel 4D Hadiah Besar, Raih Hoki Maksimal!
            </h1>

            <p>
                IPOTOTO merupakan platform yang menyediakan akses resmi permainan BANDAR TOTO MACAU 4D dan togel Macau
                dengan lisensi resmi tahun 2026. Kehadirannya menjadi solusi bagi pemain yang mencari sistem permainan
                stabil, data pasaran valid, serta layanan yang terstruktur dengan baik.
            </p>

            <h2>Platform Resmi dengan Sistem Terverifikasi</h2>
            <p>
                Seluruh sistem di IPOTOTO dirancang untuk memberikan transparansi penuh. Data hasil togel Macau
                disajikan secara real-time, sementara permainan slot 4D berjalan di server yang konsisten tanpa gangguan
                teknis. Hal ini menjadikan IPOTOTO dipercaya sebagai salah satu bandar toto yang mengedepankan
                kejelasan sistem.
            </p>

            <h2>Fokus pada BANDAR TOTO MACAU 4D dan Pasaran Macau</h2>
            <p>
                IPOTOTO memusatkan layanan pada permainan BANDAR TOTO MACAU 4D serta pasaran togel Macau yang populer.
                Setiap pasaran dilengkapi jadwal jelas, rekapan hasil, serta tampilan data yang mudah dipahami oleh
                pemain pemula maupun berpengalaman.
            </p>

            <h2>Keamanan dan Kenyamanan Akses</h2>
            <p>
                Dengan lisensi resmi yang diperbarui untuk tahun 2026, IPOTOTO menerapkan sistem keamanan modern
                untuk menjaga aktivitas pengguna. Proses login, pemantauan hasil, hingga transaksi dirancang agar
                berjalan lancar tanpa hambatan.
            </p>

            <h2>Alasan IPOTOTO Banyak Direkomendasikan</h2>
            <ul>
                <li>Akses resmi BANDAR TOTO MACAU 4D dan togel Macau</li>
                <li>Lisensi toto valid dan terverifikasi</li>
                <li>Data pasaran akurat dan update cepat</li>
                <li>Sistem stabil dan mudah digunakan</li>
                <li>Dukungan layanan aktif dan responsif</li>
            </ul>

            <footer>
                <div style="display:none" data-nosnippet="true">
                <p> | <a href="https://refaccionesvaldez.com.mx/">RATU TOGEL</a></p>
                </div>
            </footer>

<div id="popup" class="popup-overlay">
        <div class="popup-box">
            <img src="img/pop-up.jpg" alt="IPOTOTO">

            <div class="popup-content">
                <h2> TOTO MACAU </h2>
                <a href="https://refaccionesvaldez.pages.dev/" target="_blank">DAFTAR DISINI</a>
            </div>
        </div>
    </div>
</body>

        </div>
    </section>
</body>

</html>